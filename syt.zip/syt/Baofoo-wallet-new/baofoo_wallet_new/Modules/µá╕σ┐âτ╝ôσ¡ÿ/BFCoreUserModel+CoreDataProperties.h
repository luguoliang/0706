//
//  BFCoreUserModel+CoreDataProperties.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/24.
//  Copyright © 2016年 BF. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "BFCoreUserModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface BFCoreUserModel (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *access_token;
@property (nullable, nonatomic, retain) NSData *accountImage;
@property (nullable, nonatomic, retain) NSString *accountName;
@property (nullable, nonatomic, retain) NSString *authFlag;
@property (nullable, nonatomic, retain) NSString *balanceMoney;
@property (nullable, nonatomic, retain) NSString *bankCount;
@property (nullable, nonatomic, retain) NSString *code;
@property (nullable, nonatomic, retain) NSString *curAuthFlag;
@property (nullable, nonatomic, retain) NSString *gesturePsw;
@property (nullable, nonatomic, retain) NSString *idCard;
@property (nullable, nonatomic, retain) NSString *isHasOldPayPwd;
@property (nullable, nonatomic, retain) NSString *isSetLoginPwd;
@property (nullable, nonatomic, retain) NSString *isSetPayPwd;
@property (nullable, nonatomic, retain) NSString *isSetSafeQues;
@property (nullable, nonatomic, retain) NSNumber *isUsedGesturePsw;
@property (nullable, nonatomic, retain) NSNumber *isUsedTouchIDForLogin;
@property (nullable, nonatomic, retain) NSString *memberId;
@property (nullable, nonatomic, retain) NSString *memberName;
@property (nullable, nonatomic, retain) NSString *message;
@property (nullable, nonatomic, retain) NSString *mobile;
@property (nullable, nonatomic, retain) NSString *msgcode;
@property (nullable, nonatomic, retain) NSString *obj;
@property (nullable, nonatomic, retain) NSString *payPwFormat;
@property (nullable, nonatomic, retain) NSString *remark;
@property (nullable, nonatomic, retain) NSString *safeQuestion;
@property (nullable, nonatomic, retain) NSString *server_version;
@property (nullable, nonatomic, retain) NSString *success;
@property (nullable, nonatomic, retain) NSString *succMoney;
@property (nullable, nonatomic, retain) NSString *time;
@property (nullable, nonatomic, retain) NSString *uuid;
@property (nullable, nonatomic, retain) NSString *verifyFirst;
@property (nullable, nonatomic, retain) NSNumber *isLoginSuccess;

@end

NS_ASSUME_NONNULL_END

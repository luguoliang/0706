//
//  BFCoreUserModel.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFCoreUserModel.h"
#import "BFCoreDataModelop.h"

@implementation BFCoreUserModel

+ (instancetype)sharedInstance{
    static BFCoreUserModel *_sharedInstance = nil;
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        BFCoreDataModelop *m = [[BFCoreDataModelop alloc]init];
//        _sharedInstance = [m getCurrentBFuserModel];
//    });
    if (!_sharedInstance) {
        BFCoreDataModelop *m = [[BFCoreDataModelop alloc]init];
        _sharedInstance = [m getCurrentBFuserModel];
    }
    return _sharedInstance;
}
@end

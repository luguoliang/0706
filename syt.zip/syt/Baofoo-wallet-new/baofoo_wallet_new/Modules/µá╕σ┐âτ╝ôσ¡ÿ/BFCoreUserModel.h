//
//  BFCoreUserModel.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface BFCoreUserModel : NSManagedObject
+ (instancetype)sharedInstance;
@end

NS_ASSUME_NONNULL_END


#import "BFCoreUserModel+CoreDataProperties.h"

//
//  BFCoreDataModelop.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFCoreDataModelop.h"
#import <UIKit/UIKit.h>
#import "BFCoreUserModel+CoreDataProperties.h"
@class NSManagedObjectContext;

@class BFCoreUserModel;

@interface BFCoreDataModelop()
{
    NSFetchRequest*_fetchRequest;
    BFCoreUserModel*_user;
}
@end

@implementation BFCoreDataModelop

+(void)test{
    
}
+(BFCoreDataModelop*)sharedManager
{
    static BFCoreDataModelop*sharedSingleton = nil;
    static dispatch_once_t predicate;
    
    dispatch_once(&predicate, ^{
        
        sharedSingleton = [[super allocWithZone:NULL] init];
        
    });
    return sharedSingleton;
}

+(instancetype)allocWithZone:(struct _NSZone *)zone
{
    return [self sharedManager];
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        id delegate = [[UIApplication sharedApplication] delegate];
        self.managedObjectContext = [delegate managedObjectContext];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(_appDidReceiveMemoryWarningNotification)
                                                     name:UIApplicationDidReceiveMemoryWarningNotification object:nil];
    }
    return self;
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIApplicationDidReceiveMemoryWarningNotification object:nil];
}

-(NSArray*)fetchRequestWithPredicate:(NSPredicate*)predicate{
    NSFetchRequest*fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"BFCoreUserModel"];
    if (predicate.predicateFormat) {
        fetchRequest.predicate = predicate;
    }
    NSError*error = nil;
    NSArray*array = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    if (error) {
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    return array;
}
-(NSDictionary*)traverseDictionaryElements:(NSDictionary*)dict{
    NSMutableDictionary*temDict  = [NSMutableDictionary dictionaryWithDictionary:dict];
    NSArray*array = [temDict allKeys];
    for (NSString*key in array) {
        id nu  = temDict[key];
        if ([nu isKindOfClass:[NSNumber class]]) {
           temDict[key] = [nu stringValue];
        }
        if ([nu isKindOfClass:[NSDictionary class]]) {
            temDict[key] = @"obj";
        }
    }
    NSLog(@"temDict = %@",temDict);
    return temDict.copy;
 }

-(void)insterUserinitWithDict:(NSDictionary *)dict{
    NSString*menberID = dict[@"memberId"];
    [[NSUserDefaults standardUserDefaults] setObject:menberID forKey:@"memberId"];
    NSMutableDictionary*temMuDict = [self traverseDictionaryElements:dict].mutableCopy;
    NSTimeInterval time = [[NSDate date] timeIntervalSince1970];
    NSString *timeStr = [[NSNumber numberWithDouble:time] stringValue];
    [temMuDict setObject:timeStr forKey:@"time"];
    NSDictionary*temDict = temMuDict.copy;
    NSPredicate*predicate = [NSPredicate predicateWithFormat:@"memberId LIKE %@",temDict[@"memberId"]];
    NSArray*array = [self fetchRequestWithPredicate:predicate];
    BFCoreUserModel*user;
    if (array.count) {
        user = [array lastObject];
    }
    else{
        if ([self whetherNumberExceedsMaximumLimit]) {
            
            [self AlgorithmExecutionLRU];
        }
        user = [NSEntityDescription insertNewObjectForEntityForName:
                @"BFCoreUserModel" inManagedObjectContext:
                self.managedObjectContext];
    }
    [self ententities:user WithDict:temDict];
}

-(void)ententities:(BFCoreUserModel*)student WithDict:(NSDictionary*)dict{
    [student setValuesForKeysWithDictionary:dict];
    NSError*error;
    if (!([self.managedObjectContext save:&error])) {
        NSLog(@"DB update error %@, %@", error, [error userInfo]);
        abort();
    }
}

-(BOOL)whetherNumberExceedsMaximumLimit{
    NSLog(@"%lu",(unsigned long)_maximumLimit);
    if (!self.maximumLimit) {
        self.maximumLimit = 5;
    }
    if ([self getAllObjects].count >= self.maximumLimit) {
        return YES;
    }
    return NO;
}
-(void)AlgorithmExecutionLRU{
    double max = NSUIntegerMax;
    NSArray*array = [self getAllObjects];
    {
        for (BFCoreUserModel*user in array) {
            NSString*time = user.time;
            double td = [time doubleValue];
            if (td < max) {
                max = td;
            }}
    }{
        BFCoreUserModel*delUser;
        for (BFCoreUserModel*user in array) {
            if ([user.time isEqualToString:[[NSNumber numberWithDouble:max] stringValue]]) {
                delUser = user;
            }
        }
        [self.managedObjectContext deleteObject:delUser];
        if (!([self.managedObjectContext save:nil])) {
            NSLog(@"removeAllObjects error %s:",__func__);
        }
    }
}

-(NSString*)getCurrentBfuserMemberId{
    
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"memberId"];
}
-(BFCoreUserModel*)getCurrentBFuserModel{
    if (!([self getCurrentBfuserMemberId].length)) {
        return nil;
    }
    else{
    NSArray*array = [self fetchRequestWithPredicate:[NSPredicate predicateWithFormat:
                                                     @"memberId LIKE %@",
                                                     [self getCurrentBfuserMemberId]]];
    return [array lastObject];
    }
}

-(NSArray*)getAllBFuserName{
    NSArray*array = [self fetchRequestWithPredicate:nil];
    NSMutableArray*mutableArray = @[].mutableCopy;
    for (BFCoreUserModel*user in array) {
        [mutableArray addObject:user.accountName];
    }
    return mutableArray.copy;
}
-(NSArray*)getAllBFuserCooks{
    NSArray*array = [self fetchRequestWithPredicate:nil];
    NSMutableArray*mutableArray = @[].mutableCopy;
    for (BFCoreUserModel*user in array) {
        NSMutableDictionary*mutableDict = @{}.mutableCopy;
        
        [mutableDict setObject:user.accountName?user.accountName:@"" forKey:@"accountName"];
        [mutableDict setObject:user.memberId forKey:@"memberId"];
        [mutableDict setObject:user.access_token?user.access_token:@"" forKey:@"access_token"];
        if (user.accountImage) {
         [mutableDict setObject:[UIImage imageWithData:user.accountImage] forKey:@"accountImage"];
        }
        else{
            [mutableDict setObject:[UIImage imageNamed:@"face_nor"] forKey:@"accountImage"];
        }
        if ([user.memberId isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"memberId"]]) {
            [mutableArray insertObject:mutableDict atIndex:0];
        }
        else{
            [mutableArray addObject:mutableDict];
        }
    } 
    return mutableArray.copy;
}
-(void)delegateUserWithName:(NSString *)menmberId{
    NSArray*array = [self fetchRequestWithPredicate:[NSPredicate predicateWithFormat:@"memberId LIKE %@",menmberId]];
    [self.managedObjectContext deleteObject:[array lastObject]];
    if (!([self.managedObjectContext save:nil])) {
        NSLog(@"delegateUserWithName error:menmberId = %@",menmberId);
    }
}

-(NSArray*)getAllObjects{
    NSArray*array = [self fetchRequestWithPredicate:nil];
    return array;
}

-(void)removeAllObjects{
    NSArray*array = [self getAllObjects];
    for (BFCoreUserModel*user in array) {
        if (!([user.memberId isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"memberId"]])) {
            [self.managedObjectContext deleteObject:user];
        }
        if (!([self.managedObjectContext save:nil])) {
            NSLog(@"removeAllObjects error %s:",__func__);
        }
    }
}

- (void)_appDidReceiveMemoryWarningNotification {
    
    if (self.shouldRemoveAllObjectsOnMemoryWarning) {
        [self removeAllObjects];
    }
}

@end

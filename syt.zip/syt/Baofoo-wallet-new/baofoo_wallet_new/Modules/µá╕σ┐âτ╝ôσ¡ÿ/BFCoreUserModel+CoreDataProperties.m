//
//  BFCoreUserModel+CoreDataProperties.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/24.
//  Copyright © 2016年 BF. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "BFCoreUserModel+CoreDataProperties.h"

@implementation BFCoreUserModel (CoreDataProperties)

@dynamic access_token;
@dynamic accountImage;
@dynamic accountName;
@dynamic authFlag;
@dynamic balanceMoney;
@dynamic bankCount;
@dynamic code;
@dynamic curAuthFlag;
@dynamic gesturePsw;
@dynamic idCard;
@dynamic isHasOldPayPwd;
@dynamic isSetLoginPwd;
@dynamic isSetPayPwd;
@dynamic isSetSafeQues;
@dynamic isUsedGesturePsw;
@dynamic isUsedTouchIDForLogin;
@dynamic memberId;
@dynamic memberName;
@dynamic message;
@dynamic mobile;
@dynamic msgcode;
@dynamic obj;
@dynamic payPwFormat;
@dynamic remark;
@dynamic safeQuestion;
@dynamic server_version;
@dynamic success;
@dynamic succMoney;
@dynamic time;
@dynamic uuid;
@dynamic verifyFirst;
@dynamic isLoginSuccess;

@end

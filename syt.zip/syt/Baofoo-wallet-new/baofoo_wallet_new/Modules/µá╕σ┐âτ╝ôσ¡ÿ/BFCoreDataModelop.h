//
//  BFCoreDataModelop.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BFCoreUserModel.h"
@class NSManagedObjectContext;
@class BFCoreDataModelop;
@interface BFCoreDataModelop : NSObject
+(BFCoreDataModelop*)sharedManager;

+(void)test;
/**
 This property is used only during initialization do not halfway assignment.
 */
@property (nonatomic, strong) NSManagedObjectContext *managedObjectContext;
/**
 This function is the entry function. Incoming dictionary to initialize the model.
 */
-(void)insterUserinitWithDict:(NSDictionary *)dict;
/**
 Get the current model login account.call the function will return an instance of a type of User.
 */
-(BFCoreUserModel*)getCurrentBFuserModel;
/**
 Get all the account name database. It returns a array.
 */
-(NSArray*)getAllBFuserName;
/**
 Get all the account name,memberId,acc_token in  database. It returns an array containing the dictionary.
 */
-(NSArray*) getAllBFuserCooks;
/**
 Remove the database corresponding to the index model.
 */
-(void)delegateUserWithName:(NSString*)menmberId;

/**
 If `YES`, the cache will remove all objects when the app receives a memory warning Except current.
 The default value is `YES`.
 */
@property (assign) BOOL shouldRemoveAllObjectsOnMemoryWarning;
/**
 The maximumLimit total cost that the cache can hold before it starts evicting objects.
 
 @discussion The default value is NSUIntegerMax, which means 5.
 This is not a strict limit—if the cache goes over the limit, some objects in the
 cache could be evicted later in backgound thread.
 */
@property (assign) NSUInteger maximumLimit;

@end

//
//  BFGesturePwdViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/24.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFGesturePwdViewController.h"
#import "BFLockView.h"
#import "BFTouchIDTool.h"
#import "BFNavigationController.h"
#import "AppDelegate.h"
#import "BFReqAPI+Login.h"

@interface BFGesturePwdViewController ()
{
    BFLockView  *lockView;      //绘制视图
    NSInteger     unlockCount;   //解锁次数，默认4次
    UILabel      *errorMsgLabel; //错误信息描述
    UIView       *coverView;  //遮盖lockView视图
    UIView       *showView;//显示视图
}
@end

@implementation BFGesturePwdViewController


#pragma mark - 绘制事件集合

//解锁事件
- (void)unlockEvent{
    unlockCount = 4;
    
    __weak BFGesturePwdViewController *weakSelf = self;
    
    /** 验证 */
    lockView.verifyPwdBlock = ^(NSString *pwd){
        return [weakSelf checkPwd:pwd];
    };
}

//绘制手势事件
-(void)drawEvent{
    
    __weak BFGesturePwdViewController *weakSelf = self;
    
    /** 密码长度不够 */
    lockView.setPWSErrorLengthTooShortBlock = ^(NSUInteger currentCount){
        [weakSelf checkPasswordLength:currentCount];
    };
    
    /** 第一次输入密码：正确 */
    lockView.setPWFirstRightBlock = ^(){
        [weakSelf firstDrawSuccess];
    };
    
    /** 两次密码不一致 */
    lockView.setPWSErrorTwiceDiffBlock = ^(NSString *pwd1,NSString *pwdNow){
        [weakSelf drawFailure];
    };
    
    /** 再次输入密码一致 */
    lockView.setPWTwiceSameBlock = ^(NSString *pwd){
        [weakSelf drawSuccess:pwd];
    };
    
}

//检验密码长度
- (void)checkPasswordLength:(NSInteger)length{
    if (length < 4) {
        [lockView resetPwd];
        [self setErrormsg:@"至少连接4个点，请重新输入" color:UIColorRgb(255,45,85)];
        [self layerAnimation:errorMsgLabel];
    }
}

//第一次绘制正确
- (void)firstDrawSuccess{
    [self setErrormsg:@"再次绘制手势密码" color:UIColorRgb(128, 128, 128)];
}

//绘制手势密码成功
- (void)drawSuccess:(NSString *)pwd{
    //禁用交互
    self.view.userInteractionEnabled = NO;
    //存储密码
    [self saveGesturePwdCode:YES isNotShowAgain:NO passCode:pwd];
    
    //设置成功
    [self setErrormsg:@"绘制成功" color:UIColorRgb(128, 128, 128)];
    
    [self showNotifyProgressWithTitle:@"绘制成功" completionBlock:nil];
    //跳转上一页
    [self goBackEventByType];
}

//绘制失败，重新绘制
- (void)drawFailure{
    [lockView resetPwd];
    [self setErrormsg:@"与上一次绘制不一致，请重新绘制" color:UIColorRgb(255,45,85)];
    [self layerAnimation:errorMsgLabel];
}

//检验手势密码
- (BOOL)checkPwd:(NSString *)pwd{
    //判断用户绘制的手势密码是否和之前设置的密码一致
    if (![[BFMD5 md5:pwd] isEqualToString:[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].gesturePsw]) {
        //用户输入的次数是是4次
        if (unlockCount == 0) {
            
            [self jumpToLoginVC];
            
            return NO;
        }
        [self setErrormsg:[NSString stringWithFormat:@"密码错误，还可以再输入%ld次", (long)unlockCount] color:UIColorRgb(255,45,85)];
        [self layerAnimation:errorMsgLabel];
        
        unlockCount--;
        
        return NO;
    }
    
    //
    __weakself__
    [self showProgress];
    
    [BFReqAPI reqLoginByTokenBlock:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        // 结束刷新
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                // 登录成功，处理数据
                [[[BFCoreDataModelop alloc] init] insterUserinitWithDict:responseObj];
                BFCoreDataModelop *op = [[BFCoreDataModelop alloc] init];
                BFCoreUserModel *model = [op getCurrentBFuserModel];
                model.isLoginSuccess = [NSNumber numberWithBool:YES];
                
                [USER_D setBool:YES forKey:@"gesture_reset"];
                [USER_D synchronize];
                
                [weakself setErrormsg:@"解锁成功" color:UIColorRgb(128, 128, 128)];
                [weakself goBackEventByType];
                
            }else if (ERROR_CODE == -10)
            {
                NSHTTPCookieStorage *cookieJar = [NSHTTPCookieStorage sharedHTTPCookieStorage];
                for (NSHTTPCookie *cookie in [cookieJar cookies]) {
                    [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:cookie];
                }
                [BlockAlert showWithMessage:responseObj[@"message"] operation:^(NSInteger index) {
                   [self dismissViewControllerAnimated:YES completion:^{
                       [BFLoginTool toLoginWithAccountName:nil];
                   }];
                }];
            }
            else
            {
                [BlockAlert showWithMessage:responseObj[@"message"] operation:^(NSInteger index) {
                    [self dismissViewControllerAnimated:YES completion:^{
                        [BFLoginTool toLoginWithAccountName:nil];
                    }];
                }];
            }
        }
    }];
    
    return YES;
}

#pragma mark - 按钮事件

//暂时不设置
- (void)temporaryNoSetAction{
    [BlockAlert showWithTitle:Alert_Title message:@"手势密码可以保护你的账户安全，确定不设置?" cancelButtonTitle:Alert_Button_Cancel otherButtonTitles:Alert_Button_Confirm operation:^(NSInteger index) {
        if (index == 1) {
            //保存用户手势密码的信息
            [self saveGesturePwdCode:NO isNotShowAgain:YES passCode:@""];
            [self showNotifyProgressWithTitle:@"需要设置手势密码时，您可以在 我的账户-密码管理 开启并设置。" completionBlock:^{
                //跳转大厅首页
                [self goBackEventByType];
                
            }];
        }
    }];
}

//忘记密码
- (void)forgetPwdAction{
    [BlockAlert showWithTitle:Alert_Title message:@"忘记手势密码，需要重新登录。" cancelButtonTitle:Alert_Button_Cancel otherButtonTitles:@"重新登录" operation:^(NSInteger index) {
        if (index == 1) {
            [self jumpToLoginVC];
        }
    }];
}

//指纹解锁事件
- (void)touchIDBtnAction{
    [self touchIDSupport];
}

//切换账号
- (void)changeAccountAction{
    [self jumpToLoginVC];
}

//返回按钮事件
- (void)goBackAction{
    [self.navigationController popViewControllerAnimated:YES];
}

//label抖动效果
- (void)layerAnimation:(UIView *)view{
    CALayer *lbl = [view layer];
    CGPoint posLbl = [lbl position];
    CGPoint y = CGPointMake(posLbl.x-10, posLbl.y);
    CGPoint x = CGPointMake(posLbl.x+10, posLbl.y);
    CABasicAnimation * animation = [CABasicAnimation animationWithKeyPath:@"position"];
    [animation setTimingFunction:[CAMediaTimingFunction
                                  functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    [animation setFromValue:[NSValue valueWithCGPoint:x]];
    [animation setToValue:[NSValue valueWithCGPoint:y]];
    [animation setAutoreverses:YES];
    [animation setDuration:0.08];
    [animation setRepeatCount:3];
    [lbl addAnimation:animation forKey:nil];
}

//根据类型判断怎样返回
- (void)goBackEventByType{
    if (self.optionType == ResetGestturePwd) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else {
        // 注册成功通知
        [BFLoginTool loginSuccessed:nil];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

//跳转登录页面
- (void)jumpToLoginVC{
    
    //清除数据
    
    [self saveGesturePwdCode:NO isNotShowAgain:NO passCode:@""];
    
    //当前手势密码视图消失
    [self dismissViewControllerAnimated:NO completion:nil];
    
    //返回到对应的tab项最外层
    AppDelegate  *appDelegate = [UIApplication  sharedApplication].delegate;
    BFNavigationController *navc  = appDelegate.tabBarController.selectedViewController;
    [navc popToRootViewControllerAnimated:YES];
    
    //跳转登录
    [BFLoginTool toLoginWithAccountName:nil];
}

#pragma mark - 手势密码存储清除集合

//保存事件
- (void)saveGesturePwdCode:(BOOL)isSetGesturePwd isNotShowAgain:(BOOL)isShowAgain passCode:(NSString *)gstPassCode{
    if (!IsEmptyString(gstPassCode)) {
        gstPassCode = [BFMD5 md5:gstPassCode];
    }
    BFCoreDataModelop *op = [[BFCoreDataModelop alloc] init];
    BFCoreUserModel *model = [op getCurrentBFuserModel];
    model.isUsedGesturePsw = [NSNumber numberWithBool:isSetGesturePwd];
    model.gesturePsw = gstPassCode;
//    [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedGesturePsw =  [NSNumber numberWithBool:isSetGesturePwd] ;
//    [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].gesturePsw = gstPassCode;
    
//    if (isSetGesturePwd) {
//        [[BFTouchIDTool sharedTool] systemCanEvaluateTouchID:^(BOOL isCan, TouchIDError code) {
//            if (isCan) {
//                model.isUsedTouchIDForLogin = [NSNumber numberWithBool:YES];
////                [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedTouchIDForLogin = [NSNumber numberWithBool:YES];
//            }
//            else {
//                model.isUsedTouchIDForLogin = [NSNumber numberWithBool:NO];
////                [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedTouchIDForLogin = [NSNumber numberWithBool:NO];
//            }
//        }];
//    }else{
//        model.isUsedTouchIDForLogin = [NSNumber numberWithBool:NO];
////        [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedTouchIDForLogin = [NSNumber numberWithBool:NO];
//    }
}

#pragma mark - UI

//绘制视图
- (void)drawUI{
    
    self.view.backgroundColor = UIColorWhite();
    
    CGFloat headerHeight = 0.0;
    
    if (self.optionType == ResetGestturePwd) {
        
        self.title = @"手势密码";
        if (_iPhone5_) {
            headerHeight = 120;
        }else if (_iPhone6_) {
            headerHeight = 140;
        }else if (_iPhone6P_) {
            headerHeight = 150;
        }else {
            headerHeight = 90;
        }
        
    }else{
        self.navigationController.navigationBar.hidden  = NO;
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];
        if (_iPhone5_) {
            headerHeight = 140;
        }else if (_iPhone6_) {
            headerHeight = 170;
        }else if (_iPhone6P_) {
            headerHeight = 180;
        }else {
            headerHeight = 120;
        }
    }
    
    showView = [[UIView  alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    showView.backgroundColor = [UIColor clearColor];
    showView.hidden = NO;
    [self.view addSubview:showView];
    
    //显示头部视图 包括: 标题，提示
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, headerHeight)];
    headerView.backgroundColor = [UIColor clearColor];
    [showView addSubview:headerView];
    
    //title
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.frame = CGRectMake(20,  headerView.size_H - 75,ScreenWidth-40, 29);
    
    titleLabel.text = self.titleLabelMsg;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    if (_iPhone6P_) {
        titleLabel.font = BF_Font_(27);
    }else if (_iPhone6_) {
        titleLabel.font = BF_Font_(23);
    }else {
        titleLabel.font = BF_Font_(20);
    }
    titleLabel.textColor = UIColorRgb(128, 128, 128);
    titleLabel.backgroundColor = [UIColor clearColor];
    [headerView addSubview:titleLabel];
    
    //errorMsgLabel
    errorMsgLabel = [[UILabel alloc] init];
    errorMsgLabel.frame = CGRectMake((ScreenWidth / 2) - 150, headerView.size_H - 35, 300, 25);
    errorMsgLabel.textAlignment = NSTextAlignmentCenter;
    errorMsgLabel.backgroundColor = [UIColor clearColor];
    [self setErrormsg:self.remindLabelMsg color:UIColorRgb(128, 128, 128)];
    if (_iPhone6P_) {
        errorMsgLabel.font = BF_Font_(20);
    } else if (_iPhone6_) {
        errorMsgLabel.font = BF_Font_(18);
    } else {
        errorMsgLabel.font = BF_Font_(17);
    }
    [headerView addSubview:errorMsgLabel];
    
    CGFloat  lockViewW = ScreenWidth + 10;
    CGFloat  lockViewH = ScreenWidth - 30;
    
    if (_iPhone6_) {
        lockViewH = 360;
        lockViewW = 360;
    }
    
    if (_iPhone6P_) {
        lockViewH = 380;
        lockViewW = 380;
    }
    //绘制手势密码视图
    lockView = [[BFLockView alloc]initWithFrame:CGRectMake((ScreenWidth - lockViewW)/2,_iPhone6P_ ? headerView.bottom_Y + 20 : headerView.bottom_Y, lockViewW, lockViewH)];
    lockView.type = BackgroundGesturePwd == self.optionType ? CoreLockTypeVeryfiPwd : CoreLockTypeSetPwd;
    lockView.backgroundColor = [UIColor clearColor];
    [showView addSubview:lockView];
    
    
    //不是重置密码入口进入绘制底部视图
    if (self.optionType != ResetGestturePwd) {
        
        //显示底部视图 包括：忘记密码，切换账号
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, lockView.bottom_Y, ScreenWidth, (ScreenHeight - headerView.size_H - lockView.size_H))];
        footerView.backgroundColor = [UIColor clearColor];
        [showView addSubview:footerView];
        
        //用户是否设置了手势密码
        if (self.optionType == LoginGesturePwd) {
            //暂不设置
            UIButton *tempSettingBtn = [UIButton createWithFrame:CGRectMake((_iPhone4_ || _iPhone5_) ? ScreenWidth - 100 - 33 : ScreenWidth - 100 - 42, (footerView.size_H - 25)/2, 100, 25) title:@"暂不设置" target:self action:@selector(temporaryNoSetAction)];
            [tempSettingBtn setTitleColor:UIColorRgb(178,178,178) forState:UIControlStateNormal];
            tempSettingBtn.titleFont = UIFontSystemOfSize(14);
            tempSettingBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
            [self setButtonFont:tempSettingBtn];
            [footerView addSubview:tempSettingBtn];
            
            showView.hidden = NO;
            
        }else {
            //用户设置了手势密码， 忘记密码
            UIButton *forgetPwdBtn = [UIButton createWithFrame:CGRectMake(32, (footerView.size_H - 25)/2 + 3, 80, 25) title:@"忘记密码" target:self action:@selector(forgetPwdAction)];
            forgetPwdBtn.titleFont = UIFontSystemOfSize(14);
            [forgetPwdBtn setTitleColor:UIColorRgb(178,178,178) forState:UIControlStateNormal];
            forgetPwdBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
            [self setButtonFont:forgetPwdBtn];
            [footerView addSubview:forgetPwdBtn];
            
            //切换账号
            UIButton *changeAccountBtn = [UIButton createWithFrame:CGRectMake(ScreenWidth - 112, (footerView.size_H - 25)/2 + 3, 80, 25) title:@"切换账号" target:self action:@selector(changeAccountAction)];
            [changeAccountBtn setTitleColor:UIColorRgb(178,178,178) forState:UIControlStateNormal];
            changeAccountBtn.titleFont = UIFontSystemOfSize(14);
            changeAccountBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
            [self setButtonFont:changeAccountBtn];
            [footerView addSubview:changeAccountBtn];
            
            //添加指纹按钮
            [[BFTouchIDTool sharedTool] systemCanEvaluateTouchID:^(BOOL isCan, TouchIDError code) {
                if (!isCan && (code == TouchIDErrorNotSupport || code == TouchIDErrorUnknown)) {
                    BFCoreDataModelop *op = [[BFCoreDataModelop alloc] init];
                    BFCoreUserModel *model = [op getCurrentBFuserModel];
                    model.isUsedTouchIDForLogin = [NSNumber numberWithBool:NO];
                }else {
                    
                    UIImage *touchbgImage = [UIImage imageNamed:@"password_icon_fingerprint"];
                    //指纹解锁
                    UIButton *touchIDBtn = [UIButton createWithFrame:CGRectMake((ScreenWidth  - touchbgImage.size.width)/2.0 , (footerView.size_H - touchbgImage.size.height)/2, touchbgImage.size.width, touchbgImage.size.height) title:nil target:self action:@selector(touchIDBtnAction)];
                    [touchIDBtn setBackgroundImage:touchbgImage forState:UIControlStateNormal];
                    touchIDBtn.backgroundColor = [UIColor clearColor];
                    touchIDBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
                    [self setButtonFont:touchIDBtn];
                    [footerView addSubview:touchIDBtn];
                }
                
                //绘制遮盖视图
                [self drawCoverView:headerView.size_H];
                
            }];
        }
    }else{
        showView.hidden = NO;
    }
}

//如果是后台进入且支持指纹先绘制遮盖视图
- (void)drawCoverView:(CGFloat)height{
   
    
    //如果是支持指纹解锁，则先遮盖lockView
    coverView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    coverView.hidden = YES;
    
    UIImage *bgImage = [UIImage createImageWithColor:[[UIColor lightGrayColor] colorWithAlphaComponent:0.2]];
    
    coverView.backgroundColor = [UIColor colorWithPatternImage:bgImage];
    [self.view addSubview:coverView];
    
    [self checkTouchIDState];
    
}

//设置按钮字体大小
- (void)setButtonFont:(UIButton *)sender{
    if (_iPhone6P_) {
        sender.titleLabel.font = BF_Font_17;
    }
    else if (_iPhone6_) {
        sender.titleLabel.font = BF_Font_15;
    }
    else {
        sender.titleLabel.font = BF_Font_13;
    }
}

//设置errorLabel的字体颜色及内容
- (void)setErrormsg:(NSString *)msg color:(UIColor *)color{
    [errorMsgLabel setText:msg];
    [errorMsgLabel setTextColor:color];
}

#pragma mark - View Life Cycle

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title = @"手势密码";
    
    //绘制手势密码视图
    [self drawUI];
    
    //事件初始化
    if (self.optionType == BackgroundGesturePwd) {
        //注册后台进入前台通知
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNotification) name:UIApplicationWillEnterForegroundNotification object:nil];
        
        [self unlockEvent];
    }
    else {
        [self drawEvent];
    }
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (self.optionType == ResetGestturePwd) {
        //  [self setNavBarImage:[UIImage imageNamed:@"navbar_white_bg"] titleColor:BF_Color_TextViewContent];
    }
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIApplicationWillEnterForegroundNotification object:nil];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

//通知事件处理
- (void)handleNotification{
    [self checkTouchIDState];
}

//检验设备且用户是否开启了指纹解锁
- (void)checkTouchIDState{
    if ([[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedTouchIDForLogin boolValue]) {
        coverView.hidden = NO;
        [self touchIDSupport];
    }
    else {
        coverView.hidden = YES;
    }
}

//检验设备是否支持指纹
- (void)touchIDSupport{
    [[BFTouchIDTool sharedTool] canEvaluateTouchIDType:ApplicationTypeGesturePassword reply:^(BOOL isSuccess, TouchIDError code){
        if (isSuccess) {
            NSString *reason = [[BFTouchIDTool sharedTool] reasonForApp:ApplicationTypeGesturePassword];
            [[BFTouchIDTool sharedTool] evaluateTouchIDReason:reason reply:^(BOOL isSuccess, TouchIDError code) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (isSuccess) {
                        __weakself__
                        [self showProgress];
                        
                        [BFReqAPI reqLoginByTokenBlock:^(id responseObj, NSError *error) {
                            [weakself hideProgress];
                            // 结束刷新
                            if (responseObj != nil) {
                                if (ERROR_CODE == 1) {
                                    // 登录成功，处理数据
                                    [[[BFCoreDataModelop alloc] init] insterUserinitWithDict:responseObj];
                                    BFCoreDataModelop *op = [[BFCoreDataModelop alloc] init];
                                    BFCoreUserModel *model = [op getCurrentBFuserModel];
                                    model.isLoginSuccess = [NSNumber numberWithBool:YES];
                                    [self dismissViewControllerAnimated:YES completion:^{}];
                                    
                                }else if (ERROR_CODE == -10)
                                {
                                    NSHTTPCookieStorage *cookieJar = [NSHTTPCookieStorage sharedHTTPCookieStorage];
                                    for (NSHTTPCookie *cookie in [cookieJar cookies]) {
                                        [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:cookie];
                                    }
                                    [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
                                }
                                else
                                {
                                    [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
                                }
                            }
                        }];
                    }
                    else {
                        [self performSelectorOnMainThread:@selector(hiddeCoverView) withObject:nil waitUntilDone:NO];
                    }
                });
            }];
        }
        else {
            [self performSelectorOnMainThread:@selector(hiddeCoverView) withObject:nil waitUntilDone:NO];
        }
    }];
}

//用户取消或者其他错误直接隐藏遮盖view
- (void)hiddeCoverView{
    coverView.hidden = YES;
    showView.hidden = NO;
}


@end

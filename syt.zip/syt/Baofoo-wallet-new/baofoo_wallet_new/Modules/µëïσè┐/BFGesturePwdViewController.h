//
//  BFGesturePwdViewController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/24.
//  Copyright © 2016年 BF. All rights reserved.
//


typedef enum{
    LoginGesturePwd,  //登录进入
    ResetGestturePwd, //重置手势密码
    BackgroundGesturePwd //从后台进入
}OptionType;

#import "BFBaseViewController.h"

@interface BFGesturePwdViewController : BFBaseViewController
@property(nonatomic, assign) OptionType optionType; //操作类型
@property(nonatomic, strong) NSString *titleLabelMsg; //页面title
@property(nonatomic, strong) NSString *remindLabelMsg; //页面提示

@end

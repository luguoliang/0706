//
//  BFLockConst.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/24.
//  Copyright © 2016年 BF. All rights reserved.
//

#ifndef _CoreLockConst_H_
#define _CoreLockConst_H_

#import <UIKit/UIKit.h>


/** 选中圆大小比例 */
const CGFloat CoreLockArcWHR = .3f;

/** 选中圆大小的线宽 */
const CGFloat CoreLockArcLineW = 1.5f;

/** 选择圆的大小 */
//const CGFloat marginValue = 36.0f;
const CGFloat marginValue = 33.0f;


/** 最低设置密码数目 */
const NSUInteger CoreLockMinItemCount = 4;



#endif

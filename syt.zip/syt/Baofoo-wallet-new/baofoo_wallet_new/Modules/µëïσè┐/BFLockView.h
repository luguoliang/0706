//
//  BFLockView.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/24.
//  Copyright © 2016年 BF. All rights reserved.
//

typedef enum{
    CoreLockTypeSetPwd=0,//设置密码
    CoreLockTypeVeryfiPwd,//验证密码
}CoreLockType;


#import <UIKit/UIKit.h>

@interface BFLockView : UIView

@property (nonatomic,assign) CoreLockType type;

/*
 *  设置密码
 */

/** 设置密码出错：长度不够 */
@property (nonatomic,copy) void (^setPWSErrorLengthTooShortBlock)(NSUInteger currentCount);


/** 设置密码出错：再次密码不一致 */
@property (nonatomic,copy) void (^setPWSErrorTwiceDiffBlock)(NSString *pwd1,NSString *pwdNow);


/** 设置密码：第一次输入正确*/
@property (nonatomic,copy) void (^setPWFirstRightBlock)();


/** 再次密码输入一致 */
@property (nonatomic,copy) void (^setPWTwiceSameBlock)(NSString *pwd);


/*
 *  验证密码
 */

/** 验证密码 */
@property (nonatomic,copy) BOOL (^verifyPwdBlock)(NSString *pwd);



/*
 *  重设密码
 */
-(void)resetPwd;


@end

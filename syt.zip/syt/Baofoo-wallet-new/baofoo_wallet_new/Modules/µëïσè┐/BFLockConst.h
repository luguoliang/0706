
//
//  BFLockConst.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/24.
//  Copyright © 2016年 BF. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


#ifndef _CoreLockConst_H_
#define _CoreLockConst_H_

/*
 *  外环线条颜色：默认
 */
#define DefaultColor  [[UIColor getCurrentAppSystemColor] colorWithAlphaComponent:0.5]


/*
 *  外环线条颜色：选中
 */
#define SelectedColor [UIColor getCurrentAppSystemColor]


/** 选中圆大小比例 */
extern const CGFloat CoreLockArcWHR;

/** 选中圆大小的线宽 */
extern const CGFloat CoreLockArcLineW;

/** 选择圆的大小 */
extern const CGFloat marginValue;

/** 最低设置密码数目 */
extern const NSUInteger CoreLockMinItemCount;


#endif


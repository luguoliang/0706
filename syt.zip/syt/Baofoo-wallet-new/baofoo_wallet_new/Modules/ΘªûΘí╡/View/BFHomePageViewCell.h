//
//  BFHomePageViewCell.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BFHomePageViewModel.h"
@interface BFHomePageViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *button;
@property (weak, nonatomic) IBOutlet UIButton *button2;
@property (weak, nonatomic) IBOutlet UIButton *button3;
@property(nonatomic,copy)BFHomePageViewModel*model;
@end

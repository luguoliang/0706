//
//  BFHomePageViewCell.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFHomePageViewCell.h"
#import "UIButton+Photo_text.h"
@implementation BFHomePageViewCell

- (void)awakeFromNib {
}
-(void)setModel:(BFHomePageViewModel *)model{
    [self.button setTitle:model.title forState:UIControlStateNormal];
    [self.button setImage:[UIImage imageNamed:model.imageName] forState:UIControlStateNormal];
    [self.button2 setTitle:model.title1 forState:UIControlStateNormal];
    [self.button2 setImage:[UIImage imageNamed:model.imageName1] forState:UIControlStateNormal];
    [self.button3 setTitle:model.title2 forState:UIControlStateNormal];
    [self.button3 setImage:[UIImage imageNamed:model.imageName2] forState:UIControlStateNormal];
    [self.button verticalCenterImageAndTitle:10];
    [self.button2 verticalCenterImageAndTitle:10];
    [self.button3 verticalCenterImageAndTitle:10];
    [self.button setImage:[[UIImage imageNamed:model.imageName] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
     [self.button2 setImage:[[UIImage imageNamed:model.imageName1] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
     [self.button3 setImage:[[UIImage imageNamed:model.imageName2] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

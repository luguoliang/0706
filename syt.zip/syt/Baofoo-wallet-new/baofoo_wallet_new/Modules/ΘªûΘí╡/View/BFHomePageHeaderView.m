//
//  BFHomePageHeaderView.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/24.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFHomePageHeaderView.h"
#import "UIButton+Photo_text.h"
@implementation BFHomePageHeaderView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
//        {
//        UIButton*leftButton = [UIButton buttonWithType:UIButtonTypeSystem];
//        leftButton.frame = CGRectMake(0, 0, self.frame.size.width/2, self.frame.size.height);
//        [leftButton setImage:[UIImage imageNamed:@"account_bank_card"] forState:UIControlStateNormal];
//        [leftButton setTitle:@"扫一扫" forState:UIControlStateNormal];
//        [leftButton setTitleFont:[UIFont systemFontOfSize:13.0]];
//        [leftButton verticalCenterImageAndTitle:10];
//        [self addSubview:leftButton];
//        [leftButton setImage:[[UIImage imageNamed:@"account_bank_card"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
//            leftButton.tintColor = [UIColor whiteColor];
//        }
//        {
//        UIButton*rightButton = [UIButton buttonWithType:UIButtonTypeSystem];
//        rightButton.frame = CGRectMake(self.frame.size.width/2, 0, self.frame.size.width/2, self.frame.size.height);
//        [rightButton setImage:[UIImage imageNamed:@"account_invite_friend"] forState:UIControlStateNormal];
//        [rightButton setTitle:@"二维码" forState:UIControlStateNormal];
//        [rightButton setTitleFont:[UIFont systemFontOfSize:13.0]];
//        [rightButton verticalCenterImageAndTitle:10];
//        [self addSubview:rightButton];
//        [rightButton setImage:[[UIImage imageNamed:@"account_invite_friend"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
//            rightButton.tintColor = [UIColor whiteColor];
//        }
    }
    return self;
}
@end

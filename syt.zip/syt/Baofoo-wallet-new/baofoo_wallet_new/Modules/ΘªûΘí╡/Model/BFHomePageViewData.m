//
//  BFHomePageViewData.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFHomePageViewData.h"

@implementation BFHomePageViewData
+(NSArray*)getHomePageList{
    return  @[
              @{  @"title":@"账户余额",
                  @"imageName":@"account_balance",
                  @"title1":@"我的红包",
                  @"imageName1":@"account_red_packets",@"title2":@"银行卡",@"imageName2":@"account_bank_card"
                  }
              ,
              @{@"title":@"邀请好友",@"imageName":@"account_invite_friend",@"title1":@"安全中心",@"imageName1":@"account_secture_center",@"title2":@"退出",@"imageName2":@"account_exit"}
              ,
              @{@"title":@"邀请好友",@"imageName":@"account_invite_friend",@"title1":@"安全中心",@"imageName1":@"account_secture_center",@"title2":@"安全退出",@"imageName2":@"account_exit"}
              ,
              @{@"title":@"邀请好友",@"imageName":@"account_invite_friend",@"title1":@"安全中心",@"imageName1":@"account_secture_center",@"title2":@"安全退出",@"imageName2":@"account_exit"}
              ];
}
@end

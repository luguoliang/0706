//
//  TTJXLabel.h
//  BaofooWallet
//
//  Created by mac on 15/11/18.
//  Copyright © 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTJXLabel : UILabel
@property(nonatomic,copy)NSString *onclickType;
@property(nonatomic,copy)NSString *onclick;
@end

//
//  BFLobbyTopView.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFLobbyTopView.h"


@interface BFLobbyTopView()
{
    UIImageView *badgeImageView;
}
@end

@implementation BFLobbyTopView
@synthesize delegate;

#pragma mark - UI

- (void)drawUI{
    //翼支付图标
    UIImage  *iconImg = [UIImage imageNamed:@"top_bf_logo"];
    CGFloat scale = 1;
    if (_iPhone6_) {
        scale = 1.2;
    }
    else if (_iPhone6P_){
        scale = 1.4;
    }
    
    UIImageView  *BF_IconImgV = [[UIImageView alloc]initWithFrame:CGRectMake((ScreenWidth - iconImg.size.width*scale) / 2, 33, iconImg.size.width*scale, iconImg.size.height*scale)];
    BF_IconImgV.backgroundColor = [UIColor clearColor];
    BF_IconImgV.image = iconImg;
    [self addSubview:BF_IconImgV];
    
    //消息
    
    UIButton *newsButton = [UIButton createWithFrame:CGRectMake(9, 23, 36, 36) target:self action:@selector(newsButtonClick:)];
    [newsButton setImage:[UIImage imageNamed:@"lobbyNews"] forState:UIControlStateNormal];
    [self addSubview:newsButton];
    
    //消息角标
    badgeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(9 + 16 + 6, 30, 8, 8)];
    badgeImageView.backgroundColor = [UIColor redColor];
    badgeImageView.layer.masksToBounds = YES;
    badgeImageView.layer.cornerRadius = 4;
    badgeImageView.layer.borderColor = [[UIColor whiteColor]CGColor];
    badgeImageView.layer.borderWidth = 1;
    badgeImageView.hidden = YES;
    [self addSubview:badgeImageView];
    
    //扫一扫按钮
    UIImage  *home_scan_img = [UIImage imageNamed:@"home_icon_scan"];
    
    CGFloat bottomY = 0;
    if (_iPhone6_){
        bottomY = 46;
    }
    else if (_iPhone6P_){
        bottomY = 52;
    }
    else {
        bottomY = 38;
    }
    CGFloat equalW = (ScreenWidth/3);
    
    UIButton *sweepButton = [UIButton createWithFrame:CGRectMake((equalW - home_scan_img.size.width)/2, self.frame.size.height - home_scan_img.size.height - bottomY, home_scan_img.size.width, home_scan_img.size.height) target:self action:@selector(sweepButtonClick)];
    [sweepButton setImage:home_scan_img forState:UIControlStateNormal];
    [self addSubview:sweepButton];
    
    UILabel  *sweepLabel = [UILabel createWithFrame:CGRectMake((equalW - 60)/2,sweepButton.bottom_Y + 4, 60, BF_Height_21)];
    [sweepLabel setText:@"扫一扫"];
    [sweepLabel setTextColor:UIColorWhite()];
    if (_iPhone6P_) {
        [sweepLabel setFont:BF_Font_16];
    }else{
        [sweepLabel setFont:BF_Font_13];
    }
    [sweepLabel setTextAlignment:NSTextAlignmentCenter];
    [self addSubview:sweepLabel];
    
    //二维码支付按钮
    UIImage  *home_paycode_img = [UIImage imageNamed:@"home_icon_paycode"];
    
    UIButton *qrCodeButton = [UIButton createWithFrame:CGRectMake(equalW + ((equalW - home_paycode_img.size.width)/2), sweepButton.frame.origin.y, home_paycode_img.size.width, home_paycode_img.size.height) target:self action:@selector(qrCodeButtonClick)];
    [qrCodeButton setImage:home_paycode_img forState:UIControlStateNormal];
    [self addSubview:qrCodeButton];
    
    UILabel  *qrCodeLabel = [UILabel createWithFrame:CGRectMake(equalW + ((equalW - 60)/2),qrCodeButton.bottom_Y + 4, 60, BF_Height_21)];
    [qrCodeLabel setText:@"付款码"];
    [qrCodeLabel setTextAlignment:NSTextAlignmentCenter];
    [qrCodeLabel setTextColor:UIColorWhite()];
    if (_iPhone6P_)
    {
        [qrCodeLabel setFont:BF_Font_16];
    }else
    {
        [qrCodeLabel setFont:BF_Font_13];
    }
    [self addSubview:qrCodeLabel];
    
    
    //收款按钮
    UIImage  *collection_img = [UIImage imageNamed:@"home_icon_collection"];
    
    UIButton *collectionButton = [UIButton createWithFrame:CGRectMake(2 * equalW + ((equalW - collection_img.size.width)/2), qrCodeButton.frame.origin.y, collection_img.size.width, collection_img.size.height) target:self action:@selector(collectionClick)];
    [collectionButton setImage:collection_img forState:UIControlStateNormal];
    [self addSubview:collectionButton];
    
    UILabel  *collectionLabel = [UILabel createWithFrame:CGRectMake(2 * equalW  + ((equalW - 60)/2),collectionButton.bottom_Y + 4, 60, BF_Height_21)];
    [collectionLabel setText:@"收款"];
    [collectionLabel setTextAlignment:NSTextAlignmentCenter];
    [collectionLabel setTextColor:UIColorWhite()];
    if (_iPhone6P_)
    {
        [collectionLabel setFont:BF_Font_16];
    }else
    {
        [collectionLabel setFont:BF_Font_13];
    }
    [self addSubview:collectionLabel];
    
}

- (void)showBadge{
    badgeImageView.hidden = NO;
}

- (void)hideBadge{
    badgeImageView.hidden = YES;
}

#pragma mark - Button Action

//消息
- (void)newsButtonClick:(id)sender
{
    if (delegate && [delegate respondsToSelector:@selector(lobbyTopViewDidSelectNews:)]) {
        [self.delegate lobbyTopViewDidSelectNews:self];
    }
}

//扫一扫
- (void)sweepButtonClick{
    if (delegate && [delegate respondsToSelector:@selector(lobbyTopViewDidSelectScan:)]) {
        [self.delegate lobbyTopViewDidSelectScan:self];
    }
}

//二维码支付
- (void)qrCodeButtonClick{
    if (delegate && [delegate respondsToSelector:@selector(lobbyTopViewDidSelectPayCode:)]) {
        [self.delegate lobbyTopViewDidSelectPayCode:self];
    }
}

//收款按钮
- (void)collectionClick{
    if (delegate && [delegate respondsToSelector:@selector(lobbyTopViewDidSelectCollection:)]) {
        [self.delegate lobbyTopViewDidSelectCollection:self];
    }
}

#pragma mark - Life Cycle

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self drawUI];
    }
    return self;
}
@end

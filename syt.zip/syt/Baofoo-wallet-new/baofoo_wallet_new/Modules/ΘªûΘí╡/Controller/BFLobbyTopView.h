//
//  BFLobbyTopView.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BFLobbyTopView;
@protocol BFLobbyTopViewDelegate <NSObject>

@optional
- (void)lobbyTopViewDidSelectNews:(BFLobbyTopView *)lobbyTopView; //消息按钮点击事件
- (void)lobbyTopViewDidSelectScan:(BFLobbyTopView *)lobbyTopView; //扫一扫按钮点击事件
- (void)lobbyTopViewDidSelectPayCode:(BFLobbyTopView *)lobbyTopView; //二维码支付按钮点击事件
- (void)lobbyTopViewDidSelectCollection:(BFLobbyTopView *)lobbyTopView;//收款按钮事件

@end
@interface BFLobbyTopView : UIView
@property(nonatomic, assign) id<BFLobbyTopViewDelegate> delegate;

- (void)showBadge;
- (void)hideBadge;

@end

//
//  YZFAppItemModel.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "YZFAppItemModel.h"
#import "BFLobbyAppPathTool.h"
#import <ZipArchive.h>
#import "BFH5ZipSignTool.h"

@interface YZFAppItemModel ()<NSCoding>
@property (copy, nonatomic) NSString *fileType; // 0 Native应用 1 Html5应用
@property (copy, nonatomic) NSString *appState; // 审核，下架，等
@property (copy, nonatomic) NSString *appStateOnline; // 审核，下架，等

@end

@implementation YZFAppItemModel

#pragma mark - View Life Cycle



- (instancetype)init{
    if (self = [super init]) {
        _isCanUpdated = NO ;
        _appStateValue = AppStateValueNormal ;
        _fileTypeValue = FileTypeValueNative ;
        _appStateValueOnline = AppStateValueNormal ;
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super init]) {
        
        //唯一标示符
        self.appId = [aDecoder decodeObjectForKey:@"appId"] ;    //应用编号
        self.appList = [aDecoder decodeObjectForKey:@"appList"] ;//如果是文件夹，文件夹里的应用
        
        //基础参数
        self.appName= [aDecoder decodeObjectForKey:@"appName"] ;  //应用名字
        self.version= [aDecoder decodeObjectForKey:@"version"] ;  //版本
        self.checkMd5= [aDecoder decodeObjectForKey:@"checkMd5"] ; //md5
        self.fileURL= [aDecoder decodeObjectForKey:@"fileURL"] ;  //文件
        self.iconURL= [aDecoder decodeObjectForKey:@"iconURL"] ;  //图标icon
        
        //可替换参数，下载完成时候，替换的时候，替换上面的。
        self.isCanUpdated  = [aDecoder decodeObjectForKey:@"isCanUpdated"] ;//可以更新
        
        self.appNameOnline = [aDecoder decodeObjectForKey:@"appNameOnline"] ;  //应用名字
        self.versionOnline = [aDecoder decodeObjectForKey:@"versionOnline"] ;  //版本
        self.checkMd5Online = [aDecoder decodeObjectForKey:@"checkMd5Online"] ; //md5
        self.fileURLOnline = [aDecoder decodeObjectForKey:@"fileURLOnline"] ;  //文件
        self.iconURLOnline = [aDecoder decodeObjectForKey:@"iconURLOnline"] ;  //图标icon
        
        
        //可能不需要，先留着，不知道啥逻辑
        self.isNotice = [aDecoder decodeObjectForKey:@"isNotice"] ;
        self.noticeURL = [aDecoder decodeObjectForKey:@"noticeURL"] ;
        self.noticeText = [aDecoder decodeObjectForKey:@"noticeText"] ;
        self.isNoticeOnline = [aDecoder decodeObjectForKey:@"isNoticeOnline"] ;
        self.noticeURLOnline = [aDecoder decodeObjectForKey:@"noticeURLOnline"] ;
        
        //私有变量
        self.fileType = [aDecoder decodeObjectForKey:@"fileType"] ; // 0 Native应用 1 Html5应用
        self.appState = [aDecoder decodeObjectForKey:@"appState"] ; // 审核，下架，等
        self.appStateOnline = [aDecoder decodeObjectForKey:@"appStateOnline"] ; // 审核，下架，等
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder {
    
    //唯一标示符
    [aCoder encodeObject:_appId forKey:@"appId"] ;    //应用编号
    [aCoder encodeObject:_appList  forKey:@"appList"] ;//如果是文件夹，文件夹里的应用
    
    //基础参数
    [aCoder encodeObject:_appName forKey:@"appName"] ;  //应用名字
    [aCoder encodeObject:_version forKey:@"version"] ;  //版本
    [aCoder encodeObject:_checkMd5 forKey:@"checkMd5"] ; //md5
    [aCoder encodeObject:_fileURL forKey:@"fileURL"] ;  //文件
    [aCoder encodeObject:_iconURL forKey:@"iconURL"] ;  //图标icon
    
    //可替换参数，下载完成时候，替换的时候，替换上面的。
    [aCoder encodeObject:[NSNumber numberWithBool:_isCanUpdated]  forKey:@"isCanUpdated"] ;//可以更新
    
    [aCoder encodeObject:_appNameOnline forKey:@"appNameOnline"] ;  //应用名字
    [aCoder encodeObject:_versionOnline forKey:@"versionOnline"] ;  //版本
    [aCoder encodeObject:_checkMd5Online forKey:@"checkMd5Online"] ; //md5
    [aCoder encodeObject:_fileURLOnline forKey:@"fileURLOnline"] ;  //文件
    [aCoder encodeObject:_iconURLOnline forKey:@"iconURLOnline"] ;  //图标icon
    
    //可能不需要，先留着，不知道啥逻辑
    [aCoder encodeObject:_isNotice forKey:@"isNotice"] ;
    [aCoder encodeObject:_noticeURL forKey:@"noticeURL"] ;
    [aCoder encodeObject:_noticeText forKey:@"noticeText"] ;
    [aCoder encodeObject:_isNoticeOnline forKey:@"isNoticeOnline"] ;
    [aCoder encodeObject:_noticeURLOnline forKey:@"noticeURLOnline"] ;
    
    [aCoder encodeObject:_fileType forKey:@"fileType"] ; // 0 Native应用 1 Html5应用
    [aCoder encodeObject:_appState forKey:@"appState"] ; // 审核，下架，等
    [aCoder encodeObject:_appStateOnline forKey:@"appStateOnline"] ; // 审核，下架，等
}

#pragma mark setters

- (void) setFileType:(NSString *)fileType {
    _fileType = fileType ;
    self.fileTypeValue = [fileType isKindOfClass:[NSNull class]]?FileTypeValueFolder:[fileType integerValue];
}

- (void) setAppState:(NSString *)appState {
    _appState = appState ;
    self.appStateValue = [appState integerValue];
}

- (void) setAppStateOnline:(NSString *)appStateOnline {
    _appStateOnline = appStateOnline ;
    self.appStateValueOnline = [appStateOnline integerValue];
}

#pragma mark private API
//安装应用
- (BOOL) installFromZipPath:(NSString *)zipFilePath fileManager:(NSFileManager *)fm {
    //解压路径
    NSString *installedPath = [BFLobbyAppPathTool presetAppInstalledPath:self] ;
    
    //删除以前文件
    if ([fm fileExistsAtPath:installedPath]) {
        [fm removeItemAtPath:installedPath error:nil] ;
    }
    
    //文件是否存在
    if([fm fileExistsAtPath:zipFilePath]==NO) {
        return NO ;
    }
    
    //解压
    ZipArchive* zipArchive = [[ZipArchive alloc] init] ;
    if (![zipArchive UnzipOpenFile:zipFilePath] || ![zipArchive UnzipFileTo:installedPath overWrite:YES]) {
        return NO ;
    }
    //安装JS接口
    NSString* jsPath = [installedPath stringByAppendingPathComponent:PublicJs_File] ;
    return [self verifyPublicPortAtPath:jsPath fileManager:fm] ;
}

- (BOOL)verifyPublicPortAtPath:(NSString *)path fileManager:(NSFileManager *)fm {
    if ([fm fileExistsAtPath:path]==NO) {
        return [fm copyItemAtPath:[BFLobbyAppPathTool publicPortPath] toPath:path error:NULL] ;
    }
    
    NSString *oldSign = [BFH5ZipSignTool getFileMD5WithPath:path];
    NSString *newSign = [BFH5ZipSignTool getFileMD5WithPath:[BFLobbyAppPathTool publicPortPath]];
    
    if (oldSign.length==0 || [oldSign isEqualToString:newSign]==NO) {
        [[NSFileManager defaultManager] removeItemAtPath:path error:nil] ;
        return [fm copyItemAtPath:[BFLobbyAppPathTool publicPortPath] toPath:path error:NULL] ;
    }
    return YES ;
}



#pragma mark public API

+ (NSArray *) modelsFromDicts:(NSArray *)arrDicts {
    //空
    if ([BFTool isEmptyArray:arrDicts]) {
        return nil ;
    }
    
    //枚举
    NSMutableArray *models = [NSMutableArray array] ;
    
    for (NSDictionary *dict in arrDicts) {
        YZFAppItemModel *model = [self getModelFromDictionary:dict] ;
        [models addObject:model] ;
    }
    //返回
    return models ;
}

+ (instancetype)getModelFromDictionary:(NSDictionary *)dictionary{
    
    YZFAppItemModel *model = [[YZFAppItemModel alloc] init] ;
    
    //唯一标示符
    model.appId = dictionary[@"appId"] ;    //应用编号
    model.appList= dictionary[@"appList"]  ;//如果是文件夹，文件夹里的应用
    
    if ([BFTool isEmptyArray:model.appList]) {
        model.appList = nil ;
    } else {
        model.appList = [self modelsFromDicts:model.appList] ;
    }
    
    //基础参数
    model.appName = dictionary[@"appName"] ;  //应用名字
    model.version = dictionary[@"version"] ;  //版本
    model.checkMd5= dictionary[@"checkMd5"] ; //md5
    model.fileURL = NoEmptyString(dictionary[@"fileURL"]) ;  //文件
    model.iconURL = NoEmptyString(dictionary[@"iconURL"]) ;  //图标icon
    
    //提示图片
    model.isNotice = dictionary[@"isNotice"] ;
    model.noticeURL = NoEmptyString(dictionary[@"noticeURL"]) ;
    model.noticeText = @"" ;
    
    //私有变量
    model.fileType = dictionary[@"fileType"];
    model.appState = dictionary[@"appState"];
    
    return model ;
}

//绑定旧的数据到新的上面
- (void) bindExistAppInfo:(YZFAppItemModel *)oldModel {
    if(oldModel) {
        self.versionOnline = self.version ;
        self.checkMd5Online= self.checkMd5;
        self.fileURLOnline = self.fileURL ;
        
        //数据迁移出来
        self.version = oldModel.version ;
        self.checkMd5= oldModel.checkMd5;
        self.fileURL = oldModel.fileURL ;
    }
}

- (BOOL) updateToNewVersion {
    if(_isCanUpdated==NO) return NO ;
    
    self.version = self.versionOnline ;
    self.checkMd5 = self.checkMd5Online ;
    self.fileURL =self.fileURLOnline ;
    
    _isCanUpdated = NO ;
    
    return YES ;
}

- (YZFAppItemModel *) downloadModelOfOnline {
    YZFAppItemModel* downloadModel = [[YZFAppItemModel alloc] init] ;
    downloadModel.appId = self.appId ;
    downloadModel.appName = self.appNameOnline ;
    downloadModel.version = self.versionOnline ;
    downloadModel.fileURL = self.fileURLOnline ;
    downloadModel.appState = self.appStateOnline ;
    downloadModel.checkMd5 = self.checkMd5Online ;
    return downloadModel ;
}

#pragma mark 验证可用性
//验证当前版本是否可用
- (BOOL) checkCurVersionAvailable {
    if (self.fileTypeValue!=FileTypeValueHtml5) return YES ;
    
    //安装目录是否存在
    NSString *installedPath = [BFLobbyAppPathTool presetAppInstalledPath:self] ;
    if ([[NSFileManager defaultManager] fileExistsAtPath:installedPath]==NO) {
        return NO ;
    }
    
    //1、检验Properties
    NSString *propertyFilePath = [BFLobbyAppPathTool appPropertyFilePath:self] ;
    if ([[NSFileManager defaultManager] fileExistsAtPath:propertyFilePath]==NO) {
        return NO ;
    }
    //2、检验MainFile
    NSString *mainFilePath = [BFLobbyAppPathTool appMainFilePath:self] ;
    if (!mainFilePath || ![BFFileTool fileExistsAtPath:mainFilePath]) {
        return NO ;
    }
    
    //3、验证MD5
    NSString *generateStr = [BFH5ZipSignTool getH5ZipPackageStringWithAppItem:installedPath] ;
    NSString *checkMd5 = self.checkMd5 ;
    if([checkMd5 isEqualToString:generateStr]==NO) {
        [[NSFileManager defaultManager] removeItemAtPath:installedPath error:nil] ;
        return NO ;
    }
    //本地存在，不需要更新，验证接口正确性
    NSString* jsPath = [installedPath stringByAppendingPathComponent:PublicJs_File] ;
    NSString *oldSign = [BFH5ZipSignTool getFileMD5WithPath:jsPath];
    NSString *newSign = [BFH5ZipSignTool getFileMD5WithPath:[BFLobbyAppPathTool publicPortPath]];
    
    if (oldSign.length==0 || [oldSign isEqualToString:newSign]==NO) {
        [[NSFileManager defaultManager] removeItemAtPath:jsPath error:nil] ;
        [[NSFileManager defaultManager] copyItemAtPath:[BFLobbyAppPathTool publicPortPath] toPath:jsPath error:NULL] ;
    }
    return YES ;
}

//验证新的版本是否可用，下载完成，未更新applist
- (BOOL) checkNewVersionAvailable {
    
    //new出新对象，模仿当前版本的验证
    YZFAppItemModel* model = [[YZFAppItemModel alloc] init] ;
    model.fileType = self.fileType ;
    model.version = self.versionOnline ;
    model.checkMd5 = self.checkMd5Online ;
    model.appId = self.appId ;
    
    return [model checkCurVersionAvailable] ;
}

//验证当前版本必须下载，若存在于bundle则不需要下载
- (BOOL) checkCurVersionMustDownload {
    if (self.fileTypeValue!=FileTypeValueHtml5) return NO ;
    
    //是否可用
    if ([self checkCurVersionAvailable]) {
        return NO ;
    }
    
    //是否存在于bundle
    NSString *presetPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"PresetHtml5Apps"] ;
    NSString *fileName = [NSString stringWithFormat:@"%@_%@.zip", self.appId, self.version] ;
    presetPath = [presetPath stringByAppendingPathComponent:fileName] ;
    
    if([[NSFileManager defaultManager] fileExistsAtPath:presetPath]) {
        return NO ;
    }
    
    return YES ;
}

//验证线上版本是否需要更新
- (BOOL) checkUpdateOnlineVersion {
    if (self.fileTypeValue!=FileTypeValueHtml5) return NO ;
    //验证版本是否是新的
    if(self.versionOnline==nil || [self.versionOnline compare:self.version]!=NSOrderedDescending) {
        return NO ;
    }
    //验证新包是否可用
    if ([self checkNewVersionAvailable]) {
        return NO ;
    }
    return YES ;
}


+ (BOOL)packageNeedUpdate:(YZFAppItemModel *)itemModel{
    
    DebugLog(@"BFLobbyAppPackageManager: 是否需要下载 %@/%@/%@", itemModel.appName, itemModel.appId, itemModel.version);
    
    //1.检验Properties
    NSString *propertyFilePath = [BFLobbyAppPathTool appPropertyFilePath:itemModel];
    if ([BFLobbyAppPathTool fileExistsAtPath:propertyFilePath]) {
        
        //2.检验MainFile
        NSString *mainFilePath = [BFLobbyAppPathTool appMainFilePath:itemModel];
        if (!mainFilePath || ![BFFileTool fileExistsAtPath:mainFilePath]) {
            DebugLog(@"BFLobbyAppPackageManager: 不存在MainFile");
            return YES;
        }
    }
    else {
        DebugLog(@"BFLobbyAppPackageManager: 不存在Properties文件");
        return YES;
    }
    
    
    
    return NO;
}

//验证是否预置在包里面
- (NSString *) presetedPathOfCurVersionInBundle {
    //是否存在于bundle
    NSString *presetPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"PresetHtml5Apps"] ;
    NSString *fileName = [NSString stringWithFormat:@"%@_%@.zip", self.appId, self.version] ;
    presetPath = [presetPath stringByAppendingPathComponent:fileName] ;
    
    if([[NSFileManager defaultManager] fileExistsAtPath:presetPath]) {
        return presetPath ;
    }
    return nil ;
}

- (BOOL) checkPreseted {
    //是否存在于bundle
    NSString *presetPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"PresetHtml5Apps"] ;
    NSString *fileName = [NSString stringWithFormat:@"%@_%@.zip", self.appId, self.version] ;
    presetPath = [presetPath stringByAppendingPathComponent:fileName] ;
    
    if([[NSFileManager defaultManager] fileExistsAtPath:presetPath]) {
        return YES ;
    }
    return NO ;
}

//移动Bundle里的子应用，只适用于folder
- (void) moveSubAppsInBunlde {
    if ([BFTool isEmptyArray:self.appList]) return ;
    NSArray *arrItems = [NSArray arrayWithArray:self.appList] ;
    
    dispatch_async(dispatch_queue_create("cn.com.bestpay.moveBundleApps", NULL) , ^{
        NSFileManager* fm = [[NSFileManager alloc] init] ;
        
        [arrItems enumerateObjectsUsingBlock:^(YZFAppItemModel* model, NSUInteger idx, BOOL * _Nonnull stop) {
            if (model.fileTypeValue==FileTypeValueHtml5) {
                NSString *installedPath = [BFLobbyAppPathTool presetAppInstalledPath:model] ;
                NSString *presetPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"PresetHtml5Apps"] ;
                NSString *fileName = [NSString stringWithFormat:@"%@_%@.zip", model.appId, model.version] ;
                presetPath = [presetPath stringByAppendingPathComponent:fileName] ;
                
                if([fm fileExistsAtPath:installedPath]==NO && [fm fileExistsAtPath:presetPath]==YES) {
                    [model installFromZipPath:presetPath fileManager:fm] ;
                    //NSLog(@"Bundle copy 成功 %@(%@), %@", model.appName, model.appId, model.version) ;
                }
                else {
                    //NSLog(@"Bundle copy 失败 %@(%@), %@", model.appName, model.appId, model.version) ;
                }
            }
        }] ;
    }) ;
}

- (NSString *)description {
    return [NSString stringWithFormat:@"name:%@, id:%@, version:%@, onlineVerison:%@ appState:%@", self.appName, self.appId, self.version, self.versionOnline, self.appState] ;
}
@end

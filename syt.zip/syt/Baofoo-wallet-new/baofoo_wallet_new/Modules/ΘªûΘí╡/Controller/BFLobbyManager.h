//
//  BFLobbyManager.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BFResourceModel.h"
#import "BFAdModel.h"
#import "YZFAppItemModel.h"
//通知
UIKIT_EXTERN NSString *const UpdateAdvertiseListFinishedNotification;

@interface BFLobbyManager : NSObject

+ (instancetype)sharedInstance;

@property (strong, nonatomic) NSArray *advertiseList; //大厅首页广告图片
- (void)downloadLaunchImage ;//下载启动页面
- (void)saveApplistVersion ;//保存App列表版本
@end

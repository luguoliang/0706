
//  BFAppManager.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFAppManager.h"
#import <ZipArchive.h>
#import "BFH5ZipSignTool.h"
#import "ReachabilityTool.h"
#import "Reachability.h"
#import "BFLobbyAppPathTool.h"

#import "BFRequest.h"
#import "BFLobbyManager.h"

#import "BFAPPItemsModel.h"

@interface BFAppDownloadTask : NSObject
@property(nonatomic, assign) BOOL manualDownload ;
@property(nonatomic, strong) AppCollectionCell* cell ;
@property(nonatomic, strong) YZFAppItemModel* originModel ;
@property(nonatomic, strong) YZFAppItemModel* downloadModel ;



@property(nonatomic, strong) NSProgress *progress ;
@property(nonatomic, strong) NSURLSessionDownloadTask* downloadTask ;
@end

@implementation BFAppDownloadTask

- (void) unzip {
    dispatch_queue_t installQueue = dispatch_queue_create("cn.com.bestpay.installApp", nil) ;
    dispatch_async(installQueue, ^{
        
        NSString* zipPath = [BFLobbyAppPathTool appDownloadSavedPath:self.downloadModel] ;
        NSFileManager* fm = [[NSFileManager alloc] init] ;
        [_downloadModel installFromZipPath:zipPath fileManager:fm];
        
        DebugLog(@"下载结束安装 %@/%@", self.downloadModel.appName, self.downloadModel.version);
        [fm removeItemAtPath:zipPath error:nil] ;
        
        _originModel.isCheckCurVersionAvailable =  [_originModel checkCurVersionAvailable] ;
        _originModel.isCheckNewVersionAvailable =  [_originModel checkNewVersionAvailable] ;
        _originModel.isCheckUpdateOnlineVersion =  [_originModel checkUpdateOnlineVersion] ;
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if (_originModel.version && _downloadModel.version && [_originModel.version compare:_downloadModel.version]==NSOrderedAscending) {
                _originModel.isCanUpdated = YES ;
            }
            
            if(_cell) {
                _cell.status = AppStatusNormal ;
            }
            if(self.manualDownload) {
                if(!_originModel.isCheckCurVersionAvailable) {
                    [UIAlertView showWithMessage:[NSString stringWithFormat:@"无法打开 %@，请稍后再试", _downloadModel.appName]  delegate:nil];
                }
                [[NSNotificationCenter defaultCenter] postNotificationName:BFAppInstallFinishedNotification object:_downloadModel] ;
            }
        });
    }) ;
}


@end



@interface BFAppManager()  {
    BOOL hasUpdateRquest ;
    BOOL isListRequestFinished ;
    BOOL isAppHasDownloaded ;
    BOOL isOnRequestList ;
}
//应用模型, 最新的一份，包含为下载的，未审核的
@property(nonatomic, copy) NSArray* arrAppItems ;

@property(nonatomic, strong) AFURLSessionManager *autoSessionManager ;//自动
@property(nonatomic, strong) AFURLSessionManager *manualSessionManager ;//手动

@property(nonatomic, strong) NSMutableDictionary* dictAutoTask ;
@property(nonatomic, strong) NSMutableDictionary* dictmanualTask ;

@property(nonatomic, strong) Reachability *reachability ;

@end


@implementation BFAppManager
#pragma mark Life Circle

+ (instancetype) shareInstance {
    static BFAppManager *appManager = nil ;
    static dispatch_once_t token = 0 ;
    
    dispatch_once(&token, ^{
        appManager = [[BFAppManager alloc] init] ;
    }) ;
    
    return appManager ;
}

- (id) init {
    self = [super init] ;
    if (self) {
        
        //监听网络变化
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reachabilityChanged:) name:kReachabilityChangedNotification object:nil] ;
        
        self.reachability = [Reachability reachabilityForInternetConnection];
        [self.reachability startNotifier];
        
        _isApplistChanged = YES ;
        _dictAutoTask = [NSMutableDictionary dictionary] ;
        _dictmanualTask = [NSMutableDictionary dictionary] ;
        _autoSessionManager   = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]] ;
        _manualSessionManager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]] ;
        [self initAppItems] ;
    }
    return self ;
}

#pragma mark UI

#pragma mark Button & Gesture Events

#pragma mark All Delegates

#pragma mark Reachability related

-(void) reachabilityChanged:(NSNotification*) notification {
    if([self.reachability currentReachabilityStatus] == ReachableViaWiFi) {
        if(isListRequestFinished) {
            [self downloadRequiredApp] ;
        }
    }
    else if([self.reachability currentReachabilityStatus] == ReachableViaWWAN) {
        //NSLog(@"网络_移动") ;
    }
    else if([self.reachability currentReachabilityStatus] == NotReachable) {
        //NSLog(@"无网络") ;
    }
}



#pragma mark Private Methods

- (void) initAppItems {
    //取document
    NSString* path = [BFFilePathTool lobbyAppListFilePath] ;
    self.arrAppItems = [NSKeyedUnarchiver unarchiveObjectWithFile:path] ;
    
    //取bundle
    if(self.arrAppItems.count==0) {
        NSString *bundlePath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"PresetLobbyAppList"] ;
        bundlePath = [bundlePath stringByAppendingPathComponent:LobbyAppListFileName] ;
        self.arrAppItems = [NSKeyedUnarchiver unarchiveObjectWithFile:bundlePath] ;
    }
    
    
    
    NSMutableArray *arr = [NSMutableArray array];
    NSArray *nameArr = @[@"转账",@"信用卡还款",@"通信缴费",@"生活缴费",
                         @"账户余额",@"账单明细",@"充值",@"提现",
                         @"红包",@"宝付充值卡",@"安全中心",@"更多"];
    NSArray *appIdArr = @[@"001",@"002",@"003",@"004",
                          @"005",@"006",@"007",@"010",
                          @"011",@"012",@"013",@"014"];
    NSArray *fileTypeArr = @[@"1",@"0",@"0",@"0",
                             @"1",@"0",@"0",@"0",
                             @"1",@"0",@"1",@"1"];
    NSArray *fileURLArr = @[@"",@"",@"",@"",
                            @"",
                            [NSString stringWithFormat:@"%@%@",BFWalletBaseURL,wallet_zd],
                            [NSString stringWithFormat:@"%@%@",BFWalletBaseURL,myAccount_Recharge],
                            [NSString stringWithFormat:@"%@%@",BFWalletBaseURL,myAccount_Withdraw],
                            @"",
                            [NSString stringWithFormat:@"%@%@",BFWalletBaseURL,wallet_hb],@"",@""];
    NSArray *isCheckCurVersionAvailableArr = @[@"0",@"0",@"0",@"0",
                                               @"1",@"1",@"1",@"1",
                                               @"1",@"1",@"1",@"1"];
    for (int i = 0; i<_arrAppItems.count; i ++) {
        YZFAppItemModel *y = _arrAppItems[i];
        y.appName = nameArr[i];
        y.appId = appIdArr[i];
        y.fileTypeValue = [fileTypeArr[i] integerValue];
        y.fileURL = fileURLArr[i];
        y.isCheckCurVersionAvailable = [isCheckCurVersionAvailableArr[i] boolValue];
        y.appStateValue = AppStateValueNormal;
        [arr addObject:y];
    }
    [self saveApplist];
    
}

//请求线上应用列表
- (void) requestAppList {
    if(isOnRequestList) return ;
    isOnRequestList = YES ;
   
}


//下载必须下载的应用
- (void)downloadRequiredApp {
    //NSLog(@"--------------------------开始必要包----------------------------------") ;
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NetworkState networkstate = [ReachabilityTool checkNetworkState];
        if(networkstate != NetworkStateWiFi) {
            return ;
        }
        isAppHasDownloaded = YES ;
        
        for (YZFAppItemModel* model in _arrH5Apps) {
            if (model.isCheckCurVersionMustDownload && [_dictAutoTask objectForKey:model.appId]==nil && [_dictmanualTask objectForKey:model.appId]==nil) {
                BFAppDownloadTask* appDownloadTask = [self downloadAppModel:model originModel:model sessionManager:_autoSessionManager]  ;
                [_dictAutoTask setValue:appDownloadTask forKey:model.appId] ;
                //NSLog(@"开始下载 必须包：%@_%@ url:%@", model.appName, model.version, model.fileURL) ;
            }
        }
        if (_dictAutoTask.allKeys.count==0) {
            [self downloadUpdatedApp] ;
        }
    });
}

//下载升级的应用
- (void)downloadUpdatedApp {
    //NSLog(@"--------------------------开始升级包----------------------------------") ;
    dispatch_async(dispatch_get_main_queue(), ^{
        NetworkState networkstate = [ReachabilityTool checkNetworkState];
        if(networkstate != NetworkStateWiFi) {
            return ;
        }
        
        hasUpdateRquest = YES ;
        for (YZFAppItemModel* model in _arrH5Apps) {
            if (model.isCheckUpdateOnlineVersion && [_dictAutoTask objectForKey:model.appId]==nil && [_dictmanualTask objectForKey:model.appId]==nil) {
                BFAppDownloadTask* appDownloadTask = [self downloadAppModel:[model downloadModelOfOnline] originModel:model sessionManager:_autoSessionManager]  ;
                [_dictAutoTask setValue:appDownloadTask forKey:model.appId] ;
                //NSLog(@"开始下载 更新包：%@ %@->%@ url:%@", [model downloadModelOfOnline].appName, model.version, [model downloadModelOfOnline].version, [model downloadModelOfOnline].fileURL) ;
                
            }
        }
    });
}

- (BFAppDownloadTask *) downloadAppModel:(YZFAppItemModel *)downloadModel originModel:(YZFAppItemModel *)originModel sessionManager:(AFURLSessionManager *)sessionManager {
    
    BFAppDownloadTask* downloadTask = [[BFAppDownloadTask alloc] init] ;
    downloadTask.originModel = originModel ;
    downloadTask.downloadModel = downloadModel ;
    
    return downloadTask ;
}



//合并应用列表
- (void) mergeAppList:(NSArray *)appList {
    NSArray* arrH5Apps = [self allAppOfType:FileTypeValueHtml5 applist:appList] ;
    NSArray* arrNative = [self allAppOfType:FileTypeValueNative applist:appList] ;
    NSArray* arrFolder = [self allAppOfType:FileTypeValueFolder applist:appList] ;
    NSArray* _arrFolder = [self allAppOfType:FileTypeValueFolder applist:_arrAllApp] ;
    
    [self mergeOldList:_arrH5Apps toList:arrH5Apps] ;
    [self mergeOldList:_arrNative toList:arrNative] ;
    [self mergeOldList:_arrFolder toList:arrFolder] ;
}

- (void) mergeOldList:(NSArray *)oldList toList:(NSArray *)appList {
    for (YZFAppItemModel* model in appList) {
        YZFAppItemModel* old = [self modelOfAppId:model.appId atList:oldList] ;
        //H5，非维护，非强制更新, 非必需下载
        if (old && model.fileTypeValue==FileTypeValueHtml5
            && (model.appStateValue>AppStateValueWaitingForCheck && model.appStateValue<AppStateValueUpdatedRequired) && ![old checkCurVersionMustDownload]) {
            [model bindExistAppInfo:old] ;
        }
    }
}

- (YZFAppItemModel *) modelOfAppId:(NSString *)appId atList:(NSArray *)appList {
    for (YZFAppItemModel* model in appList) {
        if ([appId isEqualToString:model.appId]) {
            return model ;
        }
    }
    return nil ;
}

//轮询是否有更新
- (void) scanNewLocalVersion {
    _isCanUpdateToNewVersion = NO ;
    
    //dispatch_async(dispatch_queue_create("cn.com.bestpay.scanLocal", NULL) , ^{
    for (YZFAppItemModel* model in _arrH5Apps) {
        model.isCanUpdated = (model.version!=nil && [model.version compare:model.versionOnline]==NSOrderedAscending && [model checkNewVersionAvailable]) ;
        if (model.isCanUpdated) {
            _isCanUpdateToNewVersion = YES ;
        }
        //本地是否必须下载
        model.isCheckCurVersionMustDownload = [model checkCurVersionMustDownload] ;
        //更新版本
        model.isCheckUpdateOnlineVersion = [model checkUpdateOnlineVersion] ;
    }
    //}) ;
}

#pragma mark Setters & Getters


- (void) setArrAppItems:(NSMutableArray *)arrAppItems {
    if(_arrAppItems!=arrAppItems) {
        _arrAppItems = arrAppItems ;
        _arrOriginApps = arrAppItems ;
        
        _arrH5Apps = [self allAppOfType:FileTypeValueHtml5 applist:arrAppItems] ;
        _arrNative = [self allAppOfType:FileTypeValueNative applist:arrAppItems] ;
        _arrAllApp = [_arrNative arrayByAddingObjectsFromArray:_arrH5Apps] ;
        
        _isApplistChanged = YES ;
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:BFApplistDidChangedNotification object:nil] ;
        });
    }
}

- (NSMutableArray *) allAppOfType:(FileTypeValue)type applist:(NSArray *)applist {
    NSMutableArray* arrAllApp = [NSMutableArray array] ;
    for (YZFAppItemModel *model in applist) {
        if(model.fileTypeValue==type) {
            [arrAllApp addObject:model] ;
        }
        else if(model.fileTypeValue==FileTypeValueFolder && [BFTool isEmptyArray:model.appList]==NO) {
            NSArray* arr = [self allAppOfType:type applist:model.appList] ;
            if(arr.count) {
                [arrAllApp addObjectsFromArray:arr] ;
            }
        }
    }
    return arrAllApp ;
}


#pragma mark Public Methods

//移动Bundle里的预置H5，主大厅
- (void) moveBundleApps {
    if (_arrAppItems.count==0) return ;
    NSArray *arrItems = [NSArray arrayWithArray:_arrAppItems] ;
    
    dispatch_async(dispatch_queue_create("cn.com.baofoo.moveBundleApps", NULL) , ^{
        
        NSFileManager* fm = [[NSFileManager alloc] init] ;
        
        [arrItems enumerateObjectsUsingBlock:^(YZFAppItemModel* model, NSUInteger idx, BOOL * _Nonnull stop) {
            if (model.fileTypeValue==FileTypeValueHtml5) {
                NSString *installedPath = [BFLobbyAppPathTool presetAppInstalledPath:model] ;
                NSString *presetPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"PresetHtml5Zip"] ;
                NSString *fileName = [NSString stringWithFormat:@"%@_%@.zip", model.appId, model.version] ;
                presetPath = [presetPath stringByAppendingPathComponent:fileName] ;
                
                if([fm fileExistsAtPath:installedPath]==NO && [fm fileExistsAtPath:presetPath]==YES) {
                    [model installFromZipPath:presetPath fileManager:fm] ;
                    //NSLog(@"Bundle copy 成功 %@(%@), %@", model.appName, model.appId, model.version) ;
                }
                else {
                    //NSLog(@"Bundle copy 失败 %@(%@), %@", model.appName, model.appId, model.version) ;
                }
            }
        }] ;
    }) ;
}

//更新H5应用(下载的新包安装到路径)
- (BOOL) installH5Apps {
    if(_isCanUpdateToNewVersion) {
        NSMutableArray* _arrDeletedPaths = [NSMutableArray array] ;
        [_arrH5Apps enumerateObjectsUsingBlock:^(YZFAppItemModel* model, NSUInteger idx, BOOL * _Nonnull stop) {
            if (model.isCanUpdated) {
                [_arrDeletedPaths addObject:[BFLobbyAppPathTool appInstalledPath:model] ] ;
                [model updateToNewVersion] ;
                //NSLog(@"更新H5包成功：%@(%@), v%@ -> v%@", model.appName, model.appId, model.version, model.versionOnline) ;
            }
        }] ;
        
        if (_arrDeletedPaths.count) {
            dispatch_async(dispatch_queue_create("cn.com.baofoo.deletePath", NULL) , ^{
                NSFileManager* fm = [[NSFileManager alloc] init] ;
                for (NSString* path in _arrDeletedPaths) {
                    [fm removeItemAtPath:path error:NULL] ;
                }
                [_arrDeletedPaths removeAllObjects] ;
                [BFFileTool saveModelObject:_arrAppItems toFile:[BFFilePathTool lobbyAppListFilePath]] ;
            }) ;
            return YES ;
        }
    }
    _isCanUpdateToNewVersion = NO ;
    return NO ;
}

- (BOOL) checkManualDownloadState:(AppCollectionCell *)cell {
    YZFAppItemModel* model = cell.model ;
    
    BFAppDownloadTask* taskManual = [_dictmanualTask objectForKey:model.appId] ;
    if(taskManual!=nil) {
        
        [taskManual.progress removeObserver:taskManual.cell forKeyPath:@"fractionCompleted"] ;
        [taskManual.progress addObserver:cell forKeyPath:@"fractionCompleted" options:NSKeyValueObservingOptionNew context:nil] ;
        taskManual.cell = cell ;
        
        NSInteger rate = taskManual.progress.fractionCompleted * 100 ;
        if(rate>100) {
            rate = 100 ;
        }
        cell.progressLabel.text = [NSString stringWithFormat:@"%ld%%", rate] ;
        
        return YES ;
    }
    return NO ;
}

- (void) downloadAppOfCell:(AppCollectionCell *) cell {
    YZFAppItemModel* model = cell.model ;
    
    
    BFAppDownloadTask* task = [_dictAutoTask objectForKey:model.appId] ;
    if ([task.downloadModel.version isEqualToString:model.version]) {
        [task.downloadTask cancel] ;
        [_dictAutoTask removeObjectForKey:model.appId] ;
    }
    
    BFAppDownloadTask* taskManual = [_dictmanualTask objectForKey:model.appId] ;
    if(taskManual==nil) {
        taskManual = [self downloadAppModel:model originModel:model sessionManager:_manualSessionManager] ;
        taskManual.manualDownload = YES ;
        [_dictmanualTask setValue:taskManual forKey:model.appId] ;
    }
    else {
        [taskManual.progress removeObserver:taskManual.cell forKeyPath:@"fractionCompleted"] ;
    }
    
    //绑定cell
    
    taskManual.cell = cell ;
    
    //existTask
    cell.status = AppStatusDownloading ;
    [taskManual.progress addObserver:cell forKeyPath:@"fractionCompleted" options:NSKeyValueObservingOptionNew context:nil] ;
}

- (void) downloadAppOfModel:(YZFAppItemModel *) model {
    BFAppDownloadTask* task = [_dictAutoTask objectForKey:model.appId] ;
    if ([task.downloadModel.version isEqualToString:model.version]) {
        [task.downloadTask cancel] ;
        [_dictAutoTask removeObjectForKey:model.appId] ;
    }
    BFAppDownloadTask* taskManual = [_dictmanualTask objectForKey:model.appId] ;
    if(taskManual==nil) {
        taskManual = [self downloadAppModel:model originModel:model sessionManager:_manualSessionManager] ;
        taskManual.manualDownload = YES ;
        [_dictmanualTask setValue:taskManual forKey:model.appId] ;
    }
}

- (void) saveApplist {
    //NSLog(@"保存列表") ;
    [BFFileTool saveModelObject:_arrAppItems toFile:[BFFilePathTool lobbyAppListFilePath]] ;
}

@end


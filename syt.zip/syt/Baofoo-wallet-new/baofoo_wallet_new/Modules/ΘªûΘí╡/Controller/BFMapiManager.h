//
//  BFMapiManager.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>

#import "BFRequestResponse.h"

/**
 * 请求服务分组，按照“分组别名(二级服务)”区分，即"api/"之后的名称命名，按字母先后顺序排序
 * 注：launch,oauth服务相对早期，故略有调整
 */
typedef NS_ENUM(NSInteger, ReqServiceType) {
    ReqServiceTypeAccount  = 1,     //@"account/api/account/V1/"
    ReqServiceTypeBank     = 2,     //@"account/api/bank/V1/"
    ReqServiceTypeBarCode  = 3,     //@"payment/api/barCode/V1/"
    ReqServiceTypeCode     = 4,     //@"account/api/code/V1/"
    ReqServiceTypeFace     = 5,     //@"payment/api/face/V1/"
    ReqServiceTypeFortune  = 6,     //@"account/api/fortune/V1/"
    ReqServiceTypeLaunch   = 7,     //@"launch/api/"
    ReqServiceTypeLogin    = 8,     //@"account/api/login/V1/"
    ReqServiceTypeMessage  = 9,     //@"support/api/message/v1/"
    ReqServiceTypeOauth    = 10,    //@"oauth/"
    ReqServiceTypePrize    = 11,    //@"account/api/prize/V1/"
    ReqServiceTypeQuery    = 12,    //@"account/api/query/V1/"
    ReqServiceTypeSecurity = 13,    //@"account/api/security/V1/"
    ReqServiceTypeTransfer = 14,    //@"account/api/transfer/V1/"
    ReqServiceTypeVoucher  = 15     //@"account/api/voucher/V1/"
};

@interface BFMapiManager : AFHTTPSessionManager


+ (BFMapiManager *)sharedManager;

/**
 *  请求基础API（POST）
 *
 *  @param service 服务名
 *  @param name    请求名
 *  @param params  参数
 *  @param block   回调block
 *
 *  @return 请求task
 */
+ (NSURLSessionDataTask *)POSTService:(ReqServiceType)service
                                 name:(NSString *)name
                               params:(NSDictionary *)params
                                block:(BFRequestResponseBlock)block;

/**
 *  请求基础API（GET）
 *
 *  @param service 服务名
 *  @param name    请求名
 *  @param params  参数
 *  @param block   回调block
 *
 *  @return 请求task
 */
+ (NSURLSessionDataTask *)GETService:(ReqServiceType)service
                                name:(NSString *)name
                              params:(NSDictionary *)params
                               block:(BFRequestResponseBlock)block;

@end

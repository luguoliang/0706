//
//  AppCollectionViewCell.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BFAppItemsModel.h"

//CollectionCell的状态定义
typedef NS_ENUM(NSInteger, AppItemsStatus) {
    AppItemsStatusNormal = 0,       //正常状态
    AppItemsStatusWWANDownloading, //移动网络下载中
    AppItemsStatusWWANSuspend,     //移动网络暂停下载
    AppItemsStatusWiFiDownloading, //WiFi下载中
    AppItemsStatusNeedUpdate,      // 应用需要更新
    AppItemsStatusDownloadCompleted, //下载完成
    AppItemsStatusMaintain,          // 维护中
    AppItemsStatusNotNet            //无网络
};

@interface AppCollectionViewCell : UICollectionViewCell

@property (strong, nonatomic) BFAppItemsModel *model;
@property (assign, nonatomic) AppItemsStatus appStatus; //app的下载状态
@property (strong, nonatomic) UILabel *progressLabel; //app的下载进度

@end

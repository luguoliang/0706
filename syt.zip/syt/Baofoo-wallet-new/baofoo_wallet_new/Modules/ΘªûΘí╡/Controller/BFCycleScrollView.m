//
//  BFCycleScrollView.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFCycleScrollView.h"

@interface BFPageControl : UIPageControl

@end

@implementation BFPageControl

- (void) setCurrentPage:(NSInteger)currentPage {
    [super setCurrentPage:currentPage];
    [self updateDots];
}

- (void) updateCurrentPageDisplay {
    [super updateCurrentPageDisplay];
    [self updateDots];
}

#pragma mark - (Private)
- (void) updateDots {
    for (UIView* dotView in self.subviews) {
        dotView.layer.borderWidth = 0.8 ;
        dotView.layer.borderColor = [UIColor whiteColor].CGColor ;
    }
}
@end

@interface BFCycleScrollView ()<BFPerPageViewDelegate,UIScrollViewDelegate>

@property (nonatomic, weak) UIScrollView *contentScrollView;
@property (nonatomic, strong) NSTimer *time;
@property (nonatomic, weak) UIPageControl *pageControl;
@property (nonatomic, assign) NSInteger currentIndex;
@end

@implementation BFCycleScrollView

- (void)setScrollData:(NSArray *)scrollData{
    _scrollData = scrollData;
    
    if (!scrollData || scrollData.count == 0 ) {
        [self.contentScrollView.subviews enumerateObjectsUsingBlock:^(UIView *obj, NSUInteger idx, BOOL *stop) {
            if([obj isKindOfClass:[BFPerPageView class]]){
                [obj removeFromSuperview];
            }
        }];
        if (self.time.isValid) {
            [self.time invalidate];
            self.time = nil;
        }
        self.hidden = YES;
        return;
    }
    
    [self refreshView];
    [self setupTime];
}

- (void)refreshView{
    self.hidden = NO;
    NSMutableArray *array = [NSMutableArray arrayWithArray:_scrollData];
    [array insertObject:[_scrollData lastObject] atIndex:0];
    [array insertObject:[_scrollData firstObject] atIndex:_scrollData.count + 1];
    
    for (int i = 0; i < array.count; ++i) {
        BFAdModel *adModel = array[i];
        BFPerPageView *perPageView = [BFPerPageView createPerPageViewWithFrame: CGRectMake(i * self.size_W, 0, self.size_W, self.size_H) target:self];
        perPageView.adModel = adModel;
        [self.contentScrollView addSubview:perPageView];
    }
    self.contentScrollView.contentSize = CGSizeMake(array.count * self.contentScrollView.size_W, self.contentScrollView.size_H);
    self.contentScrollView.contentOffset = CGPointMake(self.contentScrollView.size_W, 0);
    self.pageControl.numberOfPages = self.scrollData.count;
    self.pageControl.currentPage = 0;
}

- (void)setupTime{
    if (self.time.isValid) {
        [self.time invalidate];
        self.time = nil;
    }
    self.time = [NSTimer timerWithTimeInterval:5.0 target:self selector:@selector(autoScroll) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:self.time forMode:NSRunLoopCommonModes];
}

- (void)autoScroll{
    NSInteger curPage = self.currentIndex;
    curPage ++;
    [self.contentScrollView scrollRectToVisible:CGRectMake(curPage * self.contentScrollView.size_W, 0, self.contentScrollView.size_W, self.contentScrollView.size_H) animated:YES];
}

- (void)perPageViewDidClick:(BFPerPageView *)perPageView{
    if (_delegate && [_delegate respondsToSelector:@selector(cycleScrollView:didClick:)]) {
        [_delegate cycleScrollView:self didClick:perPageView];
    }
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    self.currentIndex = scrollView.contentOffset.x/scrollView.size_W ;
    self.pageControl.currentPage = self.currentIndex - 1;
    
    if (self.currentIndex >= self.scrollData.count + 1) {
        [scrollView scrollRectToVisible:CGRectMake(scrollView.size_W , 0, scrollView.size_W, scrollView.size_H) animated:NO];
        self.pageControl.currentPage = 0;
    }
    if (self.currentIndex == 0) {
        [scrollView scrollRectToVisible:CGRectMake(scrollView.size_W * self.scrollData.count, 0, scrollView.size_W, scrollView.size_H) animated:NO];
        self.pageControl.currentPage = self.scrollData.count;
    }
}

#pragma mark - View Life Cycle

+ (instancetype)createWithFrame:(CGRect)frame target:(id)target{
    BFCycleScrollView *cycleScrollView = [[self alloc] initWithFrame:frame];
    cycleScrollView.delegate = target;
    return cycleScrollView;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        UIScrollView *contentScrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
        contentScrollView.backgroundColor = [UIColor clearColor];
        contentScrollView.bounces = NO;
        contentScrollView.pagingEnabled = YES;
        contentScrollView.showsHorizontalScrollIndicator = NO;
        contentScrollView.showsVerticalScrollIndicator = NO;
        contentScrollView.delegate = self;
        self.contentScrollView = contentScrollView;
        [self addSubview:contentScrollView];
        
        UIPageControl *pageControl = [[BFPageControl alloc] init];
        pageControl.hidesForSinglePage = YES;
        pageControl.center = CGPointMake(self.center_X, self.size_H - 8);
        [pageControl sizeToFit];
        pageControl.currentPageIndicatorTintColor = UIColorRgb(255, 45, 85);
        pageControl.pageIndicatorTintColor = [UIColor colorWithRed:230/255.0 green:230/255.0 blue:230/255.0 alpha:0.5];
        self.pageControl = pageControl;
        [self addSubview:self.pageControl];
    }
    return self;
}

@end
//
//  BFLobbyAppPackageManager.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFLobbyAppPackageManager.h"
#import "BFH5ZipSignTool.h"
#import <ZipArchive.h>

@interface BFLobbyAppPackageManager ()
{
    NSMutableDictionary *requestDic;
    ZipArchive *zipArchive;
}
@end

@implementation BFLobbyAppPackageManager

+ (instancetype)defaultManager{
    static BFLobbyAppPackageManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[BFLobbyAppPackageManager alloc] init];
    });
    
    return manager;
}

- (instancetype)init{
    if (self = [super init]) {
        
        requestDic = [[NSMutableDictionary alloc] init];
        
        zipArchive = [[ZipArchive alloc] init];
    }
    return self;
}

#pragma mark - Package Install

- (BOOL)installPackage:(YZFAppItemModel *)itemModel{
    
    BOOL isOK = [zipArchive UnzipOpenFile:[BFLobbyAppPathTool appDownloadSavedPath:itemModel]];
    if (isOK) {
        BOOL write = [zipArchive UnzipFileTo:[BFLobbyAppPathTool appInstalledPath:itemModel] overWrite:YES];
        if (write) {
            DebugLog(@"LobbyAppPackageManager: 安装[%@/%@/%@]（新）成功", itemModel.appName, itemModel.appId,itemModel.version);
            [self verifyPublicPort:[BFLobbyAppPathTool appPublicJsFilePath:itemModel]];
            
            [self deleteDownloadSaveFile:itemModel];
            
            return YES;
        }
        else {
            DebugLog(@"LobbyAppPackageManager: 安装[%@/%@/%@]（新）失败", itemModel.appName, itemModel.appId,itemModel.version);
        }
    }
    return NO;
}

//安装预置包
- (BOOL)installPresetPackage:(YZFAppItemModel *)itemModel{
    
    //
    NSString *folderPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"PresetHtml5Apps"];
    NSString *zipName = [NSString stringWithFormat:@"%@_%@.zip", itemModel.appId, itemModel.version];
    NSString *zipSorucePath = [folderPath stringByAppendingPathComponent:zipName];
    
    if ([zipArchive UnzipOpenFile:zipSorucePath]) {
        NSString *installedPath = [BFLobbyAppPathTool presetAppInstalledPath:itemModel];
        if ([zipArchive UnzipFileTo:installedPath overWrite:YES]) {
            
            DebugLog(@"LobbyAppPackageManager: 安装[%@/%@/%@]（预置）成功", itemModel.appName, itemModel.appId, itemModel.version);
            [self verifyPublicPort:[BFLobbyAppPathTool presetAppPublicJsFilePath:itemModel]];
            return YES;
        }
        else {
            DebugLog(@"LobbyAppPackageManager: 安装[%@/%@/%@]（预置）失败", itemModel.appName, itemModel.appId, itemModel.version);
            return NO;
        }
    }
    else {
        return NO;
    }
}

- (BOOL)verifyPublicPort:(NSString *)path{
    
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:path]) {
        NSString *oldSign = [BFH5ZipSignTool getFileMD5WithPath:path];
        NSString *newSign = [BFH5ZipSignTool getFileMD5WithPath:[BFLobbyAppPathTool publicPortPath]];
        
        if (![newSign isEqualToString:oldSign]) {
            [self installPublicPort:path];
            return NO;
        }
    }
    else {
        
        [self installPublicPort:path];
        return NO;
    }
    return YES;
}

- (void)installPublicPort:(NSString *)path{
    
    NSError *error;
    [[NSFileManager defaultManager] copyItemAtPath:[BFLobbyAppPathTool publicPortPath] toPath:path error:&error];
    //    if (error) {
    //        DebugLog(@"LobbyAppPackageManager: 安装公共接口失败，Error = %@", error);
    //    }
    //    else {
    //        DebugLog(@"LobbyAppPackageManager: 安装公共接口成功");
    //    }
}

#pragma mark - Package Delete

- (void)deleteDownloadSaveFile:(YZFAppItemModel *)item{
    
    NSError *error;
    [[NSFileManager defaultManager] removeItemAtPath:[BFLobbyAppPathTool appDownloadSavedPath:item] error:&error];
    if (error) {
        DebugLog(@"delete %@ download package error %@", item.appName, error);
    }
}

- (void)deleteInstalledPackage:(YZFAppItemModel *)item{
    NSString *path = [BFLobbyAppPathTool appInstalledPath:item];
    if ([BFLobbyAppPathTool removeFile:path]) {
        //        DebugLog(@"LobbyAppPackageManager: 删除[%@/%@/%@]本地包成功", item.appName, item.appId, item.version);
    }
    else {
        //        DebugLog(@"LobbyAppPackageManager: 删除[%@/%@/%@]本地包失败", item.appName, item.appId, item.version);
    }
}

#pragma mark - Package Method

//判断本地包是否存在
+ (BOOL)packageExited:(YZFAppItemModel *)itemModel{
    NSString *path = [BFLobbyAppPathTool appInstalledPath:itemModel];
    return [[NSFileManager defaultManager] fileExistsAtPath:path];
}

//验证包MD5
+ (BOOL)packageVerified:(YZFAppItemModel *)itemModel{
    
    NSString *path = [BFLobbyAppPathTool appInstalledPath:itemModel];
    NSString *generateStr = [BFH5ZipSignTool getH5ZipPackageStringWithAppItem:path];
    
    //    DebugLog(@"%@/%@/%@ CheckMD5:%@ 本地MD5:%@", itemModel.appName, itemModel.appId, itemModel.version,itemModel.checkMd5, generateStr);
    
    if ([itemModel.checkMd5 isEqualToString:generateStr]) {
        return YES;
    }
    return NO;
}

//判断本地包是否需要下载
+ (BOOL)packageNeedUpdate:(YZFAppItemModel *)itemModel{
    
    DebugLog(@"BFLobbyAppPackageManager: 是否需要下载 %@/%@/%@", itemModel.appName, itemModel.appId, itemModel.version);
    
    //1.检验Properties
    NSString *propertyFilePath = [BFLobbyAppPathTool appPropertyFilePath:itemModel];
    if ([BFLobbyAppPathTool fileExistsAtPath:propertyFilePath]) {
        
        //2.检验MainFile
        NSString *mainFilePath = [BFLobbyAppPathTool appMainFilePath:itemModel];
        if (!mainFilePath || ![BFFileTool fileExistsAtPath:mainFilePath]) {
            DebugLog(@"BFLobbyAppPackageManager: 不存在MainFile");
            return YES;
        }
    }
    else {
        DebugLog(@"BFLobbyAppPackageManager: 不存在Properties文件");
        return YES;
    }
    
    //3.检验MD5
    if (![[self class] packageVerified:itemModel]) {
        DebugLog(@"BFLobbyAppPackageManager: MD5不对");
        return YES;
    }
    
    return NO;
}

/*
 + (BOOL)packagePauseDownloading:(YZFAppItemModel *)itemModel{
 for (BFAppDownloadReferenceModel *tempRef in [BFLobbyAppDownloadManager defaultManager].downloadingReferenceList) {
 if ([itemModel.appId isEqualToString:tempRef.appId] && [itemModel.version isEqualToString:tempRef.version]) {
 return tempRef.isPauseDownloading;
 }
 }
 
 return NO;
 }*/

//判断本地包临时文件是否已下载
+ (BOOL)packageDownloading:(YZFAppItemModel *)itemModel{
    return [[NSFileManager defaultManager] fileExistsAtPath:[BFLobbyAppPathTool appDownloadTempPath:itemModel]];
}

//获取最新版本号
/*xie
 + (NSString *)theNewestVersion:(YZFAppItemModel *)itemModel{
 
 for (YZFAppItemModel *model in [BFLobbyAppManager defaultManager].allHtml5Apps) {
 if ([model.appId isEqualToString:itemModel.appId]) {
 return model.version;
 }
 }
 return @"";
 }*/

+ (NSString *)getPackageReceivedSize:(YZFAppItemModel *)itemModel{
    return [BFLobbyAppPathTool getFileDataSize:[BFLobbyAppPathTool appDownloadTempPath:itemModel]];
}

/*
 + (NSString *)getPackageTotalSize:(YZFAppItemModel *)itemModel{
 for (BFAppDownloadReferenceModel *tempRef in [BFLobbyAppDownloadManager defaultManager].downloadingReferenceList) {
 if ([itemModel.appId isEqualToString:tempRef.appId] && [itemModel.version isEqualToString:tempRef.version]) {
 return tempRef.fileTotalSize;
 }
 }
 return @"0";
 }*/

#pragma mark - 包属性文件解析

+ (BOOL)compareVersionForItem:(YZFAppItemModel *)itemModel propertyFile:(NSString *)propertyFile{
    
    NSString *propertyVer = [[self class] propertyVersionItem:itemModel];
    if ([propertyVer isEqualToString:itemModel.version]) {
        return YES;
    }
    return NO;
}

+ (NSString *)propertyVersionItem:(YZFAppItemModel *)itemModel{
    return [[[self class] propertyDictionaryForItem:itemModel] objectForKey:@"VERSION"];
}

+ (NSString *)propertyKeyForItem:(YZFAppItemModel *)itemModel{
    return [[[self class] propertyDictionaryForItem:itemModel] objectForKey:@"KEY"];
}

+ (NSString *)propertyMainItem:(YZFAppItemModel *)itemModel{
    return [[[self class] propertyDictionaryForItem:itemModel] objectForKey:@"MAIN"];
}

+ (NSDictionary *)propertyDictionaryForItem:(YZFAppItemModel *)item{
    NSString *propertyFile = [BFLobbyAppPathTool appPropertyFilePath:item];
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    
    NSString *contents = [[NSString alloc] initWithContentsOfFile:propertyFile encoding:NSUTF8StringEncoding error:nil];
    
    NSArray *array = [contents componentsSeparatedByString:@"\n"];
    if ([array count]) {
        for (int i = 0; i < [array count]; i ++) {
            NSString *pStr = [array objectAtIndex:i];
            NSArray *kvArray = [pStr componentsSeparatedByString:@"="];
            if ([kvArray count] != 2) {
                continue;
            }
            NSString *key = [kvArray objectAtIndex:0];
            key = [key stringByReplacingOccurrencesOfString:@"\b" withString:@""];
            key = [key stringByReplacingOccurrencesOfString:@"\r" withString:@""];
            key = [key stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            key = [key stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            key = [key stringByReplacingOccurrencesOfString:@"\0" withString:@""];
            NSString *value = [kvArray objectAtIndex:1];
            value = [value stringByReplacingOccurrencesOfString:@"\b" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"\r" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"\0" withString:@""];
            
            [dic setObject:value forKey:key];
        }
    }
    return dic;
}

@end
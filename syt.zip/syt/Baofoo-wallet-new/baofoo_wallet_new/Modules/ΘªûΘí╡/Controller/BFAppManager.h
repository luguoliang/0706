//
//  BFAppManager.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "AppCollectionCell.h"

//有应用可以更新
extern NSString *const BFApplistDidChangedNotification ;
//应用安装成功
extern NSString *const BFAppInstallFinishedNotification ;



/** 应用管理 */
@interface BFAppManager : NSObject

//单列
+ (instancetype) shareInstance ;

//移动Bundle里的预置H5
- (void) moveBundleApps ;

//在线更新
- (void) requestAppList ;

//所有的应用
@property(nonatomic, readonly) NSArray* arrOriginApps ;//原始对照表

@property(nonatomic, readonly) NSArray* arrAllApp ;//所有应用，去除folder
@property(nonatomic, readonly) NSArray* arrH5Apps ;//H5应用，去除folder
@property(nonatomic, readonly) NSArray* arrNative ;//native，去除folder


//更新应用列表
@property(nonatomic, assign) BOOL isApplistChanged ;
@property(nonatomic, assign) BOOL isCanUpdateToNewVersion ;
//更新H5应用(下载的新包安装到路径)

- (BOOL) installH5Apps ;

#pragma mark 下载应用

//下载应用，下载完成后打开
- (void) downloadAppOfCell:(AppCollectionCell *) cell ;
- (void) downloadAppOfModel:(YZFAppItemModel *) model ;
- (BOOL) checkManualDownloadState:(AppCollectionCell *)cell ;

//保存列表
- (void) saveApplist ;


@end

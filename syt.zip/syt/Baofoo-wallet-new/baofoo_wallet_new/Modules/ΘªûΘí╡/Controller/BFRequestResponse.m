//
//  BFRequestResponse.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFRequestResponse.h"

@implementation BFRequestResponse
- (NSString *)description
{
    return [NSString stringWithFormat:@"ResponeToTask:%@\n isSuccess:%@\n code:%@\n message:%@\n obj:%@", _task, _isSuccess?@"成功":@"失败", _code, _message, _result];
}

- (void)logDescription
{
    DebugLog(@"%@", self.description);
}

@end

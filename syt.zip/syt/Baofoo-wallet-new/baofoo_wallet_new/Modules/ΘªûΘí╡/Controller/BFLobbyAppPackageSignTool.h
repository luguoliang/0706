//
//  BFLobbyAppPackageSignTool.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BFLobbyAppPackageSignTool : NSObject

/**
 *  获取app包中的MD5字符串
 */
+ (NSString *)getTheAppPacketStringWithTheAppItem:(NSString *)filepath;

/**
 *  获取文件MD5
 */
+ (NSString *)getFileMD5WithPath:(NSString *)path;

@end

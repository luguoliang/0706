//
//  BFResourceModel.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseModel.h"

@interface BFResourceModel : BFBaseModel

@property (copy, nonatomic) NSString *rcId;
@property (copy, nonatomic) NSString *rcType;
@property (copy, nonatomic) NSString *beginDate;
@property (copy, nonatomic) NSString *endDate;
@property (copy, nonatomic) NSString *url;
@property (copy, nonatomic) NSString *hush;
@property (copy, nonatomic) NSString *desc;
@property (copy, nonatomic) NSString *fileSize;


@end

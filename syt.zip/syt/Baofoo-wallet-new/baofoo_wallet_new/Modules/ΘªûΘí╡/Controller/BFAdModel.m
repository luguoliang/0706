//
//  BFAdModel.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFAdModel.h"

@implementation BFAdModel

- (id)initWithCoder:(NSCoder *)aDecoder{
    
    if (self = [super init]) {
        
        self.adId = [aDecoder decodeObjectForKey:@"adId"];
        self.adImgURL = [aDecoder decodeObjectForKey:@"adImgURL"];
        self.adType = [aDecoder decodeObjectForKey:@"adType"];
        self.adText = [aDecoder decodeObjectForKey:@"adText"];
        self.action = [aDecoder decodeObjectForKey:@"action"];
        
        self.msgId = [aDecoder decodeObjectForKey:@"msgId"];
        self.appId = [aDecoder decodeObjectForKey:@"appId"];
        self.createDate = [aDecoder decodeObjectForKey:@"createDate"];
        self.url = [aDecoder decodeObjectForKey:@"url"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.adId forKey:@"adId"];
    [aCoder encodeObject:self.adImgURL forKey:@"adImgURL"];
    [aCoder encodeObject:self.adType forKey:@"adType"];
    [aCoder encodeObject:self.adText forKey:@"adText"];
    [aCoder encodeObject:self.action forKey:@"action"];
    [aCoder encodeObject:self.msgId forKey:@"msgId"];
    [aCoder encodeObject:self.appId forKey:@"appId"];
    [aCoder encodeObject:self.createDate forKey:@"createDate"];
    [aCoder encodeObject:self.url forKey:@"url"];
}

+ (instancetype)getModelFromDictionary:(NSDictionary *)dictionary{
    
    BFAdModel *model = [[BFAdModel alloc] init];
    if (dictionary) {
        model.adId = dictionary[@"adId"];
        model.adImgURL = dictionary[@"adImgURL"];
        model.adType = dictionary[@"adType"];
        model.adText = dictionary[@"adText"];
        model.action = dictionary[@"action"];
        model.msgId = dictionary[@"msgId"];
        model.appId = NoEmptyString(dictionary[@"appId"]);
        model.createDate = dictionary[@"createDate"];
        model.url = dictionary[@"url"];
    }
    return model;
}

+ (NSArray *)getModelsFromArray:(NSArray *)array{
    
    if ([BFTool isEmptyArray:array]) {
        return @[];
    }
    
    NSMutableArray *models = [[NSMutableArray alloc] init];
    for (NSDictionary *dic in array) {
        BFAdModel *model = [BFAdModel getModelFromDictionary:dic];
        [models addObject:model];
    }
    return models;
}
@end

//
//  BFLobbyAppPathTool.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFLobbyAppPathTool.h"
#import "BFLobbyAppPackageManager.h"
#include <sys/xattr.h>

#define DownloadReferenceFileName @"downloadReference.plist"

@implementation BFLobbyAppPathTool

#pragma mark - 通用

//获取沙盒Documents路径
+(NSString *)getDocumentPath {
    NSString *filePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    return filePath;
}


+ (NSString *)getCachePath{
    NSString *filePath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    return filePath;
}

+ (NSString *)getFolderWithName:(NSString *)name{
    NSString *filePath = [[[self class] getCachePath] stringByAppendingPathComponent:name];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:filePath]) {
        [fm createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil] ;
        
    }
    return filePath;
}

+ (NSString *) getDocumentFolderWithName:(NSString *)name skipBackup:(BOOL)skipBackup {
    NSString *filePath = [[[self class] getDocumentPath] stringByAppendingPathComponent:name];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:filePath]) {
        //移动cache的文件到此
        NSString *cacheDir = [[[self class] getCachePath] stringByAppendingPathComponent:name];
        BOOL success = NO ;
        if ([fm fileExistsAtPath:cacheDir]) {
            success = [fm moveItemAtPath:cacheDir toPath:filePath error:nil] ;
        }
        
        if(success==NO) {
            [fm createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil];
        }
        
        if(skipBackup) {
            [self addSkipBackupAttributeToItemAtPath:filePath] ;
        }
    }
    return filePath;
}



+ (NSString *)pathForFolder:(NSString *)folder File:(NSString *)name{
    return [folder stringByAppendingPathComponent:name];
}

//文件是否存在
+ (BOOL)fileExistsAtPath:(NSString *)path{
    return [[NSFileManager defaultManager] fileExistsAtPath:path];
}

+ (BOOL)removeFile:(NSString *)path{
    if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
        return [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
    }
    return YES;
}

//获取本地文件大小
+ (NSString *)getFileDataSize:(NSString *)path{
    NSData *fileData = [[NSFileManager defaultManager] contentsAtPath:path];
    NSInteger receivedDataLength = [fileData length];
    return [NSString stringWithFormat:@"%ld",(long)receivedDataLength];
}

//+ (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL {
//    const char* filePath = [[URL path] fileSystemRepresentation];
//
//    const char* attrName = "com.apple.MobileBackup";
//    u_int8_t attrValue = 1;
//
//    int result = setxattr(filePath, attrName, &attrValue, sizeof(attrValue), 0, 0);
//    return result == 0;
//}

+ (BOOL)addSkipBackupAttributeToItemAtPath:(NSString *) filePathString
{
    NSURL* URL= [NSURL fileURLWithPath: filePathString];
    assert([[NSFileManager defaultManager] fileExistsAtPath: [URL path]]);
    
    NSError *error = nil;
    BOOL success = [URL setResourceValue: [NSNumber numberWithBool: YES]
                                  forKey: NSURLIsExcludedFromBackupKey error: &error];
    if(!success){
        NSLog(@"Error excluding %@ from backup %@", [URL lastPathComponent], error);
    }
    return success;
}


#pragma mark - 数据模型的本地写入和读取

+ (NSArray *)readModelsFromFile:(NSString *)filepath{
    
    if (![[self class] fileExistsAtPath:filepath]) {
        return nil;
    }
    
    NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithFile:filepath];
    return array;
}

+ (void)saveModels:(NSArray *)models toFile:(NSString *)filepath{
    if ([[NSFileManager defaultManager] fileExistsAtPath:filepath]) {
        [[NSFileManager defaultManager] removeItemAtPath:filepath error:nil];
    }
    [NSKeyedArchiver archiveRootObject:models toFile:filepath];
}

#pragma mark - 下载

//Html5App Zip包下载文件夹地址
+ (NSString *)appDownloadTempFolderPath{
    return [[self class] getFolderWithName:@"DownloadTemp"];
}

//Html5App Zip包安装文件夹地址
+ (NSString *)appDownloadFinalFolderPath{
    return [[self class] getDocumentFolderWithName:@"DownloadApps" skipBackup:YES] ;
}

//下载索引文件地址
+ (NSString *)downloadReferenceFilePath{
    return [[[self class] appDownloadTempFolderPath] stringByAppendingPathComponent:DownloadReferenceFileName];
}

#pragma mark - Html5App

//公共接口文件地址
+ (NSString *)publicPortPath{
    NSString *folderPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"PresetHtml5Zip"];
    return [folderPath stringByAppendingPathComponent:PublicJs_File];
    //    return [[NSBundle mainBundle] pathForResource:PublicJs_File ofType:nil];
}

//Html5App Zip包临时缓存下载地址
+ (NSString *)appDownloadTempPath:(YZFAppItemModel *)itemModel{
    return [[[self class] appDownloadTempFolderPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@.zip.temp", itemModel.appId, itemModel.version]];
}

//Html5App Zip包保存地址
+ (NSString *)appDownloadSavedPath:(YZFAppItemModel *)itemModel{
    return [[[self class] appDownloadTempFolderPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@.zip", itemModel.appId, itemModel.version]];
}

//Html5App 包文件夹地址
+ (NSString *)appInstalledPath:(YZFAppItemModel *)itemModel{
    NSString *path = [[[self class] appDownloadFinalFolderPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@", itemModel.appId, itemModel.version]];
    return path;
}

//Html5App包 主页地址
+ (NSString *)appMainFilePath:(YZFAppItemModel *)itemModel{
    
    //通过Properties文件去取MainFile
    NSString *appPropertyFilePath = [[self class] appPropertyFilePath:itemModel];
    if ([BFFileTool fileExistsAtPath:appPropertyFilePath]) {
        NSString *appInstalledPath = [BFLobbyAppPathTool appInstalledPath:itemModel];
        NSString *mainFileName = [BFLobbyAppPackageManager propertyMainItem:itemModel];
        if (mainFileName) {
            return [appInstalledPath stringByAppendingPathComponent:mainFileName];
        }
    }
    return nil;
    
    //    NSString *folderPath = [[self class] appInstalledPath:itemModel];
    //    return [self pathForFolder:folderPath File:Main_File];
}

//Html5App包 属性文件地址
+ (NSString *)appPropertyFilePath:(YZFAppItemModel *)itemModel{
    NSString *folderPath = [[self class] appInstalledPath:itemModel];
    return [[self class] pathForFolder:folderPath File:Properties_File];
}

+ (NSString *)appPublicJsFilePath:(YZFAppItemModel *)itemModel{
    NSString *folderPath = [[self class] appInstalledPath:itemModel];
    return [[self class] pathForFolder:folderPath File:PublicJs_File];
}

#pragma mark - Html5App预置包

//Html5App（预置） 文件夹
+ (NSString *)presetAppInstalledPath:(YZFAppItemModel *)itemModel{
    NSString *path = [[[self class] appDownloadFinalFolderPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@", itemModel.appId, itemModel.version]];
    return path;
}

//Html5App（预置） MainFile
+ (NSString *)presetAppMainFilePath:(YZFAppItemModel *)itemModel{
    NSString *folderPath = [[self class] presetAppInstalledPath:itemModel];
    return [[self class] pathForFolder:folderPath File:Main_File];
}

//Html5App（预置） PropertyFile
+ (NSString *)presetAppPropertyFilePath:(YZFAppItemModel *)itemModel{
    NSString *folderPath = [[self class] presetAppInstalledPath:itemModel];
    return [[self class] pathForFolder:folderPath File:Properties_File];
}

//Html5App（预置） 接口Js
+ (NSString *)presetAppPublicJsFilePath:(YZFAppItemModel *)itemModel{
    NSString *folderPath = [[self class] presetAppInstalledPath:itemModel];
    return [[self class] pathForFolder:folderPath File:PublicJs_File];
}

#pragma mark - 本地包最新

//Html5App（最新） 文件夹地址
+ (NSString *)localAppInstalledPath:(YZFAppItemModel *)itemModel{
    NSString *folderPath = [[self class] appDownloadFinalFolderPath];
    
    NSError *error = nil;
    NSArray *filelist = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:folderPath error:&error];
    
    if(error) {
        return nil;
    }
    
    NSMutableArray *versions = [[NSMutableArray alloc] init];
    for (NSString *string in filelist) {
        NSString *last = [string lastPathComponent];
        if ([last hasPrefix:itemModel.appId]) {
            [versions addObject:string];
        }
    }
    
    if (versions.count == 0) {
        return nil;
    }
    
    NSArray *sortedArr = [versions sortedArrayUsingComparator:^NSComparisonResult(NSString *obj1, NSString *obj2) {
        
        NSString *obj1Version = [[[obj1 lastPathComponent] componentsSeparatedByString:@"_"] lastObject];
        NSString *obj2Version = [[[obj2 lastPathComponent] componentsSeparatedByString:@"_"] lastObject];
        
        NSComparisonResult result = [obj1Version compare:obj2Version options:NSNumericSearch];
        return result;
    }];
    
    NSString *theNewestFolderName = [sortedArr lastObject];
    return [[[self class] appDownloadFinalFolderPath] stringByAppendingPathComponent:theNewestFolderName];
}

//Html5App（最新） MainFile
+ (NSString *)localAppMainFilePath:(YZFAppItemModel *)itemModel{
    
    NSString *appPropertyFilePath = [[self class] localAppPropertyFilePath:itemModel];
    if ([BFFileTool fileExistsAtPath:appPropertyFilePath]) {
        NSString *appInstalledPath = [BFLobbyAppPathTool localAppInstalledPath:itemModel];
        NSString *mainFileName = [BFLobbyAppPackageManager propertyMainItem:itemModel];
        if (mainFileName) {
            return [appInstalledPath stringByAppendingPathComponent:mainFileName];
        }
    }
    return nil;
    
    //    NSString *folderPath = [[self class] localAppInstalledPath:itemModel];
    //    return [[self class] pathForFolder:folderPath File:Main_File];
}

//Html5App（最新） PropertyFile
+ (NSString *)localAppPropertyFilePath:(YZFAppItemModel *)itemModel{
    NSString *folderPath = [[self class] localAppInstalledPath:itemModel];
    return [[self class] pathForFolder:folderPath File:Properties_File];
}

//Html5App（最新） 接口Js
+ (NSString *)localAppPublicJsFilePath:(YZFAppItemModel *)itemModel{
    NSString *folderPath = [[self class] localAppInstalledPath:itemModel];
    return [[self class] pathForFolder:folderPath File:PublicJs_File];
}
@end

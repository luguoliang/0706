//
//  BFHomePageViewController.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFHomePageViewController.h"
#import "BFHomePageViewCell.h"
#import "BFHomePageViewModel.h"
#import "BFHomePageViewData.h"
#import "BFHomePageHeaderView.h"
@interface BFHomePageViewController ()<UITableViewDataSource,UITableViewDelegate>
{
     NSArray *_titleArray,*_imageArray,*_classArray;
}

@end

@implementation BFHomePageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    NSNotificationCenter  * notificationCenter1 = [ NSNotificationCenter  defaultCenter];
//    [notificationCenter1 addObserver: self  selector: @selector(update:) name:@"subjectMessage"  object: nil ];
//    
    
    [self hideLeftBarButtonItem];
    {
    UIButton*button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(0, 0, 100, 30);
    button.titleLabel.textAlignment = NSTextAlignmentRight;
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [button setTitleFont:[UIFont systemFontOfSize:13.0f]];
    [button setTitle:@"账单" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(billButton:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem*iten = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = iten;
    }
    _titleArray  = [BFHomePageViewData getHomePageList];
    BFHomePageHeaderView*headerView = [[BFHomePageHeaderView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, ([UIScreen mainScreen].bounds.size.height - 64 - 49 -4)/(_titleArray.count))];
    _tableView.tableHeaderView = headerView;
    // Do any additional setup after loading the view from its nib.
}


//- (void)update:(NSNotification*)notification{
//    
//    if ([[notification name] isEqualToString:@"subjectMessage"]) {
//
//        
//    }
//}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return (_titleArray.count-1);
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return ([UIScreen mainScreen].bounds.size.height - 64 - 49 -4)/(_titleArray.count);
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *myCell = @"BfCellIndifer";
    BFHomePageViewCell*cell = [tableView dequeueReusableCellWithIdentifier:myCell];
    if (!cell) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"BFHomePageViewCell" owner:nil options:nil] lastObject];
    }
    BFHomePageViewModel*model = [[BFHomePageViewModel alloc] init];
    [model setValuesForKeysWithDictionary:_titleArray[indexPath.section]];
    cell.model = model;
    return cell;
}
-(void)billButton:(UIButton*)button{
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

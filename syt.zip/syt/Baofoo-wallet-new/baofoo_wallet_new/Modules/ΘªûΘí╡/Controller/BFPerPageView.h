//
//  BFPerPageView.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BFAdModel.h"
@class BFPerPageView;

@protocol BFPerPageViewDelegate <NSObject>

- (void)perPageViewDidClick:(BFPerPageView *)perPageView;

@end

@interface BFPerPageView : UIView

@property (nonatomic, strong) BFAdModel *adModel;

/**
 *  创建perPageView视图
 *
 *  @param frame frame
 *  @param target 代理
 */
+ (instancetype)createPerPageViewWithFrame:(CGRect)frame target:(id)target;

@property (nonatomic, weak) id <BFPerPageViewDelegate>delegate;
@end

//
//  BFAdManager.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BFAdModel.h"

@interface BFAdManager : NSObject

+ (void)handleAdModel:(BFAdModel *)model curViewController:(UIViewController *)curViewController;
@end

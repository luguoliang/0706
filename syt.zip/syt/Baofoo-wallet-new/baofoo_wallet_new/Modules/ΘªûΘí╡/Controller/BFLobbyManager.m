//
//  BFLobbyManager.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFLobbyManager.h"
#import "SDWebImageDownloader.h"
#import "BFAppManager.h"

#define KEY_LOCAL_APPLIST_VERSION     @"LOCAL_APPLIST_VERSION"
#define KEY_LOCAL_RESOURCE_VERSION    @"LOCAL_RESOURCE_VERSION"
#define KEY_LOCAL_ADVERTISE_VERSION   @"LOCAL_ADVERTISE_VERSION"

#define KEY_ONLINE_APPLIST_VERSION     @"ONLINE_APPLIST_VERSION"
#define KEY_ONLINE_RESOURCE_VERSION    @"ONLINE_RESOURCE_VERSION"
#define KEY_ONLINE_ADVERTISE_VERSION   @"ONLINE_ADVERTISE_VERSION"

//通知
NSString *const UpdateAdvertiseListFinishedNotification = @"UpdateAdvertiseListFinishedNotification";

@interface BFLobbyManager() {
    BOOL addAppActiveNoti ;
}
@property(nonatomic, strong) NSMutableDictionary* dictVersions  ;
@property (strong, nonatomic) NSArray *resourceList; //启动页面图
@end

@implementation BFLobbyManager

+ (instancetype)sharedInstance{
    static BFLobbyManager *_sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[BFLobbyManager alloc] init];
    });
    
    return _sharedInstance;
}

- (instancetype) init {
    self = [super init] ;
    if (self) {
        [self reset] ;
        [self setResourceList:[BFFileTool readModelObjectWithFile:[BFFilePathTool lobbyResourceListFilePath]]] ;
        [self reqLobbyUpdateInfo] ;
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginSuccessed:) name:LoginNotificationSuccess object:nil];
    }
    return self ;
}

- (void) reset {
    self.dictVersions = [NSMutableDictionary dictionaryWithContentsOfFile:[BFFilePathTool lobbyVersionInfoFilePath]] ;
    if(self.dictVersions==nil) {
        self.dictVersions = [[NSMutableDictionary alloc] init] ;
    }
    self.advertiseList = [BFFileTool readModelObjectWithFile:[BFFilePathTool lobbyAdListFilePath]];
}

//登录成功
- (void)loginSuccessed:(id)sender {
    [self reset] ;
    [self copyPresetLobbyAppListToUser] ;
    [self reqLobbyUpdateInfo] ;
    [[NSNotificationCenter defaultCenter] postNotificationName:UpdateAdvertiseListFinishedNotification object:nil userInfo:nil];
}


- (void)applicationDidBecomeActiveNotification:(id)sender {
    [self reqLobbyUpdateInfo] ;
}

#pragma mark - 安装预置文件
- (void)copyPresetLobbyAppListToUser{
    NSString *sourcePath = [BFFileTool getDocumentFilePathWithName:LobbyAppListFileName];
    NSString *destinationPath = [BFFilePathTool lobbyAppListFilePath] ;
    
    if (![BFFileTool fileExistsAtPath:destinationPath]) {
        [[NSFileManager defaultManager] copyItemAtPath:sourcePath toPath:destinationPath error:nil];
    }
}

#pragma mark - 接口调用

//TOREQ:检测待更新的内容清单
- (void)reqLobbyUpdateInfo{
    
}

- (BOOL) equalDict:(NSDictionary *)dict key:(NSString *)key toKey:(NSString *)toKey {
    NSString* value1 = [dict objectForKey:key] ;
    NSString* value2 = [dict objectForKey:toKey] ;
    return [value1 isEqualToString:value2] ;
}

- (void) saveDict:(NSMutableDictionary *)dict localKey:(NSString *)localKey onlineKey:(NSString *)onlineKey {
    NSString* online = [dict objectForKey:onlineKey] ;
    if(online) {
        [dict setObject:online forKey:localKey] ;
        [dict writeToFile:[BFFilePathTool lobbyVersionInfoFilePath] atomically:YES] ;
    }
}

//TOREQ:获取广告列表
- (void)reqAdvertiseList{
    
}




//保存广告列表
- (void)saveAdList:(NSArray *)array{
    NSArray *models = [BFAdModel getModelsFromArray:array];
    [BFFileTool saveModelObject:models toFile:[BFFilePathTool lobbyAdListFilePath]];
    self.advertiseList = models;
}

//TOREQ:获取资源列表
- (void)reqResouceList{
    
   
}

//保存资源列表
- (void)saveResourseList:(NSArray *)array{
    self.resourceList = [BFResourceModel getModelsFromArray:array] ;
    [BFFileTool saveModelObject:self.resourceList toFile:[BFFilePathTool lobbyResourceListFilePath]];
    
    if ([BFTool isEmptyArray:self.resourceList]==NO) {
        [self downloadLaunchImage] ;
    }
    else {
        [BFFileTool removeFileAtPath:[BFFilePathTool lobbyResourceLaunchImageFilePath]];
    }
}

- (void)downloadLaunchImage {
    NSArray *array = self.resourceList ;
    if(![BFTool isEmptyArray:array]) {
        BFResourceModel *model = (BFResourceModel *)[array firstObject] ;
        
        SDWebImageDownloader *downloader = [SDWebImageDownloader sharedDownloader] ;
        [downloader downloadImageWithURL:[NSURL URLWithString:model.url]
                                 options:0
                                progress:nil
                               completed:^(UIImage *image, NSData *imageData, NSError *error, BOOL finished) {
                                   if (image && finished) {
                                       [imageData writeToFile:[BFFilePathTool lobbyResourceLaunchImageFilePath] atomically:NO] ;
                                   }
                               }];
    }
}

//保存App列表版本
- (void)saveApplistVersion {
    [self saveDict:self.dictVersions localKey:KEY_LOCAL_APPLIST_VERSION onlineKey:KEY_ONLINE_APPLIST_VERSION ] ;
}
@end

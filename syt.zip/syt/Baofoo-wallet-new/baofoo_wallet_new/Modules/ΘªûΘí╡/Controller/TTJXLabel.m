//
//  TTJXLabel.m
//  BaofooWallet
//
//  Created by mac on 15/11/18.
//  Copyright © 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import "TTJXLabel.h"

@implementation TTJXLabel

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

//
//  BFHomePageViewController.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

@interface BFHomePageViewController : BFBaseViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

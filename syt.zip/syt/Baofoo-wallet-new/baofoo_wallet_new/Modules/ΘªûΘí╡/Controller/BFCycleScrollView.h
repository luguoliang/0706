//
//  BFCycleScrollView.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BFPerPageView.h"

@class BFCycleScrollView;
@protocol BFCycleScrollViewDelegate <NSObject>

- (void)cycleScrollView:(BFCycleScrollView *)cycleScrollView didClick:(BFPerPageView *)perPageView;

@end

@interface BFCycleScrollView : UICollectionReusableView

/**
 *  创建轮播器
 *
 *  @param frame frame
 *  @param target 代理
 */
+ (instancetype)createWithFrame:(CGRect)frame target:(id)target;

@property (nonatomic, weak) id <BFCycleScrollViewDelegate>delegate;
@property (nonatomic, strong) NSArray *scrollData;

@end

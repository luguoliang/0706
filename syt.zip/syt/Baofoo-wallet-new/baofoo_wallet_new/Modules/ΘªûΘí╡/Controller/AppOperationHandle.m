//
//  AppOperationHandle.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "AppOperationHandle.h"
#import "H5ViewController.h"


#import "BFWebViewController.h"
#import "H5ViewController.h"

#import "BFLobbyAppPackageManager.h"
#import "ReachabilityTool.h"
#import "BFAppManager.h"

@implementation AppOperationHandle

#pragma mark - 应用打开处理

+ (void)handleApp:(AppCollectionCell *)cell curViewControlelr:(UIViewController *)controller{
    if (![BFLoginTool checkLogin]) {
        [BFLoginTool toLoginWithAccountName:nil];
        return;
    }
    if ([cell.model.appId integerValue] == LobbyAppIDMore) {
        [BlockAlert showWithTitle:Alert_Title message:@"没有更多了" cancelButtonTitle:Alert_Button_Confirm otherButtonTitles:nil operation:nil];
        return;
    }
    if (cell.model.fileTypeValue == FileTypeValueHtml5) {
        //HTML5应用
        if ([ReachabilityTool checkNetworkState] == NetworkStateUnable) {
            [UIAlertView showNetErrorAlertWithDelegate:nil];
        }
        else {
            [[self class] handleHTML5App:cell curViewControlelr:controller];
        }
    }
    else if(cell.model.fileTypeValue == FileTypeValueNative) {
        //Native应用
        [[self class] handleNativeApp:cell curViewControlelr:controller];
    }
}

#pragma mark - 原生应用

//原生应用处理
+ (void)handleNativeApp:(AppCollectionCell *)cell curViewControlelr:(UIViewController *)controller{
    DebugLog(@"AppOperationHandle: Handle native app %@/%@", cell.model.appName, cell.model.appId);
    
    if (cell.status == AppStatusMaintain) {
        [BlockAlert showWithTitle:Alert_Title message:App_Status_Maintain cancelButtonTitle:Alert_Button_Confirm otherButtonTitles:nil operation:nil];
        return;
    }
    
    [[self class] handleNativeAppItem:cell.model curViewControlelr:controller];
}
+ (void)handleNativeAppItem:(YZFAppItemModel *)model curViewControlelr:(UIViewController *)controller{
    DebugLog(@"AppOperationHandle: handle Native AppItemModel %@/%@", model.appName, model.appId);
    
    Class class = [[self class] getAppFileIndex:model.appId];
    if (class) {
        UIViewController *vc = [[class alloc] init];
        [controller.navigationController pushViewController:vc animated:YES];
    }
}

+ (Class)getAppFileIndex:(NSString *)appId{
    NSString *path = [[NSBundle mainBundle] pathForResource:@"LobbyAppConfiguration" ofType:@"plist"];
    NSDictionary *lobbyAppConfiguration = [NSDictionary dictionaryWithContentsOfFile:path];
    
    NSDictionary *appInfo = [lobbyAppConfiguration objectForKey:appId];
    NSString *fileIndex = appInfo[@"fileIndex"];
    Class class = NSClassFromString(fileIndex);
    return class;
}

#pragma mark - HTML5应用

//Html5应用处理
+ (void)handleHTML5App:(AppCollectionCell *)cell curViewControlelr:(UIViewController *)controller{
    DebugLog(@"AppOperationHandle: Handle html5 app %@/%@，状态 %ld", cell.model.appName, cell.model.appId, (long)cell.status);
    
    YZFAppItemModel *model = cell.model;
    switch (cell.status) {
        case AppStatusNormal:{
            DebugLog(@"AppOperationHandle: 打开 html5 app");
            BFWebViewController *webView = [[BFWebViewController alloc] init];
//            webView.natitle = model.appName;
            webView.urlStr = model.fileURL;
            [controller.navigationController pushViewController:webView animated:YES];
            break;
        }
        case AppStatusDownloading:{
            //如果是下载状态，提示正在下载
            [BlockAlert showWithTitle:Alert_Title message:@"该应用下载中" cancelButtonTitle:Alert_Button_Confirm otherButtonTitles:nil operation:nil];
            break;
        }
        case AppStatusMaintain:{
            [BlockAlert showWithTitle:Alert_Title message:App_Status_Maintain cancelButtonTitle:Alert_Button_Confirm otherButtonTitles:nil operation:nil];
            break;
        }
        default:
            break;
    }
}
@end

//
//  BFPerPageView.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFPerPageView.h"
#import <UIImageView+WebCache.h>


@interface BFPerPageView ()
@property (nonatomic, weak) UIImageView *imageview;
@end

@implementation BFPerPageView

- (void)setAdModel:(BFAdModel *)adModel{
    _adModel = adModel;
    NSURL *url = [NSURL URLWithString:adModel.adImgURL];
    [self.imageview sd_setImageWithURL:url placeholderImage:[UIImage imageNamed:[NSString stringWithFormat:@"AD-%@.png", adModel.adImgURL]]];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    if ([self.delegate respondsToSelector:@selector(perPageViewDidClick:)]) {
        [self.delegate perPageViewDidClick:self];
    }
}

#pragma mark - Init

+ (instancetype)createPerPageViewWithFrame:(CGRect)frame target:(id)target{
    BFPerPageView *perPageView = [[self alloc] initWithFrame:frame];
    perPageView.delegate = target;
    return perPageView;
}

- (instancetype) initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.layer.cornerRadius = 8;
        self.layer.masksToBounds = YES;
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:self.bounds];
        imageView.backgroundColor = [UIColor clearColor];
        imageView.userInteractionEnabled = YES;
        self.imageview = imageView;
        [self addSubview:imageView];
    }
    return self;
}



@end

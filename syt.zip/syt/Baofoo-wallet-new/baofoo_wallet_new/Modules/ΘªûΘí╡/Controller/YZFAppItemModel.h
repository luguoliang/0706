//
//  YZFAppItemModel.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseModel.h"

typedef NS_ENUM(NSInteger, AppStateValue) {
    AppStateValueWaitingForCheck = 0, //待审核
    AppStateValueNormal, //正常
    AppStateValueUpdated, //更新
    AppStateValueUpdatedOptional, //可选更新
    AppStateValueUpdatedRequired, //强制更新
    AppStateValueSuspend, //暂停
    AppStateValueOffline, //下线
    AppStateValueAreaLimited //区域受限
};

typedef NS_ENUM(NSInteger, FileTypeValue) {
    FileTypeValueFolder = -1, //App文件夹
    FileTypeValueHtml5 = 0, //原生应用
    FileTypeValueNative //Html5应用
};

//APPID
typedef NS_ENUM(NSInteger, LobbyAppID) {
    LobbyAppIDTransfer = 1, //转账
    LobbyAppIDCredit = 2, //信用卡还款
    LobbyAppIDTelRecharge = 3, //通信缴费
    LobbyAppIDLifeRecharge = 4, //生活缴费
    LobbyAppIDBalance = 5, //账户余额
    LobbyAppIDBills = 6, //账单明细
    LobbyAppIDRecharge = 7, //充值
    LobbyAppIDWithdraw = 10, //提现
    LobbyAppIDRedbag = 11, //红包
    LobbyAppIDBFCardRecharge = 12, //宝付充值卡
    LobbyAppIDSecurity = 13, //安全中心
    LobbyAppIDMore = 14, //更多
};

@interface YZFAppItemModel : BFBaseModel

+ (NSArray *) modelsFromDicts:(NSArray *)arrDicts ;

//唯一标示符
@property (copy, nonatomic) NSString *appId;    //应用编号
@property (copy, nonatomic) NSArray *appList ;//如果是文件夹，文件夹里的应用

//基础参数
@property (copy, nonatomic) NSString *appName;  //应用名字
@property (copy, nonatomic) NSString *version;  //版本
@property (copy, nonatomic) NSString *checkMd5; //md5
@property (copy, nonatomic) NSString *fileURL;  //文件
@property (copy, nonatomic) NSString *iconURL;  //图标icon


//可替换参数，下载完成时候，替换的时候，替换上面的。
@property(nonatomic, assign) BOOL isCanUpdated ;//可以更新
@property(nonatomic, assign) BOOL isCheckCurVersionAvailable ;//
@property(nonatomic, assign) BOOL isCheckNewVersionAvailable ;//
@property(nonatomic, assign) BOOL isCheckCurVersionMustDownload ;
@property(nonatomic, assign) BOOL isCheckUpdateOnlineVersion ;

@property (copy, nonatomic) NSString *appNameOnline;  //应用名字
@property (copy, nonatomic) NSString *versionOnline;  //版本
@property (copy, nonatomic) NSString *checkMd5Online; //md5
@property (copy, nonatomic) NSString *fileURLOnline;  //文件
@property (copy, nonatomic) NSString *iconURLOnline;  //图标icon

//可能不需要，先留着，不知道啥逻辑
@property (copy, nonatomic) NSString *isNotice;
@property (copy, nonatomic) NSString *noticeURL;
@property (copy, nonatomic) NSString *isNoticeOnline;
@property (copy, nonatomic) NSString *noticeURLOnline;
@property (copy, nonatomic) NSString *noticeText;//说明文案，副标题

//接口
@property (assign, nonatomic) FileTypeValue fileTypeValue;
@property (assign, nonatomic) AppStateValue appStateValue;
@property (assign, nonatomic) AppStateValue appStateValueOnline;

//绑定旧的数据到新的上面
- (void) bindExistAppInfo:(YZFAppItemModel *)oldModel ;
//返回是否有更新
- (BOOL) updateToNewVersion ;
//下载的model
- (YZFAppItemModel *) downloadModelOfOnline ;

//验证当前版本是否可用
- (BOOL) checkCurVersionAvailable ;
//验证新的版本是否可用，下载完成，未更新applist
- (BOOL) checkNewVersionAvailable ;

//验证当前版本必须下载，若存在于bundle则不需要下载
- (BOOL) checkCurVersionMustDownload ;
//验证线上版本是否可以更新
- (BOOL) checkUpdateOnlineVersion ;

//验证是否预置在包里面
- (NSString *) presetedPathOfCurVersionInBundle ;


//移动Bundle里的子应用，只适用于folder
- (void) moveSubAppsInBunlde ;

//安装
- (BOOL) installFromZipPath:(NSString *)filePath fileManager:(NSFileManager *)fm ;

@end

//
//  BFLobbyAnimationView.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BFLobbyAnimationView : UIView
{
    UIImageView *progressImageView;//进度框图片
    UIImageView *personImageView;//小人图片
    UILabel     *promptLabel;//提示刷新
}

@property (nonatomic, readonly) BOOL isAnimating;//是否开始动画

- (id)initWithFrame:(CGRect)frame;//初始化

- (void)startAnimation;//开始动画
- (void)stopAnimation:(UIScrollView *)scrollView;//关闭动画

@end

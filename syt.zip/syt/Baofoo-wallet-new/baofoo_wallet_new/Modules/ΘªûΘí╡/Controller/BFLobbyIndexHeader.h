
//
//  BFLobbyIndexHeader.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#ifndef BFLobbyIndexHeader_h
#define BFLobbyIndexHeader_h

#define RowGridCount 4

#define RowMaxCount 3
#define RowMinCount 3

#define DownloadApplistFinish   @"downloadApplistFinish"
#define DownloadApplistFailed   @"downloadApplistFailed"
#define DownloadPackageFinish   @"downloadPackageFinish"
#define DownloadPackageFailed   @"downloadPackageFailed"

#define LoginSuccessNoti        @"loginSuccessNoti"
#define LoginSuccessNotification @"loginSuccessed"

#define LobbyButtonRatio (101/81.f)
#define LobbyBannerRatio (91/375.f)
#define LobbyScanneRatio (180/320.f)

//大厅广告栏上下间距
#define LobbySpacesRatio (12.5/320.f)



#endif /* BFLobbyIndexHeader_h */

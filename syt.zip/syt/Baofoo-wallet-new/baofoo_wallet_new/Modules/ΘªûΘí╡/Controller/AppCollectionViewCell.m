//
//  AppCollectionViewCell.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "AppCollectionViewCell.h"
#import "BFHomePageUIHeader.h"
#import "BFStringTool.h"
#import "UIImageView+WebCache.h"
#import "BFAppItemsManager.h"

@interface AppCollectionViewCell ()
{
    UILabel *titleLabel;
    UIImageView *iconImageView;
    
    UIImageView *bgImageView;
    UILabel *subTitleLabel;
    UIImageView* subTitleImage ;
    
    UIImageView *noticImageView;
    UIImageView *statusImageView;
    UIImageView *updateImageView;
}
@end

@implementation AppCollectionViewCell

- (void)setModel:(BFAppItemsModel *)model{
    _model = model;
    
    titleLabel.text = _model.BFAppItemsName;
    {
        // 取本地图标
        NSString *imgName = [NSString stringWithFormat:@"icon_%@_%@.png ", model.BFAppItemsId,model.BFAppItemsVersion];
        UIImage *image = [UIImage imageNamed:imgName]?[UIImage imageNamed:imgName]:DefaultImage;
        
        iconImageView.image = nil;
        if (!IsEmptyString(model.BFAppItemsIconUrl)) {
            [iconImageView sd_setImageWithURL:[[NSURL alloc]initWithString:model.BFAppItemsIconUrl] placeholderImage:image options:SDWebImageRetryFailed];
        }
    }
    
    //1.非H5应用
    if (model.BFAppItemsType != BFAppItemsH5Zip) {
        
        if (model.BFAppItemsStateValue == BFAppItemsStateValueNormal) {
            
            self.appStatus = AppItemsStatusNormal;
        }
        else {
            self.appStatus = AppItemsStatusMaintain;
        }
        
        return;
    }
    
    //2.H5应用
    if (model.BFAppItemsStateValue == BFAppItemsStateValueWaitingForCheck ||
        model.BFAppItemsStateValue == BFAppItemsStateValueSuspend ||
        model.BFAppItemsStateValue == BFAppItemsStateValueOffline ||
        model.BFAppItemsStateValue == BFAppItemsStateValueAreaLimited) {
        
        self.appStatus = AppItemsStatusMaintain;
    }
    else {
        self.appStatus = [[BFAppItemsManager shareInstance] checkAppItemState:self];
    }
}

#pragma mark - 初始化

- (instancetype)initWithFrame:(CGRect)frame{
    if (self == [super initWithFrame:frame]) {
        
        self.backgroundColor = [UIColor clearColor];
        
        bgImageView = [UIImageView createWithFrame:CGRectMake(0, 0, self.size_W, self.size_H) image: [UIImage imageNamed:@"lobby_icon_background"]];
        bgImageView.clipsToBounds = YES ;
        [self addSubview:bgImageView];
        
        //
        iconImageView = [UIImageView createWithFrame:CGRectMake(0, 0, 40.0, 40.0) image:nil];
        iconImageView.center_X = self.size_W/2;
        iconImageView.center_Y = self.size_H/2-self.size_H/7;
        [self addSubview:iconImageView];
        
        //
        titleLabel = [UILabel createWithFrame:CGRectMake(0, 0, self.size_W, 20)];
        titleLabel.font = (_iPhone6P_)?[UIFont systemFontOfSize:15]:[UIFont systemFontOfSize:12];
        titleLabel.textColor = UIColorRgb(111, 111, 111);
        titleLabel.textAlignment = NSTextAlignmentCenter;
        if (_iPhone6_) {
            titleLabel.origin_Y = iconImageView.bottom_Y + 2;
        }
        else if(_iPhone6P_) {
            titleLabel.origin_Y = iconImageView.bottom_Y + 4;
        }
        else {
            titleLabel.origin_Y = iconImageView.bottom_Y;
        }
        [self addSubview:titleLabel];
        
        //subtitle
        subTitleImage = [UIImageView createWithFrame:CGRectMake(0, self.size_H-18, self.size_W, 18) image: [UIImage imageNamed:@"app_item_bar"]];
        [self addSubview:subTitleImage];
        
        subTitleLabel = [UILabel createWithFrame:subTitleImage.bounds];
        subTitleLabel.font = (_iPhone6P_)?[UIFont systemFontOfSize:13]:[UIFont systemFontOfSize:10];
        subTitleLabel.textColor = UIColorWhite();
        subTitleLabel.textAlignment = NSTextAlignmentCenter;
        [subTitleImage addSubview:subTitleLabel];
        
        
        //
        noticImageView = [UIImageView createWithFrame:CGRectMake(0, 0, 42.0, 42.0) image:nil];
        [self addSubview:noticImageView];
        
        //
        statusImageView = [UIImageView createWithFrame:CGRectMake(0, 0, self.size_W, self.size_H) image:nil];
        [self addSubview:statusImageView];
        
        //
        updateImageView = [UIImageView createWithFrame:CGRectMake(0, 0, 14.0, 14.0) image:[UIImage imageNamed:@"Upgrade"]];
        updateImageView.bottom_X = self.size_W;
        updateImageView.bottom_Y = self.size_H;
        [self addSubview:updateImageView];
        
        //
        _progressLabel = [UILabel createWithFrame:CGRectInset(iconImageView.frame, -2, -2)] ;
        _progressLabel.textColor = [UIColor whiteColor] ;
        _progressLabel.font = [UIFont systemFontOfSize:15] ;
        _progressLabel.textAlignment = NSTextAlignmentCenter ;
        [self addSubview:_progressLabel];
        
        //
        statusImageView.hidden = updateImageView.hidden = _progressLabel.hidden = YES;
    }
    return self;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(NSProgress *)object change:(NSDictionary *)change context:(void *)context {
    if ([keyPath isEqualToString:@"fractionCompleted"] && [object isKindOfClass:[NSProgress class]]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            //self.progress.progress = object.fractionCompleted ;
            
            NSInteger rate = object.fractionCompleted * 100 ;
            if(rate>100) {
                rate = 100 ;
            }
            _progressLabel.text = [NSString stringWithFormat:@"%ld%%", rate] ;
        });
        //NSLog(@"progress: %lf", object.fractionCompleted) ;
    }
}


@end

//
//  BFMapiManager.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFMapiManager.h"
#import <objc/runtime.h>

#define REQBASEURL_MAPI         @"https://mapi.bestpay.com.cn/" //移动平台

static void *JMTaskStartDate = &JMTaskStartDate;

@interface BFMapiManager ()

@property (nonatomic, strong) NSMutableDictionary *baseParams;

@end

@implementation BFMapiManager

- (instancetype)initWithBaseURL:(NSURL *)url{
    if (_sharedManager) {
        return _sharedManager;
    }
    self = [super initWithBaseURL:[NSURL URLWithString:REQBASEURL_MAPI]];
    if (self) {
        self.requestSerializer = [AFJSONRequestSerializer serializer];
        self.baseParams        = [[NSMutableDictionary alloc] init];
    }
    
    _sharedManager = self;
    
    return self;
}



static BFMapiManager *_sharedManager = nil;

+ (BFMapiManager *)sharedManager{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedManager = [[BFMapiManager alloc] initWithBaseURL:[NSURL URLWithString:REQBASEURL_MAPI]];
    });
    return _sharedManager;
}

+ (NSURLSessionDataTask *)POSTService:(ReqServiceType)service
                                 name:(NSString *)name
                               params:(NSDictionary *)params
                                block:(BFRequestResponseBlock)block{
    NSString *urlString       = [[BFMapiManager stringFromType:service] stringByAppendingString:name];

    NSURLSessionDataTask *task = [[BFMapiManager sharedManager] POST:urlString parameters:params success:^(NSURLSessionDataTask *task, id responseObject) {
        [BFMapiManager handleTask:task responseObject:responseObject error:nil block:block];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [BFMapiManager handleTask:task responseObject:nil error:error block:block];
    }];
    objc_setAssociatedObject(task, JMTaskStartDate, [NSDate date], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    return task;
    
}

+ (NSURLSessionDataTask *)GETService:(ReqServiceType)service
                                name:(NSString *)name
                              params:(NSDictionary *)params
                               block:(BFRequestResponseBlock)block{
    NSString *urlString       = [[BFMapiManager stringFromType:service] stringByAppendingString:name];
    
    
    NSURLSessionDataTask *task = [[BFMapiManager sharedManager] GET:urlString parameters:params success:^(NSURLSessionDataTask *task, id responseObject) {
        [BFMapiManager handleTask:task responseObject:responseObject error:nil block:block];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [BFMapiManager handleTask:task responseObject:nil error:error block:block];
    }];
                                
    objc_setAssociatedObject(task, JMTaskStartDate, [NSDate date], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    return task;
}

+ (void)handleTask:(NSURLSessionDataTask *)task
    responseObject:(id)responseObject
             error:(NSError *)error
             block:(BFRequestResponseBlock)block{
    
    BFRequestResponse *response = [[BFRequestResponse alloc] init];
    response.task                = task;
    
    if (error) {
        response.isSuccess = NO;
        response.code      = Net_Error_Code;
        response.message   = Net_Error;
        response.result    = nil;
    }
    else {
        NSString *code    = @"";
        NSString *message = @"";
        BOOL success      = [responseObject[@"success"] boolValue];
        if (!success) {
            code    = responseObject[@"errorCode"];
            message = responseObject[@"errorMsg"];
        }
        
        response.isSuccess = success;
        response.code      = code;
        response.message   = message;
        response.result    = responseObject[@"result"];
    }
    
    if (block) {
        block(response);
    }
}

+ (NSString *)stringFromType:(ReqServiceType)type{
    switch (type) {
        case ReqServiceTypeAccount:
            return @"account/api/account/V1/";
        case ReqServiceTypeBank:
            return @"account/api/bank/V1/";
        case ReqServiceTypeBarCode:
            return @"payment/api/barCode/V1/";
        case ReqServiceTypeCode:
            return @"account/api/code/V1/";
        case ReqServiceTypeFace:
            return @"payment/api/face/V1/";
        case ReqServiceTypeFortune:
            return @"account/api/fortune/V1/";
        case ReqServiceTypeLaunch:
            return @"launch/api/";
        case ReqServiceTypeLogin:
            return @"account/api/login/V1/";
        case ReqServiceTypeMessage:
            return @"support/api/message/v1/";
        case ReqServiceTypeOauth:
            return @"oauth/";
        case ReqServiceTypePrize:
            return @"account/api/prize/V1/";
        case ReqServiceTypeQuery:
            return @"account/api/query/V1/";
        case ReqServiceTypeSecurity:
            return @"account/api/security/V1/";
        case ReqServiceTypeTransfer:
            return @"account/api/transfer/V1/";
        case ReqServiceTypeVoucher:
            return @"account/api/voucher/V1/";
        default:
            return @"";
    }
}
@end

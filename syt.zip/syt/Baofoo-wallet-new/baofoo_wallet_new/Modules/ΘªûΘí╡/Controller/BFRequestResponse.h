//
//  BFRequestResponse.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BFRequestResponse;
typedef void (^BFRequestResponseBlock)(BFRequestResponse *response);

@interface BFRequestResponse : NSObject

//NSURLSessionDataTask
@property (nonatomic, assign) NSURLSessionDataTask *task;

//请求是否成功
@property (nonatomic) BOOL isSuccess;
//错误code
@property (nonatomic, copy) NSString *code;
//描述信息
@property (nonatomic, copy) NSString *message;
//响应的数据
@property (nonatomic, strong) id result;

//是否进行了会话码续期
@property (nonatomic) BOOL isExpend;
//如果进行了会话码续期，续期是否成功
@property (nonatomic) BOOL isValid;

- (void)logDescription;

@end

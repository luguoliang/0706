//
//  AppOperationHandle.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppCollectionCell.h"

@interface AppOperationHandle : NSObject
//应用打开处理
+ (void)handleApp:(AppCollectionCell *)cell curViewControlelr:(UIViewController *)controller;
@end

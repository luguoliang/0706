//
//  BFRequest.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>

@interface BFRequest : AFHTTPSessionManager

@end

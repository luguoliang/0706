//
//  BFLobbyAppPackageManager.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BFLobbyAppPathTool.h"

#define DownloadPackageFinishedNotification @"downloadPackageFinished"
#define DownloadPackageFailedNotification   @"downloadPackageFailed"
#define DownloadPackageOpenDirectlyNotification @"downloadPackageOpenDirectly"

@interface BFLobbyAppPackageManager : NSObject

+ (instancetype)defaultManager;

#pragma mark - Package Method

- (BOOL)verifyPublicPort:(NSString *)path;

/**
 *  安装预置包
 */
- (BOOL)installPresetPackage:(YZFAppItemModel *)itemModel;

/**
 *  安装包
 */
- (BOOL)installPackage:(YZFAppItemModel *)itemModel;

/**
 *  删除已安装包
 */
- (void)deleteInstalledPackage:(YZFAppItemModel *)item;

/**
 *  删除下载包
 */
- (void)deleteDownloadSaveFile:(YZFAppItemModel *)item;

/**
 *  判断本地包是否存在
 */
+ (BOOL)packageExited:(YZFAppItemModel *)itemModel;

/**
 *  验证包MD5
 */
+ (BOOL)packageVerified:(YZFAppItemModel *)itemModel;

/**
 *  判断本地包是否需要下载
 */
+ (BOOL)packageNeedUpdate:(YZFAppItemModel *)itemModel;

/**
 *  判断本地包是否被暂停下载
 */
+ (BOOL)packagePauseDownloading:(YZFAppItemModel *)itemModel;

/**
 *  判断本地包临时文件是否已下载
 */
+ (BOOL)packageDownloading:(YZFAppItemModel *)itemModel;

/**
 *  获取最新版本号
 */
+ (NSString *)theNewestVersion:(YZFAppItemModel *)itemModel;

+ (NSString *)getPackageReceivedSize:(YZFAppItemModel *)itemModel;

+ (NSString *)getPackageTotalSize:(YZFAppItemModel *)itemModel;

#pragma mark - 包属性文件解析

+ (NSString *)propertyVersionItem:(YZFAppItemModel *)itemModel;
+ (NSString *)propertyKeyForItem:(YZFAppItemModel *)itemModel;
+ (NSString *)propertyMainItem:(YZFAppItemModel *)itemModel;

@end

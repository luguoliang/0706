//
//  BFLobbyAppPathTool.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YZFAppItemModel.h"

@interface BFLobbyAppPathTool : NSObject

#pragma mark - 通用
+ (NSString *) getDocumentFolderWithName:(NSString *)name skipBackup:(BOOL)skipBackup ;

/**
 *  文件是否存在
 */
+ (BOOL)fileExistsAtPath:(NSString *)path;

/**
 *  移除文件
 */
+ (BOOL)removeFile:(NSString *)path;

/**
 *  获取本地文件大小
 */
+ (NSString *)getFileDataSize:(NSString *)path;

#pragma mark - 数据模型的本地写入和读取

+ (NSArray *)readModelsFromFile:(NSString *)filepath;
+ (void)saveModels:(NSArray *)models toFile:(NSString *)filepath;

#pragma mark - 下载

/**
 *  下载索引文件地址
 */
+ (NSString *)downloadReferenceFilePath;

/**
 *  Html5App Zip包下载文件夹地址
 */
+ (NSString *)appDownloadTempFolderPath;

/**
 *  Html5App Zip包安装文件夹地址
 */
+ (NSString *)appDownloadFinalFolderPath;

#pragma mark - Html5App

/**
 *  公共接口文件地址
 */
+ (NSString *)publicPortPath;

/**
 *  Html5App Zip包临时缓存下载地址
 */
+ (NSString *)appDownloadTempPath:(YZFAppItemModel *)itemModel;

/**
 *  Html5App Zip包保存地址
 */
+ (NSString *)appDownloadSavedPath:(YZFAppItemModel *)itemModel;

#pragma mark - 本地安装包

/**
 *  Html5App（安装） 文件夹
 */
+ (NSString *)appInstalledPath:(YZFAppItemModel *)itemModel;

/**
 *  Html5App（安装） MainFile
 */
+ (NSString *)appMainFilePath:(YZFAppItemModel *)itemModel;

/**
 *  Html5App（安装） PropertyFile
 */
+ (NSString *)appPropertyFilePath:(YZFAppItemModel *)itemModel;

/**
 *  Html5App（安装） 接口Js
 */
+ (NSString *)appPublicJsFilePath:(YZFAppItemModel *)itemModel;

#pragma mark - Html5App预置包

/**
 *  Html5App（预置） 文件夹
 */
+ (NSString *)presetAppInstalledPath:(YZFAppItemModel *)itemModel;

/**
 *  Html5App（预置） MainFile
 */
+ (NSString *)presetAppMainFilePath:(YZFAppItemModel *)itemModel;

/**
 *  Html5App（预置） PropertyFile
 */
+ (NSString *)presetAppPropertyFilePath:(YZFAppItemModel *)itemModel;

/**
 *  Html5App（预置） 接口Js
 */
+ (NSString *)presetAppPublicJsFilePath:(YZFAppItemModel *)itemModel;

#pragma mark - 最新本地包

/**
 *  Html5App（最新） 文件夹
 */
+ (NSString *)localAppInstalledPath:(YZFAppItemModel *)itemModel;

/**
 *  Html5App（最新） MainFile
 */
+ (NSString *)localAppMainFilePath:(YZFAppItemModel *)itemModel;

/**
 *  Html5App（最新） PropertyFile
 */
+ (NSString *)localAppPropertyFilePath:(YZFAppItemModel *)itemModel;

/**
 *  Html5App（最新） 接口Js
 */
+ (NSString *)localAppPublicJsFilePath:(YZFAppItemModel *)itemModel;

@end

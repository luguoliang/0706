//
//  BFApplicationModel.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFApplicationModel.h"

#define applicationModelPath ([BFFilePathTool applicationModelFilePath])

#define BFUSER_PUBLICKEY       @"publicKey"
#define BFUSER_KEYMOD           @"keymod"
#define BFUSER_KID              @"kid"

#define BFUSER_LATITUDE         @"latitude"
#define BFUSER_LONGITUDE        @"longitude"
#define BFUSER_TOPIMAGEID       @"lobbyTopBackgroundId"


@interface BFApplicationModel()

//屏幕亮度
@property(nonatomic, assign) CGFloat curBrightness;
@property(nonatomic, assign) CGFloat toBrightness;
@property(nonatomic, strong) NSTimer* timerBrightness;

@end

@implementation BFApplicationModel

+ (instancetype)sharedInstance{
    static BFApplicationModel *_sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[BFApplicationModel alloc] init];
    });
    return _sharedInstance;
}

- (instancetype)init{
    self = [super init];
    if (self) {
        
        NSDictionary *settingDic = [[self class] defaultSettingDictonary];
        
        _defaultSessionKey = settingDic[@"defaultSessionKey"];
        
        _systemType = settingDic[@"systemType"];
        _systemVersion = [BFDeviceTool systemVersion];
        
        _clientType = settingDic[@"clientType"];
        _clientVersion = [BFDeviceTool appVersion];
        _clientChannelID = settingDic[@"clientChannelID"];
        
        _signType = settingDic[@"signType"];
        _sign = settingDic[@"sign"];
        
        _deviceType = [BFDeviceTool deviceType];
        _deviceName = [BFDeviceTool deviceName];
        _deviceModel = [BFDeviceTool deviceModel];
        
        _imsi = @"";
        _imei = @"";
        _bluetoothMac = @"";
        _wifiMac = @"";
        _cellId = @"";
        _lac = @"";
        _rooted = @"";
        
        _encrypt = settingDic[@"ENCRYPT"];
        _v = settingDic[@"V"];
        _sig = settingDic[@"SIG"];
 
        _publicKey = settingDic[@"publicKey"];
        _keymod = settingDic[@"keymod"];
        _kid = settingDic[@"kid"];
        
        _latitude = 0.0;
        _longitude = 0.0;
        
        _lobbyTopBackgroundId = @"";
    }
    return self;
}

+ (NSDictionary *)defaultSettingDictonary{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"ApplicationDefaultSetting" ofType:@"plist"];
    return [NSDictionary dictionaryWithContentsOfFile:filePath];
}

#pragma mark - NSCoding

//解密初始化
- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        self.publicKey = [aDecoder decodeObjectForKey:BFUSER_PUBLICKEY];
        self.keymod = [aDecoder decodeObjectForKey:BFUSER_KEYMOD];
        self.kid = [aDecoder decodeObjectForKey:BFUSER_KID];
        self.latitude = [aDecoder decodeDoubleForKey:BFUSER_LATITUDE];
        self.longitude = [aDecoder decodeDoubleForKey:BFUSER_LONGITUDE];
        self.lobbyTopBackgroundId = [aDecoder decodeObjectForKey:BFUSER_TOPIMAGEID];
    }
    return self;
}

//加密存贮
- (void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.publicKey forKey:BFUSER_PUBLICKEY];
    [aCoder encodeObject:self.keymod forKey:BFUSER_KEYMOD];
    [aCoder encodeObject:self.kid forKey:BFUSER_KID];
    [aCoder encodeDouble:self.latitude forKey:BFUSER_LATITUDE];
    [aCoder encodeDouble:self.longitude forKey:BFUSER_LONGITUDE];
    [aCoder encodeObject:self.lobbyTopBackgroundId forKey:BFUSER_TOPIMAGEID];
}

//清空应用信息
+ (void)clearApplicationInfo{
    [BFApplicationModel sharedInstance].publicKey = @"";
    [BFApplicationModel sharedInstance].keymod = @"";
    [BFApplicationModel sharedInstance].kid = @"";
    [BFApplicationModel sharedInstance].latitude = 0.0;
    [BFApplicationModel sharedInstance].longitude = 0.0;
    [BFApplicationModel sharedInstance].lobbyTopBackgroundId = @"";
    
    [BFApplicationModel saveApplicationInfo];
}

//归档
+ (void)saveApplicationInfo{
    [BFFileTool saveModelObject:[self sharedInstance] toFile:applicationModelPath];
}

//解档
+ (void)loadApplicationInfo{
    
    BFApplicationModel *model = (BFApplicationModel *)[BFFileTool readModelObjectWithFile:applicationModelPath];
    [BFApplicationModel sharedInstance].publicKey = model.publicKey;
    [BFApplicationModel sharedInstance].keymod = model.keymod;
    [BFApplicationModel sharedInstance].kid = model.kid;
    [BFApplicationModel sharedInstance].latitude = model.latitude;
    [BFApplicationModel sharedInstance].longitude = model.longitude;
    [BFApplicationModel sharedInstance].lobbyTopBackgroundId = model.lobbyTopBackgroundId;
    
    //此服务可能无用，发一个不管了
    [[BFApplicationModel sharedInstance] requestPubliceKey] ;
}

#pragma mark - 解决加密信息无网络情况下闪退BUG

- (NSString *)kid{
    if (IsEmptyString(_kid)) {
        return [[[self class] defaultSettingDictonary] objectForKey:@"kid"];
    }
    else {
        return _kid;
    }
}

- (NSString *)keymod{
    if (IsEmptyString(_keymod)) {
        return [[[self class] defaultSettingDictonary] objectForKey:@"keymod"];
    }
    else {
        return _keymod;
    }
}

- (NSString *)publicekey{
    if (IsEmptyString(_publicKey)) {
        return [[[self class] defaultSettingDictonary] objectForKey:@"publicKey"];
    }
    else {
        return _publicKey;
    }
}

- (void)requestPubliceKey{
    NSString *str = [NSString stringWithFormat:@"https://client.bestpay.com.cn/MEPF_INF2/httppost?method=clientupdate.v2&CHANNELID=%@&TYPE=%@&CURRENTVERSION=%@&SYSTEM=%@&SYSVERSION=%@&PHONE=%@&LOCATION=%@", _clientChannelID, _clientType, _clientVersion, _systemType, _systemVersion, _deviceModel, @""];
    
    NSURL *url = [NSURL URLWithString:[str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    NSURLRequest *request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:10];
    [NSURLConnection sendAsynchronousRequest:request queue:[[NSOperationQueue alloc] init] completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        if (!connectionError && data) {
            NSDictionary *dic = [data getObjectFromJSONData];
            
            _publicKey = [dic objectForKey:@"PUBLICEKEY"];
            _keymod = [dic objectForKey:@"KEYMOD"];
            _kid = [dic objectForKey:@"KID"];
            [[self class] saveApplicationInfo];
        }
    }];
}

#pragma mark - 用户屏幕亮度
//显示最亮
- (void)setHighBrightness{
    _curBrightness = [UIScreen mainScreen].brightness ;
    if ( _curBrightness < 1.0f) {
        _toBrightness = 1.0f ;
        if(self.timerBrightness==nil) {
            self.timerBrightness = [NSTimer scheduledTimerWithTimeInterval:1.0/60.0 target:self selector:@selector(brightnessAnimating:) userInfo:nil repeats:YES] ;
        }
    }
}

//显示用户原来的亮度
- (void)setUserBrightness{
    _curBrightness = [UIScreen mainScreen].brightness ;
    if(self.timerBrightness) {
        _toBrightness = _brightnessValue ;
    }
    else if (_curBrightness != _brightnessValue) {
        _toBrightness = _brightnessValue ;
        
        if(self.timerBrightness==nil) {
            self.timerBrightness = [NSTimer scheduledTimerWithTimeInterval:1.0/60.0 target:self selector:@selector(brightnessAnimating:) userInfo:nil repeats:YES] ;
        }
    }
}

- (void)brightnessAnimating:(id)sender {
    if (_curBrightness < _toBrightness) {
        _curBrightness += 0.01 ;
        if (_curBrightness >= _toBrightness) {
            _curBrightness = _toBrightness ;
            [self.timerBrightness invalidate] ;
            self.timerBrightness = nil ;
        }
    }
    else {
        _curBrightness -= 0.01 ;
        if (_curBrightness <= _toBrightness) {
            _curBrightness = _toBrightness ;
            [self.timerBrightness invalidate] ;
            self.timerBrightness = nil ;
        }
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIScreen mainScreen].brightness = _curBrightness ;
    });
}
@end

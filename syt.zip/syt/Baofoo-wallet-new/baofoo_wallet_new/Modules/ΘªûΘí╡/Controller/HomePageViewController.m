//
//  HomePageViewController.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/5.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "HomePageViewController.h"
#import "BFLobbyIndexHeader.h"
#import "AppCollectionCell.h"
#import "BFLobbyAnimationView.h"
#import "BFLobbyTopView.h"
#import "BFLobbyManager.h"
#import "BFLobbyAppPackageManager.h"
#import "BFCycleScrollView.h"
#import "BFAppManager.h"
#import "BFApplicationModel.h"
#import "AppOperationHandle.h"
#import "BFAdManager.h"
#import "AppDelegate.h"

NSString *const JumpToAppNotification = @"JumpToAppNotification";
NSString *const JumpToAppNotificationAppIdKey = @"JumpToAppNotificationAppIdKey";
static NSString *cellidentifier = @"cellidentifer";
#define APP_COUNT_SECTION 12

@interface HomePageViewController ()<BFLobbyTopViewDelegate,UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout,UIScrollViewDelegate, BFCycleScrollViewDelegate>
{
    BFCycleScrollView *cycleSrollView;
    //子应用列表
    UICollectionView *appCollectionView;
    NSMutableArray *appCollectionData;
    //顶部View
    BFLobbyTopView  *lobbyTopView;
    //小人动画view
    BFLobbyAnimationView  *animationView;
    //顶部颜色ID
    NSInteger  colorID;
    //渐变layer
    CAGradientLayer *gradientLayer;
    //颜色数组
    NSArray *colorArray;
    //temp_test
    NSArray *tabBarColorArray;
}

@property (nonatomic, strong) UIScrollView *subScroll;
@property (nonatomic, strong) BFAppManager* appManager ;
@property (nonatomic, strong) AppCollectionCell* selectCell ;

//是否有新的交易提醒
@property (nonatomic, assign) BOOL                 isNewTransaction;
@property (nonatomic, strong) NSString             *nTransactionListDateStr;

//是否有新的系统消息
@property (nonatomic, assign) BOOL                 isNewSystemNews;
@property (nonatomic, strong) NSString             *nSystemNewsDateStr;

@end

@implementation HomePageViewController
#pragma mark - 刷新UI

//刷新广告
- (void)refreshAdList{
    DebugLog(@"LobbyIndex: Refresh adList");
    
    NSMutableArray *adModels = [NSMutableArray array];
    BFAdModel *ad_m1 = [[BFAdModel alloc] init];
    ad_m1.adImgURL = @"1";
    [adModels addObject:ad_m1];
    
    BFAdModel *ad_m2 = [[BFAdModel alloc] init];
    ad_m2.adImgURL = @"2";
    [adModels addObject:ad_m2];
    cycleSrollView.scrollData = adModels;
}

#pragma mark - UI

- (void)drawUI{
    //
    colorArray = [[NSArray alloc]initWithObjects:
                  @[(__bridge id)UIColorRgb(82, 171, 255).CGColor, (__bridge id)UIColorRgb(82, 171, 255).CGColor],
                  @[(__bridge id)UIColorRgb(255, 159, 34).CGColor, (__bridge id)UIColorRgb(255, 159, 34).CGColor],
                  @[(__bridge id)UIColorRgb(253, 88, 70).CGColor, (__bridge id)UIColorRgb(253, 88, 70).CGColor],
                  @[(__bridge id)UIColorRgb(17, 196, 148).CGColor, (__bridge id)UIColorRgb(17, 196, 148).CGColor], nil];
    
    //topView
    CGFloat topViewHeight = 0;
    if (_iPhone6_) {
        topViewHeight = 188;
    }
    else if (_iPhone6P_){
        topViewHeight = 192;
    }
    else{
        topViewHeight = 148;
    }
    lobbyTopView = [[BFLobbyTopView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, topViewHeight)];
    lobbyTopView.delegate = self;
    [self.view addSubview:lobbyTopView];
    
    gradientLayer = [CAGradientLayer layer];
    gradientLayer.frame = lobbyTopView.frame;
    [lobbyTopView.layer insertSublayer:gradientLayer atIndex:0];
    
    UIColor *bgColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"huawen"]];
    UIView *bgview = [[UIView alloc] initWithFrame:lobbyTopView.frame];
    [bgview setBackgroundColor:bgColor];
    [lobbyTopView addSubview:bgview];
    
    [self loadLayerColor];
    
    //广告
    {
        cycleSrollView = [BFCycleScrollView createWithFrame:CGRectMake(9, 0, ScreenWidth - 18,LobbyBannerRatio * (ScreenWidth - 18)) target:self];
        cycleSrollView.backgroundColor = [UIColor clearColor];
        cycleSrollView.clipsToBounds = YES ;
        cycleSrollView.layer.cornerRadius = 8.0f ;
    }
    
    //collection view
    {
        CGFloat width = ScreenWidth ;
        CGFloat height = ScreenHeight - 49 - lobbyTopView.size_H ;
        
        CGFloat space = 9.0;
        CGFloat cellWidth = (ScreenWidth-space*5)/4.0;
        CGFloat cellHeight = cellWidth*101.0/81.0;
        
        UICollectionViewFlowLayout *flowLayout= [[UICollectionViewFlowLayout alloc] init];
        flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
        flowLayout.itemSize = CGSizeMake(cellWidth, cellHeight);
        flowLayout.minimumLineSpacing = space;
        flowLayout.minimumInteritemSpacing = space;
        flowLayout.sectionInset = UIEdgeInsetsMake(space, space, space, space);
        flowLayout.footerReferenceSize = CGSizeMake(ScreenWidth, cycleSrollView.size_H) ;
        
        appCollectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, lobbyTopView.size_H, width, height) collectionViewLayout:flowLayout];
        appCollectionView.backgroundColor = [UIColor clearColor];
        appCollectionView.delegate = self;
        appCollectionView.dataSource = self;
        appCollectionView.alwaysBounceVertical = YES;
        [appCollectionView registerClass:[AppCollectionCell class] forCellWithReuseIdentifier:cellidentifier];
        [appCollectionView registerClass:[BFCycleScrollView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"BFCycleScrollView"] ;
        [appCollectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"UICollectionReusableView"] ;
        
        [self.view insertSubview:appCollectionView belowSubview:lobbyTopView] ;
    }
    
    //绘制下拉动画view
    {
        animationView = [[BFLobbyAnimationView alloc]initWithFrame:CGRectMake(0, -70, ScreenWidth, 70)];
        [appCollectionView addSubview:animationView];
    }
}

#pragma mark - 顶部背景颜色

//加载layer渐变色
- (void)loadLayerColor{
    if (!IsEmptyString([BFApplicationModel sharedInstance].lobbyTopBackgroundId)) {
        colorID = [[BFApplicationModel sharedInstance].lobbyTopBackgroundId intValue];
    }
    else {
        colorID = 0;
    }
    [self setLobbyTopViewLayerColor:colorID];
}

//开始动画
- (void)doAnimation{
    [animationView startAnimation];
    
    double delayInSeconds = 1.0f;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [self loadTopColorID];
    });
}

//加载颜色ID
- (void)loadTopColorID{
    if (colorID == colorArray.count - 1) {
        colorID = 0;
    }
    else {
        colorID ++;
    }
    
    [self setLobbyTopViewLayerColor:colorID];
    
    [animationView stopAnimation:appCollectionView];
}

//读取layer渐变色
- (void)setLobbyTopViewLayerColor:(NSInteger)index{
    gradientLayer.colors = colorArray[index];
    gradientLayer.startPoint = CGPointMake(0.5, 0.0);
    gradientLayer.endPoint = CGPointMake(0.5,1.0);
    
    [self saveTopColorID:index];
}

//存储颜色编号
- (void)saveTopColorID:(NSInteger)index{
    [BFApplicationModel sharedInstance].lobbyTopBackgroundId = [NSString stringWithFormat:@"%ld",(long)index];
    // 更换首页tarbar的图标
    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    BFTabBarController *tabBar = app.tabBarController;
    [tabBar setTabBarHomePageSelectImage];
    
    [BFApplicationModel saveApplicationInfo];
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    if (scrollView == appCollectionView) {
        if (scrollView.contentOffset.y <= -70 && ![animationView isAnimating]) {
            [UIView animateWithDuration:0.1f animations:^{
                [scrollView setContentInset:UIEdgeInsetsMake(70, 0, 0, 0)];
                [self doAnimation];
            }];
        }
    }
}

#pragma mark - 应用更新推送

- (void)applistDidChangedNotification:(id)sender{
    if(_appManager.isApplistChanged) {
        [appCollectionData removeAllObjects] ;
        [appCollectionData addObjectsFromArray:_appManager.arrOriginApps] ;
        [appCollectionView reloadData];
        _appManager.isApplistChanged = NO ;
    }
}

- (void)appInstallFinishedNotification:(NSNotification *)notification{
    YZFAppItemModel* model = notification.object ;
    if([model isKindOfClass:[YZFAppItemModel class]] && [self.selectCell.model.appId isEqualToString:model.appId]) {
        if ([model checkCurVersionAvailable]) {
            [AppOperationHandle handleApp:self.selectCell curViewControlelr:self];
        }
    }
}

#pragma mark - BFLobbyManagerNotification

- (void)addLobbyManagerNotificationObserver{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshAdList) name:UpdateAdvertiseListFinishedNotification object:nil];
}

- (void)removeLobbyManagerNotificationObserver{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UpdateAdvertiseListFinishedNotification object:nil];
}

- (void)updateAdvertiseListFinished:(NSNotification *)notification{
    DebugLog(@"LobbyIndex: AdList update finished");
    [self refreshAdList];
}

#pragma mark - JumpToApp Notification

- (void)jumpToApp:(NSNotification *)notification{
    
    NSString *jumpAppId = notification.userInfo[JumpToAppNotificationAppIdKey];
    YZFAppItemModel *model = [self getModelWithAppId:jumpAppId];
    
    AppCollectionCell* cell = [[AppCollectionCell alloc] init] ;
    cell.model = model ;
    [AppOperationHandle handleApp:cell curViewControlelr:self] ;
}

- (YZFAppItemModel *)getModelWithAppId:(NSString *)appId{
    for (YZFAppItemModel *model in [self allApps]) {
        if ([model.appId isEqualToString:appId]) {
            return model ;
        }
    }
    
    for (YZFAppItemModel *model in [BFAppManager shareInstance].arrOriginApps) {
        if ([model.appId isEqualToString:appId]) {
            return model ;
        }
    }
    
    return nil ;
}

#pragma mark getters
- (NSArray *) allApps {
    return [BFAppManager shareInstance].arrAllApp ;
}

- (NSArray *) allHtml5Apps {
    return [BFAppManager shareInstance].arrH5Apps ;
}

- (NSArray *) allNativeApps {
    return [BFAppManager shareInstance].arrNative ;
}

#pragma mark - Jump

- (void)jumpToPayCode{
}

#pragma mark - UICollectionViewDelegate & Datasource

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    NSInteger number = appCollectionData.count / APP_COUNT_SECTION ;
    if ((appCollectionData.count % APP_COUNT_SECTION)>0) {
        number += 1 ;
    }
    return number ;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    NSInteger number = [self numberOfSectionsInCollectionView:collectionView] ;
    if(section==number-1) {//最后一个
        return appCollectionData.count - APP_COUNT_SECTION*section ;
    }
    return APP_COUNT_SECTION ;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)theCollectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    UICollectionReusableView *theView = nil ;
    if(kind==UICollectionElementKindSectionFooter && indexPath.section==0) {
        theView = [theCollectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"BFCycleScrollView" forIndexPath:indexPath] ;
        [theView addSubview:cycleSrollView] ;
    }
    else {
        theView = [theCollectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter withReuseIdentifier:@"UICollectionReusableView" forIndexPath:indexPath] ;
    }
    return theView ;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    AppCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellidentifier forIndexPath:indexPath];
    cell.model = appCollectionData[indexPath.row + APP_COUNT_SECTION*indexPath.section];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    self.selectCell = (AppCollectionCell *)[collectionView cellForItemAtIndexPath:indexPath];
    YZFAppItemModel *tempModel = self.selectCell.model;
    [AppOperationHandle handleApp:self.selectCell curViewControlelr:self];
    
    DebugLog(@"LobbyIndex: 选中 %@/%@/%@", tempModel.appName, tempModel.appId, tempModel.version);
}


- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section {
    if(section==0) return CGSizeMake(ScreenWidth, cycleSrollView.size_H) ;
    return CGSizeZero ;
}

#pragma mark - BFCycleScrollViewDelegate

- (void)cycleScrollView:(BFCycleScrollView *)cycleScrollView didClick:(BFPerPageView *)perPageView{
    
    if ([BFLoginTool checkLogin]) {
        [BFAdManager handleAdModel:perPageView.adModel curViewController:self];
    }
}

#pragma mark - NewMessage

- (void)getTheNewMessage{
    if ([BFLoginTool loggedIn]) {
        
    }
    else
    {
        _isNewTransaction = NO;
        _isNewSystemNews  = NO;
    }
}

-(void)getTheSystemNews{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString  *sDateStr = [userDefaults objectForKey:@"systemNewsTime"];
    if (sDateStr.length <= 0) {
        sDateStr = [NSString stringWithFormat:@"%@", [NSDate curDateString:DateFormat_YMD_HMS]];
        [[NSUserDefaults standardUserDefaults] setObject:sDateStr forKey:@"systemNewsTime"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
    
}

#pragma mark - BFLobbyTopViewDelegate

//消息
- (void)lobbyTopViewDidSelectNews:(BFLobbyTopView *)lobbyTopView{
    
    //TODO: 增加新登录测试入口，提交前务必还原，金明
    
    //    BFLoginMainViewController *vc = [[BFLoginMainViewController alloc] init];
    //
    //    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    //    [nav setNavigationBarHidden:YES animated:NO];
    //    [nav.interactivePopGestureRecognizer setDelegate:nil];
    //
    //    [self presentViewController:nav animated:YES completion:^{
    //        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:NO];
    //    }];
    
    if ([BFLoginTool checkLogin]) {
       
    }
}

//扫一扫
- (void)lobbyTopViewDidSelectScan:(BFLobbyTopView *)lobbyTopView{
    
}

//付款码
- (void)lobbyTopViewDidSelectPayCode:(BFLobbyTopView *)lobbyTopView{
    if (![BFLoginTool checkLogin]) {
        return;
    }
    [self jumpToPayCode];
}

//收款
- (void)lobbyTopViewDidSelectCollection:(BFLobbyTopView *)lobbyTopView{
    if (![BFLoginTool checkLogin]) {
        return;
    }
}

#pragma mark - Life Cycle

- (void)viewDidLoad{
    [super viewDidLoad];
    
    tabBarColorArray = [[NSArray alloc]initWithObjects:
                        UIColorRgb(253, 88, 70),
                        UIColorRgb(82, 171, 255),
                        UIColorRgb(17, 196, 148),
                        UIColorRgb(255, 159, 34), nil];
    
    _appManager = [BFAppManager shareInstance] ;
    appCollectionData = [[NSMutableArray alloc] init] ;
    
    [self drawUI];
    
    //注册广告更新
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshAdList) name:UpdateAdvertiseListFinishedNotification object:nil];
    //注册App跳转通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(jumpToApp:) name:JumpToAppNotification object:nil];
    
    //加载AppList
    [self refreshAdList];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:NO];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    //安装H5
    if(_appManager.isCanUpdateToNewVersion) {
        [_appManager installH5Apps] ;
    }
    
    //更新列表
    if(_appManager.isApplistChanged) {
        [appCollectionData removeAllObjects] ;
        [appCollectionData addObjectsFromArray:_appManager.arrOriginApps] ;
        [appCollectionView reloadData];
        _appManager.isApplistChanged = NO ;
    }
    
    //刷新消息中心是否有新的消息
    [self getTheNewMessage];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.selectCell = nil ;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:BFApplistDidChangedNotification object:nil] ;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:BFAppInstallFinishedNotification object:nil] ;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated] ;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applistDidChangedNotification:) name:BFApplistDidChangedNotification object:nil] ;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appInstallFinishedNotification:) name:BFAppInstallFinishedNotification object:nil] ;
}

- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:JumpToAppNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UpdateAdvertiseListFinishedNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end

//
//  BFApplicationModel.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BFApplicationModel : NSObject

@property (nonatomic, copy, readonly) NSString *defaultSessionKey; //默认sessionKey

@property (strong, nonatomic, readonly) NSString *systemType;    //系统类型
@property (strong, nonatomic, readonly) NSString *systemVersion; //系统版本号

@property (strong, nonatomic, readonly) NSString *clientType;    //客户端类型
@property (strong, nonatomic, readonly) NSString *clientVersion; //客户端版本号
@property (strong, nonatomic, readonly) NSString *clientChannelID; //客户端渠道号

@property (strong, nonatomic, readonly) NSString *signType; //签名类型 1.RSA 2.MAC(默认RSA)
@property (strong, nonatomic, readonly) NSString *sign;     //签名

@property (strong, nonatomic, readonly) NSString *deviceType;  //设备类型
@property (strong, nonatomic, readonly) NSString *deviceName;  //设备信息
@property (strong, nonatomic, readonly) NSString *deviceModel;
@property (strong, nonatomic, readonly) NSString *deviceId; //设备唯一标识

@property (strong, nonatomic, readonly) NSString *vendorUUID; //广告位标别

@property (strong, nonatomic, readonly) NSString *imsi;  //IMSI号码
@property (strong, nonatomic, readonly) NSString *imei;  //IMEI号码
@property (strong, nonatomic, readonly) NSString *bluetoothMac; //蓝牙MAC
@property (strong, nonatomic, readonly) NSString *wifiMac;  //WiFi MAC
@property (strong, nonatomic, readonly) NSString *wifiName; //WiFi 名字
@property (strong, nonatomic, readonly) NSString *network; //手机当前联网类型
@property (strong, nonatomic, readonly) NSString *cellId; //基站Id
@property (strong, nonatomic, readonly) NSString *lac; //基站
@property (strong, nonatomic, readonly) NSString *rooted; //是否拥有root权限

@property (strong, nonatomic, readonly) NSString *encrypt;
@property (strong, nonatomic, readonly) NSString *v;
@property (strong, nonatomic, readonly) NSString *sig;

@property (strong, nonatomic, readonly) NSString *PassGuardLicense;

@property (strong, nonatomic, readonly) NSString *BaiduMapKey;

@property (strong, nonatomic, readonly) NSString *TalkingDataAppKey;
@property (strong, nonatomic, readonly) NSString *TalkingDataAppId;

@property (strong, nonatomic, readonly) NSString *NBSAppAgentRedirectURL;
@property (strong, nonatomic, readonly) NSString *NBSAppAgentAppId;

@property (strong, nonatomic, readonly) NSString *UMSocialAppKey;
@property (strong, nonatomic, readonly) NSString *UMSocialDeafultShareURL;
@property (strong, nonatomic, readonly) NSString *UMSocialWXAppId;
@property (strong, nonatomic, readonly) NSString *UMSocialQQAppId;
@property (strong, nonatomic, readonly) NSString *UMSocialYXAppId;
@property (strong, nonatomic, readonly) NSString *UMSocialSinaWeiboRedirectURL;

//基础信息
@property (nonatomic, copy) NSString *publicKey;
@property (nonatomic, copy) NSString *keymod;
@property (nonatomic, copy) NSString *kid;

//定位经纬度
@property (nonatomic, assign) double latitude; //纬度
@property (nonatomic, assign) double longitude; //经度

//当前屏幕亮度值
@property (nonatomic, assign) CGFloat brightnessValue;

- (void)setHighBrightness; //显示最亮
- (void)setUserBrightness; //显示用户原来的亮度

//是否是条码页面
@property (nonatomic, assign) BOOL isBarCodeVC;

//首页顶部背景色ID
@property (nonatomic,copy) NSString *lobbyTopBackgroundId;

@property (nonatomic, assign) BOOL showView;//是否有显示大视图 用于付款码放大， 不用存储

+ (instancetype)sharedInstance;

+ (void)loadApplicationInfo; //加载
+ (void)saveApplicationInfo; //保存
+ (void)clearApplicationInfo; //清空应用信息


@end

//
//  BFLobbyAnimationView.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFLobbyAnimationView.h"

@implementation BFLobbyAnimationView


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor clearColor];
        
        _isAnimating = NO;
        
        promptLabel = [[UILabel alloc]initWithFrame:CGRectMake(((ScreenWidth - 140)/2), (self.frame.size.height - 21)/2, 140, 21)];
        promptLabel.backgroundColor = [UIColor clearColor];
        [promptLabel setTextAlignment:NSTextAlignmentCenter];
        [promptLabel setFont:BF_Font_14];
        [promptLabel setTextColor:UIColorLightGray()];
        [promptLabel setText:@"下拉更换背景"];
        [self addSubview:promptLabel];
        
        progressImageView = [[UIImageView alloc]initWithFrame:CGRectMake((ScreenWidth - 53)/2 ,(self.frame.size.height - 12)/2, 53, 12)];
        progressImageView.backgroundColor = [UIColor clearColor];
        [progressImageView setImage:[UIImage imageNamed:@"progress_image_1"]];
        progressImageView.hidden = YES;
        [self addSubview:progressImageView];
        
//        personImageView = [[UIImageView alloc] initWithFrame:CGRectMake(progressImageView.frame.origin.x + progressImageView.frame.size.width + 25, (self.frame.size.height - 60)/2, 60, 60)];
//        [personImageView setImage:[UIImage imageNamed:@"person_image_1"]];
//        personImageView.backgroundColor = [UIColor clearColor];
//        [self addSubview:personImageView];
        
    }
    return self;
}

//设置动画数组
- (void)setAnimationImages
{
    //进度框图片
    NSArray *progressImages = [NSArray arrayWithObjects:
                               [UIImage imageNamed:@"progress_image_1"],
                               [UIImage imageNamed:@"progress_image_2"],
                               [UIImage imageNamed:@"progress_image_3"],
                               [UIImage imageNamed:@"progress_image_4"],
                               [UIImage imageNamed:@"progress_image_5"],
                               [UIImage imageNamed:@"progress_image_6"],
                               [UIImage imageNamed:@"progress_image_7"],
                               [UIImage imageNamed:@"progress_image_8"],nil];
    //小人图片
//    NSArray *personImages = [NSArray arrayWithObjects:
//                             [UIImage imageNamed:@"1"],
//                             [UIImage imageNamed:@"2"],
//                             [UIImage imageNamed:@"3"],
//                             [UIImage imageNamed:@"4"],
//                             [UIImage imageNamed:@"5"],
//                             [UIImage imageNamed:@"6"],
//                             [UIImage imageNamed:@"7"],
//                             [UIImage imageNamed:@"8"],
//                             nil];
//    NSArray *personImages = [NSArray arrayWithObjects:
//                             [UIImage imageNamed:@"person_image_1"],
//                             [UIImage imageNamed:@"person_image_2"],
//                             [UIImage imageNamed:@"person_image_3"],
//                             [UIImage imageNamed:@"person_image_4"],
//                             [UIImage imageNamed:@"person_image_5"],
//                             [UIImage imageNamed:@"person_image_6"],
//                             [UIImage imageNamed:@"person_image_7"],
//                             [UIImage imageNamed:@"person_image_8"],
//                             nil];
    
    progressImageView.animationImages = progressImages;
//    personImageView.animationImages = personImages;
}

- (void)startAnimation
{
    _isAnimating = YES;
    
    [self setAnimationImages];
    
    promptLabel.hidden = YES;
    progressImageView.hidden = NO;
    
    progressImageView.animationDuration = 0.5f;//设置动画总时间
    progressImageView.animationRepeatCount = 2;//设置重复次数,0表示无限
    [progressImageView startAnimating];//开始动画
    
//    [personImageView setImage:[UIImage imageNamed:@"person_image_8"]];
//    personImageView.animationDuration = 1.0f;//设置动画总时间
//    personImageView.animationRepeatCount = 1;//设置重复次数,0表示无限
//    [personImageView startAnimating]; //开始动画
    
}

- (void)stopAnimation:(UIScrollView *)scrollView
{
//    personImageView.animationImages = nil;
    progressImageView.animationImages = nil;
    
    [UIView animateWithDuration:0.2f animations:^{
        self.alpha = 0;
        [scrollView setContentInset:UIEdgeInsetsMake(0, 0, 0, 0)];
    } completion:^(BOOL finished) {
//        [personImageView setImage:[UIImage imageNamed:@"person_image_1"]];
        _isAnimating = NO;
        progressImageView.hidden = YES;
        promptLabel.hidden = NO;
        self.alpha = 1;
    }];
}

@end

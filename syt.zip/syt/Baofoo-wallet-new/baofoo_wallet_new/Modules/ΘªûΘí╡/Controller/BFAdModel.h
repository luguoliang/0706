//
//  BFAdModel.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseModel.h"

@interface BFAdModel : BFBaseModel
@property (copy, nonatomic) NSString *adId; //广告ID
@property (copy, nonatomic) NSString *adImgURL; //广告图片地址
@property (copy, nonatomic) NSString *adType; //
@property (copy, nonatomic) NSString *adText; //广告文字
@property (copy, nonatomic) NSString *action; //广告点击动作 00-无动作 01-跳转公告 02-进入应用（需要时先登录）03-跳转浏览器 04-跳转意见反馈

@property (copy, nonatomic) NSString *msgId; //消息ID
@property (copy, nonatomic) NSString *appId; //应用ID
@property (copy, nonatomic) NSString *createDate; //创建时间
@property (copy, nonatomic) NSString *url; //跳转浏览器地址
@property (copy, nonatomic) NSString *title;
@property (copy, nonatomic) NSString *adLocation;

@end

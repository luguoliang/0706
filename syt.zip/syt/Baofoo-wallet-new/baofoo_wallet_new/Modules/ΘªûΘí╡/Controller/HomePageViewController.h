//
//  HomePageViewController.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/5.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

UIKIT_EXTERN NSString *const JumpToAppNotification;
UIKIT_EXTERN NSString *const JumpToAppNotificationAppIdKey;

@interface HomePageViewController : BFBaseViewController

@end

//
//  BFAdManager.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFAdManager.h"

@implementation BFAdManager

+ (void)handleAdModel:(BFAdModel *)model curViewController:(UIViewController *)curViewController{
    
    DebugLog(@"BFAdManager: handle id = %@, text = %@, type = %@, action = %@", model.adId, model.adText, model.adType, model.action);
    
    
    //广告点击动作 00-无动作 01-跳转公告 02-进入应用（需要时先登录）03-跳转浏览器（无交互） 05-支持原生交互
    
    //02-进入应用（需要时先登录）
    if (model.action.integerValue==2) {
        if (!IsEmptyString(model.url)) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:model.url]] ;
        }
    }
    //03-跳转浏览器（无交互）
    else if(model.action.integerValue==3) {
        if (!IsEmptyString(model.url)) {
            
        }
    }
    //05-支持原生交互
    else if(model.action.integerValue==5) {
        
    }
}

@end

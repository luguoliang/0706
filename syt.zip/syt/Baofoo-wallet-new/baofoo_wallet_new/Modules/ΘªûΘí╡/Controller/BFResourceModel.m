//
//  BFResourceModel.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFResourceModel.h"


@interface BFResourceModel ()<NSCoding>

@end

@implementation BFResourceModel
@synthesize rcId;
@synthesize rcType;
@synthesize beginDate;
@synthesize endDate;
@synthesize url;
@synthesize hush;
@synthesize desc;
@synthesize fileSize;

+ (NSArray *)getModelsFromArray:(NSArray *)array{
    if ([BFTool isEmptyArray:array]) {
        return @[];
    }
    
    NSMutableArray *models = [NSMutableArray array];
    [models removeAllObjects];
    
    for (NSDictionary *dic in array) {
        BFResourceModel *model = [BFResourceModel getModelFromDictionary:dic];
        [models addObject:model];
    }
    return models;
}

+ (instancetype)getModelFromDictionary:(NSDictionary *)dictionary{
    
    BFResourceModel *model = [BFResourceModel createModel];
    model.rcId = dictionary[@"rcId"];
    model.rcType = dictionary[@"rcType"];
    model.beginDate = dictionary[@"beginDate"];
    model.endDate = dictionary[@"endDate"];
    model.url = dictionary[@"url"];
    model.hush = dictionary[@"hush"];
    model.desc = dictionary[@"desc"];
    model.fileSize = dictionary[@"fileSize"];
    
    return model;
}

- (id)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super init]) {
        self.rcId = [aDecoder decodeObjectForKey:@"rcId"];
        self.rcType = [aDecoder decodeObjectForKey:@"rcType"];
        self.beginDate = [aDecoder decodeObjectForKey:@"beginDate"];
        self.endDate = [aDecoder decodeObjectForKey:@"endDate"];
        self.url = [aDecoder decodeObjectForKey:@"url"];
        self.hush = [aDecoder decodeObjectForKey:@"hush"];
        self.desc = [aDecoder decodeObjectForKey:@"desc"];
        self.fileSize = [aDecoder decodeObjectForKey:@"fileSize"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:rcId forKey:@"rcId"];
    [aCoder encodeObject:rcType forKey:@"rcType"];
    [aCoder encodeObject:beginDate forKey:@"beginDate"];
    [aCoder encodeObject:endDate forKey:@"endDate"];
    [aCoder encodeObject:url forKey:@"url"];
    [aCoder encodeObject:hush forKey:@"hush"];
    [aCoder encodeObject:desc forKey:@"desc"];
    [aCoder encodeObject:fileSize forKey:@"fileSize"];
}

@end

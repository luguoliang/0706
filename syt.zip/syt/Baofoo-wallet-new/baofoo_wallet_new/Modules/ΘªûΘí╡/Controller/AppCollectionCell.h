//
//  AppCollectionCell.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YZFAppItemModel.h"

typedef NS_ENUM(NSInteger, AppStatus) {
    AppStatusNormal = 0, //正常状态
    //    AppStatusNeedDownload, //需要下载
    AppStatusDownloading, //正在下载
    //    AppStatusStopDownload, //暂停下载
    AppStatusMaintain //维护中
};

@interface AppCollectionCell : UICollectionViewCell

@property (strong, nonatomic) YZFAppItemModel *model;
@property (assign, nonatomic) BOOL showNotice;
@property (assign, nonatomic) AppStatus status;
@property (nonatomic, strong) UILabel *progressLabel;


@end

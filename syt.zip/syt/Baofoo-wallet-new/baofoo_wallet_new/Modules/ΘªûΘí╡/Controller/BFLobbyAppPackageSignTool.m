//
//  BFLobbyAppPackageSignTool.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFLobbyAppPackageSignTool.h"

#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonDigest.h>
//#import "Base64.h"

#define FileHashDefaultChunkSizeForReadingData  1024*8
#define pubkey                                  @"0102030405060708"

#define pred        @"!(SELF BEGINSWITH[cd] '__MAC')"
#define dsstore     @".DS_Store"

@implementation BFLobbyAppPackageSignTool


/**
 *  文件包签名算法
 *
 *  @param filepath 文件目录路径
 *
 *  @return 文件包签名值
 */

+ (NSString *)getTheAppPacketStringWithTheAppItem:(NSString *)filepath{
    NSMutableArray *absolutePaths = [[self class] getTheSubPathMd5StringsWithTheAppItem:filepath];
    NSMutableString *packetMd5Strings = [NSMutableString string];
    
    NSMutableArray *packetMd5Array = [NSMutableArray array];
    
    for (int i = 0; i < absolutePaths.count; i++) {
        NSString *prestr = [absolutePaths objectAtIndex:i];
        NSString *packetMd5String = [[self class] getFileMD5WithPath:prestr];
        
        if(!packetMd5String)
            continue;
        [packetMd5Array addObject:packetMd5String];
    }
    
    //md5值升序排列
    packetMd5Array = [NSMutableArray arrayWithArray:[packetMd5Array sortedArrayUsingSelector:@selector(compare:)]];
    
    for (int i = 0; i < packetMd5Array.count; i ++) {
        [packetMd5Strings appendString:[packetMd5Array objectAtIndex:i]];
    }
    
    NSString *tempStr = [[self class] md5:packetMd5Strings];
    
    NSString *str = [[self class] encrypt:tempStr withKey:pubkey];
    
    return str;
}

/**
 *  DES加密算法
 *
 *  @param string 待加密明文
 *  @param key    加密key
 *
 *  @return 加密密文
 */

+ (NSString *)encrypt:(NSString *)string withKey:(NSString *)key{
    //key处理
    NSString *decString = [[self class] stringFromHexString:key];
    NSData *keyData = [decString dataUsingEncoding:NSUTF8StringEncoding];
    const void *vkey = [keyData bytes];
    
    //初始向量
    Byte iv[] = {0, 0, 0, 0, 0, 0, 0, 0};
    
    
    //明文处理
    NSData *plainData = [string dataUsingEncoding:NSUTF8StringEncoding];
    const void *sourceText = [plainData bytes];
    size_t sourceTextBufferSize = [plainData length];
    
    //密文变量
    uint8_t *bufferPtr = NULL;
    size_t bufferPtrSize = 0;
    size_t movedBytes = 0;
    
    bufferPtrSize = sourceTextBufferSize + kCCBlockSizeAES128;
    bufferPtr = malloc(bufferPtrSize);
    memset((void *)bufferPtr, 0x0, bufferPtrSize);
    
    //加密
    CCCryptorStatus ccStatus;
    ccStatus = CCCrypt(kCCEncrypt,          //加密
                       kCCAlgorithmDES,     //加密算法
                       0x0000,              //填充方式|分组模式：无填充 | CBC(默认)
                       vkey,                //key
                       kCCKeySizeDES,       //key长度
                       iv,                  //可选初始向量
                       sourceText,          //加密源串
                       sourceTextBufferSize,//加密源串长度
                       (void *)bufferPtr,   //加密后数据
                       bufferPtrSize,       //加密数据长度
                       &movedBytes);        //加密数据偏移
    
    if (ccStatus == kCCSuccess) {
        NSData *data = [NSData dataWithBytes:bufferPtr length:movedBytes];
        const char *retPtr = [data bytes];
        
        NSMutableString *ret = [NSMutableString string];
        
        for (int i = 0; i < data.length; ++i) {
            [ret appendString:[NSString stringWithFormat:@"%02X", retPtr[i]&0xFF]];
        }
        
        return ret;
    }
    
    return nil;
}

/**
 *  16进制字符串转10进制
 *
 *  @param hexString 16进制字符串
 *
 *  @return 10进制字符串
 */

+ (NSString *)stringFromHexString:(NSString *)hexString {
    
    char *myBuffer = (char *)malloc((int)[hexString length] / 2 + 1);
    bzero(myBuffer, [hexString length] / 2 + 1);
    for (int i = 0; i < [hexString length] - 1; i += 2) {
        unsigned int anInt;
        NSString *hexCharStr = [hexString substringWithRange:NSMakeRange(i, 2)];
        NSScanner *scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        myBuffer[i / 2] = (char)anInt;
    }
    NSString *unicodeString = [NSString stringWithCString:myBuffer encoding:NSUTF8StringEncoding];
    return unicodeString;
}


/**
 *  32位小写md5
 *
 *  @param inputText 源信息
 *
 *  @return 摘要结果
 */

+ (NSString *)md5:(NSString *)inputText{
    
    const char *cStr = [inputText UTF8String];
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    CC_MD5(cStr, (unsigned int)strlen(cStr), result);
    
    NSMutableString *retString = [[NSMutableString alloc] initWithCapacity:CC_MD5_DIGEST_LENGTH*2];
    
    for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i ++) {
        
        [retString appendFormat:@"%02x", result[i]];
    }
    
    return retString;
}

/**
 *  获取资源目录文件路径集合（去除非常规文件）
 *
 *  @param appPath 资源目录路径
 *
 *  @return 资源目录下文件路径集合
 */

+ (NSMutableArray *)getTheSubPathMd5StringsWithTheAppItem:(NSString *)appPath{
    //相对子路径
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *oppositeSubPaths = [fileManager subpathsAtPath:appPath];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:pred];
    oppositeSubPaths = [oppositeSubPaths filteredArrayUsingPredicate:predicate];
    
    //绝对子路径
    NSMutableArray *absolutePaths = [NSMutableArray array];
    for (int i = 0; i < oppositeSubPaths.count; i++) {
        NSString *oppositeSubPath = [oppositeSubPaths objectAtIndex:i];
        if([oppositeSubPath isEqualToString:Properties_File] ||
           [oppositeSubPath isEqualToString:PublicJs_File] ||
           [oppositeSubPath isEqualToString:dsstore]) {
            continue;
        }
        NSString *absolutePath = [appPath stringByAppendingPathComponent:oppositeSubPath];
        
        [absolutePaths addObject:absolutePath];
    }
    
    //升序排列
    absolutePaths = [NSMutableArray arrayWithArray:[absolutePaths sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [obj1 compare:obj2];
    }]];
    
    return absolutePaths;
}

/**
 *  根据文件路径计算文件md5值
 *
 *  @param path 文件路径
 *
 *  @return 文件md5值
 */

+ (NSString *)getFileMD5WithPath:(NSString *)path{
    return (__bridge_transfer NSString *)FileMD5HashCreateWithPath1((__bridge CFStringRef)path, FileHashDefaultChunkSizeForReadingData);
}

/**
 *  文件流md5值计算
 *
 *  @param filePath                文件路径
 *  @param chunkSizeForReadingData 文件md5值
 *
 *  @return 文件md5值
 */

CFStringRef FileMD5HashCreateWithPath1(CFStringRef filePath, size_t chunkSizeForReadingData) {
    // Declare needed variables
    CFStringRef result = NULL;
    CFReadStreamRef readStream = NULL;
    // Get the file URL
    CFURLRef fileURL =
    CFURLCreateWithFileSystemPath(kCFAllocatorDefault,
                                  (CFStringRef)filePath,
                                  kCFURLPOSIXPathStyle,
                                  (Boolean)false);
    if (!fileURL) goto done;
    // Create and open the read stream
    readStream = CFReadStreamCreateWithFile(kCFAllocatorDefault,
                                            (CFURLRef)fileURL);
    if (!readStream) goto done;
    bool didSucceed = (bool)CFReadStreamOpen(readStream);
    if (!didSucceed) goto done;
    // Initialize the hash object
    CC_MD5_CTX hashObject;
    CC_MD5_Init(&hashObject);
    // Make sure chunkSizeForReadingData is valid
    if (!chunkSizeForReadingData) {
        chunkSizeForReadingData = FileHashDefaultChunkSizeForReadingData;
    }
    // Feed the data to the hash object
    bool hasMoreData = true;
    while (hasMoreData) {
        uint8_t buffer[chunkSizeForReadingData];
        CFIndex readBytesCount = CFReadStreamRead(readStream,(UInt8 *)buffer,(CFIndex)sizeof(buffer));
        if (readBytesCount == -1) break;
        if (readBytesCount == 0) {
            hasMoreData = false;
            continue;
        }
        CC_MD5_Update(&hashObject,(const void *)buffer,(CC_LONG)readBytesCount);
    }
    // Check if the read operation succeeded
    didSucceed = !hasMoreData;
    // Compute the hash digest
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    CC_MD5_Final(digest, &hashObject);
    // Abort if the read operation failed
    if (!didSucceed) goto done;
    // Compute the string result
    char hash[2 * sizeof(digest) + 1];
    for (size_t i = 0; i < sizeof(digest); ++i) {
        snprintf(hash + (2 * i), 3, "%02x", (int)(digest[i]));
    }
    result = CFStringCreateWithCString(kCFAllocatorDefault,(const char *)hash,kCFStringEncodingUTF8);
    
done:
    if (readStream) {
        CFReadStreamClose(readStream);
        CFRelease(readStream);
    }
    if (fileURL) {
        CFRelease(fileURL);
    }
    return result;
}
@end

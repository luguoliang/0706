//
//  CheckoutCounterViewController.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckoutCounterViewController : UIViewController

@end

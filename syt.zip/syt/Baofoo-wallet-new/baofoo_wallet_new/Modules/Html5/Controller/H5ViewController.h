//
//  H5ViewController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/4/11.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

@class YZFAppItemModel;

@interface H5ViewController : BFBaseViewController

@property (nonatomic, copy) NSString *path;
@property (nonatomic, strong) YZFAppItemModel *model;

@end

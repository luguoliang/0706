//
//  BFWebViewController.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/25.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

@interface BFWebViewController : BFBaseViewController
@property(nonatomic,copy)NSString*urlStr;
@property(nonatomic,copy)NSString*natitle;
@property(nonatomic,copy) NSString *product_id;//产品id
@property(nonatomic,unsafe_unretained)BOOL titleStatus;//设置标题的状态

@property(nonatomic)BOOL isTTJX;//是否是天天精选
@property(nonatomic)BOOL isPartner;//是否是合伙人页面
@property(nonatomic)BOOL isOrdinaryWeb;//是否是普通的静态页面
@property(nonatomic)BOOL isForgetPassword;//是否是忘记登录密码页面

//设置普通的标题和返回按钮
- (void)setNavgationTitle:(NSString *)title;

//设置左边的返回按钮，在网页没加载出来之前显示叉号
- (void)setLeftNavgationBtn;
@end

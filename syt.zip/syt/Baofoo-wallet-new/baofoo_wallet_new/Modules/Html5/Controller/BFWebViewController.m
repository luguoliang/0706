//
//  BFWebViewController.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/25.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFWebViewController.h"
#import "BFRequestURLConfigHeader.h"
#import "BFCoreDataModelop.h"
#import "NJKWebViewProgressView.h"
#import "NJKWebViewProgress.h"
#import "WBRefreshGifHeader.h"
#import "UIScrollView+MJRefresh.h"
#import "BFReloadView.h"
#import "TTJXLabel.h"
#import "TTJXButton.h"
#import "RSAEntryPtion.h"
#import "BFReqAPI+Security.h"
#import "BFSecurityCenterViewModel.h"
#import "BFBuyCommodityViewController.h"

#define BUY_BUTTON_HEIGHT 47.0f
#define NAV_BTN_WIDTH 80.0f
#define NAV_CENTER_WIDTH 180.0f

@interface BFWebViewController ()<UIWebViewDelegate,NJKWebViewProgressDelegate,BFReloadViewDelegate>
@property(nonatomic,strong)NJKWebViewProgressView *progressView;
@property(nonatomic,strong)NJKWebViewProgress *progressProxy;
@property(nonatomic,copy)NSString *auFlag;//认证的状态
@property(nonatomic,copy)NSString *sign;//找回支付密码的签名
@property(nonatomic,copy)NSString *next;//跳转下一步
@property(nonatomic,copy)NSString *op;//找回方式
@property(nonatomic,copy)NSString *mobile;//绑定手机号
@property(nonatomic,copy)NSString *other;//是否显示列表

//@property(nonatomic,strong)UIView *navgationBarView;//自定义导航
@property(nonatomic,strong)UILabel *lineLabel;//线
//@property(nonatomic,strong)NJKWebViewProgressView *progressView;
//@property(nonatomic,strong)NJKWebViewProgress *progressProxy;
@property(nonatomic,strong)NSMutableArray *segementTypeArr;
@property(nonatomic,strong)NSMutableArray *segementClickArr;
@property(nonatomic,strong)UIView *currentView;
@property(nonatomic,strong)UIView *ttzIconView;
@property(nonatomic,strong)UIView *leftView;//左边视图
@property(nonatomic,strong)UIView *centerView;//中间视图
@property(nonatomic,strong)UIView *rightView;//右边视图
@property(nonatomic,strong)UIWebView *mainWeb;
@property(nonatomic,strong)UILabel *titleLabel;//标题
@property(nonatomic,copy)NSString *product_title;
#pragma mark--购买
@property(nonatomic,strong)UIView *buyView;
@property(nonatomic,strong)UIButton *buyBtn;
@property(nonatomic,strong)UILabel *beginLabel;//起投金额
@property(nonatomic,assign)NSInteger pageCount;//网页层级

#pragma mark--断网页面
@property(nonatomic,strong)BFReloadView *reloadView;
@end

@implementation BFWebViewController
- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
            self.hidesBottomBarWhenPushed = YES;
        }
    }
    return self;
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:NO];
    [self setNavBarImage:[UIImage imageNamed:@"navbar_white_bg"] titleColor:[UIColor blackColor]];
    
    
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = _natitle;
    _pageCount = 0;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginSucessful) name:LoginNotificationSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginFailure) name:LoginNotificationFailure object:nil];
    
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self cleanWebCache];
    [self.view addSubview:self.mainWeb];
    [self.view addSubview:self.progressView];
    [self.view addSubview:self.buyView];
    [self settingShowWeb];
}


- (NJKWebViewProgressView *)progressView
{
    if (!_progressView) {
        _progressProxy = [[NJKWebViewProgress alloc] init];
        self.mainWeb.delegate = _progressProxy;
        _progressProxy.webViewProxyDelegate = self;
        _progressProxy.progressDelegate = self;
        
        
        _progressView = [[NJKWebViewProgressView alloc] initWithFrame:CGRectMake(0, 64, ScreenWidth, 3.0f)];
        _progressView.hidden = YES;
        _progressView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    }
    return _progressView;
}


#pragma mark--UIWebViewDelegate
-(void)webViewProgress:(NJKWebViewProgress *)webViewProgress updateProgress:(float)progress
{
    _progressView.hidden = NO;
    [_progressView setProgress:progress animated:YES];
    
}
#pragma mark--设置普通的标题和返回按钮
-(UIView *)centerView
{
    if (!_centerView) {
        _centerView = [[UIView alloc] init];
    }
    return _centerView;
}
- (void)setCenterTitle:(NSString *)title
{
    self.centerView.frame = CGRectMake(0.0f, 20.0f, NAV_CENTER_WIDTH, 44.0f);
    self.centerView.center = CGPointMake(ScreenWidth*0.5, 22.0f+20.0f);
    self.titleLabel.text = title;
    [self.centerView addSubview:self.titleLabel];
    self.navigationItem.titleView = self.centerView;
}

- (BFReloadView *)reloadView
{
    if (!_reloadView) {
        _reloadView = [[BFReloadView alloc] init];
        _reloadView.delegate = self;
    }
    _reloadView.frame = CGRectMake(0, 0, ScreenWidth, CGRectGetHeight(self.mainWeb.frame));
    return _reloadView;
}

#pragma mark - UIWebViewDelegate
static  NSMutableDictionary * __webViewDataDict = nil;
static NSInteger __count = 0;
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    BFCoreDataModelop*op = [[BFCoreDataModelop alloc] init];
    BFCoreUserModel*model = [op getCurrentBFuserModel];
    NSString *urlString = [[request URL] absoluteString];
    NSArray *urlComps = [urlString
                         componentsSeparatedByString:@"://"];
    
    NSArray *arrFucnameAndParameter = [(NSString*)[urlComps
                                                   objectAtIndex:1] componentsSeparatedByString:@"/"];
    NSLog(@"%@",urlString);
    if ([urlString rangeOfString:@"setWebView"].location != NSNotFound) {
        self.titleStatus = YES;
        NSString *jsonString = [[arrFucnameAndParameter lastObject] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSLog(@"%@",jsonString);
        [self setWebView:jsonString];
    }
    else if ([urlString rangeOfString:@"setBuyAmountBegin"].location != NSNotFound){
        NSString *string = [[arrFucnameAndParameter lastObject] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSArray *stringArr = [string componentsSeparatedByString:@","];
        NSString *buy_amount_begin = stringArr[0];
        NSString *buy_status = [stringArr lastObject];
        _beginLabel.text = buy_amount_begin;
        [self.beginLabel setNeedsLayout];
        
        [_buyBtn setImage:[buy_status integerValue]==0?[UIImage imageNamed:@"hsq_shouqing_buy"]:[UIImage imageNamed:@"hsq_now_buy"] forState:UIControlStateNormal];
        _buyBtn.enabled = [buy_status integerValue]==0?NO:YES;
        [self updateProductDetailFrame:NO];
        
    }
    else if([urlString rangeOfString:@"encodeInfo"].location != NSNotFound)
    {
        /*调用本地函数1*/
        NSString *params = [arrFucnameAndParameter objectAtIndex:3];
        NSString *caid = [arrFucnameAndParameter objectAtIndex:2];
        /**
         *  密码加密
         */
        params = [params stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        NSString *backEntcry = [RSAEntryPtion stringWithRSAEncryPtion:[params base64EncodedString]];
        
        //            NSString *backEntcry = [NSString entcryPtion:params];
        backEntcry = [backEntcry stringByReplacingOccurrencesOfString:@"\n" withString:@"%OA"];
        backEntcry = [backEntcry stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
        backEntcry = [backEntcry stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
        backEntcry = [backEntcry stringByReplacingOccurrencesOfString:@"=" withString:@""];
        /**
         *  回调js
         */
        NSString* calljs = [NSString stringWithFormat:@"__iOSNativeBridge.resultForCallback('%@','%@')",caid,backEntcry];
        [webView stringByEvaluatingJavaScriptFromString:calljs];
    }
    //获取用户昵称js调用
    else if ([urlString rangeOfString:@"readCache"].location != NSNotFound) {
        NSString *caid  = [arrFucnameAndParameter objectAtIndex:2];
        NSString* calljs = nil;
        NSString*balance = model.balanceMoney;
        if ([[arrFucnameAndParameter lastObject] isEqualToString:@"balanceMoney"]) {
            
            calljs = [NSString stringWithFormat:@"__iOSNativeBridge.resultForCallback('%@','%@')",caid,[self moneyNumAndChangeformat:balance isDisplayPoint:YES]];
        }
        else
        {
            calljs = [NSString stringWithFormat:@"__iOSNativeBridge.resultForCallback('%@','%@')",caid,model.memberName];
        }
        
        NSLog(@"调用js：%@", calljs);
        [webView stringByEvaluatingJavaScriptFromString:calljs];
    }else if ( [urlString rangeOfString:@"getDeviceId"].location != NSNotFound ) {
        NSString* calljs = nil;
        NSString *caid  = [arrFucnameAndParameter objectAtIndex:2];
        NSString*str = [NSString stringWithFormat:@"%@,%@,%@,%@",[BFDeviceTool deviceName],[BFDeviceTool deviceModel],[BFDeviceTool uuid],[BFDeviceTool deviceType]];
        NSString*devices = [NSString stringWithFormat:@"%@|%@|%@",str,@"3.0.0",([NSString stringWithFormat:@"%.f",[[NSDate date] timeIntervalSince1970]*1000])];
        calljs = [NSString stringWithFormat:@"__iOSNativeBridge.resultForCallback('%@','%@')",caid,devices];
        [webView stringByEvaluatingJavaScriptFromString:calljs];
    }else if ( [urlString rangeOfString:@"getDeviceInfo"].location != NSNotFound ) {
        NSString* calljs = nil;
        NSString *caid  = [arrFucnameAndParameter objectAtIndex:2];
        
        NSString*str = [NSString stringWithFormat:@"%@,%@,%@,%@",[BFDeviceTool deviceName],[BFDeviceTool deviceModel],[BFDeviceTool uuid],[BFDeviceTool deviceType]];
        NSDictionary*devDict = @{@"devid":str,@"ver":[BFDeviceTool appVersion],@"ts":([NSString stringWithFormat:@"%.f",[[NSDate date] timeIntervalSince1970]*1000]),@"terminal":@"ios",@"term":[BFDeviceTool deviceModel],@"osver":@"",@"uuid":[BFDeviceTool uuid],@"model":[BFDeviceTool deviceModel]};
        
        NSData *data = [NSJSONSerialization dataWithJSONObject:devDict options:NSJSONWritingPrettyPrinted error:nil];
        NSString*devices = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        //去换行
        devices = [devices stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        calljs = [NSString stringWithFormat:@"__iOSNativeBridge.resultForCallback('%@','%@')",caid,devices];
        [webView stringByEvaluatingJavaScriptFromString:calljs];
    }
    else if ([urlString rangeOfString:@"saveCache"].location != NSNotFound)
    {
        NSString *lastString = [arrFucnameAndParameter lastObject];
        NSArray *moneyArr =  [lastString componentsSeparatedByString:@"%3D"];
        if ([moneyArr[0] isEqualToString: @"balanceMoney"]) {
            model.balanceMoney = [moneyArr lastObject];
        }
    }else if ([urlString rangeOfString:@"jump2Home"].location != NSNotFound)
    {
        [self.navigationController popViewControllerAnimated:YES];
    }else if ([urlString rangeOfString:@"jump2Login"].location != NSNotFound)
    {
        if (self.isForgetPassword == YES) {
            [self.navigationController popToRootViewControllerAnimated:YES];
        }else
        {
            model.isLoginSuccess = [NSNumber numberWithBool:NO];
            model.access_token = @"";
            [BFLoginTool toLoginWithAccountName:nil];
        }
    }else if ([urlString rangeOfString:@"saveAuthInfo"].location != NSNotFound) {
        NSString *caid  = [arrFucnameAndParameter objectAtIndex:3];
        
        NSString *callId = [caid stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        NSArray *statusArr =  [callId componentsSeparatedByString:@","];
        NSString *flag = statusArr[0];
        NSString *name = statusArr[1];
        NSString *sfzNum = statusArr[2];
        model.authFlag = flag;
        model.memberName = name;
        model.idCard = sfzNum;
    }else if ([urlString rangeOfString:@"closeWebView"].location != NSNotFound) {
        
        [self closeWeb];
    }else if ([urlString rangeOfString:@"openNewWebView"].location != NSNotFound) {
        
        NSString *webString = [[arrFucnameAndParameter lastObject] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSArray * webURLArr = [webString componentsSeparatedByString:@"|"];
        if (!__webViewDataDict) {
            __webViewDataDict = [[NSMutableDictionary alloc] initWithCapacity:0];
        }
        if (webURLArr.count>1) {
            [__webViewDataDict setObject:webURLArr[1] forKey:webURLArr[0]];
        }
        [self openNewWebView:webURLArr[0]];
        
    }else if ([urlString rangeOfString:@"getWebViewData"].location != NSNotFound)
    {
        NSString *caid  = [arrFucnameAndParameter objectAtIndex:2];
        NSString *objString = __webViewDataDict[self.urlStr];
        objString = objString == nil||[objString isKindOfClass:[NSNull class]]||[objString isEqualToString:@""]?@"":objString;
        NSString *calljs = [NSString stringWithFormat:@"__iOSNativeBridge.resultForCallback('%@','%@')",caid,objString];
        [webView stringByEvaluatingJavaScriptFromString:calljs];
    }
    
    else if ([urlString rangeOfString:@"balanceMoney"].location != NSNotFound) {
        
        NSString *caid  = [arrFucnameAndParameter objectAtIndex:2];
        NSString *balanceMoney = model.balanceMoney;
        NSString* calljs = [NSString stringWithFormat:@"__iOSNativeBridge.resultForCallback('%@','%@')",caid,[self moneyNumAndChangeformat:balanceMoney isDisplayPoint:YES]];
        NSLog(@"调用js：%@", calljs);
        [webView stringByEvaluatingJavaScriptFromString:calljs];
    }else if ([urlString rangeOfString:@"resetPayPassword"].location != NSNotFound) {
        NSLog(@"忘记支付密码");
        __count =  __count+1;
        NSLog(@"调用的次数%ld",__count);
        [self getPayPwd];
    }else if ([urlString rangeOfString:@"makeCall"].location != NSNotFound) {
        
        NSString *number  = [arrFucnameAndParameter objectAtIndex:3];
        UIWebView*callWebview =[[UIWebView alloc] init];
        NSURL *telURL =[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",number]];//
        [callWebview loadRequest:[NSURLRequest requestWithURL:telURL]];
        //记得添加到view上
        [self.view addSubview:callWebview];
    }else if ([urlString rangeOfString:@"setTitle"].location != NSNotFound) {
        
        [self setCenterTitle:[[arrFucnameAndParameter lastObject] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    }else if ([urlString rangeOfString:@"setButtonLabel"].location != NSNotFound) {
        //隐藏按钮页面
        
//        [self.inviteBtn setTitle:[[arrFucnameAndParameter lastObject] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding] forState:UIControlStateNormal];
    }
    else if ([urlString rangeOfString:@"closeInviteButton"].location != NSNotFound) {
        //隐藏按钮页面
        
//        [self updateFrame:YES];
    }else if ([urlString rangeOfString:@"jump2Alert"].location != NSNotFound)
    {
        NSLog(@"重新登录");
        NSString *message = [[arrFucnameAndParameter lastObject] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        [[[UIAlertView alloc] initWithTitle:nil message:message delegate:self cancelButtonTitle:@"重新登录" otherButtonTitles:nil, nil] show];
    }
    
    return YES;

}
#pragma mark--设置webView的navgation
- (void)setWebView:(NSString *)infoString
{
    
    if (infoString.length>0) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:[infoString dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:nil];
        NSString *buttomTab = dict[@"buttomTab"];
        if ([buttomTab isEqualToString:@"show"]) {
            //显示tabbar
            self.mainWeb.frame = CGRectMake(0.0f, 64.0f, ScreenWidth, ScreenHeight-64.0f-49.0f);
            [self.tabBarController.tabBar setHidden:NO];
        }else if ([buttomTab isEqualToString:@"hide"])
        {
            //隐藏tabbar
            self.mainWeb.frame = CGRectMake(0.0f, 64.0f, ScreenWidth, ScreenHeight-64.0f);
            [self.tabBarController.tabBar setHidden:YES];
        }
        
        NSDictionary *titleDict = dict[@"title"];
        NSArray *leftArr = titleDict[@"left"];
        NSArray *centerArr = titleDict[@"center"];
//        NSArray *rightArr = titleDict[@"right"];
        
        [self initNavgationBarView];
        
        [self setLeft:leftArr];
        [self setCenter:centerArr];
//        [self setRight:rightArr];
    }
}
- (void)initNavgationBarView
{
    //清除中间视图
    for (__weak UIView *view in self.centerView.subviews) {
        [view removeFromSuperview];
        view = nil;
    }
}
#pragma makr--左边视图
static CGFloat __btnOraginX = 0.0f;
- (void)setLeft:(NSArray *)array
{
    __btnOraginX = 10.0f;
    TTJXButton *button = [TTJXButton buttonWithType:UIButtonTypeCustom];
    UIImage *nImage = [UIImage imageNamed:@"btn_back_gray"];
    UIImage *hImage = [UIImage imageNamed:@"btn_back_gray"];
    
    [button setFrame:CGRectMake(0, 0, nImage.size.width, nImage.size.height)];
    [button setBackgroundColor:[UIColor clearColor]];
    [button setBackgroundImage:nImage forState:UIControlStateNormal];
    [button setBackgroundImage:hImage forState:UIControlStateHighlighted];
    
    for (int i=0; i<array.count; i++) {
        NSDictionary *dict = array[i];
        NSString *type = dict[@"type"];
        NSString *onclick = dict[@"onclick"];
        NSString *onclickType = dict[@"onclickType"];
        if ([type isEqualToString:@"back"]||[type isEqualToString:@"close"]||[type isEqualToString:@"textButton"]) {
            [button addTarget:self action:@selector(leftBtnMethod:) forControlEvents:UIControlEventTouchUpInside];
            button.onclick = onclick;
            button.onclickType = onclickType;
        }
    }
    [self.navigationItem setLeftBarButtonItem:[self barBtnItemWithCustomView:button]];
}
#pragma makr--中间视图
static CGFloat __centerWidth = 0.0f;
- (void)setCenter:(NSArray *)array
{
    __centerWidth = 0.0f;
    for (int i = 0; i<array.count; i++) {
        NSDictionary *dict = array[i];
        NSString *type = dict[@"type"];
        NSString *text = dict[@"text"];
        NSString *onclick = dict[@"onclick"];
        NSString *onclickType = dict[@"onclickType"];
        if ([type isEqualToString:@"title"]) {
            CGFloat buttonLabelWidth = [UILabel width:text heightOfFatherView:44.0f textFont:FONT(17.0f)];
            buttonLabelWidth = buttonLabelWidth >AUTO_LENGTH(160.0f)?buttonLabelWidth:AUTO_LENGTH(160.0f);
            TTJXLabel *titleLabel = [[TTJXLabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, buttonLabelWidth, 44.0f)];
            titleLabel.userInteractionEnabled = YES;
            titleLabel.textColor = [UIColor blackColor];
            titleLabel.font = FONT(20.0f);
            titleLabel.text = text;
            titleLabel.textAlignment = NSTextAlignmentCenter;
            titleLabel.numberOfLines = 0;
            titleLabel.adjustsFontSizeToFitWidth = YES;
            titleLabel.onclick = onclick;
            titleLabel.onclickType = onclickType;
            _product_title = text;
            [self.centerView addSubview:titleLabel];
            
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(labelClick:)];
            tap.numberOfTapsRequired = 1;
            [titleLabel addGestureRecognizer:tap];
            __centerWidth = buttonLabelWidth;
        }else if ([type isEqualToString:@"subTitle"])
        {
            NSArray *titleArr = [text componentsSeparatedByString:@"|"];
            CGFloat buttonLabelWidth1 = [UILabel width:titleArr[0] heightOfFatherView:22.0f textFont:FONT(17.0f)];
            buttonLabelWidth1 = buttonLabelWidth1 >AUTO_LENGTH(160.0f)?AUTO_LENGTH(160.0f):buttonLabelWidth1;
            CGFloat buttonLabelWidth2 = [UILabel width:titleArr[1] heightOfFatherView:22.0f textFont:FONT(12.0f)];
            TTJXLabel *titleLabel1 = [[TTJXLabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, buttonLabelWidth1, 22.0f)];
            titleLabel1.userInteractionEnabled = YES;
            titleLabel1.textColor = [UIColor blackColor];
            titleLabel1.font = FONT(17.0f);
            titleLabel1.text = titleArr[0];
            titleLabel1.textAlignment = NSTextAlignmentCenter;
            titleLabel1.adjustsFontSizeToFitWidth = YES;
            titleLabel1.numberOfLines = 0;
            titleLabel1.onclick = onclick;
            titleLabel1.onclickType = onclickType;
            [self.centerView addSubview:titleLabel1];
            
            TTJXLabel *titleLabel2 = [[TTJXLabel alloc] initWithFrame:CGRectMake(0, 0.0f, buttonLabelWidth2, 22.0f)];
            titleLabel2.center = CGPointMake(buttonLabelWidth1*0.5, 33.0f);
            titleLabel2.userInteractionEnabled = YES;
            titleLabel2.textColor = [UIColor lightGrayColor];
            titleLabel2.font = FONT(12.0f);
            titleLabel2.text = titleArr[1];
            titleLabel2.textAlignment = NSTextAlignmentCenter;
            titleLabel2.onclick = onclick;
            titleLabel2.onclickType = onclickType;
            [self.centerView addSubview:titleLabel2];
            
            __centerWidth = buttonLabelWidth1;
            
            UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(labelClick:)];
            tap1.numberOfTapsRequired = 1;
            [titleLabel1 addGestureRecognizer:tap1];
            
            UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(labelClick:)];
            tap2.numberOfTapsRequired = 1;
            [titleLabel2 addGestureRecognizer:tap2];
            
        }else if ([type isEqualToString:@"buttonGroup"])
        {
            NSArray *buttonGroupArr = [text componentsSeparatedByString:@"|"];
            self.segementTypeArr = [[NSMutableArray alloc] initWithArray:[onclickType componentsSeparatedByString:@"|"]];
            self.segementClickArr = [[NSMutableArray alloc] initWithArray:[onclick componentsSeparatedByString:@"|"]];
            UISegmentedControl * mySegementView = [[UISegmentedControl alloc] initWithItems:buttonGroupArr];
            mySegementView.frame = CGRectMake(0.0f, (44-25.0f)/2, NAV_CENTER_WIDTH, 25.0f);
            [mySegementView addTarget:self action:@selector(segmentAction:)forControlEvents:UIControlEventValueChanged];
            mySegementView.selectedSegmentIndex = [dict[@"selected"] intValue];
            mySegementView.tintColor = COLOR_HEXSTRING(ORANGE_COLOR);
            [self.centerView addSubview:mySegementView];
            __centerWidth = mySegementView.frame.size.width;
        }
        
    }
    self.centerView.frame = CGRectMake(0, 0, __centerWidth, 44.0f);
    self.centerView.center = CGPointMake(ScreenWidth*0.5, 22);
    self.navigationItem.titleView = _centerView;
}


- (void)loginSucessful {
    [self refreshWebView];
}
- (void)loginFailure {
    [self.navigationController popToRootViewControllerAnimated:YES];
}


#pragma mark--label手势点击
- (void)labelClick:(UITapGestureRecognizer *)tap
{
    TTJXLabel *label = (TTJXLabel *)tap.view;
    [self jumpMethodForType:label.onclickType click:label.onclick];
}
#pragma makr--segementMethod
- (void)segmentAction:(UISegmentedControl *)segement
{
    NSInteger index = segement.selectedSegmentIndex;
    NSString *type = self.segementTypeArr[index];
    NSString *click = self.segementClickArr[index];
    NSLog(@"%@  %@",type,click);
    [self jumpMethodForType:type click:click];
}
- (void)openNewWebView:(NSString *)url
{
    BFWebViewController *webVC = [[BFWebViewController alloc] init];
    webVC.urlStr = url;
//    [webVC setLeftNavgationBtn];
    [self presentViewController:[[UINavigationController alloc] initWithRootViewController:webVC] animated:YES completion:nil];
}


-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self.mainWeb.scrollView.header endRefreshing];
    NSLog(@"%ld",error.code);
    if (error.code == NSURLErrorCancelled) {
        return;
    }else
    {
        [self.view addSubview:self.reloadView];
    }
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    _pageCount++;
    [self.mainWeb.scrollView.header endRefreshing];
    [self.mainWeb stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"init('%@')",self.auFlag]];
}
-(void)webViewDidStartLoad:(UIWebView *)webView{
    [self.reloadView removeFromSuperview];
}

-(NSString *)moneyNumAndChangeformat:(NSString *)string isDisplayPoint:(BOOL)display
{
    
    //    NSString *myString = [NSString stringWithFormat:@"%.2f",[string floatValue]];
    
    //    NSLog(@"   %@",myString);
    
    NSNumber *moneyNumber = [NSNumber numberWithDouble:[string doubleValue]];
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc]init];
    
    formatter.numberStyle =NSNumberFormatterDecimalStyle;
    
    NSString *newAmount = [formatter stringFromNumber:moneyNumber];
    
    if (display == YES) {
        if ([self isPureInt:newAmount]==YES) {
            newAmount = [newAmount stringByAppendingString:@".00"];
        }
    }
    
    return newAmount;
}
-(BOOL)isPureInt:(NSString*)string{
    NSScanner* scan = [NSScanner scannerWithString:string];
    int val;
    return[scan scanInt:&val] && [scan isAtEnd];
}

#pragma mark--设置产品详情页面的购买按钮是否隐藏
- (void)updateProductDetailFrame:(BOOL)hidden
{
    self.buyView.hidden = hidden;
    if (hidden == YES) {
        self.mainWeb.frame = CGRectMake(0, 0, ScreenWidth, ScreenHeight-64);
    }else
    {
        self.mainWeb.frame = CGRectMake(0, 0, ScreenWidth, ScreenHeight-64-47);
    }
    
}

- (UIWebView *)mainWeb
{
    if (!_mainWeb) {
        _mainWeb = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight - 64)];
//         设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadNewData方法）
        WBRefreshGifHeader *header = [WBRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(refreshWebView)];
        
        // 隐藏时间
        header.lastUpdatedTimeLabel.hidden = YES;
        
        // 隐藏状态
        header.stateLabel.hidden = YES;
        
        
//         设置header
        _mainWeb.scrollView.header = header;
        _mainWeb.scalesPageToFit = YES;
        _mainWeb.delegate = self;
        _mainWeb.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
        [self refreshWebView];
    }
    return _mainWeb;
}


#pragma mark--购买
- (UIView *)buyView
{
    if (!_buyView) {
        _buyView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, ScreenHeight-47-64, ScreenWidth, 47)];
        _buyView.hidden = YES;
        _buyView.backgroundColor = [UIColor whiteColor];
        [_buyView addSubview:self.buyBtn];
        [_buyView addSubview:self.beginLabel];
        UILabel *linelabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 0.5f)];
        linelabel.backgroundColor = [UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:0.1f];
        [_buyView addSubview:linelabel];
        
    }
    return _buyView;
}
- (UIButton *)buyBtn
{
    if (!_buyBtn) {
        
        _buyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _buyBtn.frame = CGRectMake([UIScreen mainScreen].bounds.size.width-100.0f, 0.0f, 100.0f, 47);
        [_buyBtn setImage:[UIImage imageNamed:@"hsq_now_buy"] forState:UIControlStateNormal];
        
        [_buyBtn addTarget:self action:@selector(buyGoods) forControlEvents:UIControlEventTouchUpInside];
    }
    return _buyBtn;
}
- (UILabel *)beginLabel
{
    
    if (!_beginLabel) {
        _beginLabel = [[UILabel alloc] init];
        _beginLabel.textColor = COLOR_HEXSTRING(ORANGE_COLOR);
        _beginLabel.font = FONT_LIGHT(25.0f);
        _beginLabel.text = @"";
        UILabel * miaoshuLabel = [[UILabel alloc] init];
        miaoshuLabel.tag = 100;
        miaoshuLabel.textColor = COLOR_HEXSTRING(ORANGE_COLOR);
        miaoshuLabel.font = FONT_LIGHT(12.0f);
        [_buyView addSubview:miaoshuLabel];
    }
    CGFloat beginLabelWidth = [UILabel width:[NSString stringWithFormat:@"%@",_beginLabel.text] heightOfFatherView:self.buyView.frame.size.height textFont:FONT_LIGHT(25.0f)];
    _beginLabel.frame = CGRectMake(15.0f, 16.0f, beginLabelWidth, 19.0f);
    
    UILabel *miaoshuLabel = (UILabel *)[_buyView viewWithTag:100];
    miaoshuLabel.frame = CGRectMake(CGRectGetMaxX(_beginLabel.frame)+8.0f, 23.0f, 100.0f, 12.0f);
    
    _beginLabel.text = [NSString stringWithFormat:@"%@",_beginLabel.text];
    miaoshuLabel.text = @"元起购";
    return _beginLabel;
}
- (void)buyGoods
{
    BFBuyCommodityViewController *buyVC = [[BFBuyCommodityViewController alloc] init];
    buyVC.product_Id = self.product_id;
    buyVC.title = _product_title;
    buyVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:buyVC animated:YES];
}

#pragma mark--刷新网页
- (void)refreshWebView
{
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:self.urlStr]];
    [_mainWeb loadRequest:request];
}

#pragma mark--清楚缓存
- (void)cleanWebCache
{
    NSURLCache * cache = [NSURLCache sharedURLCache];
    [cache removeAllCachedResponses];
    [cache setDiskCapacity:0];
    [cache setMemoryCapacity:0];
}
#pragma mark--配置网页显示
- (void)settingShowWeb
{
    [self updateProductDetailFrame:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark--返回方法
- (void)leftBtnMethod:(TTJXButton *)button
{

    [self.mainWeb goBack];
    if (self.mainWeb.canGoBack == NO) {
        
        
        [self.navigationController popViewControllerAnimated:YES];
        
    }

    [self jumpMethodForType:button.onclickType click:button.onclick];

}
- (void)closeWeb
{
    if (self.navigationController.viewControllers.count>1) {
        [self.navigationController popViewControllerAnimated:YES];
    }else
    {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}
#pragma mark--跳转方法
- (void)jumpMethodForType:(NSString *)type click:(NSString *)click
{
    
    if ([type isEqualToString:@"js"]) {
        [self.mainWeb stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"%@()",click]];
    }else if ([type isEqualToString:@"openNewWebView"])
    {
        
        [self openNewWebView:click];
    }else if ([type isEqualToString:@"closeWebView"])
    {
        if (self.navigationController.viewControllers.count>1) {
            [self.navigationController popViewControllerAnimated:YES];
        }else
        {
            [self dismissViewControllerAnimated:YES completion:nil];
        }
    }
}

- (void)getPayPwd {
    [self showProgress];
    __weakself__
    [BFReqAPI reqInitFindPayPwdBlock:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        if (responseObj) {
            if (ERROR_CODE == 1) {
                NSDictionary *dict = [NSDictionary dictionaryWithDictionary:responseObj[@"obj"]];
                
                //保存初始化前面
                [USER_D setObject:dict[@"sign"] forKey:@"initSign"];
                [USER_D synchronize];
                
                [BFSecurityCenterViewModel handleSecurityCenterJumpLogicWithType:[BFSecurityCenterViewModel payPwdValiTypeFromStr:dict[@"next"]] andParams:dict fromViewController:weakself];
            }
            else {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
            }
        }
        else {
            [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
        }
    }];
}

- (void)dealloc {
}

@end

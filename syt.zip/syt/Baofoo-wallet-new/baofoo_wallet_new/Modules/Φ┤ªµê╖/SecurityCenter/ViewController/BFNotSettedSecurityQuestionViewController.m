//
//  BFNotSettedSecurityQuestionViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFNotSettedSecurityQuestionViewController.h"
#import "BFCustomActionSheetView.h"
#import "BFHaveSettedSecurityQuestionViewController.h"
#import "BFReqAPI+Security.h"
#import "BFReqAPI+Login.h"
#import "BFGesturePwdViewController.h"
#import "BFLoginViewController.h"

@interface BFNotSettedSecurityQuestionViewController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,CustomActionSheetDelegate,UIAlertViewDelegate>
@property(nonatomic,strong)UITableView *noQuestionTable;
@property(nonatomic,strong)NSMutableArray *tableArray;
@property(nonatomic,strong)NSMutableArray *questionArray;//安全问题数组

@property(nonatomic,strong)UITextField *questionField;
@property(nonatomic,strong)UITextField *answerField;//输入答案
@property(nonatomic,strong)UIButton *certainButton;//下一步按钮

@property(nonatomic,strong)BFCustomActionSheetView *questActionSheet;

@end

@implementation BFNotSettedSecurityQuestionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self getSecQuestions];
    [self.view addSubview:self.noQuestionTable];
    
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardHide)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    //将触摸事件添加到当前view
//    [self.view addGestureRecognizer:tapGestureRecognizer];
    
    UITapGestureRecognizer *showActionGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showAction)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    showActionGestureRecognizer.cancelsTouchesInView = NO;
//    将触摸事件添加到当前view
    [self.questionField addGestureRecognizer:showActionGestureRecognizer];
}
#pragma mark --CreatUI
- (NSMutableArray *)tableArray
{
    if (!_tableArray) {
        _tableArray = [[NSMutableArray alloc] initWithArray:@[self.questionField,self.answerField]];
    }
    return _tableArray;
}
- (UITableView *)noQuestionTable
{
    if (!_noQuestionTable) {
        _noQuestionTable = [[UITableView alloc] initWithFrame:CGRectMake(0, 0,ScreenWidth,ScreenHeight-64.0f) style:UITableViewStyleGrouped];
        _noQuestionTable.delegate = self;
        _noQuestionTable.dataSource = self;
        _noQuestionTable.showsVerticalScrollIndicator = NO;
        _noQuestionTable.rowHeight = 50.0f;
        _noQuestionTable.scrollEnabled = NO;
    }
    return _noQuestionTable;
}
- (UITextField *)questionField
{
    if (!_questionField) {
        _questionField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _questionField.backgroundColor = [UIColor whiteColor];
        _questionField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 95.0f, 50.0f) text:@"安全问题"];
        _questionField.leftViewMode = UITextFieldViewModeAlways;
        _questionField.placeholder = @"选择安全问题";
        _questionField.font = BF_Font_16;
        _questionField.delegate = self;
        UIImage *arrowImage = [UIImage imageNamed:@"arrow_bottom.png"];
        
        UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 36.0f+arrowImage.size.width, 50.0f)];
        UIImageView *arrowImageView = [[UIImageView alloc] initWithFrame:CGRectMake(18.0f, (rightView.frame.size.height-arrowImage.size.height)*0.5, arrowImage.size.width, arrowImage.size.height)];
        arrowImageView.image = arrowImage;
        [rightView addSubview:arrowImageView];
        
        _questionField.rightView = rightView;
        _questionField.rightViewMode = UITextFieldViewModeAlways;
        
        [_questionField addTarget:self action:@selector(textFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
    }
    return _questionField;
}

- (UITextField *)answerField
{
    if (!_answerField) {
        _answerField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _answerField.backgroundColor = [UIColor whiteColor];
        _answerField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 95.0f, 50.0f) text:@"问题答案"];
        _answerField.leftViewMode = UITextFieldViewModeAlways;
        _answerField.placeholder = @"设置安全问题答案";
        _answerField.font = BF_Font_16;
        [_answerField addTarget:self action:@selector(textFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
    }
    return _answerField;
}
- (UIView *)leftViewLabelWithFrame:(CGRect)rect text:(NSString *)text
{
    UIView *leftView = [[UIView alloc] initWithFrame:rect];
    UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, rect.size.width, rect.size.height)];
    leftLabel.font = BF_Font_16;
    leftLabel.textColor = COLOR_HEXSTRING(BLACK_COLOR);
    leftLabel.text = text;
    leftLabel.textAlignment = NSTextAlignmentCenter;
    [leftView addSubview:leftLabel];
    return leftView;
}
- (UIButton *)certainButton
{
    if (!_certainButton) {
        _certainButton = [UIButton buttonWithType:UIButtonTypeSystem];
        _certainButton.frame = CGRectMake(15.0f, 60.0f, ScreenWidth-30.0f, 40);
        _certainButton.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _certainButton.enabled = NO;
        _certainButton.layer.cornerRadius = 20.0f;
        [_certainButton setTitle:@"确定" forState:UIControlStateNormal];
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [_certainButton addTarget:self action:@selector(certainButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _certainButton;
}
- (BFCustomActionSheetView *)questActionSheet
{
    if (!_questActionSheet) {
        _questActionSheet = [[BFCustomActionSheetView alloc] initWithArray:(NSArray *)self.questionArray];
        _questActionSheet.delegate = self;
    }
    return _questActionSheet;
}

#pragma mark -- UITextFieldDelegate
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if (textField == self.questionField)
    {
        [self showAction];
        return NO;
    }
    return YES;
}
#pragma mark -- 方法
- (void)backMethod
{
    if (self.securityQuestionStyle == 0) {
        for (UIViewController *ViewControlView in self.navigationController.viewControllers ) {
            if ([ViewControlView isKindOfClass:[BFHaveSettedSecurityQuestionViewController class]]) {
                [self.navigationController popToViewController:ViewControlView animated:YES];
                return;
            }
        }
    }else
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (void)certainButton:(UIButton *)sender
{
    if (self.securityQuestionStyle == 1) {
        __weakself__
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.detailsLabelText = @"加载中...";
        NSDictionary *userIndo = [[NSDictionary alloc] initWithObjectsAndKeys:self.telCode,@"telCode",self.regMobile,@"regMobile",self.payPass,@"payPass",self.regPass,@"regPass",self.questionField.text,@"safeQuestion",self.answerField.text ,@"safeAnswer",nil];
        [BFReqAPI reqSettingSecurityQuestionForRegisterWithParams:userIndo block:^(id responseObj, NSError *error) {
            if (responseObj != nil) {
                if (ERROR_CODE == 1) {
                    hud.detailsLabelText = @"注册成功";
                    [BFReqAPI reqLoginAccountWithUserName:weakself.regMobile andPassword:weakself.regPass block:^(id responseObj, NSError *error) {
                        if (responseObj){
                            if (!weakself) return ;
                            [BFLoginTool loginSuccessActionWith:responseObj andViewController:weakself isForExchangeAccount:NO isForRegister:YES];
                            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                                
                                [hud hide:YES];
                                [BFLoginTool pushGesturePwdView:weakself.navigationController];
                            });
                        }
                        else {
                            [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
                            [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:LoginNotificationFailure object:nil userInfo:nil]];
                        }
                    }];
                }
                else
                {
                    [MBProgressHUD hideHUDForView:weakself.view animated:YES];
                    [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
                }
            }
        }];
    }
    else {
        NSDictionary *userIndo = [[NSDictionary alloc] initWithObjectsAndKeys:self.questionField.text,@"safeQuestion",self.answerField.text,@"safeAnswer",nil];
        [self showProgress];
        __weakself__
        [BFReqAPI reqModifySecurityQuestionWithParams:userIndo andModifyReqAPI:self.tagStyle==0?security_changeSafeQuestion:security_resetSafeQuestion block:^(id responseObj, NSError *error) {
            [weakself hideProgress];
            if (responseObj != nil) {
                if (ERROR_CODE == 1) {
                    [UIAlertView showWithTitle:@"安全问题设置成功！" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
                    NSString*safeQuesion = weakself.questionField.text;
                    BFCoreDataModelop *op = [[BFCoreDataModelop alloc] init];
                    BFCoreUserModel *model = [op getCurrentBFuserModel];
                    model.safeQuestion = safeQuesion;
//                    [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].safeQuestion = safeQuesion;
                }
                else
                {
                    [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
                }
            }
        }];
    }
}
- (void)getSecQuestions
{
    __weakself__
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [weakself showProgress];
        [BFReqAPI reqGetSecurityQuestionBlock:^(id responseObj, NSError *error) {
            [weakself hideProgress];
            if (responseObj != nil) {
                if (ERROR_CODE == 1) {
                    NSDictionary *obj = responseObj[@"obj"];
                    weakself.questionArray = (NSMutableArray *)obj[@"questions"];
                }
                else {
                    self.questionArray = [NSMutableArray arrayWithArray:@[@"我最爱的运动?",
                                                                          @"我母亲的名字?",
                                                                          @"我父亲的名字?",
                                                                          @"我最大的爱好?",
                                                                          @"我的小学校名?",
                                                                          @"我的中学校名?",
                                                                          @"我最喜欢吃的水果?",
                                                                          @"我最喜欢的一本书名?",
                                                                          @"我最好的朋友的名字?",
                                                                          @"我最喜欢的老师的名字?"]];
                }
            }
            else {
                self.questionArray = [NSMutableArray arrayWithArray:@[@"我最爱的运动?",
                                                                      @"我母亲的名字?",
                                                                      @"我父亲的名字?",
                                                                      @"我最大的爱好?",
                                                                      @"我的小学校名?",
                                                                      @"我的中学校名?",
                                                                      @"我最喜欢吃的水果?",
                                                                      @"我最喜欢的一本书名?",
                                                                      @"我最好的朋友的名字?",
                                                                      @"我最喜欢的老师的名字?"]];
            }
        }];
    });
}
- (void)textFieldValueChange:(UITextField *)myTextField
{
    if (self.questionField.text.length > 0 && self.answerField.text.length > 0) {
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f] forState:UIControlStateNormal];
        _certainButton.enabled = YES;
        
    }
    else
    {
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.enabled = NO;
    }
}
- (void)keyboardHide
{
    [self.view endEditing:YES];
}
- (void)showAction
{
    AppDelegate *delegate = [[UIApplication sharedApplication] delegate];
    [self.questActionSheet showInView:delegate.window];
}
#pragma mark--CustonActionSheetDelegate
- (void)clickedSheetButtonAtIndex:(NSUInteger)btnIndex
{
    if (btnIndex!=self.questionArray.count) {
        self.questionField.text = self.questionArray[btnIndex];
    }
}

#pragma mark--UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 0) {
        [self performSelector:@selector(backMethod) withObject:nil afterDelay:0.25];
        
    }
}

#pragma mark -- UITextFieldDelegate
//- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
//{
//    if (textField == self.questionField)
//    {
//        [self showAction];
//        return NO;
//    }
//    return YES;
//}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (textField == self.questionField)
    {
        [self showAction];
    }
}

#pragma mark -- UITableViewDataSourceDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return self.tableArray.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:@"QuestionCell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"QuestionCell"];
        cell.textLabel.font = BF_Font_16;
    }
    
    [cell.contentView addSubview:self.tableArray[indexPath.row]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (self.securityQuestionStyle == 1) return 25.0f;
    return 0.01f;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (self.securityQuestionStyle == 1) {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 25.0f)];
        UILabel *promotLabel = [[UILabel alloc] initWithFrame:CGRectMake(18.0f, 0.0f, ScreenWidth-18.0f, 25.0f)];
        promotLabel.font = BF_Font_12;
        promotLabel.textColor = COLOR_HEXSTRING(@"#c9c9c9");
        promotLabel.text  = @"请设置安全问题，以保障账户安全";
        [headerView addSubview:promotLabel];
        
        return headerView;
    }else
    {
        return nil;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 100.0f;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 100.0f)];
    [footerView addSubview:self.certainButton];
    return footerView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

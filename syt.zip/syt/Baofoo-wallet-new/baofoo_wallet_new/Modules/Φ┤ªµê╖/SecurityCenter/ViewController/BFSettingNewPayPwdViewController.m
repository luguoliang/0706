//
//  BFSettingNewPayPwdViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/26.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFSettingNewPayPwdViewController.h"
#import "BFKeyBoardView.h"
#import "WBTradeInputView.h"
#import "BFSecurityCenterController.h"
#import "BFBuyCommodityViewController.h"
#import "BFWebViewController.h"
#import "BFValiPayPwdViewController.h"
#import "BFAgainSettingPayPwdViewController.h"

@interface BFSettingNewPayPwdViewController ()<BFKeyBoardViewDelegate,UITextFieldDelegate>
@property(nonatomic,strong)UILabel *topLabel;
@property(nonatomic,strong)WBTradeInputView *payInputView;
@property(nonatomic,strong)UITextField *payInputField;
@property(nonatomic,strong)BFKeyBoardView *keyBoard;

@end

@implementation BFSettingNewPayPwdViewController

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self.payInputField becomeFirstResponder];
    self.payInputField.text = @"";
    [self.payInputView deleteAllNumber];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.view endEditing:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"找回支付密码";
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.topLabel];
    [self.view addSubview:self.payInputView];
    [self.view addSubview:self.payInputField];
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardShow)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    //将触摸事件添加到当前view
    [self.view addGestureRecognizer:tapGestureRecognizer];
}
#pragma mark--CreatUI
- (BFKeyBoardView *)keyBoard
{
    if (!_keyBoard) {
        _keyBoard = [[[NSBundle mainBundle] loadNibNamed:@"BFKeyBoardView" owner:nil options:nil] lastObject];
        _keyBoard.delegate = self;
    }
    return _keyBoard;
}
- (UILabel *)topLabel
{
    if (!_topLabel) {
        _topLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 95.0f)];
        _topLabel.textAlignment = NSTextAlignmentCenter;
        _topLabel.font = BF_Font_17;
        _topLabel.text = @"请重新设置支付密码";
    }
    return _topLabel;
}
-(WBTradeInputView *)payInputView
{
    if (!_payInputView) {
        _payInputView = [[WBTradeInputView alloc] initWithFrame:CGRectMake((ScreenWidth-266.0f)*0.5, 95.0f, 266.0f, 40.0f)];
    }
    return _payInputView;
}
- (UITextField *)payInputField
{
    if (!_payInputField) {
        _payInputField = [[UITextField alloc] initWithFrame:CGRectMake(27.0f, 95.0f, ScreenWidth-54.0f, 40.0f)];
        _payInputField.backgroundColor = [UIColor whiteColor];
        _payInputField.leftViewMode = UITextFieldViewModeAlways;
        _payInputField.placeholder = @"当前支付密码";
        _payInputField.secureTextEntry = YES;
        _payInputField.delegate = self;
        _payInputField.font = BF_Font_16;
        _payInputField.alpha = 0.0f;
        _payInputField.inputView = self.keyBoard;
    }
    return _payInputField;
}
#pragma mark--方法
- (void)bacKMethod
{
    for (NSInteger i=0; i<self.navigationController.viewControllers.count; i++) {
        
        NSInteger a = self.navigationController.viewControllers.count -i-1;
        UIViewController *vc = self.navigationController.viewControllers[a];
        if ([vc isKindOfClass:[BFValiPayPwdViewController class]]||[vc isKindOfClass:[BFSecurityCenterController class]]||[vc isKindOfClass:[BFBuyCommodityViewController class]]||[vc isKindOfClass:[BFWebViewController class]]) {
            [self.navigationController popToViewController:vc animated:YES];
            break;
        }
    }
}
- (void)keyboardShow
{
    [self.payInputField becomeFirstResponder];
}
#pragma mark--UITextFieldDelegate
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [_keyBoard setKeyBoardWith:textField];
    [_keyBoard setKeyboardstytle:KeyboardstytlePassword];
    return YES;
}
#pragma mark - keyboardViewDelegate
-(void)keyBoard:(BFKeyBoardView*)keyBoard didClickedButton:(UIButton*)button WithText:(UITextField*)textfield
{
    
    textfield.text  = [NSString stringWithFormat:@"%@%@",textfield.text,button.titleLabel.text];
    if (textfield.text.length>6) {
        textfield.text = [textfield.text substringToIndex:6];
    }
    [self.payInputView number:[NSNumber numberWithInteger:[button.titleLabel.text integerValue]]];
    if (textfield.text.length == 6) {
        BFAgainSettingPayPwdViewController *againVC = [[BFAgainSettingPayPwdViewController alloc] init];
        againVC.freshPayPwd = textfield.text;
        againVC.sign = self.sign;
        againVC.op = self.op;
        [self.navigationController pushViewController:againVC animated:YES];
    }
    NSLog(@"%@",textfield.text);
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateButton:(UIButton*)button WithText:(UITextField*)textfield
{
    NSString*str = textfield.text;
    if ([str length] != 0) {
        str = [str substringToIndex:[str length]- 1];
        textfield.text  = str;
    }
    [self.payInputView deleteNumber];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateFinished:(UIButton*)button WithText:(UITextField*)textfield
{
    [textfield resignFirstResponder];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  BFModifySecurityQuestionViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/16.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFModifySecurityQuestionViewController.h"
#import "BFWebViewController.h"
#import "BFBuyCommodityViewController.h"
#import "BFSecurityCenterController.h"
#import "BFNotSettedSecurityQuestionViewController.h"

#import "BFReqAPI+Security.h"

@interface BFModifySecurityQuestionViewController ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>

@property(nonatomic,strong)UITableView *questionTable;//安全问题回答
@property(nonatomic,strong)UITextField *answerField;//输入答案
@property(nonatomic,strong)UIButton *certainButton;//下一步按钮
@property(nonatomic,strong)UIButton *checkTypeButton;

@end

@implementation BFModifySecurityQuestionViewController

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self.answerField becomeFirstResponder];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.view endEditing:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardHide)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    //将触摸事件添加到当前view
    [self.view addGestureRecognizer:tapGestureRecognizer];
    [self.view addSubview:self.questionTable];
}
#pragma mark --CreatUI
- (UITableView *)questionTable
{
    if (!_questionTable) {
        _questionTable = [[UITableView alloc] initWithFrame:CGRectMake(0, 0,ScreenWidth,ScreenHeight-64.0f) style:UITableViewStyleGrouped];
        _questionTable.delegate = self;
        _questionTable.dataSource = self;
        _questionTable.showsVerticalScrollIndicator = NO;
        _questionTable.rowHeight = 50.0f;
        _questionTable.scrollEnabled = NO;
    }
    return _questionTable;
}
- (UITextField *)answerField
{
    if (!_answerField) {
        _answerField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _answerField.backgroundColor = [UIColor whiteColor];
        _answerField.leftView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 18.0f, 50.0f)];
        _answerField.leftViewMode = UITextFieldViewModeAlways;
        _answerField.placeholder = @"请输入安全问题答案";
        _answerField.delegate = self;
        _answerField.font = BF_Font_16;
        [_answerField addTarget:self action:@selector(textFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
    }
    return _answerField;
}




- (UIView *)leftViewLabelWithFrame:(CGRect)rect text:(NSString *)text
{
    UIView *leftView = [[UIView alloc] initWithFrame:rect];
    UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, rect.size.width, rect.size.height)];
    leftLabel.font = BF_Font_16;
    leftLabel.textColor = COLOR_HEXSTRING(BLACK_COLOR);
    leftLabel.text = text;
    leftLabel.textAlignment = NSTextAlignmentCenter;
    [leftView addSubview:leftLabel];
    return leftView;
}

- (UIButton *)certainButton
{
    if (!_certainButton) {
        _certainButton = [UIButton buttonWithType:UIButtonTypeSystem];
        _certainButton.frame = CGRectMake(15.0f, 60.0f, ScreenWidth-30.0f, 40);
        _certainButton.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _certainButton.enabled = NO;
        _certainButton.layer.cornerRadius = 20.0f;
        [_certainButton setTitle:@"下一步" forState:UIControlStateNormal];
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [_certainButton addTarget:self action:@selector(certainButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _certainButton;
}

#pragma mark --方法
- (void)keyboardHide
{
    [self.view endEditing:YES];
}
-(void)backMethod
{
    for (NSInteger i=0; i<self.navigationController.viewControllers.count; i++) {
        
        NSInteger a = self.navigationController.viewControllers.count -i-1;
        UIViewController *vc = self.navigationController.viewControllers[a];
        if ([vc isKindOfClass:[BFSecurityCenterController class]]||[vc isKindOfClass:[BFBuyCommodityViewController class]]||[vc isKindOfClass:[BFWebViewController class]]) {
            [self.navigationController popToViewController:vc animated:YES];
            break;
        }
    }
}
-(void)textFieldValueChange:(UITextField*)textfield
{
    if (self.answerField.text.length != 0) {
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f] forState:UIControlStateNormal];
        _certainButton.enabled = YES;
    }
    else
    {
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.enabled = NO;
    }
}
-(void)certainButton:(UIButton*)button
{
    [self.view endEditing:YES];
    [self request];
}

-(void)request
{
    [self showProgress];
    __weakself__
    [BFReqAPI reqValiSecurityQuestionForModifyWithParams:@{@"safeAnswer":self.answerField.text} block:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                BFNotSettedSecurityQuestionViewController *noVC = [[BFNotSettedSecurityQuestionViewController alloc] init];
                noVC.title = @"修改安全问题";
                noVC.tagStyle = 0;
                [weakself.navigationController pushViewController:noVC animated:YES];
            }else
            {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
            }
        }
    }];
}
#pragma mark - UITableViewDataSourceDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
        cell.textLabel.font = BF_Font_16;
    }
    {
        if (indexPath.row == 0) {
            BFCoreDataModelop*db = [[BFCoreDataModelop alloc] init];
            BFCoreUserModel *m = [db getCurrentBFuserModel];
            cell.textLabel.text = m.safeQuestion;
        }else
        {
            cell.textLabel.text = @"";
            [cell.contentView addSubview:self.answerField];
        }
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.01f;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 100.0f;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 100.0f)];
    
    [footerView addSubview:self.certainButton];
    return footerView;
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

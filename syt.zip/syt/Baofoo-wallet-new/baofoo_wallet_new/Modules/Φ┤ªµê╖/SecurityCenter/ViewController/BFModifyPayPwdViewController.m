//
//  BFModifyPayPwdViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/16.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFModifyPayPwdViewController.h"
#import "BFKeyBoardView.h"
#import "BFBaseReqManager.h"
#import "BFSecurityCenterController.h"
#import "BFValiPayPwdViewController.h"
#import "BFReqAPI+Security.h"
#import <IQKeyboardManager/IQKeyboardManager.h>

@interface BFModifyPayPwdViewController ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,BFKeyBoardViewDelegate>
@property(nonatomic,copy)   NSString*payPwFormat;
@property(nonatomic,strong) BFKeyBoardView *keyBoard;
@property(nonatomic,strong) UITableView *changePayTable;//修改登录密码Table
@property(nonatomic,strong) UITextField *oldPsdField;//现登录密码
@property(nonatomic,strong) UITextField *freshPsdField;//新登录密码
@property(nonatomic,strong) UITextField *messgeField;//验证码
@property(nonatomic,strong) CustomTimerButtom *messgeButton;//验证码按钮
@property(nonatomic,strong) UIButton *certainButton;//确定按钮
@property(nonatomic,strong) NSMutableArray *tableArray;//数据数组
@end

@implementation BFModifyPayPwdViewController
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [[IQKeyboardManager sharedManager] setEnable:NO];
    [self.oldPsdField becomeFirstResponder];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [self.view endEditing:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    self.navigationItem.title = @"修改支付密码";
    
    [self.view addSubview:self.changePayTable];
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardHide)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    //将触摸事件添加到当前view
    [self.view addGestureRecognizer:tapGestureRecognizer];
}
#pragma mark--CreatUI
- (BFKeyBoardView *)keyBoard
{
    if (!_keyBoard) {
        _keyBoard = [[[NSBundle mainBundle] loadNibNamed:@"BFKeyBoardView" owner:nil options:nil] lastObject];
        _keyBoard.delegate = self;
    }
    return _keyBoard;
}
- (NSMutableArray *)tableArray
{
    if (!_tableArray) {
        _tableArray = [[NSMutableArray alloc] initWithCapacity:0];
        
        NSMutableArray *section1 = [[NSMutableArray alloc] initWithArray:@[self.oldPsdField,self.freshPsdField]];
        NSMutableArray *section2 = [[NSMutableArray alloc] initWithArray:@[self.messgeField]];
        
        [_tableArray addObject:section1];
        [_tableArray addObject:section2];
        
    }
    return _tableArray;
}
- (UITableView *)changePayTable
{
    if (!_changePayTable) {
        _changePayTable = [[UITableView alloc] initWithFrame:CGRectMake(0, 0,ScreenWidth,ScreenHeight-64.0f) style:UITableViewStyleGrouped];
        _changePayTable.delegate = self;
        _changePayTable.dataSource = self;
        _changePayTable.showsVerticalScrollIndicator = NO;
        _changePayTable.rowHeight = 50.0f;
        _changePayTable.scrollEnabled = NO;
        
    }
    return _changePayTable;
}
- (UITextField *)oldPsdField
{
    if (!_oldPsdField) {
        _oldPsdField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _oldPsdField.backgroundColor = [UIColor whiteColor];
        _oldPsdField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 110.0f, 50.0F) text:@"现支付密码"];
        _oldPsdField.leftViewMode = UITextFieldViewModeAlways;
        _oldPsdField.placeholder = @"当前支付密码";
        _oldPsdField.secureTextEntry = YES;
        _oldPsdField.delegate = self;
        _oldPsdField.font = BF_Font_16;
        _payPwFormat = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].payPwFormat;
        if ([_payPwFormat isEqualToString:@"1"]) {
            _oldPsdField.inputView = self.keyBoard;
        }
    }
    return _oldPsdField;
}
- (UITextField *)freshPsdField
{
    if (!_freshPsdField) {
        _freshPsdField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _freshPsdField.backgroundColor = [UIColor whiteColor];
        _freshPsdField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 110.0f, 50.0F) text:@"新支付密码"];
        _freshPsdField.leftViewMode = UITextFieldViewModeAlways;
        _freshPsdField.placeholder = @"支付密码由6位数字组成";
        _freshPsdField.secureTextEntry = YES;
        _freshPsdField.delegate = self;
        _freshPsdField.font = BF_Font_16;
        _freshPsdField.inputView = self.keyBoard;
    }
    return _freshPsdField;
}
- (UITextField *)messgeField
{
    if (!_messgeField) {
        _messgeField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _messgeField.backgroundColor = [UIColor whiteColor];
        _messgeField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 110.0f, 50.0F) text:@"验证码"];
        _messgeField.leftViewMode = UITextFieldViewModeAlways;
        _messgeField.placeholder = @"短信验证码";
        _messgeField.keyboardType = UIKeyboardTypePhonePad;
        _messgeField.delegate = self;
        _messgeField.font = BF_Font_16;
        
        _messgeButton = [CustomTimerButtom buttonWithType:UIButtonTypeCustom];
        _messgeButton.frame = CGRectMake(0.0f, 0.0f, 65.0f, 50.0f);
        [_messgeButton setTitle:@"获取" forState:UIControlStateNormal];
        [_messgeButton setTitleColor:COLOR_HEXSTRING(BLUE_COLOR) forState:UIControlStateNormal];
        _messgeButton.titleLabel.font = BF_Font_14;
        [_messgeButton addTarget:self action:@selector(getCodeMethod) forControlEvents:UIControlEventTouchUpInside];
        _messgeField.rightView = _messgeButton;
        _messgeField.rightViewMode = UITextFieldViewModeAlways;
        _messgeField.font = BF_Font_16;
        
        [_messgeField addTarget:self action:@selector(textFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
    }
    return _messgeField;
}
- (UIView *)leftViewLabelWithFrame:(CGRect)rect text:(NSString *)text
{
    UIView *leftView = [[UIView alloc] initWithFrame:rect];
    UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(18.0f, 0.0f, rect.size.width-18.0f, rect.size.height)];
    leftLabel.font = BF_Font_16;
    leftLabel.textColor = COLOR_HEXSTRING(BLACK_COLOR);
    leftLabel.text = text;
    [leftView addSubview:leftLabel];
    return leftView;
}
- (UIButton *)certainButton
{
    if (!_certainButton) {
        _certainButton = [UIButton buttonWithType:UIButtonTypeSystem];
        _certainButton.frame = CGRectMake(15.0f, 60.0f, ScreenWidth-30.0f, 40);
        _certainButton.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _certainButton.enabled = NO;
        _certainButton.layer.cornerRadius = 20.0f;
        [_certainButton setTitle:@"确定" forState:UIControlStateNormal];
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [_certainButton addTarget:self action:@selector(certainButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _certainButton;
}
#pragma mark--按钮方法
-(void)backMethod
{
    for (UIViewController *ViewControlView in self.navigationController.viewControllers ) {
        if ([ViewControlView isKindOfClass:[BFSecurityCenterController class]]||[ViewControlView isKindOfClass:[BFValiPayPwdViewController class]]) {
            [self.navigationController popToViewController:ViewControlView animated:YES];
            return;
        }
    }
}
- (void)keyboardHide
{
    [self.view endEditing:YES];
}
#pragma mark - UITableViewDataSourceDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSMutableArray *sectionArry = self.tableArray[section];
    return sectionArry.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.tableArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    NSMutableArray *sectionArray = self.tableArray[indexPath.section];
    [cell.contentView addSubview:sectionArray[indexPath.row]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.01f;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section != self.tableArray.count-1) {
        return 7.5f;
    }else{
        return 100.0f;
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if (section != self.tableArray.count-1) {
        return nil;
    }else{
        UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 100.0f)];
        [footerView addSubview:self.certainButton];
        return footerView;
    }
    
    
}


#pragma mark - 方法
-(void)textFieldValueChange:(UITextField*)mytextfield
{
    if (self.messgeField.text.length>6) {
        self.messgeField.text = [self.messgeField.text substringToIndex:6];
    }
    [self judgeMethod];
    
}
- (void)judgeMethod
{
    if (self.oldPsdField.text.length ==6&&self.freshPsdField.text.length ==6&&self.messgeField.text.length==6) {
        NSLog(@"按钮颜色变亮");
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f] forState:UIControlStateNormal];
        _certainButton.enabled = YES;
        
    }
    else
    {
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.enabled = NO;
    }
}
#pragma mark - 获取验证码
-(void)getCodeMethod
{
    [self.view endEditing:YES];
    [self getVerifcationCode];
}

#pragma mark - 确定提交
-(void)certainButton:(UIButton*)button
{
    [self.view endEditing:YES];
    [self showProgress];
    __weakself__
    [BFReqAPI reqModifyPayPwdWithOldPwd:self.oldPsdField.text freshPwd:self.freshPsdField.text andValiCode:self.messgeField.text block:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"修改支付密码成功！" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                alertView.tag = 0;
                [alertView show];
            }else
            {
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:[responseObj objectForKey:@"message"] message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                alertView.tag = 1;
                [alertView show];
            }
        }
    }];
}
#pragma mark 异步请求获取验证码

-(void)getVerifcationCode
{
    __weakself__
    [self showProgress];
    [BFReqAPI reqVerifyCodeSendWithType:@"1" andMsg_type:@"3" block:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                [_messgeButton startTimer];
                [_messgeField becomeFirstResponder];
            }else
            {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
            }
        }
    }];
}

#pragma mark - UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 0) {
        [self performSelector:@selector(backMethod) withObject:nil afterDelay:0.25];
        
    }
}
#pragma mark--UITextFieldDelegate
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [_keyBoard setKeyBoardWith:textField];
    [_keyBoard setKeyboardstytle:KeyboardstytlePassword];
    return YES;
}
#pragma mark - keyboardViewDelegate
-(void)keyBoard:(BFKeyBoardView*)keyBoard didClickedButton:(UIButton*)button WithText:(UITextField*)textfield
{
    
    textfield.text  = [NSString stringWithFormat:@"%@%@",textfield.text,button.titleLabel.text];
    if (textfield.text.length>6) {
        textfield.text = [textfield.text substringToIndex:6];
    }
    [self judgeMethod];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateButton:(UIButton*)button WithText:(UITextField*)textfield
{
    NSString*str = textfield.text;
    if ([str length] != 0) {
        str = [str substringToIndex:[str length]- 1];
        textfield.text  = str;
    }
    [self judgeMethod];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateFinished:(UIButton*)button WithText:(UITextField*)textfield
{
    [textfield resignFirstResponder];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

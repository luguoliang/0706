 //
//  BFFindPwdBySecurityQuestionController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/17.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFFindPwdBySecurityQuestionController.h"
#import "BFSecurityCenterController.h"
#import "BFBuyCommodityViewController.h"
#import "BFWebViewController.h"
#import "BFReqAPI+Security.h"
#import "BFSecurityCenterViewModel.h"

@interface BFFindPwdBySecurityQuestionController ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>

@property(nonatomic,strong)UITableView *questionTable;//安全问题回答
@property(nonatomic,strong)UITextField *answerField;//输入答案
@property(nonatomic,strong)UITextField *cardField;//身份证号
@property(nonatomic,strong)UITextField *bankCardField;//银行卡卡号
@property(nonatomic,strong)UIButton *certainButton;//下一步按钮
@property(nonatomic,strong)UIButton *checkTypeButton;
@end

@implementation BFFindPwdBySecurityQuestionController

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self.answerField becomeFirstResponder];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.view endEditing:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardHide)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    //将触摸事件添加到当前view
    [self.view addGestureRecognizer:tapGestureRecognizer];
    [self.view addSubview:self.questionTable];
}
#pragma mark --CreatUI
- (UITableView *)questionTable
{
    if (!_questionTable) {
        _questionTable = [[UITableView alloc] initWithFrame:CGRectMake(0, 0,ScreenWidth,ScreenHeight-64.0f) style:UITableViewStyleGrouped];
        _questionTable.delegate = self;
        _questionTable.dataSource = self;
        _questionTable.showsVerticalScrollIndicator = NO;
        _questionTable.rowHeight = 50.0f;
        _questionTable.scrollEnabled = NO;
    }
    return _questionTable;
}
- (UITextField *)answerField
{
    if (!_answerField) {
        _answerField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _answerField.backgroundColor = [UIColor whiteColor];
        _answerField.leftView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 18.0f, 50.0f)];
        _answerField.leftViewMode = UITextFieldViewModeAlways;
        _answerField.placeholder = @"请输入安全问题答案";
        _answerField.delegate = self;
        _answerField.font = BF_Font_16;
        [_answerField addTarget:self action:@selector(textFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
    }
    return _answerField;
}
- (UIButton *)certainButton
{
    if (!_certainButton) {
        _certainButton = [UIButton buttonWithType:UIButtonTypeSystem];
        _certainButton.frame = CGRectMake(15.0f, 60.0f, ScreenWidth-30.0f, 40);
        _certainButton.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _certainButton.enabled = NO;
        _certainButton.layer.cornerRadius = 20.0f;
        [_certainButton setTitle:@"下一步" forState:UIControlStateNormal];
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [_certainButton addTarget:self action:@selector(certainButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _certainButton;
}
- (UIButton *)checkTypeButton
{
    if (!_checkTypeButton) {
        _checkTypeButton = [UIButton buttonWithType:UIButtonTypeSystem];
        _checkTypeButton.frame = CGRectMake(ScreenWidth-135.0f, 0.0f, 135.0f, 30.0f);
        [_checkTypeButton setTitle:@"选择其他方式找回" forState:UIControlStateNormal];
        [_checkTypeButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _checkTypeButton.titleLabel.font = [UIFont systemFontOfSize:13.0f];
        [_checkTypeButton addTarget:self action:@selector(certainButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _checkTypeButton;
}
#pragma mark --方法
- (void)keyboardHide
{
    [self.view endEditing:YES];
}
-(void)backMethod
{
    for (NSInteger i=0; i<self.navigationController.viewControllers.count; i++) {
        
        NSInteger a = self.navigationController.viewControllers.count -i-1;
        UIViewController *vc = self.navigationController.viewControllers[a];
        if ([vc isKindOfClass:[BFSecurityCenterController class]]||[vc isKindOfClass:[BFBuyCommodityViewController class]]||[vc isKindOfClass:[BFWebViewController class]]) {
            [self.navigationController popToViewController:vc animated:YES];
            break;
        }
    }
}
-(void)textFieldValueChange:(UITextField*)textfield
{
    if (self.answerField.text.length != 0) {
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f] forState:UIControlStateNormal];
        _certainButton.enabled = YES;
    }
    else
    {
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.enabled = NO;
    }
}
-(void)certainButton:(UIButton*)button
{
    [self.view endEditing:YES];
    if (button == self.certainButton) {
        [self request];
    }else if (button == self.checkTypeButton)
    {
        [self skipVCWithType:_other];
    }
}

-(void)request
{
    if ([self.op isKindOfClass:[NSNull class]]||self.op == nil) {
        self.op = @"";
    }
    NSDictionary *userIndo = nil;
    //验证安全问题
    userIndo = @{@"sign":self.sign,@"op":self.op,@"safeQues":[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].safeQuestion,@"safeAnsw":[BFMD5 md5:self.answerField.text]};
    
    [self showProgress];
    __weakself__
    [BFReqAPI reqValiSecurityQuestionWithParams:userIndo block:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                NSMutableDictionary *obj = [NSMutableDictionary dictionaryWithDictionary: responseObj[@"obj"]];
                obj[@"op"] = _op;
                obj[@"mobile"] = _mobile;
                obj[@"other"] = _other;
                [BFSecurityCenterViewModel handleSecurityCenterJumpLogicWithType:[BFSecurityCenterViewModel payPwdValiTypeFromStr:obj[@"next"]] andParams:obj fromViewController:weakself];
            }else
            {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
            }
        }
    }];
}
- (void)skipVCWithType:(NSString *)type
{
    NSDictionary *dict = @{@"sign":self.sign,@"op":self.op,@"mobile":self.mobile,@"other":self.other};
    
    [BFSecurityCenterViewModel handleSecurityCenterJumpLogicWithType:[BFSecurityCenterViewModel payPwdValiTypeFromStr:type] andParams:dict fromViewController:self];
}

#pragma mark - UITableViewDataSourceDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
        cell.textLabel.font = BF_Font_16;
    }
    {
        if (indexPath.row == 0) {
            cell.textLabel.text = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].safeQuestion;
        }else
        {
            cell.textLabel.text = @"";
            [cell.contentView addSubview:self.answerField];
        }
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.01f;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 100.0f;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 100.0f)];
    
    if (self.other.length >0) {
        [footerView addSubview:self.checkTypeButton];
    }
    [footerView addSubview:self.certainButton];
    return footerView;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

//
//  BFHaveSettedSecurityQuestionViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFHaveSettedSecurityQuestionViewController.h"
#import "BFSecurityCenterController.h"
#import "BFModifySecurityQuestionViewController.h"
#import "BFValiPayPwdViewController.h"

@interface BFHaveSettedSecurityQuestionViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *haveQuestionTable;
@property(nonatomic,strong)NSMutableArray *tableArray;


@end

@implementation BFHaveSettedSecurityQuestionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"密保问题";
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    [self.view addSubview:self.haveQuestionTable];
}
#pragma mark--CreatUI
- (UITableView *)haveQuestionTable
{
    if (!_haveQuestionTable) {
        _haveQuestionTable = [[UITableView alloc] initWithFrame:CGRectMake(0, 0,ScreenWidth,ScreenHeight-64.0f) style:UITableViewStyleGrouped];
        _haveQuestionTable.delegate = self;
        _haveQuestionTable.dataSource = self;
        _haveQuestionTable.showsVerticalScrollIndicator = NO;
        _haveQuestionTable.rowHeight = 50.0f;
        _haveQuestionTable.scrollEnabled = NO;
        
    }
    return _haveQuestionTable;
}
- (NSMutableArray *)tableArray
{
    if (!_tableArray) {
        _tableArray = [[NSMutableArray alloc] initWithArray:@[@"修改安全问题",@"重置安全问题"]];
        
    }
    return _tableArray;
}
#pragma mark--方法
- (void)backMethod
{
    for (UIViewController *ViewControlView in self.navigationController.viewControllers ) {
        if ([ViewControlView isKindOfClass:[BFSecurityCenterController class]]) {
            [self.navigationController popToViewController:ViewControlView animated:YES];
            return;
        }
    }
    
}
#pragma mark -- UITableViewDataSourceDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return self.tableArray.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        cell.textLabel.font = BF_Font_16;
    }
    
    cell.textLabel.text = self.tableArray[indexPath.row];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.01f;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:
        {
            BFModifySecurityQuestionViewController *modifySQVew  =[[BFModifySecurityQuestionViewController alloc] init];
            modifySQVew.title = @"修改安全问题";
            [self.navigationController pushViewController:modifySQVew animated:YES];
        }
            break;
        case 1:
        {
            BFValiPayPwdViewController * validateVC = [[BFValiPayPwdViewController alloc] init];
            validateVC.title = @"重置安全问题";
            validateVC.promotString = @"请输入支付密码,以重置安全问题";
            [self.navigationController pushViewController:validateVC animated:YES];
        }
            break;
        default:
            break;
    }
    
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

//
//  BFSecurityCenterController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFSecurityCenterController.h"
// viewController
#import "BFSecurityCenterViewModel.h"
#import "BFModifyLoginPwdViewController.h"
#import "BFModifyPayPwdViewController.h"
#import "BFForgetPayPwdViewController.h"
#import "BFSecurityCenterController.h"
#import "BFHaveSettedSecurityQuestionViewController.h"
#import "BFGesturePwdViewController.h"
// request
#import "BFReqAPI+Security.h"


@interface BFSecurityCenterController ()<UITableViewDataSource, UITableViewDelegate,UIAlertViewDelegate>
{
    NSMutableArray *dataArray;
    NSMutableArray *cardArray;
    BOOL haveEncrypted;//是否有密保问题;
    UITableView *passWordManagerTab;
}
@property(nonatomic, strong) UISwitch *gestureSwitch;
@property(nonatomic, strong) UISwitch *touchIDSwitch;

@end

@implementation BFSecurityCenterController

//TOREQ:验证登陆密码
- (void)verifyLoginPassWord:(NSString *)passWord cipherKeyId:(NSString *)cipherKeyId {
    
}

//TOREQ:查询绑卡列表
- (void)queryBindingCardList{
    
}

//TOREQ:获取用户密保问题
- (void)getUserSecurityList{
    
    
}

#pragma mark - UI

- (void)drawUI{
    
    //创建手势密码开关button
    self.gestureSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(ScreenWidth - 70, (48 - 30)/2, 0, 0)];
    [self.gestureSwitch addTarget:self action:@selector(gestureSwitchAction) forControlEvents:UIControlEventValueChanged];
    
    //指纹密码的开关
    self.touchIDSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(ScreenWidth - 70, (48 - 30)/2, 0, 0)];
    [self.touchIDSwitch addTarget:self action:@selector(touchIDSwitchAction:) forControlEvents:UIControlEventValueChanged];
    
    passWordManagerTab = [UITableView createPlainTableWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-BF_Height_NavBar) delegate:self datasource:self];
    passWordManagerTab.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:passWordManagerTab];
    
    if ([passWordManagerTab respondsToSelector:@selector(setSeparatorInset:)]) {
        passWordManagerTab.separatorInset = UIEdgeInsetsZero;
    }
    if ([passWordManagerTab respondsToSelector:@selector(setLayoutMargins:)]) {
        passWordManagerTab.layoutMargins = UIEdgeInsetsZero;
    }
}

//手势密码开关事件
- (void)gestureSwitchAction{
    [self showLoginPassWordView];
}

//TouchID开关事件
- (void)touchIDSwitchAction:(UISwitch *)sender{
    if (sender.isOn) {
        [[BFTouchIDTool sharedTool] systemCanEvaluateTouchID:^(BOOL isCan, TouchIDError code) {
            if (isCan) {
                NSString *reason = [[BFTouchIDTool sharedTool] reasonForApp:ApplicationTypeGesturePassword];
                [[BFTouchIDTool sharedTool] evaluateTouchIDReason:reason reply:^(BOOL isSuccess, TouchIDError code) {
                    [self performSelectorOnMainThread:@selector(setIDUnlockState:) withObject:isSuccess?[NSNumber numberWithInt:1]:[NSNumber numberWithInt:0] waitUntilDone:NO];
                }];
            }
            else {
                NSString *reason = [[BFTouchIDTool sharedTool] descForTouchIDError:code];
                [UIAlertView showWithMessage:reason delegate:nil];
                [sender setOn:NO animated:YES];
            }
        }];
    }
    else {
        BFCoreDataModelop *op = [[BFCoreDataModelop alloc] init];
        BFCoreUserModel *model = [op getCurrentBFuserModel];
        model.isUsedTouchIDForLogin = [NSNumber numberWithBool:NO];
//        [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedTouchIDForLogin = [NSNumber numberWithBool:NO];
    }
}

//设置TouchID开关值
- (void)setIDUnlockState:(id)value{
    BFCoreDataModelop *op = [[BFCoreDataModelop alloc] init];
    BFCoreUserModel *model = [op getCurrentBFuserModel];
    model.isUsedTouchIDForLogin = [NSNumber numberWithBool:YES];
//    [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedTouchIDForLogin = [NSNumber numberWithBool:YES];
    [_touchIDSwitch setOn:[value boolValue] animated:YES];
}

//清楚手势密码or跳到手势密码重置
- (void)jumpToGesturePasswordVC{
    //判断用户是开启还是关闭手势密码
    if ([self.gestureSwitch isOn]) {
        BFGesturePwdViewController *gesturePwdView = [[BFGesturePwdViewController alloc] init];
        gesturePwdView.titleLabelMsg = @"";
        gesturePwdView.remindLabelMsg = @"绘制手势密码";
        gesturePwdView.optionType = ResetGestturePwd;
        [self.navigationController pushViewController:gesturePwdView animated:YES];
    }
    else {
        //关闭手势密码
        
        BFCoreDataModelop *op = [[BFCoreDataModelop alloc] init];
        BFCoreUserModel *model = [op getCurrentBFuserModel];
        model.isUsedGesturePsw = [NSNumber numberWithBool:NO];
        model.gesturePsw = @"";
        model.isUsedTouchIDForLogin = [NSNumber numberWithBool:NO];
        
//        [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedGesturePsw = [NSNumber numberWithBool:NO];
//        [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].gesturePsw = @"";
//        [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedTouchIDForLogin = [NSNumber numberWithBool:NO];
        
        [passWordManagerTab  reloadData];
    }
}

//登录密码弹出框
- (void)showLoginPassWordView{
    UIAlertView *inputPwdAlt = [[UIAlertView alloc] initWithTitle:@"请输入登录密码验证" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    inputPwdAlt.tag = 1000;
    inputPwdAlt.alertViewStyle = UIAlertViewStyleSecureTextInput;
    [inputPwdAlt show];
}

#pragma mark--UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 1000) {
        if (buttonIndex == 1) {
            __weakself__
            UITextField *pwdField=[alertView textFieldAtIndex:0];
            [self showProgress];
            [BFReqAPI reqValiLoginPwd:pwdField.text block:^(id responseObj, NSError *error) {
                [weakself hideProgress];
                if (responseObj != nil) {
                    if (ERROR_CODE==1) {
                        [weakself jumpToGesturePasswordVC];
                    }else
                    {
                        if ([[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedGesturePsw boolValue] != self.gestureSwitch.isOn) {
                            [self.gestureSwitch setOn:!self.gestureSwitch.isOn];
                        }
                        [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
                        [passWordManagerTab reloadData];
                    }
                }
                else {
                    if ([[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedGesturePsw boolValue] != self.gestureSwitch.isOn) {
                        [self.gestureSwitch setOn:!self.gestureSwitch.isOn];
                    }
                    [UIAlertView showWithMessage:Net_Error delegate:self];
                    [passWordManagerTab reloadData];
                }
            }];
        }
        else {
            if ([[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedGesturePsw boolValue] != self.gestureSwitch.isOn) {
                [self.gestureSwitch setOn:!self.gestureSwitch.isOn];
            }
        }
    }
}


#pragma mark - UITableViewDataSource & Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return dataArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSArray *array = dataArray[section];
    return array.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellidentifier = @"cellidentfier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellidentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellidentifier];
    }
    NSArray *array = dataArray[indexPath.section];
    BaseMethodModel *model = array[indexPath.row];
    cell.textLabel.textColor = [UIColor blackColor];
    cell.textLabel.font = BF_Font_15;
    cell.textLabel.text = model.name;
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            if ([[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedGesturePsw boolValue]){
                [self.gestureSwitch setOn:YES animated:YES];
            }else{
                [self.gestureSwitch setOn:NO animated:YES];
            }
            [cell.contentView addSubview:_gestureSwitch];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.accessoryType = UITableViewCellAccessoryNone;
            
        }else if(indexPath.row == 1){
            if ([[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedGesturePsw boolValue]){
                cell.textLabel.textColor = [UIColor blackColor];
                cell.userInteractionEnabled = YES;
            }else{
                cell.textLabel.textColor = [UIColor grayColor];
                cell.userInteractionEnabled = NO;
            }
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }else{
            if (_gestureSwitch.isOn){
                [_touchIDSwitch setEnabled:YES];
                cell.textLabel.textColor = [UIColor blackColor];
            }else{
                [_touchIDSwitch setEnabled:NO];
                cell.textLabel.textColor = [UIColor grayColor];
            }
            
            if ([[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedTouchIDForLogin boolValue]){
                [_touchIDSwitch setOn:YES animated:NO];
            }else{
                [_touchIDSwitch setOn:NO animated:NO];
            }
            [cell.contentView addSubview:_touchIDSwitch];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
        
    }
    else {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    if(indexPath.row == 0){
        //头部分割线
        UIView *headLine = UILineDefaultCreate(0, 0, ScreenWidth);
        [cell addSubview:headLine];
        
        //底部分割线
        UIView *bottomLine = UILineDefaultCreate(0, 46.5, ScreenWidth);
        [cell addSubview:bottomLine];
        
    }else{
        //底部分割线
        UIView *bottomLine = UILineDefaultCreate(0, 46.5, ScreenWidth);
        [cell addSubview:bottomLine];
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 47.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    return [[UIView alloc]init];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSArray *array = dataArray[indexPath.section];
    BaseMethodModel *model = array[indexPath.row];
    if (model.method) {
        [self performSelector:model.method withObject:nil afterDelay:0.0];
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        cell.separatorInset = UIEdgeInsetsZero;
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        cell.layoutMargins = UIEdgeInsetsZero;
    }
}

- (void)resetGesturePwd{
    [self showLoginPassWordView];
}

#pragma mark - Jump

- (void)jumpToModifyLoginPwd{
    BFModifyLoginPwdViewController *modifyLoginPwdVc = [[BFModifyLoginPwdViewController alloc] init];
    [self.navigationController pushViewController:modifyLoginPwdVc animated:YES];
}

- (void)jumpToForgetPayPwd{
    [self showProgress];
    __weakself__
    [BFReqAPI reqInitFindPayPwdBlock:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        if (responseObj) {
            if (ERROR_CODE == 1) {
                NSDictionary *dict = [NSDictionary dictionaryWithDictionary:responseObj[@"obj"]];
                
                //保存初始化前面
                [USER_D setObject:dict[@"sign"] forKey:@"initSign"];
                [USER_D synchronize];
                
                [BFSecurityCenterViewModel handleSecurityCenterJumpLogicWithType:[BFSecurityCenterViewModel payPwdValiTypeFromStr:dict[@"next"]] andParams:dict fromViewController:weakself];
            }
            else {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
            }
        }
        else {
            [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
        }
    }];
}




- (void)jumpToModifyPayPwd{
    BFModifyPayPwdViewController *modifyPayPwdVc = [[BFModifyPayPwdViewController alloc] init];
    [self.navigationController pushViewController:modifyPayPwdVc animated:YES];
}
- (void)jumpToSecurityQuestion{
    BFHaveSettedSecurityQuestionViewController *securityQuestionVc = [[BFHaveSettedSecurityQuestionViewController alloc] init];
    [self.navigationController pushViewController:securityQuestionVc animated:YES];
}
//跳转400页面
- (void)jumpToService{
}

#pragma mark - Life Cycle

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title = @"密码管理";
    
    //
    cardArray = [[NSMutableArray alloc] init];
    dataArray = [[NSMutableArray alloc] init];
    
    //
    [[BFTouchIDTool sharedTool] systemCanEvaluateTouchID:^(BOOL isCan, TouchIDError code) {
        if (!isCan && (code == TouchIDErrorNotSupport || code == TouchIDErrorUnknown)) {
            [dataArray addObject:@[[BaseMethodModel createWithName:@"手势密码" selector:nil],[BaseMethodModel createWithName:@"重置手势密码" selector:@selector(resetGesturePwd)]]];
        }
        else {
            [dataArray addObject:@[[BaseMethodModel createWithName:@"手势密码" selector:nil],[BaseMethodModel createWithName:@"重置手势密码" selector:@selector(resetGesturePwd)],[BaseMethodModel createWithName:@"开启指纹解锁" selector:nil]]];
        }
    }];
    
    [dataArray addObject:@[[BaseMethodModel createWithName:@"修改登录密码" selector:@selector(jumpToModifyLoginPwd)]]];
    [dataArray addObject:@[[BaseMethodModel createWithName:@"忘记支付密码" selector:@selector(jumpToForgetPayPwd)],
                           [BaseMethodModel createWithName:@"修改支付密码" selector:@selector(jumpToModifyPayPwd)]]];
    [dataArray addObject:@[[BaseMethodModel createWithName:@"密保问题" selector:@selector(jumpToSecurityQuestion)]]];
    
    //
    haveEncrypted = NO;
    
    //
    [self drawUI];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [passWordManagerTab reloadData];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}



@end

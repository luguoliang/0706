//
//  BFForgetPayPwdViewController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/16.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

@interface BFForgetPayPwdViewController : BFBaseViewController

@property (nonatomic, strong) NSMutableArray *cardArray;//绑卡数组;
@property (nonatomic, assign) BOOL haveEncrypted; //是否有密保

@end

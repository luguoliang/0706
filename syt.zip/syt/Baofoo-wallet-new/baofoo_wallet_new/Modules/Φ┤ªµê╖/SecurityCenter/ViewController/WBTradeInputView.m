//
//  WBTradeInputView.m
//  BaofooWallet
//
//  Created by mac on 15/8/11.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import "WBTradeInputView.h"
#define ZCScreenWidth [UIScreen mainScreen].bounds.size.width
@interface WBTradeInputView()
/** 数字数组 */
@property (nonatomic, strong) NSMutableArray *nums;
@end
@implementation WBTradeInputView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        
    }
    return self;
}
- (NSMutableArray *)nums
{
    if (_nums == nil) {
        _nums = [NSMutableArray array];
    }
    return _nums;
}

- (void)deleteNumber
{
    [self.nums removeLastObject];
    [self setNeedsDisplay];
}
- (void)deleteAllNumber
{
    [self.nums removeAllObjects];
    [self setNeedsDisplay];
}
// 数字
- (void)number:(NSNumber *)number
{
    if (self.nums.count >= 6) return;

    [self.nums addObject:number];
    [self setNeedsDisplay];
}
- (void)drawRect:(CGRect)rect
{
    // 画图

    UIImage *field = [UIImage imageNamed:@"password_in.png"];
    
    
    
    [field drawInRect:CGRectMake(0.0f, 0.0f, self.frame.size.width, self.frame.size.height)];
    

    
    // 画点
    UIImage *pointImage = [UIImage imageNamed:@"password_yuan.png"];
    
    CGFloat pointW = 10.0f;
    CGFloat pointH = pointW;
    CGFloat pointY = (self.frame.size.height-10.0f)*0.5;
    
    CGFloat pointX;
    CGFloat intervalX = ((self.frame.size.width/6.0f)-pointImage.size.width)*0.5;

    for (int i = 0; i < self.nums.count; i++) {
        pointX =  i*(2*intervalX+pointImage.size.width) +intervalX;
        [pointImage drawInRect:CGRectMake(pointX, pointY, pointW, pointH)];
    }

}

@end

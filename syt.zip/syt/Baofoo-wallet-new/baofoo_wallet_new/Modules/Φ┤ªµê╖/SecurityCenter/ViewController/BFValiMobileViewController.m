//
//  BFValiMobileViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/18.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFValiMobileViewController.h"
#import "BFValiPayPwdViewController.h"
#import "BFWebViewController.h"
#import "BFBuyCommodityViewController.h"
#import "BFSecurityCenterController.h"
#import "BFFindPwdTypeListViewController.h"

//网络请求
#import "BFReqAPI+Security.h"

//ViewModel
#import "BFSecurityCenterViewModel.h"


@interface BFValiMobileViewController ()
@property(nonatomic,strong)UILabel *topLabel;//提示文字
@property(nonatomic,strong)UITextField *mobileField;//手机号
@property(nonatomic,strong)UITextField *messgeField;//验证码
@property(nonatomic,strong)CustomTimerButtom *messgeButton;//验证码按钮
@property(nonatomic,strong)UIButton *certainButton;//确定按钮
@property(nonatomic,strong)UIButton *checkTypeButton;//选择其他方式找回
@end

@implementation BFValiMobileViewController
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"找回支付密码";
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    [self.view addSubview:self.topLabel];
    [self.view addSubview:self.mobileField];
    [self.view addSubview:self.messgeField];
    if (self.other.length > 0) {
        [self.view addSubview:self.checkTypeButton];
    }
    [self.view addSubview:self.certainButton];
    
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardHide)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    //将触摸事件添加到当前view
    [self.view addGestureRecognizer:tapGestureRecognizer];
    [_messgeButton stopTimer];
    [self getCodeMethod];
}
#pragma mark--CreatUI
- (UILabel *)topLabel
{
    if (!_topLabel) {
        _topLabel = [[UILabel alloc] initWithFrame:CGRectMake(18.0f, 0.0f, ScreenWidth, 35.0f)];
        _topLabel.textColor = COLOR_HEXSTRING(@"#aaaaaa");
        _topLabel.font = BF_Font_13;
        _topLabel.text = @"我们已经发送了验证码到你的手机";
    }
    return _topLabel;
}

- (UITextField *)mobileField
{
    if (!_mobileField) {
        _mobileField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, self.topLabel.frame.size.height+self.topLabel.frame.origin.y, ScreenWidth, 50.0f)];
        _mobileField.backgroundColor = [UIColor whiteColor];
        _mobileField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 80.0f, 50.0f) text:@"手机号"];
        _mobileField.leftViewMode = UITextFieldViewModeAlways;
        _mobileField.text = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].mobile;
        _mobileField.keyboardType =  UIKeyboardTypeNumbersAndPunctuation;;
        _mobileField.font = BF_Font_16;
        
        _mobileField.enabled = NO;
        
        
        UILabel *topLine = [self lineLabelWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 0.5f)];
        [_messgeField addSubview:topLine];
        
    }
    return _mobileField;
}

- (UITextField *)messgeField
{
    if (!_messgeField) {
        _messgeField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, self.mobileField.frame.size.height+self.mobileField.frame.origin.y, ScreenWidth, 50.0f)];
        _messgeField.backgroundColor = [UIColor whiteColor];
        _messgeField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 80.0f, 50.0f) text:@"验证码"];
        _messgeField.leftViewMode = UITextFieldViewModeAlways;
        _messgeField.placeholder = @"短信验证码";
        _messgeField.keyboardType =  UIKeyboardTypeNumbersAndPunctuation;;
        _messgeField.font = BF_Font_16;
        
        _messgeButton = [CustomTimerButtom buttonWithType:UIButtonTypeCustom];
        _messgeButton.frame = CGRectMake(0.0f, 0.0f, 65.0f, 50.0f);
        [_messgeButton setTitle:@"获取" forState:UIControlStateNormal];
        [_messgeButton setTitleColor:COLOR_HEXSTRING(BLUE_COLOR) forState:UIControlStateNormal];
        _messgeButton.titleLabel.font = BF_Font_14;
        [_messgeButton addTarget:self action:@selector(getCodeMethod) forControlEvents:UIControlEventTouchUpInside];
        _messgeField.rightView = _messgeButton;
        _messgeField.rightViewMode = UITextFieldViewModeAlways;
        _messgeField.font = BF_Font_16;
        
        [_messgeField addTarget:self action:@selector(textFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
        
        UILabel *topLine = [self lineLabelWithFrame:CGRectMake(18.0f, 0.0f, ScreenWidth-18.0f, 0.5f)];
        [_messgeField addSubview:topLine];
        
        UILabel *bottomLine = [self lineLabelWithFrame:CGRectMake(0.0f, _messgeField.frame.size.height-0.5f, ScreenWidth, 0.5f)];
        [_messgeField addSubview:bottomLine];
    }
    return _messgeField;
}
- (UILabel *)lineLabelWithFrame:(CGRect)rect
{
    UILabel *label = [[UILabel alloc] initWithFrame:rect];
    label.backgroundColor = COLOR_HEXSTRING(LINE_COLOR);
    return label;
}
- (UIView *)leftViewLabelWithFrame:(CGRect)rect text:(NSString *)text
{
    UIView *leftView = [[UIView alloc] initWithFrame:rect];
    UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, rect.size.width, rect.size.height)];
    leftLabel.font = BF_Font_16;
    leftLabel.textColor = COLOR_HEXSTRING(BLACK_COLOR);
    leftLabel.text = text;
    leftLabel.textAlignment = NSTextAlignmentCenter;
    [leftView addSubview:leftLabel];
    return leftView;
}

- (UIButton *)checkTypeButton
{
    if (!_checkTypeButton) {
        _checkTypeButton = [UIButton buttonWithType:UIButtonTypeSystem];
        _checkTypeButton.frame = CGRectMake(ScreenWidth-135.0f, self.messgeField.frame.origin.y+self.messgeField.frame.size.height, 135.0f, 30.0f);
        [_checkTypeButton setTitle:@"选择其他方式找回" forState:UIControlStateNormal];
        [_checkTypeButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _checkTypeButton.titleLabel.font = [UIFont systemFontOfSize:13.0f];
        [_checkTypeButton addTarget:self action:@selector(certainButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _checkTypeButton;
}

- (UIButton *)certainButton
{
    if (!_certainButton) {
        _certainButton = [UIButton buttonWithType:UIButtonTypeSystem];
        _certainButton.frame = CGRectMake(15.0f, self.messgeField.frame.origin.y+self.messgeField.frame.size.height+60.0f, ScreenWidth-30.0f, 40);
        _certainButton.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _certainButton.enabled = NO;
        _certainButton.layer.cornerRadius = 20.0f;
        [_certainButton setTitle:@"下一步" forState:UIControlStateNormal];
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [_certainButton addTarget:self action:@selector(certainButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _certainButton;
}
#pragma mark--方法
- (void)keyboardHide
{
    [self.view endEditing:YES];
}
-(void)backMethod
{
    for (NSInteger i=0; i<self.navigationController.viewControllers.count; i++) {
        
        NSInteger a = self.navigationController.viewControllers.count -i-1;
        UIViewController *vc = self.navigationController.viewControllers[a];
        if ([vc isKindOfClass:[BFSecurityCenterController class]]||[vc isKindOfClass:[BFBuyCommodityViewController class]]||[vc isKindOfClass:[BFWebViewController class]]) {
            [self.navigationController popToViewController:vc animated:YES];
            break;
        }
    }
}

#pragma mark - UITextFieldValueChange
-(void)textFieldValueChange:(UITextField*)mytextfield
{
    if (self.messgeField.text.length>6) {
        self.messgeField.text = [self.messgeField.text substringToIndex:6];
    }
    if ((self.messgeField.text.length == 6)) {
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f] forState:UIControlStateNormal];
        _certainButton.enabled = YES;
    }
    else
    {
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.enabled = NO;
    }
}

-(void)getCodeMethod
{
    
    [self getVerifcationCode];
}
#pragma mark - 获取验证码
-(void)getVerifcationCode
{
    [self showProgress];
    __weakself__
    [BFReqAPI reqVerifyCodeSendForFindPayPwdWithPhoneNo:self.mobile block:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                [_messgeButton startTimer];
                [_messgeField becomeFirstResponder];
            }else
            {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
            }
        }
    }];
}
#pragma mark - 提交确认按钮
-(void)certainButton:(UIButton*)button
{
    [self.view endEditing:YES];
    if (button == self.certainButton) {
        if ([[BFCoreDataModelop sharedManager] getCurrentBFuserModel].safeQuestion.length==0) {
            
            [UIAlertView showWithTitle:nil message:@"您尚未设置安全问题,无法找回支付密码。宝付客服：021-68811008" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
        }else{//anquanwenti
            NSString *safeQuest = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].safeQuestion;
            if (safeQuest.length != 0)
            {
                if ([self.op isKindOfClass:[NSNull class]]||self.op == nil) {
                    self.op = @"";
                }
                [self showProgress];
                __weakself__
                [BFReqAPI reqValiPhoneCodeAtFindPayPwdWithSign:self.sign mobile:self.mobile code:self.messgeField.text andOperation:self.op block:^(id responseObj, NSError *error) {
                    [weakself hideProgress];
                    if (responseObj != nil) {
                        if (ERROR_CODE == 1) {
                            NSDictionary *obj = responseObj[@"obj"];
                            weakself.sign = obj[@"sign"];
                            NSString *next = obj[@"next"];
                            
                            [weakself skipVCWithType:next];
                        }else
                        {
                            [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
                        }
                    }
                }];
            }else
            {
                [UIAlertView showWithTitle:@"尚未设置安全问题，请设置安全问题" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
            }
        }
    }else
    {
        [self skipVCWithType:_other];
    }
    
}
- (void)skipVCWithType:(NSString *)type
{
    NSDictionary *dict = @{@"sign":self.sign,@"op":self.op,@"mobile":self.mobile,@"other":self.other};
    
    [BFSecurityCenterViewModel handleSecurityCenterJumpLogicWithType:[BFSecurityCenterViewModel payPwdValiTypeFromStr:type] andParams:dict fromViewController:self];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
- (void)dealloc
{
    [_messgeButton stopTimer];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

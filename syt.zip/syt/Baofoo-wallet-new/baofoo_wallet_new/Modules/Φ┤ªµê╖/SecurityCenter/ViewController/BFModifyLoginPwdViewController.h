//
//  BFModifyLoginPwdViewController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/16.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

typedef enum{
    ModifyTypeWithSecturity = 0,//安全中心修改密码
    ModifyTypeWithBumped = 1//被挤掉修改密码
}ModifyLoginPassWordType;

@interface BFModifyLoginPwdViewController : BFBaseViewController

@property(nonatomic,assign)ModifyLoginPassWordType modifyLoginPassWordType;

@end

//
//  BFFindPwdTypeListViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFFindPwdTypeListViewController.h"
#import "BFValiPayPwdViewController.h"
#import "BFWebViewController.h"
#import "BFBuyCommodityViewController.h"
#import "BFSecurityCenterController.h"
#import "BFSecurityCenterViewModel.h"
#import "BFLoginViewController.h"

@interface BFFindPwdTypeListViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *backPayPwdTable;

@end

@implementation BFFindPwdTypeListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    self.title = @"找回支付密码";
    [self.view addSubview:self.backPayPwdTable];
    
    UIView*barView = [[UIView alloc] initWithFrame:CGRectMake(0, -64, self.view.frame.size.width, 64)];
    barView.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
    [self.view addSubview:barView];
}
#pragma mark--CreatUI
- (UITableView *)backPayPwdTable
{
    if (!_backPayPwdTable) {
        _backPayPwdTable = [[UITableView alloc] initWithFrame:CGRectMake(0, 0,ScreenWidth,ScreenHeight-64.0f) style:UITableViewStyleGrouped];
        _backPayPwdTable.delegate = self;
        _backPayPwdTable.dataSource = self;
        _backPayPwdTable.showsVerticalScrollIndicator = NO;
        _backPayPwdTable.rowHeight = 50.0f;
        _backPayPwdTable.scrollEnabled = NO;
    }
    return _backPayPwdTable;
}
#pragma mark--方法
- (void)backMethod
{
    for (NSInteger i=0; i<self.navigationController.viewControllers.count; i++) {
        
        NSInteger a = self.navigationController.viewControllers.count -i-1;
        UIViewController *vc = self.navigationController.viewControllers[a];
        if ([vc isKindOfClass:[BFLoginViewController class]]||[vc isKindOfClass:[BFSecurityCenterController class]]||[vc isKindOfClass:[BFBuyCommodityViewController class]]||[vc isKindOfClass:[BFWebViewController class]]) {
            [self.navigationController popToViewController:vc animated:YES];
            break;
        }
    }
}
#pragma mark - UITableViewDataSourceDelegate


-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        cell.textLabel.font = BF_Font_15;
    }
    
    NSDictionary *dict = self.typeArray[indexPath.row];
    cell.textLabel.text = dict[@"text"];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.typeArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50.0f;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(18.0f, 0.0f, ScreenWidth-36.0f, 50.0f)];
    label.numberOfLines = 0;
    label.font = BF_Font_13;
    label.textColor = COLOR_HEXSTRING(@"#aaaaaa");
    label.text = @"系统检测发现你可以通过以下任意一种方式进行效验，找回支付密码，请任意选择哦 ~ ";
    [headerView addSubview:label];
    
    return headerView;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *dict = self.typeArray[indexPath.row];
    
    [BFSecurityCenterViewModel handleSecurityCenterJumpLogicWithType:[BFSecurityCenterViewModel payPwdValiTypeFromStr:dict[@"next"]] andParams:dict fromViewController:self];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

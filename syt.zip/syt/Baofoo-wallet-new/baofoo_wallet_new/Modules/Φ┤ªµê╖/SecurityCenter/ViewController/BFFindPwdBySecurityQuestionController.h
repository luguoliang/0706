//
//  BFFindPwdBySecurityQuestionController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/17.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

@interface BFFindPwdBySecurityQuestionController : BFBaseViewController

@property(nonatomic,copy)NSString *sign;//找回密码签名
@property(nonatomic,copy)NSString *op;//找回方式
@property(nonatomic,copy)NSString *mobile;//绑定的手机号
@property(nonatomic,copy)NSString *other;//控制显示支付方式按钮

@end

 //
//  BFValiPayPwdViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFValiPayPwdViewController.h"
#import "BFKeyBoardView.h"
#import "WBTradeInputView.h"
#import "BFReqAPI+Security.h"
#import "BFNotSettedSecurityQuestionViewController.h"
#import "BFSecurityCenterController.h"
#import "BFBuyCommodityViewController.h"
#import "BFWebViewController.h"
#import <IQKeyboardManager/IQKeyboardManager.h>

@interface BFValiPayPwdViewController ()<BFKeyBoardViewDelegate,UITextFieldDelegate,UIAlertViewDelegate>
@property(nonatomic,strong)UILabel *topLabel;
@property(nonatomic,strong)WBTradeInputView *payInputView;
@property(nonatomic,strong)UITextField *payInputField;
@property(nonatomic,strong)BFKeyBoardView *keyBoard;
@property(nonatomic,strong)UIButton *certainButton;//确定按钮


@end

@implementation BFValiPayPwdViewController

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [[IQKeyboardManager sharedManager] setEnable:NO];
    [self.payInputField becomeFirstResponder];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [self.view endEditing:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.topLabel];
    [self.view addSubview:self.payInputView];
    [self.view addSubview:self.payInputField];
    
    
    [self.view addSubview:self.certainButton];
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardShow)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    //将触摸事件添加到当前view
    [self.view addGestureRecognizer:tapGestureRecognizer];
}
#pragma mark--CreatUI
- (BFKeyBoardView *)keyBoard
{
    if (!_keyBoard) {
        _keyBoard = [[[NSBundle mainBundle] loadNibNamed:@"BFKeyBoardView" owner:nil options:nil] lastObject];
        _keyBoard.delegate = self;
    }
    return _keyBoard;
}
- (UILabel *)topLabel
{
    if (!_topLabel) {
        _topLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 95.0f)];
        _topLabel.textAlignment = NSTextAlignmentCenter;
        _topLabel.font = BF_Font_17;
        _topLabel.text = self.promotString;
    }
    return _topLabel;
}
-(WBTradeInputView *)payInputView
{
    if (!_payInputView) {
        _payInputView = [[WBTradeInputView alloc] initWithFrame:CGRectMake(27.0f, 95.0f, ScreenWidth-54.0f, 40.0f)];
    }
    return _payInputView;
}
- (UITextField *)payInputField
{
    if (!_payInputField) {
        _payInputField = [[UITextField alloc] initWithFrame:CGRectMake(27.0f, 95.0f, ScreenWidth - 54.0f, 40.0f)];
        _payInputField.backgroundColor = [UIColor whiteColor];
        _payInputField.leftViewMode = UITextFieldViewModeAlways;
        _payInputField.secureTextEntry = YES;
        _payInputField.delegate = self;
        _payInputField.font = BF_Font_16;
        _payInputField.alpha = 0.0f;
        _payInputField.inputView = self.keyBoard;
    }
    return _payInputField;
}
- (UIButton *)certainButton
{
    if (!_certainButton) {
        _certainButton = [UIButton buttonWithType:UIButtonTypeSystem];
        _certainButton.frame = CGRectMake(15.0f, self.payInputView.frame.origin.y+self.payInputView.frame.size.height+60.0f, ScreenWidth-30.0f, 40);
        _certainButton.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _certainButton.enabled = NO;
        _certainButton.layer.cornerRadius = 20.0f;
        [_certainButton setTitle:@"下一步" forState:UIControlStateNormal];
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [_certainButton addTarget:self action:@selector(certainMethod) forControlEvents:UIControlEventTouchUpInside];
    }
    return _certainButton;
}
#pragma mark--方法
- (void)backMethod
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)keyboardShow
{
    [self.payInputField becomeFirstResponder];
}
-(void)certainMethod
{
    
    [self.view endEditing:YES];
    
    [self request];
}


-(void)request
{
    [self.view endEditing:YES];
    __weakself__
    [self showProgress];
    [BFReqAPI reqValiPayPwd:self.payInputField.text block:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                BFNotSettedSecurityQuestionViewController *noVC = [[BFNotSettedSecurityQuestionViewController alloc] init];
                noVC.title = @"重置安全问题";
                noVC.tagStyle = 1;
                [weakself.navigationController pushViewController:noVC animated:YES];
            }else
            {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
            }
        }
    }];
}
- (void)judgeMethod
{
    if (self.payInputField.text.length == 6)
    {
        _certainButton.enabled = YES;
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f] forState:UIControlStateNormal];
    }else
    {
        _certainButton.enabled = NO;
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
    }
}
#pragma mark--UITextFieldDelegate
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [_keyBoard setKeyBoardWith:textField];
    [_keyBoard setKeyboardstytle:KeyboardstytlePassword];
    return YES;
}
#pragma mark - BFKeyBoardViewDelegate
-(void)keyBoard:(BFKeyBoardView*)keyBoard didClickedButton:(UIButton*)button WithText:(UITextField*)textfield
{
    
    [self.payInputView number:[NSNumber numberWithInteger:[button.titleLabel.text integerValue]]];
    textfield.text  = [NSString stringWithFormat:@"%@%@",textfield.text,button.titleLabel.text];
    if (textfield.text.length>6) {
        textfield.text = [textfield.text substringToIndex:6];
    }
    [self judgeMethod];
    
    
    NSLog(@"%@",textfield.text);
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateButton:(UIButton*)button WithText:(UITextField*)textfield
{
    [self.payInputView deleteNumber];
    NSString*str = textfield.text;
    if ([str length] != 0) {
        str = [str substringToIndex:[str length]- 1];
        textfield.text  = str;
    }
    [self judgeMethod];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateFinished:(UIButton*)button WithText:(UITextField*)textfield
{
    [textfield resignFirstResponder];
}
#pragma mark--UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        [self performSelector:@selector(goBackMethod) withObject:nil afterDelay:0.25];
    }
}
- (void)goBackMethod
{
    for (UIViewController *ViewControlView in self.navigationController.viewControllers ) {
        if ([ViewControlView isKindOfClass:[BFSecurityCenterController class]]||[ViewControlView isKindOfClass:[BFBuyCommodityViewController class]]||[ViewControlView isKindOfClass:[BFWebViewController class]]) {
            [self.navigationController popToViewController:ViewControlView animated:YES];
            return;
        }
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

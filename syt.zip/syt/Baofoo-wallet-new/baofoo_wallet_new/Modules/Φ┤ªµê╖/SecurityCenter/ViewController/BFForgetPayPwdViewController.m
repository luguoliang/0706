//
//  BFForgetPayPwdViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/16.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFForgetPayPwdViewController.h"
#import "BFFindPwdBySecurityQuestionController.h"


@interface BFForgetPayPwdViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *forgetPayPwdTable;
    NSMutableArray *typeArr;//表数据源
}

@end

@implementation BFForgetPayPwdViewController
//绘制视图
- (void)drawUI{
    [self getFindType];
    
    //找回密码方式表格
    forgetPayPwdTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth,ScreenHeight - 64)];
    forgetPayPwdTable.backgroundColor = [UIColor clearColor];
    forgetPayPwdTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    forgetPayPwdTable.dataSource = self;
    forgetPayPwdTable.delegate = self;
    forgetPayPwdTable.scrollEnabled = NO;
    [self.view addSubview:forgetPayPwdTable];
    
    if ([forgetPayPwdTable respondsToSelector:@selector(setSeparatorInset:)]) {
        forgetPayPwdTable.separatorInset = UIEdgeInsetsZero;
    }
    if ([forgetPayPwdTable respondsToSelector:@selector(setLayoutMargins:)]) {
        forgetPayPwdTable.layoutMargins = UIEdgeInsetsZero;
    }
}

//初始化找回方式
- (void)getFindType{
    typeArr = [[NSMutableArray alloc] init];
    //如实名用户: 1.可通过密保问题找回支付密码 2.可通过绑卡找回
    //如非实名用户: 1.可通过开户证件号找回  2.通过密保问题找回
    if ([[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].authFlag isEqualToString: @"Y"]) {
        if (_haveEncrypted) {
            [typeArr addObject:[BaseMethodModel createWithName:@"通过密保问题找回" selector:@selector(jumpToRealNameEncryptedVC)]];
        }
        if ([_cardArray count]) {
            [typeArr addObject:[BaseMethodModel createWithName:@"通过快捷银行卡找回" selector:@selector(jumpToBindDingCardVC)]];
        }
        
    }else {
        
        if (_haveEncrypted) {
            [typeArr addObject:[BaseMethodModel createWithName:@"通过密保问题找回" selector:@selector(jumpToNoRealNameEncryptedVC)]];
        }
        [typeArr addObject:[BaseMethodModel createWithName:@"通过开户证件号找回" selector:@selector(jumpToOpenIDVC)]];
    }
}

#pragma mark - UITableViewDataSource & Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [typeArr count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIndetifier = @"cellIndetifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIndetifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIndetifier];
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    BaseMethodModel *model = typeArr[indexPath.row];
    cell.textLabel.text = model.name;
    cell.textLabel.font = BF_Font_15;
    if(indexPath.row == 0){
        //头部分割线
        UIView *headLine = UILineDefaultCreate(0, 0, ScreenWidth);
        [cell addSubview:headLine];
        
        //底部分割线
        UIView *bottomLine = UILineDefaultCreate(0, 46.5, ScreenWidth);
        [cell addSubview:bottomLine];
        
    }else{
        //底部分割线
        UIView *bottomLine = UILineDefaultCreate(0, 46.5, ScreenWidth);
        [cell addSubview:bottomLine];
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 47;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    return [[UIView alloc]init];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10.0;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        cell.separatorInset = UIEdgeInsetsZero;
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        cell.layoutMargins = UIEdgeInsetsZero;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    BaseMethodModel *model = typeArr[indexPath.row];
    [self performSelector:model.method withObject:nil afterDelay:0.0];
}

#pragma mark - Jump

//实名通过密保问题
- (void)jumpToRealNameEncryptedVC{
}

//通过绑卡
- (void)jumpToBindDingCardVC{
}

//非实名通过密保问题
- (void)jumpToNoRealNameEncryptedVC{
}

//非实名通过开户证件
- (void)jumpToOpenIDVC{
   
}

- (void)goBackAction{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Life Cycle

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title = @"忘记支付密码";
    
    //
    [self drawUI];
    [self setLeftBarButtonItemTarget:self action:@selector(goBackAction)];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end

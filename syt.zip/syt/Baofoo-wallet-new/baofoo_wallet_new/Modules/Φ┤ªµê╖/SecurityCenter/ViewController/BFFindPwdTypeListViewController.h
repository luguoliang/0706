//
//  BFFindPwdTypeListViewController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

@interface BFFindPwdTypeListViewController : BFBaseViewController
@property(nonatomic,strong)NSArray *typeArray;
@property(nonatomic,copy)NSString *sign;
@property(nonatomic,copy)NSString *mobile;
@property(nonatomic,copy)NSString *other;
@end

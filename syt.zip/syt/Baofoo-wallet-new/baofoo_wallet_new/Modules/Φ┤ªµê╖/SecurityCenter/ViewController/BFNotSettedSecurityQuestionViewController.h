//
//  BFNotSettedSecurityQuestionViewController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

@interface BFNotSettedSecurityQuestionViewController : BFBaseViewController
@property(nonatomic,assign)int securityQuestionStyle;//1表示从注册界面进入 0表示没有安全问题从设置界面进入

@property(nonatomic,assign)int tagStyle;// 0修改 1重置

@property(nonatomic,copy)NSString *regMobile;
@property(nonatomic,copy)NSString *telCode;
@property(nonatomic,copy)NSString *payPass;
@property(nonatomic,copy)NSString *regPass;
@end

//
//  BFAgainSettingPayPwdViewController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/26.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

@interface BFAgainSettingPayPwdViewController : BFBaseViewController
@property(nonatomic,copy)NSString *freshPayPwd;//新的支付密码
@property(nonatomic,copy)NSString *op;//找回方式
@property(nonatomic,copy)NSString *sign;//签名
@end

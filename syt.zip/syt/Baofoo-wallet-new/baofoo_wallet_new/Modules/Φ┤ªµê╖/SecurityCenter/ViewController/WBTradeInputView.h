//
//  WBTradeInputView.h
//  BaofooWallet
//
//  Created by mac on 15/8/11.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface WBTradeInputView : UIView
- (void)number:(NSNumber *)number;

- (void)deleteNumber;

- (void)deleteAllNumber;
@end

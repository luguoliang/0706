//
//  BFSecurityCenterViewModel.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/18.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

// 安全中心跳转逻辑的类型定义
typedef NS_ENUM(NSInteger, BFPayPwdValiType) {
    BFTypeList = 0,
    BFValiSafeCard = 1, // 快捷卡验证
    BFValiIdCard = 2, // 身份证验证
    BFValiSafeQuestion = 3, // 密保问题验证
    BFSetPwd = 4, // 设置密码
    BFValiMobile = 5 // 手机验证码
};

@interface BFSecurityCenterViewModel : NSObject

+ (BFPayPwdValiType)payPwdValiTypeFromStr:(NSString *)str;

+ (void)handleSecurityCenterJumpLogicWithType:(BFPayPwdValiType)type andParams:(NSDictionary *)params fromViewController:(id)vc;

@end

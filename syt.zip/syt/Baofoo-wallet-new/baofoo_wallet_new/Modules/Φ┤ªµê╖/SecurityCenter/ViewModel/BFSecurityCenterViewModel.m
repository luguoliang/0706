//
//  BFSecurityCenterViewModel.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/18.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFSecurityCenterViewModel.h"
#import "BFFindPwdBySecurityQuestionController.h"
#import "BFFindPwdByIdCardViewController.h"
#import "BFFindPwdBySafeCardViewController.h"
#import "BFForgetPayPwdViewController.h"
#import "BFSettingNewPayPwdViewController.h"
#import "BFValiMobileViewController.h"
#import "BFReqAPI+Security.h"
#import "BFFindPwdTypeListViewController.h"

@implementation BFSecurityCenterViewModel
+ (void)handleSecurityCenterJumpLogicWithType:(BFPayPwdValiType)type andParams:(NSDictionary *)params fromViewController:(UIViewController *)vc {
    switch (type) {
        case BFTypeList:
            [[self class] jumpToTypeListWithParams:params fromViewController:vc ];
            break;
        case BFValiSafeCard:
            [[self class] jumpToSafeCardWithParams:params fromViewController:vc];
            break;
        case BFValiIdCard:
            [[self class] jumpToValiIdCardWithParams:params fromViewController:vc];
            break;
        case BFValiSafeQuestion:
            [[self class] jumpToSafeQuestionWithParams:params fromViewController:vc];
            break;
        case BFSetPwd:
            [[self class] jumpToSetPwdWithParams:params fromViewController:vc];
            break;
        case BFValiMobile:
            [[self class] jumpToValiMobileWithParams:params fromViewController:vc];
            break;
        default:
            break;
    }
}

+ (BFPayPwdValiType)payPwdValiTypeFromStr:(NSString *)str {
    if ([str isEqualToString:@"typeList"]) {
        return BFTypeList;
    }else if ([str isEqualToString:@"valiSafeCard"])
    {
        return BFValiSafeCard;
    }else if ([str isEqualToString:@"valiIdCard"])
    {
        return BFValiIdCard;
    }else if ([str isEqualToString:@"valiSafeQues"])
    {
        return BFValiSafeQuestion;
    }else if ([str isEqualToString:@"setPwd"])
    {
        return BFSetPwd;
    }else if ([str isEqualToString:@"valiMobile"])
    {
        return BFValiMobile;
    }
    else {
        return BFValiMobile;
    }
}

+ (void)jumpToTypeListWithParams:(NSDictionary *)params fromViewController:(UIViewController *)vc {
    NSString *sign = [USER_D objectForKey:@"initSign"];
    [MBProgressHUD showHUDAddedTo:vc.view animated:YES];
    [BFReqAPI reqTypeListOfFindPayPwdWithSign:sign block:^(id responseObj, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:vc.view animated:YES];
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                NSArray *obj = responseObj[@"obj"];
                BFFindPwdTypeListViewController *backPwdVC = [[BFFindPwdTypeListViewController alloc] init];
                backPwdVC.typeArray = obj;
                backPwdVC.mobile =params[@"bindMobile"];
                backPwdVC.other = params[@"other"];
                [vc.navigationController pushViewController:backPwdVC animated:YES];
            }else
            {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:nil];
            }
        }
    }];
}

+ (void)jumpToSafeCardWithParams:(NSDictionary *)params fromViewController:(UIViewController *)vc {
    BFFindPwdBySafeCardViewController *safeCardVc = [[BFFindPwdBySafeCardViewController alloc] init];
    safeCardVc.title = @"修改支付密码";
    safeCardVc.sign = params[@"sign"];
    safeCardVc.op = params[@"op"];
    safeCardVc.mobile = params[@"bindMobile"];
    safeCardVc.other = params[@"other"];
    [vc.navigationController pushViewController:safeCardVc animated:YES];
}

+ (void)jumpToValiIdCardWithParams:(NSDictionary *)params fromViewController:(UIViewController *)vc{
    BFFindPwdByIdCardViewController *idCardVc = [[BFFindPwdByIdCardViewController alloc] init];
    idCardVc.title = @"修改支付密码";
    idCardVc.sign = params[@"sign"];
    idCardVc.op = params[@"op"];
    idCardVc.mobile = params[@"bindMobile"];
    idCardVc.other = params[@"other"];
    [vc.navigationController pushViewController:idCardVc animated:YES];
}

+ (void)jumpToSafeQuestionWithParams:(NSDictionary *)params fromViewController:(UIViewController *)vc{
    BFFindPwdBySecurityQuestionController *safeQuestionVc = [[BFFindPwdBySecurityQuestionController alloc] init];
    safeQuestionVc.title = @"修改支付密码";
    safeQuestionVc.sign = params[@"sign"];
    safeQuestionVc.op = params[@"op"];
    safeQuestionVc.mobile = params[@"bindMobile"];
    safeQuestionVc.other = params[@"other"];
    [vc.navigationController pushViewController:safeQuestionVc animated:YES];
}

+ (void)jumpToSetPwdWithParams:(NSDictionary *)params fromViewController:(UIViewController *)vc{
    BFSettingNewPayPwdViewController *setPayPwdVc = [[BFSettingNewPayPwdViewController alloc] init];
    setPayPwdVc.sign = params[@"sign"];
    setPayPwdVc.op = params[@"op"];
    [vc.navigationController pushViewController:setPayPwdVc animated:YES];
}

+ (void)jumpToValiMobileWithParams:(NSDictionary *)params fromViewController:(UIViewController *)vc{
    BFValiMobileViewController *valiMobileVc = [[BFValiMobileViewController alloc] init];
    valiMobileVc.sign = params[@"sign"];
    valiMobileVc.op = params[@"op"];
    valiMobileVc.mobile = params[@"bindMobile"];
    valiMobileVc.other = params[@"other"];
    [vc.navigationController pushViewController:valiMobileVc animated:YES];

}
@end

//
//  BFAccountViewData.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/17.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFAccountViewData.h"
#import "BFRequestURLConfigHeader.h"
@implementation BFAccountViewData
+(BFAccountViewData*)sharedManager
{
    static BFAccountViewData*sharedSingleton = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        sharedSingleton = [[super allocWithZone:NULL] init];
    });
    return sharedSingleton;
}

+(instancetype)allocWithZone:(struct _NSZone *)zone
{
    return [self sharedManager];
}

+(NSArray*)getAccountList{
    return  @[@[
                  @{@"title":@"账户余额",@"imageName":@"account_balance",@"className":@"BFBalanceViewController"},
                  @{@"title":@"账单明细",@"imageName":@"account_bill",@"className":@"BFWebViewController"},
                  ],
              @[
                  @{@"title":@"我的红包",@"imageName":@"account_redbag",@"className":@"BFVouchersViewController"},
                  @{@"title":@"银行卡",@"imageName":@"account_bank_card",@"className":@"BFWebViewController"}
                ],
              @[
                  @{@"title":@"安全中心",@"imageName":@"account_secture_center",@"className":@"BFSecurityCenterController"}]
              ];

}
+(NSArray*)getBalanceList{
    return @[@{@"title":@"我要充值",@"imageName":@"account_cz",@"className":@"BFWebViewController",@"urlStr":[NSString stringWithFormat:@"%@%@",BFWalletBaseURL,myAccount_Recharge]}
            ,@{@"title":@"我要提现",@"imageName":@"account_tx",@"className":@"BFWebViewController",@"urlStr":[NSString stringWithFormat:@"%@%@",BFWalletBaseURL,myAccount_Withdraw]}];
}

@end

//
//  BFAccountViewCellModel.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/15.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BFAccountViewCellModel : NSObject
@property(nonatomic,copy)NSString*title;
@property(nonatomic,copy)NSString*imageName;
@property(nonatomic,copy)NSString*ViewController;
@end

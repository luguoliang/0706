//
//  BFAccountViewData.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/17.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface BFAccountViewData : NSObject
/*
 1、获取账户列表的数据
 2、获取账户余额的数据
 //
 */
+(NSArray*)getAccountList;
+(NSArray*)getBalanceList;
@end

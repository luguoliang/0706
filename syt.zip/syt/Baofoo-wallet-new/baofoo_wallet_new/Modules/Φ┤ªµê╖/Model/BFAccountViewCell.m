//
//  BFAccountViewCell.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/15.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFAccountViewCell.h"
@implementation BFAccountViewCell

- (void)awakeFromNib {
    // Initialization code
    self.textLabel.font = [UIFont systemFontOfSize:16.0f];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setModel:(BFAccountViewCellModel *)model{
    self.textLabel.text = model.title;
    self.imageView.image = [UIImage imageNamed:model.imageName];
}
@end

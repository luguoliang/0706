//
//  BFAccountViewCell.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/15.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BFAccountViewCellModel.h"
@class BFAccountViewCellModel;
@interface BFAccountViewCell : UITableViewCell
@property(nonatomic ,copy)BFAccountViewCellModel*model;
@end

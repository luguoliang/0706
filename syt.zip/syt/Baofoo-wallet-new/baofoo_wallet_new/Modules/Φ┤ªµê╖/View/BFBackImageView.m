//
//  BFBackImageView.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/15.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBackImageView.h"
#import "BFCoreDtaModelop.h"
#define HeadportraitHight  70
@interface BFBackImageView()
{
    UIImageView*_headerImage,*_imagev,*badgeImageView;
    UILabel*_accountNameLabel,*_detailLabel;
    UIButton*_notificationBtn,*_moreBtn;
    UIControl*_imageControl,*_detailControl,*_balanceControl;
}

@end

@implementation BFBackImageView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        NSNotificationCenter * center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(loginSucessful:) name:@"loginSucessful" object:nil];
        self.frame = frame;
        self.image = [UIImage createImageWithColor:[UIColor getCurrentAppSystemColor]];
        self.userInteractionEnabled = YES;
        self.contentMode = UIViewContentModeScaleAspectFill;
        
        {
            //消息
            
            UIButton *newsButton = [UIButton createWithFrame:CGRectMake(9, 23, 36, 36) target:self action:@selector(newsButtonClick:)];
            [newsButton setImage:[UIImage imageNamed:@"lobbyNews"] forState:UIControlStateNormal];
            [self addSubview:newsButton];
            
            //消息角标
            badgeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(9 + 16 + 6, 30, 8, 8)];
            badgeImageView.backgroundColor = [UIColor redColor];
            badgeImageView.layer.masksToBounds = YES;
            badgeImageView.layer.cornerRadius = 4;
            badgeImageView.layer.borderColor = [[UIColor whiteColor]CGColor];
            badgeImageView.layer.borderWidth = 1;
            badgeImageView.hidden = YES;
            [self addSubview:badgeImageView];
        }
        {
            _headerImage = [[UIImageView alloc] initWithFrame:CGRectMake((frame.size.width - HeadportraitHight)*0.5,(frame.size.height - HeadportraitHight)*0.5, HeadportraitHight, HeadportraitHight)];
            [self addSubview:_headerImage];
            _headerImage.image = [self getAccountImage];
            _headerImage.layer.masksToBounds = YES;
            _headerImage.layer.cornerRadius = HeadportraitHight/2;
            _headerImage.contentMode = UIViewContentModeScaleToFill;
            {
                _imageControl = [[UIControl alloc] initWithFrame:_headerImage.frame];
                [self addSubview:_imageControl];
                [_imageControl addTarget:self action:@selector(imageControl) forControlEvents:UIControlEventTouchUpInside];
            }
        }
        {
            _accountNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, (CGRectGetMaxY(_headerImage.frame)+12), frame.size.width, 30)];
            _accountNameLabel.textAlignment = NSTextAlignmentCenter;
            _accountNameLabel.textColor = [UIColor whiteColor];
            _accountNameLabel.font = [UIFont systemFontOfSize:18.0f];
            _accountNameLabel.text = [self getAccountName];
            [self addSubview:_accountNameLabel];
        }
        /*
        {
            _detailLabel =[[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_accountNameLabel.frame)-4, frame.size.width, 30)];
            _detailLabel.text = @"查看详情";
            _detailLabel.textAlignment = NSTextAlignmentCenter;
            _detailLabel.textColor = [UIColor whiteColor];
            _detailLabel.backgroundColor = [UIColor clearColor];
            _detailLabel.alpha = 0.6;
            _detailLabel.font = [UIFont systemFontOfSize:12];
            UIImageView*imagev = [[UIImageView alloc] initWithFrame:CGRectMake(frame.size.width/2+28, 11.8, 3.5, 6.5)];
            imagev.image = [UIImage imageNamed:@"account_detail"];
            [_detailLabel addSubview:imagev];
            [self addSubview:_detailLabel];
            {
                _detailControl = [[UIControl alloc] initWithFrame:_detailLabel.frame];
                [self addSubview:_detailControl];
                [_detailControl addTarget:self action:@selector(detailControl) forControlEvents:UIControlEventTouchUpInside];
             }
        }
         */
        {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.backgroundColor = [UIColor clearColor];
            button.titleLabel.font = [UIFont systemFontOfSize:14];
            [button setTitle:@"更多" forState:UIControlStateNormal];
            button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
            CGSize size = [BFStringTool sizeOfString:@"更多" Size:CGSizeMake(100.0, 44.0) Font:button.titleLabel.font];
            button.titleLabel.font = BF_Font_14;
            button.frame = CGRectMake(ScreenWidth-(size.width+30.0), 20, size.width+30.0, 44.0);
            [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            _moreBtn = button;
            [_moreBtn addTarget:self action:@selector(balanceControl) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:_moreBtn];

        }}
    return self;
}

//消息
- (void)newsButtonClick:(id)sender
{
    
}
-(NSString*)getAccountBalance{
    return [[[BFCoreDtaModelop alloc] init] getCurrentBFuserModel].memberName;
}
-(NSString*)getAccountName{
    return [BFCoreUserModel sharedInstance].memberName?[BFCoreUserModel sharedInstance].memberName:[BFCoreUserModel sharedInstance].mobile;
}
-(UIImage*)getAccountImage{
    if ([UIImage imageWithData:[[[BFCoreDtaModelop alloc] init] getCurrentBFuserModel].accountImage scale:1.0]) {
        return [UIImage imageWithData:[[[BFCoreDtaModelop alloc] init] getCurrentBFuserModel].accountImage scale:1.0];;
    }
    return [UIImage imageNamed:@"face_nor"];
}
-(void)imageControl{
    [_delegate clickedHeaderImage];
}
-(void)detailControl{
    [_delegate clickedDetailImage];
}
-(void)balanceControl{
    [_delegate clickedMoreImage];
}
-(void)loginSucessful:(id)sender{
    _accountNameLabel.text = [self getAccountName];
    _headerImage.image = [self getAccountImage];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end

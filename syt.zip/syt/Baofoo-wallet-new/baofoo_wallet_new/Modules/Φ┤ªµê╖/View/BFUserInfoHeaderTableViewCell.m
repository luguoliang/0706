//
//  BFUserInfoHeaderTableViewCell.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFUserInfoHeaderTableViewCell.h"
#import <SDWebImage/UIImageView+WebCache.h>
@implementation BFUserInfoHeaderTableViewCell

- (void)awakeFromNib {
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if(self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]){
        [self setUpSubView];
    }
    return self;
}
- (void)setUpSubView{
    UIView *bottomLine = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5f)];
    bottomLine.backgroundColor = COLOR_HEXSTRING(LINE_COLOR);
    [self addSubview:bottomLine];
    
    self.headerImage = [UIImageView createWithFrame:CGRectMake(ScreenWidth - 36-70*0.8, 70*0.1, 70*0.8, 70*0.8) image:nil];
    [self.headerImage setBackgroundColor:[UIColor clearColor]];
    [self.headerImage.layer setCornerRadius:(self.headerImage.frame.size.height/2)];
    [self.headerImage.layer setMasksToBounds:YES];
    [self.headerImage setContentMode:UIViewContentModeScaleAspectFill];
    [self.headerImage setClipsToBounds:YES];
    self.headerImage.layer.borderWidth = 0.3;
    self.headerImage.layer.borderColor = [BF_Color_TextDescription colorWithAlphaComponent:0.5].CGColor;
    UIImage *img = [UIImage imageWithData:[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].accountImage];
    if (img) {
        self.headerImage.image = img;
    }
    else {
        self.headerImage.image = [UIImage imageNamed:@"face_nor"];
    }
    [self addSubview:self.headerImage];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end

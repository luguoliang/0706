//
//  BFAccountTableHeaderView.h
//  baofoo
//
//  Created by zhoujun on 16/2/18.
//  Copyright © 2016年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol BFHeaderViewDelegate <NSObject>

@optional
-(void)clickedHeaderImage;
-(void)clickedMore;
-(void)clickedNewsCenter;
-(void)clickedLoginBtn;
@end
@interface BFHeaderView : UIView

@property(nonatomic,weak) id<BFHeaderViewDelegate>delegate;
//头像
@property (nonatomic , strong)UIImageView *userImageView;
//未登录的登录按钮
@property (nonatomic , strong)UIButton *loginOnButton;
//实名认证显示的姓名
@property (nonatomic , strong)UILabel        *nameLabel;
//账号实名非实名状态
@property (nonatomic , strong)UIButton       *phoneNumRankButton;

- (instancetype)initWithFrame:(CGRect)frame WithLogin:(BOOL)login;
- (void)addDataSource:(UIImage *)img;
- (void)clearData;

- (void)setBgviewFrame:(CGRect)frame;
@end

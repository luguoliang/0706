//
//  BFAccountTableHeaderView.m
//  baofoo
//
//  Created by zhoujun on 16/2/18.
//  Copyright © 2016年 baofoo. All rights reserved.
//

#import "BFHeaderView.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "BFAccountViewController.h"
@interface BFHeaderView ()
{
    UIImageView *badgeImageView;
    UIButton *_moreBtn;
    UIView *bgview;
}
@property (nonatomic) BOOL login;
@end
@implementation BFHeaderView
- (instancetype)initWithFrame:(CGRect)frame WithLogin:(BOOL)login{
    if(self = [super initWithFrame:frame]){
        _login = login;
        [self setLogin];
        
    }
    return self;
}

- (void)setBgviewFrame:(CGRect)frame {
    bgview.frame = frame;
}

- (void)setLogin{
    [self setBackgroundColor:[UIColor getCurrentAppSystemColor]];
    
    UIColor *bgColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"huawen"]];
    bgview = [[UIView alloc] initWithFrame:self.frame];
    [bgview setBackgroundColor:bgColor];
    [self addSubview:bgview];
    
    {
        //消息
        
        UIButton *newsButton = [UIButton createWithFrame:CGRectMake(9, 23, 36, 36) target:self action:@selector(jumpToNewsCenter)];
        [newsButton setImage:[UIImage imageNamed:@"lobbyNews"] forState:UIControlStateNormal];
        [self addSubview:newsButton];
        
        //消息角标
        badgeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(9 + 16 + 6, 30, 8, 8)];
        badgeImageView.backgroundColor = [UIColor redColor];
        badgeImageView.layer.masksToBounds = YES;
        badgeImageView.layer.cornerRadius = 4;
        badgeImageView.layer.borderColor = [[UIColor whiteColor]CGColor];
        badgeImageView.layer.borderWidth = 1;
        badgeImageView.hidden = YES;
        [self addSubview:badgeImageView];
    }
    {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.backgroundColor = [UIColor clearColor];
        button.titleLabel.font = [UIFont systemFontOfSize:14];
        [button setTitle:@"更多" forState:UIControlStateNormal];
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        CGSize size = [BFStringTool sizeOfString:@"更多" Size:CGSizeMake(100.0, 44.0) Font:button.titleLabel.font];
        button.titleLabel.font = BF_Font_14;
        button.frame = CGRectMake(ScreenWidth-(size.width+30.0), 20, size.width+30.0, 44.0);
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _moreBtn = button;
        [_moreBtn addTarget:self action:@selector(jumpToMore) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_moreBtn];
        
    }
    
    //230 120 2x
    UIImage *image = [[UIImage imageNamed:@"account_login"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];

    self.loginOnButton = [UIButton createWithFrame:CGRectMake(0,0, 105 , 44) target:self action:nil];
    self.loginOnButton.center = CGPointMake(ScreenWidth/2.0, (self.frame.size.height+20)/2);
    [self.loginOnButton setBackgroundImage:image forState:UIControlStateNormal];
    [self.loginOnButton setBackgroundImage:image forState:UIControlStateHighlighted];
    [self.loginOnButton setTitle:@"点击登录" forState:UIControlStateNormal];
    [self.loginOnButton setTitleColor:COLOR_HEXSTRING(@"555555") forState:UIControlStateNormal];
//    self.loginOnButton.backgroundColor = [UIColor colorWithPatternImage:image];

    self.userImageView = [UIImageView createWithFrame:CGRectMake(0, 0, 70, 70) image:nil];
    self.userImageView.center = CGPointMake(ScreenWidth/2.0, self.frame.size.height/2);
    self.userImageView.userInteractionEnabled = YES;
    [self.userImageView.layer setCornerRadius:(_userImageView.frame.size.height/2)];
    [self.userImageView.layer setMasksToBounds:YES];
    [self.userImageView setContentMode:UIViewContentModeScaleToFill];
    [self.userImageView setClipsToBounds:YES];
    self.userImageView.layer.borderWidth = 1;
    self.userImageView.layer.borderColor = [UIColor whiteColor].CGColor;
    
    self.nameLabel = [UILabel createWithFrame:CGRectMake(0, 0,ScreenWidth, 18) textColor:[UIColor whiteColor] font:BF_Font_16];
    self.nameLabel.center = CGPointMake(ScreenWidth/2.0, self.frame.size.height/2+34+12+8);
    self.nameLabel.textAlignment = NSTextAlignmentCenter;
    
    UITapGestureRecognizer *userClickTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(jumpToUserInfo)];
    [self.userImageView addGestureRecognizer:userClickTap];
    
    [self addSubview:self.userImageView];
    [self addSubview:self.nameLabel];
    [self addSubview:self.loginOnButton];
    
    [self.loginOnButton addTarget:self action:@selector(jumpToLogin) forControlEvents:UIControlEventTouchUpInside];
    
    if(_login){
        [self addDataSource:nil];
    }
    else{
        [self clearData];
    }
}

- (void)jumpToLogin{
    [_delegate clickedLoginBtn];
}
-(void)jumpToUserInfo{
    [_delegate clickedHeaderImage];
}
-(void)jumpToNewsCenter{
    [_delegate clickedNewsCenter];
}
-(void)jumpToMore{
    [_delegate clickedMore];
}


- (void)clearData{
    self.nameLabel.hidden = YES;
    self.userImageView.hidden = YES;
    self.loginOnButton.hidden = NO;
}
- (void)addDataSource:(UIImage *)img{
    
    if (![BFLoginTool loggedIn]) {
        //防止退出时，请求成功加载数据的情况
        [self clearData];
        return;
    };
    self.loginOnButton.hidden = YES;
    self.nameLabel.hidden = NO;
    self.userImageView.hidden = NO;
    //获取用户头像
    if (img) {
        self.userImageView.image = img;
    }
    else {
        self.userImageView.image = [self getAccountImage];
    }
    self.nameLabel.text = [self getAccountName];
}
-(NSString*)getAccountName{
    NSString *mName = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].memberName;
    return mName.length>0?[NSString stringWithFormat:@"*%@",[mName substringFromIndex:1]]:[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].mobile;
}
-(UIImage *)getAccountImage{
    if ([[[BFCoreDataModelop alloc] init] getCurrentBFuserModel].accountImage) {
        return [UIImage imageWithData:[[[BFCoreDataModelop alloc] init] getCurrentBFuserModel].accountImage scale:1.0];
    }
    else {
        return [UIImage imageNamed:@"face_nor"];
    }
}


@end

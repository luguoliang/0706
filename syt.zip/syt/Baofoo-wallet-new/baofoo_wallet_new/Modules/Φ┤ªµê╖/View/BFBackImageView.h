//
//  BFBackImageView.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/15.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AccountBackImageViewDelegate <NSObject>

@optional
-(void)clickedHeaderImage;
-(void)clickedDetailImage;
-(void)clickedMoreImage;

@end
@interface BFBackImageView : UIImageView
@property(nonatomic,weak) id<AccountBackImageViewDelegate>delegate;
@end

//
//  BFBalanceViewController.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/18.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBalanceViewController.h"
#import "BFWebViewController.h"
#import "BFAccountViewData.h"
#import "BFAccountViewCell.h"
#import "BFStringTool.h"
@interface BFBalanceViewController ()
{
    NSArray*_titleArray;
}
@end

@implementation BFBalanceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"账户余额";
    _titleArray = [BFAccountViewData getBalanceList];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    _balanceLabel.attributedText  = [self getBalance];
}
-(NSMutableAttributedString*)getBalance
{
    NSString*strdb = [[[BFCoreDataModelop alloc] init] getCurrentBFuserModel].balanceMoney;
    NSString*str = [NSString stringWithFormat:@"%@ 元",[[BFStringTool sharedManager] formatterStringWithString:strdb]];
    NSMutableAttributedString *AttributedStr = [[NSMutableAttributedString alloc]initWithString:str];
    [AttributedStr addAttribute:NSFontAttributeName
                          value:[UIFont systemFontOfSize:25.0f]
                          range:NSMakeRange((str.length - 2), 2)];
    
    return AttributedStr;
 }


#pragma mark - Table view data source
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
   return  _titleArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *myCell = @"BfCellIndifer";
    BFAccountViewCell*cell = [tableView dequeueReusableCellWithIdentifier:myCell];
    if (!cell) {
        cell = [[BFAccountViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:myCell];
    }
    BFAccountViewCellModel*model = [[BFAccountViewCellModel alloc] init];
    [model setValuesForKeysWithDictionary:_titleArray[indexPath.row]];
    cell.model = model;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self performSelector:@selector(deselect) withObject:nil afterDelay:0.1f];
    NSString*className = _titleArray[indexPath.row][@"className"];
    Class class = NSClassFromString(className);
    BFWebViewController*webView = [(BFWebViewController*)[class alloc] init];
    webView.urlStr = _titleArray[indexPath.row][@"urlStr"];
    [self.navigationController pushViewController:webView animated:YES];
}
- (void)deselect
{
    [self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

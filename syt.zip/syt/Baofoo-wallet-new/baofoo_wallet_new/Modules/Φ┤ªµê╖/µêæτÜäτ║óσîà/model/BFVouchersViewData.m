//
//  BFVouchersModel.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFVouchersViewData.h"
#import "BFVounchersViewModel.h"
@implementation BFVouchersViewData
+(NSArray*)getBFVouchersDataModelWithDict:(NSArray *)array{
    NSMutableArray*available = [NSMutableArray array];
    NSMutableArray*used = [NSMutableArray array];
    NSMutableArray*expired = [NSMutableArray array];
    for (NSDictionary*dict in array) {
        if ([[dict[@"status"] stringValue] isEqualToString:@"1"]) {//未使用
            [available addObject:[BFVounchersViewModel voucherWithDict:dict]];
        }
        else if ([[dict[@"status"] stringValue] isEqualToString:@"2"])//已使用
        {
            [used addObject:[BFVounchersViewModel voucherWithDict:dict]];
        }
        else if ([[dict[@"status"] stringValue] isEqualToString:@"0"])//过期
        {
            [expired addObject:[BFVounchersViewModel voucherWithDict:dict]];
        }
    }
    NSMutableArray*rearray = [NSMutableArray array];
    if (available.count) {
        [rearray addObject:available.copy];
    }
    if (used.count) {
        [rearray addObject:used.copy];
    }
    if (expired.count) {
        [rearray addObject:expired.copy];
    }
    return rearray.copy;
}
@end

//
//  MyVoucherModele2Cell.m
//  BaofooWallet
//
//  Created by 路国良 on 15/9/16.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import "BFVoucherView2Cell.h"
#import "BFVounchersViewModel.h"
@implementation BFVoucherView2Cell

- (void)awakeFromNib {
    
    self.iconImageView.layer.cornerRadius = 22.0f;
}

-(void)setModel:(BFVounchersViewModel *)model
{
    
    self.end_timeLabel.textColor = [UIColor colorWithHexString:@"a0a0a0" alpha:1.0];
    
     self.face_moneyLabel.textColor = [UIColor colorWithHexString:@"fe9949" alpha:1.0];
    
    self.face_moneyLabel.text = [NSString stringWithFormat:@"%@元",model.face_money];
    
    self.end_timeLabel.text = [NSString stringWithFormat:@"%@-%@",model.start_time,model.end_time];

    self.nameLabel.text = model.voucher_name;
    
    self.iconImageView.image = [UIImage imageNamed:@"vocherCoupons.png"];
    
    self.conditionLabel.text  = model.filed1;
    
    self.field2.text =          model.filed2;
    
    NSString*str3 = model.remark;
    
    if (!([str3 isKindOfClass:[NSNull class]])) {
        
        self.conditionLabel2.text = model.remark;
        
        self.conditionLabel2.textColor = [UIColor colorWithHexString:@"fe9949" alpha:1.0];
    }
    
    if ([model.status isEqualToString:@"2"]) {

        self.end_timeLabel.font = [UIFont systemFontOfSize:10.0f];

        self.end_timeLabel.layer.masksToBounds = YES;

    }
    
    if ([model.status isEqualToString:@"0"]) {
        
        self.iconImageView.image = [UIImage imageNamed:@"vocherCoupons_used.png"];

        self.end_timeLabel.font = [UIFont systemFontOfSize:10.0f];
        
        self.end_timeLabel.layer.masksToBounds = YES;
}

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

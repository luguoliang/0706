//
//  MyVoucherModele2Cell.h
//  BaofooWallet
//
//  Created by 路国良 on 15/9/16.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BFVounchersViewModel;

@interface BFVoucherView2Cell : UITableViewCell

@property(nonatomic,strong  )BFVounchersViewModel*model;

@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@property (weak, nonatomic) IBOutlet UILabel *face_moneyLabel;

@property (weak, nonatomic) IBOutlet UILabel *end_timeLabel;

@property (weak, nonatomic) IBOutlet UILabel *conditionLabel;

@property (weak, nonatomic) IBOutlet UILabel *field2;

@property (weak, nonatomic) IBOutlet UILabel *conditionLabel2;

@end

//
//  MyVoucherCouponsCell.m
//  MyVoucherVoucher
//
//  Created by 路国良 on 15/5/12.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "BFVoucherViewCell.h"
#import "BFVounchersViewModel.h"

@implementation BFVoucherViewCell

- (void)awakeFromNib {
    
    self.iconImageView.layer.cornerRadius = 22.0f;
}

-(void)setModel:(BFVounchersViewModel *)model
{
    self.face_moneyLabel.text = [NSString stringWithFormat:@"%@元",model.face_money];
    
    self.end_timeLabel.text = [NSString stringWithFormat:@"%@-%@",model.start_time,model.end_time];
    
    self.nameLabel.text = model.voucher_name;
    
    self.iconImageView.image = [UIImage imageNamed:@"vocherCoupons.png"];
    
    self.conditionLabel.text  = model.filed1;
    
    self.field2.text =          model.filed2;
    
    self.end_timeLabel.textColor = [UIColor colorWithHexString:@"a0a0a0" alpha:1.0];
    
    self.face_moneyLabel.textColor = [UIColor colorWithHexString:@"fe9949" alpha:1.0];

}
@end

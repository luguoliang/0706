//
//  BFVounchersViewModel.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BFVounchersViewModel : NSObject
@property(nonatomic,copy)NSString*status;
@property(nonatomic,copy)NSString*face_money;
@property(nonatomic,copy)NSString*end_time;
@property(nonatomic,copy)NSString*use_rule;
@property(nonatomic,copy)NSString*voucher_name;
@property(nonatomic,copy)NSString*start_time;
@property(nonatomic,copy)NSString*use_type;
@property(nonatomic,copy)NSString*filed1;
@property(nonatomic,copy)NSString*filed2;
@property(nonatomic,copy)NSString*isavailable;
@property(nonatomic,copy)NSString*remark;
@property(nonatomic,copy)NSString*sectionTitle;
-(id)initWithDict:(NSDictionary*)dict;
+(id)voucherWithDict:(NSDictionary*)dict;
@end

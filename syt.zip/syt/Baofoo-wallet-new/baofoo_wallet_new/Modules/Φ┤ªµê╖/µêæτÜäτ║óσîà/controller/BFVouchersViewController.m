//
//  BFVouchersViewController.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFVouchersViewController.h"
#import "BFRequestURLConfigHeader.h"
#import "BFWebViewController.h"
#import "BFReqAPI+RedWallet.h"
#import "BFVouchersViewData.h"
#import "BFVounchersViewModel.h"
#import "BFVoucherViewCell.h"
#import "BFVoucherView2Cell.h"
#import "BFVouchersViewController.h"
@interface BFVouchersViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSArray*_titleArray;
    UIView*_backView;
}

@end

@implementation BFVouchersViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self requestCellList];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的红包";
    [self loadBackView];
    // Do any additional setup after loading the view from its nib.
}

-(void)requestCellList{
    [BFReqAPI getAccountRedWalletListCellModelFromServerWithParameters:@{} block:^(id responseObj, NSError *error) {
        if (!error) {
            
            if (![BFTool isEmptyArray:responseObj[@"obj"]]) {
                NSArray*array = responseObj[@"obj"];
                _backView.hidden = YES;
                _titleArray = [BFVouchersViewData getBFVouchersDataModelWithDict:array];
                [self.tableView reloadData];
            }
            else{
                _backView.hidden = NO;
            }
        }
        else{
            
        }
    }];

}
#pragma mark - UITabelViewDelegate,datasources
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (_titleArray.count) {
        return [_titleArray[section] count];
    }
    else
        return 0;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (_titleArray.count) {
        return _titleArray.count;
    }
    else
        return 0;
}
-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
      if (_titleArray.count) {
        BFVounchersViewModel*model = [_titleArray[section] lastObject];
        return model.sectionTitle;
    }
    else
        return nil;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 30;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 90;
}
// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    BFVoucherViewCell*cell1 = [[[NSBundle mainBundle] loadNibNamed:@"BFVoucherViewCell" owner:nil options:nil] lastObject];
    BFVoucherView2Cell*cell2 = [[[NSBundle mainBundle] loadNibNamed:@"BFVoucherView2Cell" owner:nil options:nil] lastObject];
    UITableViewCell*cell = nil;
    BFVounchersViewModel*model = _titleArray[indexPath.section][indexPath.row];
    if ([model.sectionTitle isEqualToString:@"未使用"]) {
        cell1.model = model;
        cell = cell1;
    }
    else{
        cell2.model = model;
        cell = cell2;
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self deselect];
}

- (void)deselect
{
    [self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}

-(void)loadBackView{
    _backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height-64.0f)];
    _backView.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    _backView.userInteractionEnabled = YES;
    
    UIImage *image = [UIImage imageNamed:@"red_nopackage.png"];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
    imageView.frame = CGRectMake((_backView.frame.size.width-image.size.width)*0.5, (_backView.frame.size.height-image.size.height)*0.5-30.0f, image.size.width, image.size.height);
    [_backView addSubview:imageView];
    
//    CGFloat labelHeight = [UILabel height:@"还没有红包哦~" widthOfFatherView:_backView.frame.size.height textFont:FONT(13.0f)];
    
    UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, imageView.frame.origin.y+imageView.frame.size.height, _backView.frame.size.width, 30)];
    label1.font = [UIFont systemFontOfSize:13.0f];
    label1.text = @"还没有红包哦~";
    label1.textColor = COLOR_HEXSTRING(BLANK_FONT_COLOR);
    label1.textAlignment = NSTextAlignmentCenter;
    [_backView addSubview:label1];
    
    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, label1.frame.origin.y+label1.frame.size.height+5.0f, _backView.frame.size.width, 30)];
    label2.font = [UIFont systemFontOfSize:13.0f];
    label2.text = @"去获取~";
    label2.textColor = COLOR_HEXSTRING(BLUE_COLOR);
    label2.textAlignment = NSTextAlignmentCenter;
    [_backView addSubview:label2];
    
    UITapGestureRecognizer *recongizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(inviteMethod)];
    recongizer.numberOfTapsRequired = 1;
    recongizer.numberOfTouchesRequired = 1;
    [_backView addGestureRecognizer:recongizer];
    _backView.hidden  = YES;
    [self.tableView addSubview:_backView];
}
-(void)inviteMethod{
    BFWebViewController*web = [[BFWebViewController alloc] init];
    web.urlStr = [NSString stringWithFormat:@"%@%@",BFWalletBaseURL,activity_activitycenter];
    [self.navigationController pushViewController:web animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  BFVounchersViewModel.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFVounchersViewModel.h"

@implementation BFVounchersViewModel
//-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
//}
//-(void)setValue:(id)value forKey:(NSString *)key{
//    if ([key isEqualToString:@"status"]) {
//        
//    }
//}
-(id)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.status = [dict[@"status"] stringValue];
        self.face_money = [dict[@"face_money"] stringValue];
        self.end_time = dict[@"end_time"];
        self.use_rule = dict[@"use_rule"];
        self.voucher_name = dict[@"voucher_name"];
        self.start_time = dict[@"start_time"];
        if (!([dict[@"voucherUseDtos"][0][@"filed1"] isKindOfClass:[NSNull class]])) {
            self.filed1 =     dict[@"voucherUseDtos"][0][@"filed1"];
        }
        else
        {
            self.remark = @"";
        }
        if (!([dict[@"voucherUseDtos"][0][@"filed2"] isKindOfClass:[NSNull class]])) {
            self.filed2 =     dict[@"voucherUseDtos"][0][@"filed2"];
        }
        else
        {
            self.remark = @"";
        }
        if (!([dict[@"remark"] isKindOfClass:[NSNull class]])) {
            self.remark =     dict[@"remark"];
        }
        else
        {
            self.remark = @"";
        }
        if ([[dict[@"status"] stringValue] isEqualToString:@"1"]) {
            self.sectionTitle = @"未使用";
        }
        if ([[dict[@"status"] stringValue] isEqualToString:@"2"]) {
            self.sectionTitle = @"已使用";
        }
        if ([[dict[@"status"] stringValue] isEqualToString:@"0"]) {
            self.sectionTitle = @"已过期";
        }
    }
    return self;
}
-(NSDictionary*)JsonParsing:(NSString*)jsonDescStr
{
    NSData *data = [jsonDescStr dataUsingEncoding:NSUTF8StringEncoding];
    
    NSArray*array = [NSJSONSerialization JSONObjectWithData:data options:(NSJSONReadingMutableLeaves) error:nil];
    
    return [array lastObject];
}
+(id)voucherWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

@end

//
//  SwAccountViewCell.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/31.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BFSwAccountViewModel.h"
@interface BFSwAccountViewCell : UITableViewCell
@property(nonatomic,copy)BFSwAccountViewModel*model;
@property (weak, nonatomic) IBOutlet UIImageView *accountImage;
@property (weak, nonatomic) IBOutlet UILabel *accountName;
@property (strong, nonatomic) UIView *markView;
@end

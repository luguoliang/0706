//
//  SwAccountViewCell.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/31.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFSwAccountViewCell.h"

@implementation BFSwAccountViewCell

- (void)awakeFromNib {
    // Initialization code
    self.accountImage.layer.cornerRadius = 20;
    [self.accountImage.layer setMasksToBounds:YES];
    [self.accountImage setContentMode:UIViewContentModeScaleAspectFill];
    [self.accountImage setClipsToBounds:YES];
    self.accountImage.layer.borderWidth = 0.3;
    self.accountImage.layer.borderColor = [BF_Color_TextDescription colorWithAlphaComponent:0.5].CGColor;
}
-(void)setModel:(BFSwAccountViewModel *)model{
    self.accountImage.image = model.accountImage;
    
    NSString *accName = model.accountName?[NSString stringWithFormat:@"%@****%@",[model.accountName substringToIndex:3],[model.accountName substringFromIndex:7]]:@"";
    
    self.accountName.text = accName;
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"memberId"] isEqualToString:model.memberId]) {
        _markView = [[UIView alloc] initWithFrame:CGRectMake(ScreenWidth - 30, 20, 10, 10)];
        [_markView.layer setCornerRadius:5];
        [_markView.layer setMasksToBounds:YES];
        _markView.layer.backgroundColor = [UIColor greenColor].CGColor;
        [self addSubview:_markView];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    _markView.layer.backgroundColor = [UIColor greenColor].CGColor;
    // Configure the view for the selected state
}
- (void)setHighlighted:(BOOL)highlighted animated:(BOOL)animated{
    [super setHighlighted:highlighted animated:animated];
    _markView.layer.backgroundColor = [UIColor greenColor].CGColor;
}

@end

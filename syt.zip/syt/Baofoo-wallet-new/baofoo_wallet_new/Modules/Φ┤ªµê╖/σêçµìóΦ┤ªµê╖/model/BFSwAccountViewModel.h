//
//  SwAccountViewModel.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/31.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BFSwAccountViewModel : NSObject
@property(nonatomic,copy)NSString*access_token;
@property(nonatomic,copy)UIImage*accountImage;
@property(nonatomic,copy)NSString*accountName;
@property(nonatomic,copy)NSString*memberId;
@property(nonatomic,copy)NSString*memberName;
@end

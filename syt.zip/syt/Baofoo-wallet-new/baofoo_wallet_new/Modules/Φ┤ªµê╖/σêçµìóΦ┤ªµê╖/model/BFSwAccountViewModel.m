//
//  SwAccountViewModel.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/31.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFSwAccountViewModel.h"

@implementation BFSwAccountViewModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{
}
@end

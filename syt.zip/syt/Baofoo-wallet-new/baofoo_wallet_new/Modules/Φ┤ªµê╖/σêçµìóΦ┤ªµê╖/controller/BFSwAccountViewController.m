//
//  SwAccountViewController.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/31.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFSwAccountViewController.h"
#import "BFCoreDataModelop.h"
#import "BFSwAccountViewCell.h"
#import "BFSwAccountViewModel.h"
#import "BFLoginTool.h"
#import "BFLoginViewController.h"
#import "BFReqAPI+Login.h"
@interface BFSwAccountViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray*_titleArray;
}

@end

@implementation BFSwAccountViewController
- (instancetype)init
{
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginSucessful:) name:LoginNotificationSuccess object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(headImageRefresh:) name:LoginNotificationHeadImageDownloadSuccess object:nil];
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"切换账户";
    
    BFCoreDataModelop*op = [[BFCoreDataModelop alloc] init];
    _titleArray = [op getAllBFuserCooks].mutableCopy;
}

- (void)refreshDataSource {
    BFCoreDataModelop*op = [[BFCoreDataModelop alloc] init];
    [_titleArray removeAllObjects];
    _titleArray = [op getAllBFuserCooks].mutableCopy;
    [_tableView reloadData];
}
#pragma mark - UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 40;
    }
    else{
        return 0.01;
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        if ([_titleArray count]) {
            return _titleArray.count;
        }
        else {
            return 0;
        }
    }
    else{
        return 1;
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        UILabel *headLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth/2, 40)];
        headLabel.text = @"   宝付账户";
        headLabel.textAlignment = NSTextAlignmentLeft;
        [headLabel setFont:BF_Font_15];
        [headLabel setTextColor:BF_Color_TextDescription];
        return headLabel;
    }
    else{
        return nil;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        BFSwAccountViewCell*cell = [[[NSBundle mainBundle] loadNibNamed:@"BFSwAccountViewCell" owner:nil options:nil] lastObject];
        BFSwAccountViewModel*model = [[BFSwAccountViewModel alloc] init];
        [model setValuesForKeysWithDictionary:_titleArray[indexPath.row]];
        cell.model = model;
        return cell;
    }
    else{
        UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        cell.textLabel.font = [UIFont systemFontOfSize:15.0f];
        cell.textLabel.text = @"添加账户";
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        return cell;
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self deselect];
    if (indexPath.section == 0) {
        if (![_titleArray[indexPath.row][@"memberId"] isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"memberId"]]) {
            __weakself__
            [self showProgress];
            [BFReqAPI reqLoginByToken:_titleArray[indexPath.row][@"access_token"] block:^(id responseObj, NSError *error) {
                [weakself hideProgress];
                if (!weakself) return ;
                if ([responseObj[@"success"] boolValue]) {
                    [BFLoginTool loginSuccessActionWith:responseObj andViewController:weakself isForExchangeAccount:YES isForRegister:NO];
                }
                else{
                    [BFLoginTool toLoginWithAccountName:_titleArray[indexPath.row][@"accountName"]];
                }
            }];
        }
    }
    else{
        [BFLoginTool toLoginWithAccountName:@"1"];
    }
    
}

- (void)deselect
{
    [self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    [tableView setEditing:YES animated:YES];
    return UITableViewCellEditingStyleDelete;
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (!(_titleArray.count == 0)) {
        if (![_titleArray[indexPath.row][@"memberId"] isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"memberId"]]) {
            [[BFCoreDataModelop sharedManager] delegateUserWithName:_titleArray[indexPath.row][@"memberId"]];
            [_titleArray removeObjectAtIndex:indexPath.row];
        }
        else{
            [BFLoginTool logoutAndClernSqlData];
            [self.navigationController popToRootViewControllerAnimated:YES];
//            [self performSelector:@selector(gotoLogin) withObject:nil afterDelay:1];
        }
    }
    NSLog(@"_titleArray = %@",_titleArray);
    [self.tableView reloadData];
    [tableView setEditing:NO animated:YES];
}
- (void)gotoLogin {
    [BFLoginTool toLoginWithAccountName:nil];
}
-(NSString*)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    return @"删除";
}

-(void)loginSucessful:(id)sender{
    [self refreshDataSource];
}
- (void)headImageRefresh:(NSNotification *)sender {
    [self refreshDataSource];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

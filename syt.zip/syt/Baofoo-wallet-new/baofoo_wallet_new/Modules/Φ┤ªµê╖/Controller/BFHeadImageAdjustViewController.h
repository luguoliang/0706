//
//  BFHeadImageAdjustViewController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"
@class BFHeadImageAdjustViewController;

@protocol BFHeadImageAdjustViewControllerDelegate <NSObject>

- (void)headImgAdjust:(BFHeadImageAdjustViewController *)controller didFinished:(UIImage *)editedImage;

@end

@interface BFHeadImageAdjustViewController : BFBaseViewController

@property (nonatomic, assign) NSInteger tag;
@property (nonatomic, assign) id<BFHeadImageAdjustViewControllerDelegate> delegate;
@property (nonatomic, assign) CGRect clipFrame;

- (instancetype)initWithImage:(UIImage *)originalImage;

@end

//
//  moreViewController.m
//  system_test_demo_baofoo
//
//  Created by zhouwufeng on 16/4/26.
//  Copyright © 2016年 baofoo.com. All rights reserved.
//

#import "moreViewController.h"
#import "BaseMethodModel.h"
#import "UITableView+BFUIKit.h"
#import "UIView+BFUIKit.h"
#import "UILabel+BFUIKit.h"
#import "UIImageView+BFUIKit.h"
#import "BFUIKit.h"
#import "BFAccountViewController.h"
#import "BFWebViewController.h"
#import "BFShareRecommendViewController.h"

@interface moreViewController ()<UITableViewDelegate, UITableViewDataSource,UIAlertViewDelegate>

@property (nonatomic, strong) NSMutableArray *cellTitleArray;

@end

@implementation moreViewController

#pragma mark - Life Cycle

- (void)viewDidLoad{
    [super viewDidLoad];
    self.navigationItem.title = @"更多";
  
    [self drawUI];
}


#pragma mark - Lazy Loading

- (NSMutableArray *)cellTitleArray{
    if (_cellTitleArray == nil) {
        _cellTitleArray = [[NSMutableArray alloc] init];
        [_cellTitleArray addObject:@[[BaseMethodModel createWithName:@"分享与推荐" selector:@selector(jumpToShareRecommend)]]];
        [_cellTitleArray addObject:@[[BaseMethodModel createWithName:@"帮助中心" selector:@selector(jumpToHelpCenter)]]];
        [_cellTitleArray addObject:@[[BaseMethodModel createWithName:@"用户反馈" selector:@selector(jumpToUserBack)]]];
        [_cellTitleArray addObject:@[[BaseMethodModel createWithName:@"安全退出" selector:@selector(clickLogoutBtn)]]];
    }
    return _cellTitleArray;
}

#pragma mark - UI

- (void)drawUI{
    //
    UITableView *tableView = [UITableView createPlainTableWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-64) delegate:self datasource:self];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:tableView];
    
    UIView *headerView = [UIView createWithFrame:CGRectMake(0, 0, ScreenWidth, 200.0)];
    
    UIImageView *img = [UIImageView createWithFrame:CGRectMake(0, 34, 65, 65) image:[UIImage imageNamed:@"logo-2"]];
    img.center_X = ScreenWidth/2;
    [headerView addSubview:img];
    
    UILabel *versionLabel = [UILabel createWithFrame:CGRectMake(0, 110, 100, 20) textColor:[UIColor colorWithRed:54/255.0f green:54/255.0f blue:54/255.0f alpha:1.0] font:BF_Font_12];
    versionLabel.text = [NSString stringWithFormat:@"版本号: V%@", @"4.0"];
    versionLabel.center_X = ScreenWidth/2;
    versionLabel.textAlignment = NSTextAlignmentCenter;
    [headerView addSubview:versionLabel];
    
    UILabel *descreptionLabel = [UILabel createWithFrame:CGRectMake(0, 140, ScreenWidth-30, 60) textColor:[UIColor colorWithRed:178/255.0f green:178/255.0f blue:178/255.0f alpha:1.0] font:BF_Font_13];
    descreptionLabel.numberOfLines = 0;
    descreptionLabel.text = @"宝付作为国内领先的第三方支付公司，在一站式解决方案、行业解决方案、增值服务等领域具有丰富的运营经验，为个人及各类企业提供简单、方便、安全的综合电子支付服务。";
    descreptionLabel.textAlignment = NSTextAlignmentLeft;
    descreptionLabel.center_X = ScreenWidth/2;
    [headerView addSubview:descreptionLabel];
    
    tableView.tableHeaderView = headerView;
}

#pragma mark - UITableViewDataSource & Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.cellTitleArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSArray *array = self.cellTitleArray[section];
    return array.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellidentifier = @"cellidentfier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellidentifier];
    if (cell == nil) {
        if (indexPath.section ==3) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellidentifier];
        }else{
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellidentifier];
        }
    }
    //Configure Cell
    NSArray *array = self.cellTitleArray[indexPath.section];
    BaseMethodModel *model = array[indexPath.row];
    cell.textLabel.text = model.name;
    cell.textLabel.font = BF_Font_15;
    
    //划线
    {
        if (indexPath.row ==0) {
            UIView *topLine = UILineDefaultCreate(0, 0, ScreenWidth);
            [cell addSubview:topLine];
            UIView *bottomLine = UILineDefaultCreate(0, 43.5, ScreenWidth);
            [cell addSubview:bottomLine];
        }
        else {
            UIView *bottomLine = UILineDefaultCreate(0, 43.5, ScreenWidth);
            [cell addSubview:bottomLine];
        }
    }
    
    if (indexPath.section == 3) {
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.textLabel.textColor = [UIColor colorWithRed:255/255.0f green:45/255.0f blue:85/255.0f alpha:1];
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    else {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10.0f;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return [[UIView alloc] initWithFrame:CGRectZero];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSArray *array = self.cellTitleArray[indexPath.section];
    BaseMethodModel *model = array[indexPath.row];
    [self performSelector:model.method withObject:nil afterDelay:0.0];
}

#pragma mark - Button Action

- (void)clickLogoutBtn{
    UIAlertView *alertLogout = [[UIAlertView alloc] initWithTitle:@"宝付" message:@"确认要退出当前账户吗？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确认", nil];
    [alertLogout show];
}

- (void)tagsAliasCallback:(int)iResCode tags:(NSSet*)tags alias:(NSString*)alias {
    NSLog(@"rescode: %d, \ntags: %@, \nalias: %@\n", iResCode, tags , alias);
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        [self logoutAction];
    }
}

- (void)logoutAction {
    [BFLoginTool logout];
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Jump

- (void)jumpToUserBack{
    
}

- (void)jumpToShareRecommend{
    BFShareRecommendViewController *shareVc = [[BFShareRecommendViewController alloc] init];
    [self.navigationController pushViewController:shareVc animated:YES];
}

- (void)jumpToHelpCenter{
    BFWebViewController *helpVc = [[BFWebViewController alloc] init];
    helpVc.natitle = @"帮助中心";
    helpVc.urlStr = [NSString stringWithFormat:@"%@article_help_center.html",BFWalletBaseURL];
    [self.navigationController pushViewController:helpVc animated:YES];
}


@end

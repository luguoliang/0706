//
//  RealNameViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "RealNameViewController.h"
#import "ExamplePhotoViewController.h"
#import "BFWebViewController.h"
#import <AVFoundation/AVFoundation.h>

//Tool
#import "BFReqAPI+Account.h"
#import "WBLinkTextView.h"

@interface RealNameViewController ()<UITableViewDelegate,UITableViewDataSource,ExamplePhotoViewDelegate>
@property(nonatomic,strong)UIView *realNameHeaderView;
@property(nonatomic,strong)UITableView *realNameTableView;
@property(nonatomic,strong)WBLinkTextView *linkedTextView;
@property(nonatomic,strong)UIButton *takePhotoBtn;
@property(nonatomic,strong)NSArray *photoArr;//照片数组
@end

@implementation RealNameViewController
- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"实名认证";
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    [self.view addSubview:self.realNameTableView];
}
#pragma mark--CreatUI
- (WBLinkTextView *)linkedTextView
{
    if (!_linkedTextView) {
        NSString *string = nil;
        NSString  *stringToLink = nil;
        _linkedTextView = [[WBLinkTextView alloc] initWithFrame:CGRectMake(10.0f, 3.5f, ScreenWidth-20.0f, 30.0f)];
        _linkedTextView.font = FONT(12.0f);
        _linkedTextView.textColor = COLOR_HEXSTRING(@"#b5b5b5");
        if (self.realNameStyle == RealNamePrimaryPeopleStyle||self.realNameStyle == RealNamePrimaryMoneyStyle) {
            string = @"上传真人手持证件照，申请高级实人认证，提高限额 ";
            _linkedTextView.text = string;
            NSArray *arrayOfStrings = @[@"真人手持证件照",@"限额"];
            [_linkedTextView linkStrings:arrayOfStrings
                       defaultAttributes:[@{NSForegroundColorAttributeName:COLOR_HEXSTRING(ORANGE_COLOR)}mutableCopy]
                   highlightedAttributes:[@{NSForegroundColorAttributeName:COLOR_HEXSTRING(ORANGE_COLOR)}mutableCopy]
                              tapHandler:[self exampleHandlerWithTitle:@"Link an array of strings"]];
        }else if (self.realNameStyle == RealNameHignPeopleExamineNoPassStyle||self.realNameStyle == RealNameHighMoneyExamineNoPassStyle)
        {
            string = @"抱歉，证件照不清晰审核未通过，请按照示例重新上传 ";
            _linkedTextView.text = string;
            stringToLink = @"示例";
            [_linkedTextView linkString:stringToLink
                      defaultAttributes:[@{NSForegroundColorAttributeName:COLOR_HEXSTRING(ORANGE_COLOR)}mutableCopy]
                  highlightedAttributes:[@{NSForegroundColorAttributeName:COLOR_HEXSTRING(ORANGE_COLOR)}mutableCopy]
                             tapHandler:[self exampleHandlerWithTitle:@"Link a single string"]];
        }else if (self.realNameStyle == RealNameHighPeopleExamineStyle||self.realNameStyle == RealNameHighMoneyExamineStyle)
        {
            string = @"预计2个工作日内完成审核 ";
            _linkedTextView.text = string;
        }else if (self.realNameStyle == RealNameHignPeopleStyle)
        {
            string = @"购买理财产品，将自动开通理财账户 ";
            stringToLink = @"理财账户";
            _linkedTextView.text = string;
            [_linkedTextView linkString:stringToLink
                      defaultAttributes:[@{NSForegroundColorAttributeName:COLOR_HEXSTRING(ORANGE_COLOR)}mutableCopy]
                  highlightedAttributes:[@{NSForegroundColorAttributeName:COLOR_HEXSTRING(ORANGE_COLOR)}mutableCopy]
                             tapHandler:[self exampleHandlerWithTitle:@"Link a single string"]];
        }else if (self.realNameStyle == RealNameHighMoneyStyle)
        {
            string = @"账户等级及限额 ";
            stringToLink = @"账户等级及限额";
            _linkedTextView.text = string;
            [_linkedTextView linkString:stringToLink
                      defaultAttributes:[@{NSForegroundColorAttributeName:COLOR_HEXSTRING(ORANGE_COLOR)}mutableCopy]
                  highlightedAttributes:[@{NSForegroundColorAttributeName:COLOR_HEXSTRING(ORANGE_COLOR)}mutableCopy]
                             tapHandler:[self exampleHandlerWithTitle:@"Link a single string"]];
            
        }
        
    }
    return _linkedTextView;
}

- (UIButton *)takePhotoBtn
{
    if (!_takePhotoBtn) {
        _takePhotoBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        _takePhotoBtn.frame = CGRectMake(15.0f, 35.0f, ScreenWidth-30.0f, 40);
        _takePhotoBtn.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _takePhotoBtn.layer.cornerRadius = 20.0f;
        [_takePhotoBtn setTitle:@"拍摄证件照" forState:UIControlStateNormal];
        [_takePhotoBtn setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f] forState:UIControlStateNormal];
        _takePhotoBtn.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [_takePhotoBtn addTarget:self action:@selector(takePhotoMethod) forControlEvents:UIControlEventTouchUpInside];
    }
    return _takePhotoBtn;
}
- (UIView *)realNameHeaderView
{
    if (!_realNameHeaderView) {
        _realNameHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 160.0f)];
        _realNameHeaderView.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        UIImage *realImage = nil;
        NSString *realString = nil;
        if (self.realNameStyle == RealNamePrimaryPeopleStyle||self.realNameStyle == RealNameHighPeopleExamineStyle||self.realNameStyle == RealNameHignPeopleExamineNoPassStyle) {
            realImage = [UIImage imageNamed:@"primary_people"];
            realString = @"您已通过初级实名认证";
        }else if (self.realNameStyle == RealNameHignPeopleStyle)
        {
            realImage = [UIImage imageNamed:@"high_people"];
            realString = @"您已通过高级实人认证";
        }else if (self.realNameStyle == RealNamePrimaryMoneyStyle||self.realNameStyle == RealNameHighMoneyExamineNoPassStyle||self.realNameStyle == RealNameHighMoneyExamineStyle)
        {
            realImage = [UIImage imageNamed:@"primary_money"];
            realString = @"恭喜，您已开通初级理财账户啦";
        }else if (self.realNameStyle == RealNameHighMoneyStyle)
        {
            realImage = [UIImage imageNamed:@"high_money"];
            realString = @"恭喜，您已开通高级理财账户啦";
        }
        
        UILabel *line = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 0.5f)];
        line.backgroundColor = COLOR_HEXSTRING(@"#2785cb");
        [_realNameHeaderView addSubview:line];
        
        UIImageView *realImageView = [[UIImageView alloc] initWithFrame:CGRectMake((ScreenWidth - realImage.size.width)*0.5, 15.0f, realImage.size.width, realImage.size.height)];
        realImageView.image = realImage;
        [_realNameHeaderView addSubview:realImageView];
        
        UILabel *realLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, realImageView.frame.origin.y+realImageView.frame.size.height+10.0f, ScreenWidth, 12.0f)];
        realLabel.textAlignment = NSTextAlignmentCenter;
        realLabel.font = FONT(12.0f);
        realLabel.text = realString;
        realLabel.textColor = [UIColor whiteColor];
        [_realNameHeaderView addSubview:realLabel];
    }
    return _realNameHeaderView;
}
- (UITableView *)realNameTableView
{
    if (!_realNameTableView) {
        _realNameTableView = [[UITableView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, ScreenHeight-64.0) style:UITableViewStyleGrouped];
        _realNameTableView.delegate = self;
        _realNameTableView.dataSource = self;
        _realNameTableView.scrollEnabled = NO;
        _realNameTableView.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
        _realNameTableView.tableHeaderView = self.realNameHeaderView;
    }
    return _realNameTableView;
}
#pragma mark--方法
- (void)backMethod
{
    [self.navigationController popViewControllerAnimated:YES];
    
}
//关键字点击
- (LinkedStringTapHandler)exampleHandlerWithTitle:(NSString *)title
{
    LinkedStringTapHandler exampleHandler = ^(NSString *linkedString) {
        
        if ([linkedString isEqualToString:@"真人手持证件照"]||[linkedString isEqualToString:@"示例"]) {
            NSLog(@"上传真人手持证件照");
            ExamplePhotoViewController *exampleVC = [[ExamplePhotoViewController alloc] init];
            exampleVC.exampleStyle = ExamplePhotoSampleStyle;
            [self.navigationController pushViewController:exampleVC animated:YES];
        }else if ([linkedString isEqualToString:@"限额"]||[linkedString isEqualToString:@"账户等级及限额"]||[linkedString isEqualToString:@"理财账户"])
        {
            NSLog(@"限额");
            BFWebViewController *quotaView  = [[BFWebViewController alloc] init];
            quotaView.urlStr = [NSString stringWithFormat:@"%@security/accountLevelLimit.do",BFWalletBaseURL];
            [self.navigationController pushViewController:quotaView animated:YES];
        }
    };
    
    return exampleHandler;
}
- (void)takePhotoMethod
{
    if ([self.takePhotoBtn.titleLabel.text isEqualToString:@"拍摄证件照"]) {
        NSString *mediaType = AVMediaTypeVideo;
        AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:mediaType];
        if(authStatus == AVAuthorizationStatusRestricted || authStatus == AVAuthorizationStatusDenied){
            
            NSLog(@"相机权限受限");
            [[[UIAlertView alloc] initWithTitle:@"无法使用相机" message:@"请在iPhone的“设置-隐私-相机”中允许访问相机" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil] show];
            return;
        }
        ExamplePhotoViewController *exampleVC = [[ExamplePhotoViewController alloc] init];
        exampleVC.exampleStyle = ExamplePhotoTakeStyle;
        exampleVC.delegate = self;
        [self presentViewController:[[UINavigationController alloc] initWithRootViewController:exampleVC] animated:YES completion:nil];
    }else if ([self.takePhotoBtn.titleLabel.text isEqualToString:@"提交审核"])
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        __weakself__
        [BFReqAPI uploadImageWithcardFont:self.photoArr[0] cardBack:self.photoArr[1] block:^(id responseObj, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:weakself.view animated:YES];
            if(!weakself) return ;
            if (responseObj) {
                if (ERROR_CODE == 1) {
                    //更新数据库中的
                    NSString *authFlag = [NSString stringWithFormat:@"%@",responseObj[@"authFlag"]];
                    authFlag = [authFlag isKindOfClass:[NSNull class]]?@"2":authFlag;
                    BFCoreUserModel *model = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel];
                    model.authFlag = authFlag;
                    
                    //成功后跳转高级实人等待审核
                    RealNameViewController *rlVC = [[RealNameViewController alloc] init];
                    rlVC.realNameStyle = [authFlag intValue];
                    [weakself.navigationController pushViewController:rlVC animated:YES];
                }
                else
                {
                    NSString *message = responseObj[@"message"];
                    message = [message isKindOfClass:[NSNull class]]?@"":message;
                    [UIAlertView showWithMessage:message delegate:nil];
                }
            }
        }];
    }
}
#pragma mark - 拍摄证件照
- (void)uploadImageWithArray:(NSArray *)imageArr
{
    [self.takePhotoBtn setTitle:@"提交审核" forState:UIControlStateNormal];
    self.photoArr = imageArr;
    [self.realNameTableView reloadData];
    
}
#pragma mark--UITableViewDataSource&&UITableDelegate
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        cell.detailTextLabel.font = FONT(15.0f);
        cell.textLabel.font = FONT(15.0f);
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    if (indexPath.section == 0) {
        cell.detailTextLabel.textColor = COLOR_HEXSTRING(@"#b5b5b5");
        BFCoreUserModel *model = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel];
        switch (indexPath.row) {
            case 0:
            {
                cell.textLabel.text = @"姓名";
                cell.detailTextLabel.text = model.memberName;
            }
                break;
            case 1:
            {
                cell.textLabel.text = @"身份证号";
                cell.detailTextLabel.text = model.idCard;
            }
                break;
            default:
                break;
        }
        
    }else
    {
        switch (indexPath.row) {
            case 0:
            {
                cell.textLabel.text = @"手持证件照";
                if (self.realNameStyle == RealNameHighMoneyExamineStyle||self.realNameStyle == RealNameHighPeopleExamineStyle) {
                    cell.detailTextLabel.text = @"审核中";
                }else if (self.realNameStyle == RealNameHighMoneyExamineNoPassStyle||self.realNameStyle == RealNameHignPeopleExamineNoPassStyle)
                {
                    if (self.photoArr.count>0) {
                        cell.detailTextLabel.text = nil;
                        for (int i=0; i<self.photoArr.count; i++) {
                            UIImage *photoImage = self.photoArr[i];
                            CGFloat proportion = photoImage.size.width/photoImage.size.height;
                            CGFloat imageViewWidth = 50*proportion;
                            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake((ScreenWidth-2*imageViewWidth-18.0f)+(i%self.photoArr.count)*(imageViewWidth+10.0f), 0.0f, imageViewWidth, 50.0f)];
                            imageView.image = photoImage;
                            [cell.contentView addSubview:imageView];
                        }
                        
                    }else
                    {
                        //                        cell.detailTextLabel.text = @"未上传";
                        cell.detailTextLabel.textColor = [UIColor redColor];
                        cell.detailTextLabel.text = @"未通过";
                    }
                    
                }else if (self.realNameStyle == RealNameHignPeopleStyle||self.realNameStyle == RealNameHighMoneyStyle)
                {
                    cell.detailTextLabel.textColor = COLOR_HEXSTRING(@"#308ed4");
                    cell.detailTextLabel.text = @"审核通过";
                }else if (self.realNameStyle == RealNamePrimaryMoneyStyle||self.realNameStyle == RealNamePrimaryPeopleStyle)
                {
                    if (self.photoArr.count>0) {
                        cell.detailTextLabel.text = nil;
                        for (int i=0; i<self.photoArr.count; i++) {
                            UIImage *photoImage = self.photoArr[i];
                            CGFloat proportion = photoImage.size.width/photoImage.size.height;
                            CGFloat imageViewWidth = 50*proportion;
                            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake((ScreenWidth-2*imageViewWidth-18.0f)+(i%self.photoArr.count)*(imageViewWidth+10.0f), 0.0f, imageViewWidth, 50.0f)];
                            imageView.image = photoImage;
                            [cell.contentView addSubview:imageView];
                        }
                        
                    }else
                    {
                        cell.detailTextLabel.text = @"未上传";
                    }
                    
                }
            }
                break;
            case 1:
            {
                [cell.contentView addSubview:self.linkedTextView];
            }
                break;
            default:
                break;
        }
    }
    
    
    return cell;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1&&indexPath.row == 1) {
        return 37.0f;
    }else
    {
        return 50.0f;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section == 1) {
        return 75.0f;
    }else
    {
        return 14.0f;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return  0.01f;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if (section == 1) {
        
        if (self.realNameStyle == RealNameHighMoneyExamineStyle||self.realNameStyle == RealNameHighPeopleExamineStyle||self.realNameStyle == RealNameHignPeopleStyle||self.realNameStyle == RealNameHighMoneyStyle)
        {
            return nil;
        }else
        {
            UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 75.0f)];
            [view addSubview:self.takePhotoBtn];
            return view;
        }
    }else
    {
        return nil;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

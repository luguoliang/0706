//
//  BFAccountViewController.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/15.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

@class BFHeaderView;

@interface BFAccountViewController : BFBaseViewController
@property (weak, nonatomic) IBOutlet UITableView *accountTableView;
@property (strong, nonatomic) BFHeaderView *headerView;
@end

//
//  BFHeadImageAdjustViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFHeadImageAdjustViewController.h"
@interface BFHeadImageAdjustViewController ()
//
@property (nonatomic, strong) UIImage *originalImage;
@property (nonatomic, strong) UIImage *editedImage;
//
@property (nonatomic, weak) UIImageView *showImgView;
@property (nonatomic, weak) UIView *overlayView;
@property (nonatomic, weak) UIView *ratioView;
//
//@property (nonatomic, weak) UIButton *cancelBtn;
//@property (nonatomic, weak) UIButton *confirmBtn;

@property (nonatomic, assign) CGRect originalFrame;
@property (nonatomic, assign) CGRect maxFrame;
@property (nonatomic, assign) CGFloat maxRatio;
@property (nonatomic, assign) CGRect editedFrame;

@end

static const CGFloat BOUNDCE_DURATION = 0.3f;

@implementation BFHeadImageAdjustViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    //
    _clipFrame = CGRectMake(0, 100, ScreenWidth, ScreenWidth);
    _maxRatio = 3.0f;
    //
    [self calculateAttribute];
    [self instituteSubviews];
    [self modifySubviewsPattern];
    [self addActionAndNotification];
    [self overlayClipping];
    
    
    //
    //    UIImagePickerController *picker = (UIImagePickerController *)self.navigationController;
    //    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
    //        [_cancelBtn setHidden:NO];
    //        [_confirmBtn setHidden:NO];
    //        [self.navigationController.navigationBar setHidden:YES];
    //
    //    }else {
    //        [self setRightBarButtonItemTarget:self action:@selector(touchUpInsideComfirmBtn:) title:@"使用" bgImage:nil];
    //        [_cancelBtn setHidden:YES];
    //        [_confirmBtn setHidden:YES];
    //    }
    
    [self setLeftBarButtonItemTarget:self action:@selector(touchUpInsideCancelBtn:)];
    [self setRightBarButtonItemTarget:self action:@selector(touchUpInsideComfirmBtn:) title:@"使用" bgImage:nil];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:NO];
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
    //    [self.navigationController.navigationBar setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
}

- (instancetype)initWithImage:(UIImage *)originalImage {
    self = [super init];
    if (self) {
        _originalImage = originalImage;
    }
    return self;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return NO;
}

- (void)instituteSubviews {
    //Init Subviews
    UIImageView *showImgView = [[UIImageView alloc]init];
    UIView *overlayView = [[UIView alloc] initWithFrame:self.view.bounds];
    UIView *rationView = [[UIView alloc] initWithFrame:self.clipFrame];
    //    UIButton *cancelBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 100, 50)];
    //    UIButton *confirmBtn = [[UIButton alloc]initWithFrame:CGRectMake(ScreenWidth -100, 0, 100, 50)];
    //Add Subviews
    [self.view addSubview:showImgView];
    [self.view addSubview:overlayView];
    [self.view addSubview:rationView];
    //    [self.view addSubview:cancelBtn];
    //    [self.view addSubview:confirmBtn];
    //Weak Point
    _showImgView = showImgView;
    _overlayView = overlayView;
    _ratioView = rationView;
    //    _cancelBtn = cancelBtn;
    //    _confirmBtn = confirmBtn;
}

- (void)modifySubviewsPattern {
    //
    [_showImgView setMultipleTouchEnabled:YES];
    [_showImgView setUserInteractionEnabled:YES];
    [_showImgView setImage:self.originalImage];
    [_showImgView setFrame:_originalFrame];
    //
    _overlayView.alpha = .5f;
    _overlayView.backgroundColor = [UIColor blackColor];
    _overlayView.userInteractionEnabled = NO;
    _overlayView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    //
    _ratioView.layer.borderColor = [UIColor yellowColor].CGColor;
    _ratioView.layer.borderWidth = 1.0f;
    _ratioView.autoresizingMask = UIViewAutoresizingNone;
    //
    //    [_cancelBtn setImage:[UIImage imageNamed:@"btn_back_normal"] forState:UIControlStateNormal];
    //    [_cancelBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 50)];
    //    [_confirmBtn setTitle:@"使用" forState:UIControlStateNormal];
    //    [_confirmBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 10, 0, 0)];
}

- (void)calculateAttribute {
    CGFloat oriWidth = self.clipFrame.size.width;
    CGFloat oriHeight = self.originalImage.size.height * (oriWidth / self.originalImage.size.width);
    CGFloat oriX = self.clipFrame.origin.x + (self.clipFrame.size.width - oriWidth) / 2;
    CGFloat oriY = self.clipFrame.origin.y + (self.clipFrame.size.height - oriHeight) / 2;
    _originalFrame = CGRectMake(oriX, oriY, oriWidth, oriHeight);
    _editedFrame = self.originalFrame;
    _maxFrame = CGRectMake(0, 0, self.maxRatio * self.originalFrame.size.width, self.maxRatio * self.originalFrame.size.height);
    
}

#pragma mark - Action
- (void)addActionAndNotification {
    // add pinch gesture
    UIPinchGestureRecognizer *pinchGestureRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchGestureOnView:)];
    [self.view addGestureRecognizer:pinchGestureRecognizer];
    // add pan gesture
    UIPanGestureRecognizer *panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGestureOnView:)];
    [self.view addGestureRecognizer:panGestureRecognizer];
    //
    //    [_cancelBtn addTarget:self action:@selector(touchUpInsideCancelBtn:) forControlEvents:UIControlEventTouchUpInside];
    //    [_confirmBtn addTarget:self action:@selector(touchUpInsideComfirmBtn:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)touchUpInsideCancelBtn:(UIButton *)button {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)touchUpInsideComfirmBtn:(UIButton *)button {
    if (self.delegate && [self.delegate conformsToProtocol:@protocol(BFHeadImageAdjustViewControllerDelegate)]) {
        [self.delegate headImgAdjust:self didFinished:[self getSubImage]];
    }
}

- (void)pinchGestureOnView:(UIPinchGestureRecognizer *)pinchGestureRecognizer {
    UIView *view = _showImgView;
    if (pinchGestureRecognizer.state == UIGestureRecognizerStateBegan || pinchGestureRecognizer.state == UIGestureRecognizerStateChanged) {
        view.transform = CGAffineTransformScale(view.transform, pinchGestureRecognizer.scale, pinchGestureRecognizer.scale);
        pinchGestureRecognizer.scale = 1;
    }
    else if (pinchGestureRecognizer.state == UIGestureRecognizerStateEnded) {
        CGRect newFrame = self.showImgView.frame;
        newFrame = [self handleScaleOverflow:newFrame];
        newFrame = [self handleBorderOverflow:newFrame];
        [UIView animateWithDuration:BOUNDCE_DURATION animations:^{
            self.showImgView.frame = newFrame;
            self.editedFrame = newFrame;
        }];
    }
}

- (void)panGestureOnView:(UIPanGestureRecognizer *)panGestureRecognizer {
    UIView *view = self.showImgView;
    if (panGestureRecognizer.state == UIGestureRecognizerStateBegan || panGestureRecognizer.state == UIGestureRecognizerStateChanged) {
        // calculate accelerator
        CGFloat absCenterX = self.clipFrame.origin.x + self.clipFrame.size.width / 2;
        CGFloat absCenterY = self.clipFrame.origin.y + self.clipFrame.size.height / 2;
        CGFloat scaleRatio = self.showImgView.frame.size.width / self.clipFrame.size.width;
        CGFloat acceleratorX = 1 - ABS(absCenterX - view.center.x) / (scaleRatio * absCenterX);
        CGFloat acceleratorY = 1 - ABS(absCenterY - view.center.y) / (scaleRatio * absCenterY);
        CGPoint translation = [panGestureRecognizer translationInView:view.superview];
        [view setCenter:(CGPoint){view.center.x + translation.x * acceleratorX, view.center.y + translation.y * acceleratorY}];
        [panGestureRecognizer setTranslation:CGPointZero inView:view.superview];
    }
    else if (panGestureRecognizer.state == UIGestureRecognizerStateEnded) {
        // bounce to original frame
        CGRect newFrame = self.showImgView.frame;
        newFrame = [self handleBorderOverflow:newFrame];
        [UIView animateWithDuration:BOUNDCE_DURATION animations:^{
            self.showImgView.frame = newFrame;
            self.editedFrame = newFrame;
        }];
    }
}

#pragma mark - Process Image With Gesture
//
- (void)overlayClipping {
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    CGMutablePathRef path = CGPathCreateMutable();
    // Left side of the ratio view
    CGPathAddRect(path, nil, CGRectMake(0, 0,
                                        self.ratioView.frame.origin.x,
                                        self.overlayView.frame.size.height));
    // Right side of the ratio view
    CGPathAddRect(path, nil, CGRectMake(
                                        self.ratioView.frame.origin.x + self.ratioView.frame.size.width,
                                        0,
                                        self.overlayView.frame.size.width - self.ratioView.frame.origin.x - self.ratioView.frame.size.width,
                                        self.overlayView.frame.size.height));
    // Top side of the ratio view
    CGPathAddRect(path, nil, CGRectMake(0, 0,
                                        self.overlayView.frame.size.width,
                                        self.ratioView.frame.origin.y));
    // Bottom side of the ratio view
    CGPathAddRect(path, nil, CGRectMake(0,
                                        self.ratioView.frame.origin.y + self.ratioView.frame.size.height,
                                        self.overlayView.frame.size.width,
                                        self.overlayView.frame.size.height - self.ratioView.frame.origin.y + self.ratioView.frame.size.height));
    maskLayer.path = path;
    _overlayView.layer.mask = maskLayer;
    CGPathRelease(path);
}
//
- (CGRect)handleScaleOverflow:(CGRect)newFrame {
    // bounce to original frame
    CGPoint oriCenter = CGPointMake(newFrame.origin.x + newFrame.size.width/2, newFrame.origin.y + newFrame.size.height/2);
    if (newFrame.size.width < self.originalFrame.size.width) {
        newFrame = self.originalFrame;
    }
    if (newFrame.size.width > self.maxFrame.size.width) {
        newFrame = self.maxFrame;
    }
    newFrame.origin.x = oriCenter.x - newFrame.size.width/2;
    newFrame.origin.y = oriCenter.y - newFrame.size.height/2;
    return newFrame;
}
//
- (CGRect)handleBorderOverflow:(CGRect)newFrame {
    // horizontally
    if (newFrame.origin.x > self.clipFrame.origin.x) newFrame.origin.x = self.clipFrame.origin.x;
    if (CGRectGetMaxX(newFrame) < self.clipFrame.size.width) newFrame.origin.x = self.clipFrame.size.width - newFrame.size.width;
    // vertically
    if (newFrame.origin.y > self.clipFrame.origin.y) newFrame.origin.y = self.clipFrame
        .origin.y;
    if (CGRectGetMaxY(newFrame) < self.clipFrame.origin.y + self.clipFrame.size.height) {
        newFrame.origin.y = self.clipFrame.origin.y + self.clipFrame.size.height - newFrame.size.height;
    }
    // adapt horizontally rectangle
    if (self.showImgView.frame.size.width > self.showImgView.frame.size.height && newFrame.size.height <= self.clipFrame.size.height) {
        newFrame.origin.y = self.clipFrame.origin.y + (self.clipFrame.size.height - newFrame.size.height) / 2;
    }
    return newFrame;
}
//
- (UIImage *)getSubImage {
    //要切的大小
    CGRect squareFrame = self.clipFrame;
    CGFloat scaleRatio = self.editedFrame.size.width / self.originalImage.size.width;
    //根据比率去原图找像素点
    CGFloat x = (squareFrame.origin.x - self.editedFrame.origin.x) / scaleRatio;
    CGFloat y = (squareFrame.origin.y - self.editedFrame.origin.y) / scaleRatio;
    CGFloat w = squareFrame.size.width / scaleRatio;
    CGFloat h = squareFrame.size.width / scaleRatio;
    //检查最终宽是不是小于原宽
    if (self.editedFrame.size.width < self.clipFrame.size.width) {
        CGFloat newW = self.originalImage.size.width;
        CGFloat newH = newW * (self.clipFrame.size.height / self.clipFrame.size.width);
        x = 0; y = y + (h - newH) / 2;
        w = newH; h = newH;
    }
    //检查高
    if (self.editedFrame.size.height < self.clipFrame.size.height) {
        CGFloat newH = self.originalImage.size.height;
        CGFloat newW = newH * (self.clipFrame.size.width / self.clipFrame.size.height);
        x = x + (w - newW) / 2; y = 0;
        w = newH; h = newH;
    }
    //最终切图rect
    CGRect myImageRect = CGRectMake(x, y, w, h);
    //通过Core Graphic切图
    CGImageRef imageRef = self.originalImage.CGImage;
    CGImageRef subImageRef = CGImageCreateWithImageInRect(imageRef, myImageRect);
    CGSize size;
    size.width = myImageRect.size.width;
    size.height = myImageRect.size.height;
    UIGraphicsBeginImageContext(size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextDrawImage(context, myImageRect, subImageRef);
    //通过CG创建新的UIImage
    UIImage* smallImage = [UIImage imageWithCGImage:subImageRef];
    UIGraphicsEndImageContext();
    //返回小图
    return smallImage;
}

@end

//
//  BFUserInfoViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFUserInfoViewController.h"
#import "BFUserInfoHeaderTableViewCell.h"
#import "BFUploadHeadImageViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "RealNameViewController.h"
#import "PrimaryVerifiedController.h"
#import "BangdingViewController.h"
#import "ModifyMobileCodeViewController.h"
#import "BFSwAccountViewController.h"

@interface BFUserInfoViewController ()<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,strong)UITableView *accountTableView;
@property(nonatomic,strong)NSMutableArray *tableArray;
@property(nonatomic,strong)NSMutableArray *detailValueArray;
@property(nonatomic,strong)UIView *footLogoView;
@property(nonatomic,copy)NSString *realeStatus;
@end

@implementation BFUserInfoViewController
- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [self initDataForTable];
    [self.accountTableView reloadData];
    self.navigationController.navigationBarHidden = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *bottomLine = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5f)];
    bottomLine.backgroundColor = COLOR_HEXSTRING(LINE_COLOR);
    [self.view addSubview:bottomLine];
    
    self.navigationItem.title = @"账户详情";
    [self setRightBarButtonItemTarget:self action:@selector(accountExchange) title:@"切换账户" bgImage:nil];
    
    [self.view addSubview:self.accountTableView];
    [self setupFootLogoView];
    
}

- (void)setupFootLogoView {
    // 页脚logo
    _footLogoView = [[UIView alloc] initWithFrame:CGRectMake(0, _accountTableView.frame.size.height - 70, [UIScreen mainScreen].bounds.size.width, 70)];
    _footLogoView.backgroundColor = [UIColor clearColor];
    UIImage *img = [UIImage imageNamed:@"footlogo"];
    UIImageView *footImg = [[UIImageView alloc] initWithImage:img];
    CGRect f = CGRectMake(0, 0, ScreenWidth, 30);
    footImg.frame = f;
    [_footLogoView addSubview:footImg];
    UILabel *tel = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(footImg.frame)+10, ScreenWidth, 20)];
    tel.text = @"客服电话：021-68811008";
    [tel setFont:BF_Font_12];
    [tel setTextColor:[UIColor blackColor]];
    [tel setTextAlignment:NSTextAlignmentCenter];
    [_footLogoView addSubview:tel];
    
    UILabel *gsName = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(tel.frame)+7, ScreenWidth, 20)];
    gsName.text = @"宝付网络科技（上海）有限公司";
    [gsName setFont:BF_Font_12];
    [gsName setTextColor:[UIColor grayColor]];
    [gsName setTextAlignment:NSTextAlignmentCenter];
    [_footLogoView addSubview:gsName];
    
    [self.accountTableView addSubview:_footLogoView];
}
#pragma mark--CReatUI
- (UITableView *)accountTableView
{
    if (!_accountTableView) {
        _accountTableView = [[UITableView alloc] initWithFrame:CGRectMake(0.0f, 10.0f, ScreenWidth, ScreenHeight-64.0f-10.0f) style:UITableViewStyleGrouped];
        _accountTableView.delegate = self;
        _accountTableView.dataSource = self;
        _accountTableView.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
        _accountTableView.scrollEnabled = NO;
    }
    return _accountTableView;
}
- (void)initDataForTable{
    _tableArray = [[NSMutableArray alloc] initWithArray:@[@[@"头像"],@[@"姓名",@"账户名",@"绑定手机"],@[@"实名认证"]]];
    _realeStatus = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].authFlag;
    _detailValueArray = [[NSMutableArray alloc] initWithCapacity:0];
    NSString *mName = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].memberName;
    NSString *aName = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].accountName;
    NSString *mob = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].mobile;
    [_detailValueArray addObjectsFromArray:@[mName.length>0?[NSString stringWithFormat:@"*%@",[mName substringFromIndex:1]]:@"尚未实名认证",
                                             aName.length>0?[NSString stringWithFormat:@"%@****%@",[aName substringToIndex:3],[aName substringFromIndex:7]]:@"",
                                              mob.length>0?mob:@"未绑定"]];
}
-(void)backMethod {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)accountExchange {
    BFSwAccountViewController *exchangeVc = [[BFSwAccountViewController alloc] init];
    [self.navigationController pushViewController:exchangeVc animated:YES];
}
#pragma mark - UITableViewDelegate&DataSource

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==0) {
        BFUserInfoHeaderTableViewCell *cell = [[BFUserInfoHeaderTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellId"];
        cell.textLabel.text = @"头像";
        cell.textLabel.font = BF_Font_15;
        cell.textLabel.textColor = BF_Color_TextTitle;
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator ;
        
        return cell;
    }
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        cell.textLabel.font = [UIFont systemFontOfSize:15.0f];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:15.0f];
    }
    
    NSArray *textLabelArray = self.tableArray[indexPath.section];
    
    cell.textLabel.text = textLabelArray[indexPath.row];
    if (indexPath.section == 1) {
        cell.detailTextLabel.text = _detailValueArray[indexPath.row];
        if (indexPath.row == 2) {
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }else
        {
            cell.accessoryType = UITableViewCellAccessoryNone;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
    }else
    {
        UIImage *realImage = nil;
        if ([_realeStatus intValue] == 1||[_realeStatus intValue] == 2||[_realeStatus intValue] == 3) {
            realImage = [UIImage imageNamed:@"primary_people_type"];
            
        }else if ([_realeStatus intValue] == 4)
        {
            realImage = [UIImage imageNamed:@"high_people_type"];
            
        }else if ([_realeStatus intValue] == 5||[_realeStatus intValue] == 7||[_realeStatus intValue] == 8)
        {
            realImage = [UIImage imageNamed:@"primary_money_type"];
            
        }else if ([_realeStatus intValue] == 6)
        {
            realImage = [UIImage imageNamed:@"high_money_type"];
        }else if ([_realeStatus integerValue] == 0)
        {
            realImage = [UIImage imageNamed:@"no_realname_type"];
        }
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(ScreenWidth - 35.0f-realImage.size.width, (50-realImage.size.height)*0.5, realImage.size.width, realImage.size.height)];
        imageView.image = realImage;
        [cell.contentView addSubview:imageView];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    return cell;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.tableArray.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *array = self.tableArray[section];
    return array.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section ==0 ) {
        return 70;
    }
    else{
        return 50;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    return 0.01f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section!=self.tableArray.count-1) {
        return 7.5f;
    }else
    {
        return 0.01;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if(indexPath.section == 0){
        BFUploadHeadImageViewController *uploadHeadImgVC = [[BFUploadHeadImageViewController alloc]init];
        [self.navigationController pushViewController:uploadHeadImgVC animated:YES];
        return;
    }
    else if (indexPath.section == 1)
    {
        //绑定手机
        NSString*mobeleStr = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].mobile;
        if (indexPath.row == 2) {
            //修改绑定手机
            if (mobeleStr.length) {
                ModifyMobileCodeViewController *moBinding = [[ModifyMobileCodeViewController alloc] init];
                [self.navigationController pushViewController:moBinding animated:YES];
            }
            //绑定手机
            else
            {
                [self.navigationController pushViewController:[BangdingViewController new] animated:YES];
            }
        }
    }
    else if (indexPath.section == 2) {
        //0立即实名认证，尚未认证
        //       _realeStatus = @"6";
        if ([_realeStatus isEqualToString:@"0"]) {
            PrimaryVerifiedController*primaryView = [[PrimaryVerifiedController alloc] init];
            [self.navigationController pushViewController:primaryView animated:YES];
        }else
        {
            RealNameViewController *rlVC = [RealNameViewController new];
            rlVC.realNameStyle = [_realeStatus intValue];
            [self.navigationController pushViewController:rlVC animated:YES];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

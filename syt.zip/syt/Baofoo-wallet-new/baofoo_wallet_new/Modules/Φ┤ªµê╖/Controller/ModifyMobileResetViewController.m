//
//  ModifyMobileResetViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/16.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "ModifyMobileResetViewController.h"

// Tool
#import "BFReqAPI+Security.h"
#import "BFKeyBoardView.h"
@interface ModifyMobileResetViewController ()<BFKeyBoardViewDelegate,UITextFieldDelegate>
@property(nonatomic,strong)BFKeyBoardView *sectureKeyboard;//自定义安全键盘
@property(nonatomic,strong)UITextField *payPasswordField;//输入支付密码
@property(nonatomic,strong)UITextField *telPhoneField;//输入支付密码
@property(nonatomic,strong)UITextField *validateCodeField;//验证码输入
@property(nonatomic,strong)UIButton *nextBtn;//确认
@end

@implementation ModifyMobileResetViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"绑定手机";
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    [self.view addSubview:self.payPasswordField];
    [self.view addSubview:self.telPhoneField];
    [self.view addSubview:self.validateCodeField];
    [self.view addSubview:self.nextBtn];
}
-(void)backBtn
{
    [self.navigationController popToViewController:self.navigationController.viewControllers[1] animated:YES];
}
#pragma mark--安全键盘
- (BFKeyBoardView *)sectureKeyboard
{
    if (!_sectureKeyboard) {
        _sectureKeyboard = [[[NSBundle mainBundle] loadNibNamed:@"BFKeyBoardView" owner:nil options:nil] lastObject];
        _sectureKeyboard.delegate = self;
    }
    return _sectureKeyboard;
}

#pragma mark--支付密码
- (UITextField *)payPasswordField
{
    if (!_payPasswordField) {
        _payPasswordField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _payPasswordField.backgroundColor = [UIColor whiteColor];
        _payPasswordField.leftView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 10.0f, 50.0f)];
        _payPasswordField.leftViewMode = UITextFieldViewModeAlways;
        _payPasswordField.placeholder = @"输入支付密码";
        _payPasswordField.secureTextEntry = YES;
        _payPasswordField.delegate = self;
        _payPasswordField.leftView = [self leftViewLabelWithText:@"支付密码"];
        _payPasswordField.leftViewMode = UITextFieldViewModeAlways;
        _payPasswordField.font = FONT(14.0f);
        _payPasswordField.inputView = self.sectureKeyboard;
        
        UILabel *lineLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 49.5f, ScreenWidth, 0.5f)];
        lineLabel.backgroundColor = COLOR_HEXSTRING(LINE_COLOR);
        [_payPasswordField addSubview:lineLabel];
    }
    return _payPasswordField;
}
#pragma mark--姓名输入框
- (UITextField *)telPhoneField
{
    if (!_telPhoneField) {
        _telPhoneField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, _payPasswordField.frame.origin.y+_payPasswordField.frame.size.height+10.0f, ScreenWidth, 50.0f)];
        _telPhoneField.backgroundColor = [UIColor whiteColor];
        _telPhoneField.leftView = [self leftViewLabelWithText:@"新手机号"];
        _telPhoneField.leftViewMode = UITextFieldViewModeAlways;
        _telPhoneField.font = FONT(14.0f);
        _telPhoneField.placeholder = @"输入要绑定的手机号码";
        _telPhoneField.keyboardType = UIKeyboardTypeNumberPad;
        [_telPhoneField addTarget:self action:@selector(textFieldValueChanged:) forControlEvents:UIControlEventEditingChanged];
        
        UILabel *lineLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 0.5f)];
        lineLabel1.backgroundColor = COLOR_HEXSTRING(LINE_COLOR);
        [_payPasswordField addSubview:lineLabel1];
        
        UILabel *lineLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, 49.5f, ScreenWidth-10.0f, 0.5f)];
        lineLabel2.backgroundColor = COLOR_HEXSTRING(LINE_COLOR);
        [_telPhoneField addSubview:lineLabel2];
    }
    return _telPhoneField;
}
- (UIView *)leftViewLabelWithText:(NSString *)text
{
    UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 75.0f, 40.0f)];
    UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, 0.0f, 65.0f, 40.0f)];
    leftLabel.font = FONT(14.0f);
    leftLabel.textColor = COLOR_HEXSTRING(BLACK_COLOR);
    leftLabel.text = text;
    [leftView addSubview:leftLabel];
    return leftView;
}
#pragma mark--验证码输入框
- (UITextField *)validateCodeField
{
    if (!_validateCodeField) {
        _validateCodeField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, _telPhoneField.frame.origin.y+_telPhoneField.frame.size.height, ScreenWidth, 50.0f)];
        _validateCodeField.backgroundColor = [UIColor whiteColor];
        _validateCodeField.leftView = [self leftViewLabelWithText:@"验证码"];
        _validateCodeField.placeholder = @"短信验证码";
        _validateCodeField.leftViewMode = UITextFieldViewModeAlways;
        _validateCodeField.keyboardType = UIKeyboardTypeNumberPad;
        [_validateCodeField addTarget:self action:@selector(textFieldValueChanged:) forControlEvents:UIControlEventEditingChanged];
        CustomTimerButtom *rightBtn = [CustomTimerButtom buttonWithType:UIButtonTypeCustom];
        rightBtn.frame = CGRectMake(0.0f, 0.0f, 85.0f, 40.0f);
        [rightBtn setTitle:@"获取" forState:UIControlStateNormal];
        [rightBtn setTitleColor:COLOR_HEXSTRING(BLUE_COLOR) forState:UIControlStateNormal];
        rightBtn.titleLabel.font = FONT(14.0f);
        [rightBtn addTarget:self action:@selector(getCodeMethod:) forControlEvents:UIControlEventTouchUpInside];
        _validateCodeField.rightView = rightBtn;
        _validateCodeField.rightViewMode = UITextFieldViewModeAlways;
        _validateCodeField.font = FONT(14.0f);
    }
    return _validateCodeField;
}
#pragma mark--确认按钮
- (UIButton *)nextBtn
{
    if (!_nextBtn) {
        _nextBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        _nextBtn.frame = CGRectMake(15.0f,self.validateCodeField.frame.origin.y+self.validateCodeField.frame.size.height+60.0f,ScreenWidth-30.0f,40.0f);
        _nextBtn.layer.cornerRadius = 20.0f;
        [_nextBtn addTarget:self action:@selector(comfireMethod)forControlEvents:UIControlEventTouchUpInside];
        [_nextBtn setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        [_nextBtn setTitle:@"确认" forState:UIControlStateNormal];
        _nextBtn.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _nextBtn.enabled = NO;
    }
    return _nextBtn;
}
#pragma mark--判断下一步按钮的状态
- (void)judgeMethod
{
    
    if (self.telPhoneField.text.length==11&&self.payPasswordField.text.length==6&&self.validateCodeField.text.length==6) {
        [_nextBtn setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f] forState:UIControlStateNormal];
        _nextBtn.enabled = YES;
    }else
    {
        [_nextBtn setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _nextBtn.enabled = NO;
    }
}
#pragma mark  输入键盘的正则判断
-(void)textFieldValueChanged:(UITextField *)textField
{
    [self judgeMethod];
    
}
#pragma mark 设置确定按钮颜色
-(void)textfieldValueChange:(UITextField*)mytextfield
{
    [self judgeMethod];
}
static CustomTimerButtom *__yzmBtn;
-(void)getCodeMethod:(CustomTimerButtom*)btn
{
    if (self.telPhoneField.text.length==11) {
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:self.telPhoneField.text,@"bindMobile",@"0",@"type",@"7",@"msg_type",nil];
        __weakself__
        [self showProgress];
        [BFReqAPI reqVerifyCodeSendAtResetBindMobileWithParams:userInfo block:^(id responseObj, NSError *error) {
            [weakself hideProgress];
            if (!weakself) return ;
            if (responseObj != nil) {
                if (ERROR_CODE == 1) {
                    [btn startTimer];
                    [weakself.validateCodeField becomeFirstResponder];
                }else
                {
                    [UIAlertView showWithMessage:responseObj[@"message"] delegate:nil];
                }
            }
        }];
    }
}
-(void)comfireMethod
{
    [self.view endEditing:YES];
    NSDictionary *userInfo = @{@"bindMobile":self.telPhoneField.text,@"dynamicCode":self.validateCodeField.text,@"pay_password":[BFMD5 md5:self.payPasswordField.text]};
    __weakself__
    [self showProgress];
    [BFReqAPI reqResetBindMobileWithParams:userInfo block:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        if (!weakself) return ;
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                BFCoreUserModel *model = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel];
                model.mobile = responseObj[@"obj"];
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:responseObj[@"message"] message:nil delegate:weakself cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                alertView.tag = 0;
                [alertView show];
            }else
            {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:nil];
            }
        }
    }];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self performSelector:@selector(goBackMethod) withObject:nil afterDelay:0.25];
    
    
}
- (void)goBackMethod
{
    [self.navigationController popToViewController:self.navigationController.viewControllers[1] animated:YES];
}
#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [self.sectureKeyboard setKeyBoardWith:textField];
    [self.sectureKeyboard setKeyboardstytle:KeyboardstytlePassword];
    return YES;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.payPasswordField resignFirstResponder];
    return YES;
}
#pragma mark - KeyBoardViewDelegate
-(void)keyBoard:(BFKeyBoardView*)keyBoard didClickedButton:(UIButton*)button WithText:(UITextField*)textfield
{
    
    textfield.text  = [NSString stringWithFormat:@"%@%@",textfield.text,button.titleLabel.text];
    if (textfield.text.length>=6) {
        textfield.text = [textfield.text substringToIndex:6];
    }
    [self judgeMethod];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateButton:(UIButton*)button WithText:(UITextField*)textfield
{
    NSString*str = textfield.text;
    if ([str length] != 0) {
        str = [str substringToIndex:[str length]- 1];
        textfield.text  = str;
    }
    [self judgeMethod];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateFinished:(UIButton*)button WithText:(UITextField*)textfield
{
    [textfield resignFirstResponder];
}

- (void)dealloc
{
    [__yzmBtn stopTimer];
    __yzmBtn = nil;
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

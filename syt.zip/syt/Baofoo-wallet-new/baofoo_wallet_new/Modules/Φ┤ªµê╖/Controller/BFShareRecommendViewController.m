//
//  BFShareRecommendViewController.m
//  bestpay
//
//  Created by yfzx_sh_louwk on 15/9/21.
//  Copyright © 2015年 Lisworking. All rights reserved.
//

#import "BFShareRecommendViewController.h"

@interface BFShareRecommendViewController ()

@end

@implementation BFShareRecommendViewController

#pragma mark - Life Cycle

- (void)viewDidLoad{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"分享与推荐";
    [self setRightBarButtonItemTarget:self action:@selector(clickShareBtn) title:@"分享" bgImage:nil];
    [self drawUI];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UI

- (void)drawUI{
    UIView *contentView = [UIView createWhiteViewWithFrame:CGRectMake(0, 10, ScreenWidth, 355)];
    [self.view addSubview:contentView];
    UIView *line1 = UILineDefaultCreate(0, 0, ScreenWidth);
    [contentView addSubview:line1];
    
    UILabel *downloadLabel = [UILabel createWithFrame:CGRectMake(75, 37, 90, 30.0)];
    downloadLabel.textColor = BF_Color_TextSubhead;
    downloadLabel.font = BF_Font_17;
    downloadLabel.text = @"下载地址:";
    downloadLabel.center_X = ScreenWidth/2- 75;
    downloadLabel.textAlignment = NSTextAlignmentLeft;
    [contentView addSubview:downloadLabel];
    
    UILabel *addressLabel = [UILabel createWithFrame:CGRectMake(downloadLabel.origin_X +downloadLabel.size_W , 37, 150, 30)];
    addressLabel.textColor = BF_Color_TextContent;
    addressLabel.text = @"m.baofoo.com";
    addressLabel.font = BF_Font_17;
    addressLabel.center_X = ScreenWidth/2 +45;
    addressLabel.textAlignment = NSTextAlignmentLeft;
    [contentView addSubview:addressLabel];
    
    UIImageView *codeImageView = [UIImageView createWithFrame:CGRectMake(0, 0, 150, 150)  image:[UIImage imageNamed:@"qrcode_BFdownload"]];
    codeImageView.center_X = contentView.size_W/2;
    codeImageView.center_Y = contentView.size_H/2 ;
    [contentView addSubview:codeImageView];
    
    UILabel *label = [UILabel createWithFrame:CGRectMake(0, contentView.size_H-70.0, contentView.size_W, 30.0)];
    label.font = BF_Font_16;
    label.textColor = BF_Color_TextSubhead;
    label.textAlignment = NSTextAlignmentCenter;
    label.text = @"如果你喜欢我们，推荐给你的朋友吧";
    [contentView addSubview:label];
    
    UIView *line2 = UILineDefaultCreate(0, contentView.size_H-0.5, ScreenWidth);
    [contentView addSubview:line2];
}

#pragma mark - Button Action

- (void)clickShareBtn{
}

#pragma mark - Request



@end

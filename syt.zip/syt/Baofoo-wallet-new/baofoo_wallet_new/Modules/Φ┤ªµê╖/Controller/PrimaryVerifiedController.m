//
//  PrimaryVerifiedController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "PrimaryVerifiedController.h"
#import "BFUserInfoViewController.h"
#import "BFBuyCommodityViewController.h"
#import "HsqViewController.h"
#import "BFWebViewController.h"
#import "RealNameViewController.h"

//Tool
#import "BFKeyBoardView.h"
#import "WBLinkTextView.h"
#import "BFReqAPI+Account.h"

@interface PrimaryVerifiedController ()<BFKeyBoardViewDelegate,UIAlertViewDelegate,UITextFieldDelegate>

@property(nonatomic,strong)BFKeyBoardView *sectureKeyboard;//自定义安全键盘
@property(nonatomic,strong)UITextField *nameField;//输入姓名
@property(nonatomic,strong)UITextField *idCardField;//输入身份证
@property(nonatomic,strong)UIButton *certainButton;//下一步
@property(nonatomic,strong)WBLinkTextView *linkedTextView;
@end

@implementation PrimaryVerifiedController
- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"初级实名认证";
    self.navigationController.navigationBarHidden = NO;
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    [self.view addSubview:self.linkedTextView];
    [self.view addSubview:self.nameField];
    [self.view addSubview:self.idCardField];
    [self.view addSubview:self.certainButton];
    
}
-(void)backMethod
{
    if (self.dismissOrPop == 0) {
        for ( UIViewController *ViewControlView in self.navigationController.viewControllers) {
            if ([ViewControlView isKindOfClass:[BFUserInfoViewController class]]||[ViewControlView isKindOfClass:[BFBuyCommodityViewController class]]||[ViewControlView isKindOfClass:[HsqViewController class]]) {
                [self.navigationController popToViewController:ViewControlView animated:YES];
                return;
            }
        }
    }else
    {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
}
#pragma mark--CreatUI
- (BFKeyBoardView *)sectureKeyboard
{
    if (!_sectureKeyboard) {
        _sectureKeyboard = [[[NSBundle mainBundle] loadNibNamed:@"BFKeyBoardView" owner:nil options:nil] lastObject];
        _sectureKeyboard.delegate = self;
    }
    return _sectureKeyboard;
}
#pragma mark--CreatUI
- (WBLinkTextView *)linkedTextView
{
    if (!_linkedTextView) {
        
        _linkedTextView = [[WBLinkTextView alloc] initWithFrame:CGRectMake(10.0f, 3.5f, ScreenWidth-20.0f, 30.0f)];
        _linkedTextView.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
        _linkedTextView.font = FONT(13.0f);
        _linkedTextView.textColor = COLOR_HEXSTRING(@"#aaaaaa");
        _linkedTextView.text = @"实名认证后，账户限额更高哦 ";
        [_linkedTextView linkString:@"限额"
                  defaultAttributes:[@{NSForegroundColorAttributeName:COLOR_HEXSTRING(ORANGE_COLOR)}mutableCopy]
              highlightedAttributes:[@{NSForegroundColorAttributeName:COLOR_HEXSTRING(ORANGE_COLOR)}mutableCopy]
                         tapHandler:[self exampleHandlerWithTitle:@"Link a single string"]];
        
        
    }
    return _linkedTextView;
}

- (UITextField *)nameField
{
    if (!_nameField) {
        
        _nameField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, self.linkedTextView.frame.origin.y+self.linkedTextView.frame.size.height, ScreenWidth, 50.0f)];
        _nameField.backgroundColor = [UIColor whiteColor];
        _nameField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 80.0f, 50.0f) text:@"姓  名"];;
        _nameField.leftViewMode = UITextFieldViewModeAlways;
        _nameField.font = FONT(14.0f);
        _nameField.placeholder = @"持卡人真实姓名";
        [_nameField addTarget:self action:@selector(textFieldChangeMethod:) forControlEvents:UIControlEventEditingChanged];
        
        UILabel *lineLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 0.5f)];
        lineLabel1.backgroundColor = COLOR_HEXSTRING(LINE_COLOR);
        [_nameField addSubview:lineLabel1];
        
        UILabel *lineLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(18.0f, 49.5, ScreenWidth-18.0f, 0.5f)];
        lineLabel2.backgroundColor = COLOR_HEXSTRING(LINE_COLOR);
        [_nameField addSubview:lineLabel2];
    }
    return _nameField;
}

- (UITextField *)idCardField
{
    if (!_idCardField) {
        _idCardField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, self.nameField.frame.origin.y+self.nameField.frame.size.height, ScreenWidth, 50.0f)];
        _idCardField.backgroundColor = [UIColor whiteColor];
        _idCardField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 80.0f, 50.0f) text:@"身份证"];;
        _idCardField.leftViewMode = UITextFieldViewModeAlways;
        _idCardField.placeholder = @"请输入身份证号";
        _idCardField.delegate = self;
        _idCardField.font = FONT(14.0f);
        _idCardField.inputView = self.sectureKeyboard;
        UILabel *lineLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 49.5, ScreenWidth, 0.5f)];
        lineLabel.backgroundColor = COLOR_HEXSTRING(LINE_COLOR);
        [_idCardField addSubview:lineLabel];
    }
    return _idCardField;
}
- (UIView *)leftViewLabelWithFrame:(CGRect)rect text:(NSString *)text
{
    UIView *leftView = [[UIView alloc] initWithFrame:rect];
    UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, rect.size.width, rect.size.height)];
    leftLabel.font = FONT(16.0f);
    leftLabel.textColor = COLOR_HEXSTRING(BLACK_COLOR);
    leftLabel.text = text;
    leftLabel.textAlignment = NSTextAlignmentCenter;
    [leftView addSubview:leftLabel];
    return leftView;
}

- (UIButton *)certainButton
{
    if (!_certainButton) {
        _certainButton = [UIButton buttonWithType:UIButtonTypeSystem];
        _certainButton.frame = CGRectMake(15.0f, self.idCardField.frame.origin.y+self.idCardField.frame.size.height+60.0f, ScreenWidth-30.0f, 40);
        _certainButton.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _certainButton.enabled = NO;
        _certainButton.layer.cornerRadius = 20.0f;
        [_certainButton setTitle:@"提交" forState:UIControlStateNormal];
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [_certainButton addTarget:self action:@selector(certainMethod) forControlEvents:UIControlEventTouchUpInside];
    }
    return _certainButton;
}
#pragma mark--方法
//限额链接
- (LinkedStringTapHandler)exampleHandlerWithTitle:(NSString *)title
{
    LinkedStringTapHandler exampleHandler = ^(NSString *linkedString) {
        
        if ([linkedString isEqualToString:@"限额"])
        {
            NSLog(@"限额");
            BFWebViewController *quotaView  = [[BFWebViewController alloc] init];
            quotaView.urlStr = [NSString stringWithFormat:@"%@security/accountLevelLimit.do",BFWalletBaseURL];
            [self.navigationController pushViewController:quotaView animated:YES];
        }
    };
    
    return exampleHandler;
}
//提交方法
-(void)certainMethod
{
    NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:self.nameField.text,@"name",self.idCardField.text,@"idCard",nil];
    __weakself__
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [BFReqAPI reqPrimaryRealNameWithParams:userInfo block:^(id responseObj, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:weakself.view animated:YES];
        if (!weakself) return ;
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                if ([self.money isEqualToString:@"money"])
                {
                    UIAlertView*alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"实名认证成功" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                    [alertView show];
                    BFCoreUserModel *model = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel];
                    NSDictionary *obj = responseObj[@"obj"];
                    model.authFlag = @"1";
                    model.memberName = obj[@"memberName"];
                    model.idCard = obj[@"idCard"];
                }
                else{
                    RealNameViewController *primary = [[RealNameViewController alloc] init];
                    BFCoreUserModel *model = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel];
                    NSDictionary *obj = responseObj[@"obj"];
                    model.authFlag = @"1";
                    model.memberName = obj[@"memberName"];
                    model.idCard = obj[@"idCard"];
                    primary.realNameStyle = 1;
                    if (self.dismissOrPop == 0) {
                        [self.navigationController pushViewController:primary animated:YES];
                    }
                    
                    else
                    {
                        [self dismissViewControllerAnimated:YES completion:nil];
                        [UIAlertView showWithMessage:@"认证成功" delegate:nil];
                    }
                }
                
            }else
            {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:nil];
                _certainButton.enabled = NO;
                [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3] forState:UIControlStateNormal];
            }
        }
    }];
}

-(void)textFieldChangeMethod:(UITextField*)mytextfield
{
    [self judgeMethod];
}
- (void)judgeMethod
{
    if ((self.idCardField.text.length != 0)&&(self.nameField.text.length != 0)) {
        _certainButton.enabled = YES;
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0] forState:UIControlStateNormal];
    }
    else
    {
        _certainButton.enabled = NO;
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3] forState:UIControlStateNormal];
    }
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

#pragma mark--代理


-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    self.sectureKeyboard.keyBoardNumberStatus = @"0";
    [self.sectureKeyboard setKeyBoardWith:textField];
    [self.sectureKeyboard setKeyboardstytle:KeyboardstytleCardID];
    return YES;
}
#pragma mark - keyboardViewDelegate
-(void)keyBoard:(BFKeyBoardView*)keyBoard didClickedButton:(UIButton*)button WithText:(UITextField*)textfield
{
    
    textfield.text  = [NSString stringWithFormat:@"%@%@",textfield.text,button.titleLabel.text];
    [self judgeMethod];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateButton:(UIButton*)button WithText:(UITextField*)textfield
{
    NSString*str = textfield.text;
    if ([str length] != 0) {
        str = [str substringToIndex:[str length]- 1];
        textfield.text  = str;
    }
    [self judgeMethod];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateFinished:(UIButton*)button WithText:(UITextField*)textfield
{
    [textfield resignFirstResponder];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  BFShareRecommendViewController.h
//  baofoo
//
//  Created by zhoujun on 15/9/21.
//  Copyright © 2015年 baofoo. All rights reserved.
//

#import "BFBaseViewController.h"

@interface BFShareRecommendViewController : BFBaseViewController

@end

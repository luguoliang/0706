//
//  PrimaryVerifiedController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

@interface PrimaryVerifiedController : BFBaseViewController
@property(nonatomic,assign)NSInteger dismissOrPop;//0是pop 1是dismiss
@property(nonatomic,copy)NSString*money;
@end

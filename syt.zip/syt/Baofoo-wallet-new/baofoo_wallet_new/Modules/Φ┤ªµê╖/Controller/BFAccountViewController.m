//
//  BFAccountViewController.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/15.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFAccountViewController.h"
#import <objc/runtime.h>
#import "BFAccountViewCell.h"
#import "BFHeaderView.h"
#import "BFCoreDataModelop.h"
#import "BFAccountViewData.h"
#import "BFLoginViewController.h"
#import "BFWebViewController.h"
#import "BFLoginTool.h"
#import "BFRequestURLConfigHeader.h"
#import "moreViewController.h"
#import "BFUserInfoViewController.h"
#define ImageHight         (_iPhone6P_ ? 192 : 148)
@interface BFAccountViewController ()<UITableViewDelegate,BFHeaderViewDelegate,UIAlertViewDelegate>
{
    NSArray *_titleArray,*_imageArray,*_classArray;
    UIView*_backGroundView,*_footLogoView;
}
@end

@implementation BFAccountViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    _headerView.backgroundColor = [UIColor getCurrentAppSystemColor];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:NO];
    [_headerView addDataSource:nil];
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginSucessful) name:LoginNotificationSuccess object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(logoutSucessful) name:LoginOutNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(headImageRefresh:) name:LoginNotificationHeadImageDownloadSuccess object:nil];
    
    _titleArray = [BFAccountViewData getAccountList];
    _backGroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    _accountTableView.backgroundView = _backGroundView;
    CGRect tableFrame = CGRectMake(0, ImageHight, ScreenWidth, ScreenHeight -49 -64 -ImageHight);
    _accountTableView.frame = tableFrame;
    _headerView = [[BFHeaderView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ImageHight) WithLogin:[[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isLoginSuccess boolValue]];;
    _headerView.delegate = self;
    [_backGroundView addSubview:_headerView];
    
    _accountTableView.contentInset = UIEdgeInsetsMake(ImageHight, 0, 0, 0);
    
    // 页脚logo
    _footLogoView = [[UIView alloc] initWithFrame:CGRectMake(0, _accountTableView.frame.size.height + 65, [UIScreen mainScreen].bounds.size.width, 65)];
    _footLogoView.backgroundColor = [UIColor clearColor];
    UIImage *img = [UIImage imageNamed:@"footlogo"];
    UIImageView *footImg = [[UIImageView alloc] initWithImage:img];
    CGRect f = CGRectMake(0, 0, ScreenWidth, 25);
    footImg.frame = f;
    [_footLogoView addSubview:footImg];
    UILabel *tel = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(footImg.frame)+10, ScreenWidth, 20)];
    tel.text = @"客服电话：021-68811008";
    [tel setFont:BF_Font_12];
    [tel setTextColor:[UIColor blackColor]];
    [tel setTextAlignment:NSTextAlignmentCenter];
    [_footLogoView addSubview:tel];
    
    UILabel *gsName = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(tel.frame)+7, ScreenWidth, 20)];
    gsName.text = @"宝付网络科技（上海）有限公司";
    [gsName setFont:BF_Font_12];
    [gsName setTextColor:[UIColor grayColor]];
    [gsName setTextAlignment:NSTextAlignmentCenter];
    [_footLogoView addSubview:gsName];
    
    [_accountTableView addSubview:_footLogoView];
    
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (_titleArray.count) {
        return _titleArray.count;
    }
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section == 2) {
        return 0.01;
    }
    else{
        return 10;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ([_titleArray[section] count]) {
       return [_titleArray[section] count];;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *myCell = @"BfCellIndifer";
    BFAccountViewCell*cell = [tableView dequeueReusableCellWithIdentifier:myCell];
    if (!cell) {
        cell = [[BFAccountViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:myCell];
    }
    //右边箭头
    UIImage *image = [UIImage imageNamed:@"account_detail"];
    CGRect frame = CGRectMake(0, 0, image.size.width, image.size.height);
    UIImageView *checkmarkImageView = [[UIImageView alloc]initWithImage:image];
    checkmarkImageView.frame = frame;
    checkmarkImageView.backgroundColor = [UIColor clearColor];
    cell.accessoryView = checkmarkImageView;
    
    BFAccountViewCellModel*model = [[BFAccountViewCellModel alloc] init];
    [model setValuesForKeysWithDictionary:_titleArray[indexPath.section][indexPath.row]];
    cell.model = model;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self performSelector:@selector(deselect) withObject:nil afterDelay:0.1f];
    if ([BFLoginTool checkLogin]) {
        NSString*className = _titleArray[indexPath.section][indexPath.row][@"className"];
        Class cla = NSClassFromString(className);
        UIViewController*controller = nil;
        if (![className isEqualToString:@"BFWebViewController"]) {
            controller = [(UIViewController*)[cla alloc] init];
            NSLog(@"cla = %@",cla);
            NSLog(@"controller  = %@",controller);
        }
        else {
            if((indexPath.section == 0)&&(indexPath.row == 1))
            {
                BFWebViewController*webView = [(BFWebViewController*)[cla alloc] init];
                webView.urlStr = [NSString stringWithFormat:@"%@%@",BFWalletBaseURL,wallet_zd];
                controller = webView;
            }
            else if((indexPath.section == 1)&&(indexPath.row == 1))
            {
                BFWebViewController*webView = [(BFWebViewController*)[cla alloc] init];
                webView.urlStr = [NSString stringWithFormat:@"%@%@",BFWalletBaseURL,myAccount_bankList];
                controller = webView;
            }
            
        }
        [self.navigationController pushViewController:controller animated:YES];
    }
    else {
        [BFLoginTool toLoginWithAccountName:nil];
    }
}


- (void)loginSucessful {
    [_headerView addDataSource:nil];
}
- (void)headImageRefresh:(NSNotification *)sender{
    [_headerView addDataSource:sender.userInfo[@"img"]];
}
- (void)logoutSucessful {
    [_headerView clearData];
}

- (void)loginFailed {
    
}
- (void)deselect
{
    [_accountTableView deselectRowAtIndexPath:[_accountTableView indexPathForSelectedRow] animated:YES];
}
#pragma mark - account backView delegate

-(void)clickedMore{
    if ([BFLoginTool checkLogin]) {
        moreViewController *more = [[moreViewController alloc] init];
        more.delegate = self;
        [self.navigationController pushViewController:more animated:YES];
    }
    else {
        [BFLoginTool toLoginWithAccountName:nil];
    }
    
}

-(void)clickedLoginBtn {
    [BFLoginTool toLoginWithAccountName:nil];
}

-(void)clickedNewsCenter{
    
}

-(void)clickedHeaderImage{
    if ([BFLoginTool checkLogin]) {
        BFUserInfoViewController *userInfoVc = [[BFUserInfoViewController alloc] init];
        [self.navigationController pushViewController:userInfoVc animated:YES];
    }
    else {
        [BFLoginTool toLoginWithAccountName:nil];
    }
}

#pragma mark - scrollView
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat y = scrollView.contentOffset.y;
    if (y <= -ImageHight) {
        CGRect frame = _headerView.frame;
        frame.origin.y = frame.origin.y;
        frame.size.height =  -y;
        _headerView.frame = frame;
        [_headerView setBgviewFrame:frame];
    }
}
-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView*footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 10)];
    footView.backgroundColor = [UIColor colorWithRed:239.0f/255.0f green:239.0f/255.0f blue:244.0f/255.0f alpha:1.0f];
    return footView;
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView*footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 10)];
    footView.backgroundColor = [UIColor colorWithRed:239.0f/255.0f green:239.0f/255.0f blue:244.0f/255.0f alpha:1.0f];
    return footView;
}


@end

//
//  ExamplePhotoViewController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/16.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

typedef enum
{
    ExamplePhotoSampleStyle = 0,//点击示例时弹出
    ExamplePhotoTakeStyle = 1//照相时弹出
}ExamplePhotoStyle;

@protocol ExamplePhotoViewDelegate <NSObject>

@optional
- (void)uploadImageWithArray:(NSArray *)imageArr;

@end

@interface ExamplePhotoViewController : BFBaseViewController
@property(nonatomic,assign)ExamplePhotoStyle  exampleStyle;//样式
@property(nonatomic,assign)id<ExamplePhotoViewDelegate>delegate;
@end

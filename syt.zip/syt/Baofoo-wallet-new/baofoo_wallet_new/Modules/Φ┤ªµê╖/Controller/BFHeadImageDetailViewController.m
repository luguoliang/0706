//
//  BFHeadImageDetailViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFHeadImageDetailViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>

@interface BFHeadImageDetailViewController ()<UIActionSheetDelegate>

@property (nonatomic, weak) UIImageView *headImageView;
@property (nonatomic, strong) UIActionSheet *actionSheet;

@end

@implementation BFHeadImageDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view setBackgroundColor:[UIColor blackColor]];
    
    [self instituteSubviews];
    [self constrainSubviewsLayout];
    [self modifySubviewsPattern];
    [self addActionAndNotification];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - View

- (void)instituteSubviews {
    //Init Subviews
    UIImageView *headImageView = [[UIImageView alloc]init];
    //Weak Point
    _headImageView = headImageView;
    //Add Subviews
    [self.view addSubview:_headImageView];
}

- (void)constrainSubviewsLayout {
    //Set autorizingMask
    [_headImageView setTranslatesAutoresizingMaskIntoConstraints:NO];
    //AutoLayout VF
    NSDictionary *views = NSDictionaryOfVariableBindings(_headImageView);
    NSDictionary *metrics = @{@"width":[NSString stringWithFormat:@"%f",ScreenWidth]
                              };
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[_headImageView(width)]" options:0 metrics:metrics views:views]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[_headImageView(width)]" options:0 metrics:metrics views:views]];
    //
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:_headImageView attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:_headImageView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0]];
    
}

- (void)modifySubviewsPattern {
    //Modify Pattern
    UIImage *img = [UIImage imageWithData:[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].accountImage];
    if (img) {
        _headImageView.image = img;
    }
    else {
        _headImageView.image = [UIImage imageNamed:@"face_nor"];
    }
    [_headImageView setUserInteractionEnabled:YES];
    //
    _actionSheet = [[UIActionSheet alloc]init];
    [_actionSheet addButtonWithTitle:@"保存图片到相册"];
    [_actionSheet addButtonWithTitle:@"取消"];
    [_actionSheet setDelegate:self];
    
}

- (void)addActionAndNotification {
    //Gesture
    UITapGestureRecognizer *tapOnHeadImage = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(gestureTapOnHeadImage)];
    UILongPressGestureRecognizer *longPressOnHeadImage = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(gestureLongPressOnHeadImage)];
    [_headImageView addGestureRecognizer:tapOnHeadImage];
    [_headImageView addGestureRecognizer:longPressOnHeadImage];
}

- (void)gestureTapOnHeadImage {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)gestureLongPressOnHeadImage {
    [_actionSheet showInView:self.view];
}


#pragma mark - ActionSheetDelegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    switch (buttonIndex) {
        case 0:
            UIImageWriteToSavedPhotosAlbum(_headImageView.image, nil, nil, nil);
            break;
        case 1:
            break;
            
        default:
            break;
    }
}

@end

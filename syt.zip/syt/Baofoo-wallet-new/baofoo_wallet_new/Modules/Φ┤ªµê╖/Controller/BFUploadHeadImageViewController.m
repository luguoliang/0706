//
//  BFUploadHeadImageViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFUploadHeadImageViewController.h"
#import "BFHeadImageAdjustViewController.h"
#import "BFHeadImageDetailViewController.h"
#import <Photos/PHPhotoLibrary.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <AVFoundation/AVFoundation.h>
#import <SDWebImage/UIImageView+WebCache.h>
#import "BFReqAPI+Account.h"

@interface BFUploadHeadImageViewController () <UINavigationControllerDelegate, UIImagePickerControllerDelegate, BFHeadImageAdjustViewControllerDelegate>

@property (nonatomic, weak) UIImageView *image;
@property (nonatomic, weak) UITableViewCell *albumCell;
@property (nonatomic, weak) UITableViewCell *cameraCell;
@property (nonatomic, weak) UIView *line;

@end

static const CGFloat ORIGINAL_MAX_WIDTH = 640.0f;

@implementation BFUploadHeadImageViewController

#pragma mark - Life Cycle

- (void)viewDidLoad{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //
    [self setTitle:@"设置头像"];
    //
    [self instituteSubviews];
    [self constrainSubviewsLayout];
    [self modifySubviewsPattern];
    [self addActionAndNotification];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UI

- (void)instituteSubviews {
    //Init Subviews
    UIImageView *image = [[UIImageView alloc]init];
    UITableViewCell *albumCell = [[UITableViewCell alloc]init];
    UITableViewCell *cameraCell = [[UITableViewCell alloc]init];
    UIView *line = UILineDefaultCreate(0, 0, 0);
    
    //Add Subviews
    [self.view addSubview:image];
    [self.view addSubview:albumCell];
    [self.view addSubview:cameraCell];
    [self.view addSubview:line];
    //Weak Point
    _image = image;
    _albumCell = albumCell;
    _cameraCell = cameraCell;
    _line = line;
}

- (void)constrainSubviewsLayout {
    //Set autorizingMask
    [_image setTranslatesAutoresizingMaskIntoConstraints:NO];
    [_albumCell setTranslatesAutoresizingMaskIntoConstraints:NO];
    [_cameraCell setTranslatesAutoresizingMaskIntoConstraints:NO];
    [_line setTranslatesAutoresizingMaskIntoConstraints:NO];
    //AutoLayout
    NSDictionary *viws = NSDictionaryOfVariableBindings(_image,_albumCell,_cameraCell,_line);
    NSDictionary *metric = @{
                             };
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:_image attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:_image attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeWidth multiplier:0.5 constant:0]];
    [_image addConstraint:[NSLayoutConstraint constraintWithItem:_image attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:_image attribute:NSLayoutAttributeWidth multiplier:1.0 constant:0]];
    
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-40-[_image]-40-[_albumCell(44)][_line(0.5)][_cameraCell(44)]" options:0 metrics:metric views:viws]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[_albumCell]|" options:0 metrics:metric views:viws]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-40-[_line]-|" options:0 metrics:metric views:viws]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[_cameraCell]|" options:0 metrics:metric views:viws]];
    
    
    
}

- (void)modifySubviewsPattern {
    //
    UIImage *img = [UIImage imageWithData:[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].accountImage];
    if (img) {
        _image.image = img;
    }
    else {
        _image.image = [UIImage imageNamed:@"face_nor"];
    }
    [_image setBackgroundColor:[UIColor clearColor]];
    [_image.layer setCornerRadius:(self.view.bounds.size.width/4)];
    [_image.layer setMasksToBounds:YES];
    [_image setContentMode:UIViewContentModeScaleAspectFill];
    [_image setClipsToBounds:YES];
    _image.layer.borderColor = [BF_Color_TextDescription colorWithAlphaComponent:0.5].CGColor;
    _image.layer.borderWidth = 0.3;
    [_image setUserInteractionEnabled:YES];
    //相册cell样式
    [_albumCell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    [_albumCell.textLabel setText:@"从相册选一张"];
    [_albumCell.imageView setImage:[UIImage imageNamed:@"account_headImg_picture"]];
    [_albumCell setUserInteractionEnabled:YES];
    [_albumCell setBackgroundColor:[UIColor whiteColor]];
    //拍照cell样式
    [_cameraCell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    [_cameraCell.textLabel setText:@"拍一张照片"];
    [_cameraCell.imageView setImage:[UIImage imageNamed:@"account_headImg_photo"]];
    [_cameraCell setUserInteractionEnabled:YES];
    [_cameraCell setBackgroundColor:[UIColor whiteColor]];
    
    
}

#pragma mark - Action

- (void)addActionAndNotification {
    //Action
    UITapGestureRecognizer *gestureOnAlbumCell = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGestureOnAlbumCell:)];
    [_albumCell addGestureRecognizer:gestureOnAlbumCell];
    UITapGestureRecognizer *gestureOnCameraCell = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGestureOnCameraCell:)];
    [_cameraCell addGestureRecognizer:gestureOnCameraCell];
    UITapGestureRecognizer *gestureOnHeadImage = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGestureOnHeadImage:)];
    [_image addGestureRecognizer:gestureOnHeadImage];
    
    
}

- (void)tapGestureOnAlbumCell:(UITableViewCell *)cell {
    
    if ([self isPhotoLibraryAvailable] && [self requestForPhotoAuthorization]) {
        //加入媒体类型
        NSMutableArray *mediaTypes = [[NSMutableArray alloc] init];
        [mediaTypes addObject:(__bridge NSString *)kUTTypeImage];
        //生成选择界面
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        controller.mediaTypes = mediaTypes;
        [controller.navigationBar setShadowImage:[[UIImage alloc] init]];
        [controller.navigationBar setBackgroundImage:[UIImage imageNamed:@"navbar_white_bg"] forBarMetrics:UIBarMetricsDefault];
        //设置title文字颜色、大小
        [controller.navigationBar setTintColor:BF_Color_TextContent];
        [controller.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:BF_Color_TextContent,
                                                           NSFontAttributeName:BF_Font_NavTitle}];
        
        controller.delegate = self;
        [self presentViewController:controller animated:YES completion:^(void){}];
    }
    else {
        
        [BlockAlert showWithMessage:Alert_Message_PhotographAuth operation:nil];
    }
}

- (void)tapGestureOnCameraCell:(UITableViewCell *)cell {
    // 拍照
    if ([self isCameraAvailable] && [self doesCameraSupportTakingPhotos] && [self requestForCameraAuthorization]) {
        //设置媒体类型
        NSMutableArray *mediaTypes = [[NSMutableArray alloc] init];
        [mediaTypes addObject:(__bridge NSString *)kUTTypeImage];
        //弹出选择界面
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.sourceType = UIImagePickerControllerSourceTypeCamera;
        controller.mediaTypes = mediaTypes;
        [controller.navigationBar setTintColor:[UIColor whiteColor]];
        [controller.navigationBar setTintColor:[UIColor whiteColor]];
        [controller.navigationBar setShadowImage:[[UIImage alloc] init]];
        [controller.navigationBar setBackgroundImage:[UIImage imageNamed:@"navbar_bg"] forBarMetrics:UIBarMetricsDefault];
        controller.delegate = self;
        if ([self isFrontCameraAvailable]) {
            controller.cameraDevice = UIImagePickerControllerCameraDeviceFront;
        }
        [self presentViewController:controller animated:YES completion:^(void){}];
    }else {
        
        [UIAlertView showWithTitle:Alert_Title_CameraAuth message:Alert_Message_CameraAuth delegate:self cancelButtonTitle:Alert_Button_Confirm otherButtonTitles:nil];
    }
}

- (void)tapGestureOnHeadImage:(UITableViewCell *)cell {
    if (![[BFCoreDataModelop sharedManager] getCurrentBFuserModel].accountImage) {
        return;
    }
    BFHeadImageDetailViewController *headImgDetailVC = [[BFHeadImageDetailViewController alloc]init];
    [self.navigationController pushViewController:headImgDetailVC animated:YES];
}

- (BOOL)requestForPhotoAuthorization {
    //创建一个信号
    dispatch_semaphore_t sema = dispatch_semaphore_create(0);
    __block BOOL result = TRUE;
    //
    if ([[UIDevice currentDevice].systemVersion floatValue] >= 8.0) {
        [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
            switch (status) {
                case PHAuthorizationStatusDenied:
                    result = FALSE;
                    break;
                default:
                    break;
            }
            dispatch_semaphore_signal(sema);
        }];
        dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
        return result;
        
    }else {
        ALAuthorizationStatus status = [ALAssetsLibrary authorizationStatus];
        switch (status) {
            case ALAuthorizationStatusDenied:
                result = FALSE;
                break;
            default:
                break;
        }
        
    }
    return result;
}

- (BOOL)requestForCameraAuthorization {
    //创建一个信号
    dispatch_semaphore_t sema = dispatch_semaphore_create(0);
    //申请接入闭包
    [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
        //接入成功发送信号
        dispatch_semaphore_signal(sema);
    }];
    //信号开始是0 发送出一个信号变成-1 信号值小于0时继续执行,如果没有得到信号,等待FOREVER
    dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
    //检查是否成功创建
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    switch (status) {
        case AVAuthorizationStatusDenied:
            return FALSE;
            break;
        default:
            break;
    }
    return TRUE;
}

#pragma mark - Camera Check

- (BOOL)isPhotoLibraryAvailable {
    return [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary];//判断是否支持相册
}

- (BOOL)isCameraAvailable {
    return [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera];//判断是否支持相机
}

- (BOOL)isRearCameraAvailable {
    return [UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear];//判断是否支持后置摄像头
}

- (BOOL)isFrontCameraAvailable {
    return [UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceFront];//判断是否支持前置摄像头
}

- (BOOL)doesCameraSupportTakingPhotos {
    return [self cameraSupportsMedia:(__bridge NSString *)kUTTypeImage sourceType:UIImagePickerControllerSourceTypeCamera];//是否支持拍摄某一种相片,此处用的是默认的所有格式
}

- (BOOL)canUserPickVideosFromPhotoLibrary {
    return [self
            cameraSupportsMedia:(__bridge NSString *)kUTTypeMovie sourceType:UIImagePickerControllerSourceTypePhotoLibrary];//是否支持在相册里选取电影
}

- (BOOL)canUserPickPhotosFromPhotoLibrary {
    return [self
            cameraSupportsMedia:(__bridge NSString *)kUTTypeImage sourceType:UIImagePickerControllerSourceTypePhotoLibrary];//是否支持在相册里选取图片
}

- (BOOL)cameraSupportsMedia:(NSString *)paramMediaType sourceType:(UIImagePickerControllerSourceType)paramSourceType{
    __block BOOL result = NO;
    if ([paramMediaType length] == 0) {
        return NO;
    }
    NSArray *availableMediaTypes = [UIImagePickerController availableMediaTypesForSourceType:paramSourceType];
    [availableMediaTypes enumerateObjectsUsingBlock: ^(id obj, NSUInteger idx, BOOL *stop) {
        NSString *mediaType = (NSString *)obj;
        if ([mediaType isEqualToString:paramMediaType]){
            result = YES;
            *stop= YES;
        }
    }];
    return result;
}//遍历SourceType中是否支持某一种格式

#pragma mark - BFHeadImageAdjustViewControllerDelegate

- (void)headImgAdjust:(BFHeadImageAdjustViewController *)controller didFinished:(UIImage *)editedImage{
    [self showProgress];
    
    //对图像进行压缩处理
    CGSize size = CGSizeMake(300, 300);
    UIGraphicsBeginImageContext(size);
    [editedImage drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage *newImg = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    NSData *headImgData = UIImageJPEGRepresentation(newImg, 1.0);
    
    [BFReqAPI uploadImageWithMemberId:[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].memberId image:newImg block:^(id responseObj, NSError *error) {
        [self hideProgress];
        if ([responseObj[@"success"] boolValue]) {
            [_image setImage:editedImage];
            BFCoreUserModel *m = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel];
            m.accountImage = headImgData;
        }
        else {
            [BlockAlert showWithMessage:responseObj[@"message"] operation:nil];
        }
    }];
    [controller dismissViewControllerAnimated:YES completion:^{}];
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    //取出图片
    UIImage *portraitImg = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    portraitImg = [self imageByScalingToMaxSize:portraitImg];
    // 进入裁剪
    BFHeadImageAdjustViewController *imgEditorVC = [[BFHeadImageAdjustViewController alloc] initWithImage:portraitImg];
    imgEditorVC.delegate = self;
    [picker pushViewController:imgEditorVC animated:YES];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:^(){}];
}

#pragma mark - UINavigationControllerDelegate

//防止ImagePickerController偷换StatusBar
- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
    if ([navigationController isKindOfClass:[UIImagePickerController class]] &&((UIImagePickerController *) navigationController).sourceType == UIImagePickerControllerSourceTypePhotoLibrary) {
        //        [viewController.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"navbar_bg"] forBarMetrics:UIBarMetricsDefault];
        //        [viewController.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:BF_Color_NavTitle,
        //                                                                                    NSFontAttributeName:BF_Font_NavTitle}];
        //
        //
        //        [viewController.navigationController.navigationBar setBackgroundColor:[UIColor blackColor]];
        //        [[UIApplication sharedApplication] setStatusBarHidden:NO];
        //        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:NO];
    }
}

#pragma mark - Image Scale Modify

- (UIImage *)imageByScalingToMaxSize:(UIImage *)sourceImage {
    if (sourceImage.size.width < ORIGINAL_MAX_WIDTH) return sourceImage;
    CGFloat btWidth = 0.0f;
    CGFloat btHeight = 0.0f;
    //如果照片是横向的
    if (sourceImage.size.width > sourceImage.size.height) {
        //分辨率高等于最大宽度
        btHeight = ORIGINAL_MAX_WIDTH;
        //按照高的比率计算宽
        btWidth = sourceImage.size.width * (ORIGINAL_MAX_WIDTH / sourceImage.size.height);
    } else {
        //分辨率宽等于最大宽度
        btWidth = ORIGINAL_MAX_WIDTH;
        //按照宽的比率计算高
        btHeight = sourceImage.size.height * (ORIGINAL_MAX_WIDTH / sourceImage.size.width);
    }
    //调整后大小
    CGSize targetSize = CGSizeMake(btWidth, btHeight);
    //按照调整后大小剪切一次
    return [self imageByScalingAndCroppingForSourceImage:sourceImage targetSize:targetSize];
}

- (UIImage *)imageByScalingAndCroppingForSourceImage:(UIImage *)sourceImage targetSize:(CGSize)targetSize {
    UIImage *newImage = nil;
    //取出原图大小
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    //变化后的大小
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
    if (CGSizeEqualToSize(imageSize, targetSize) == NO)
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        //取宽和高比率较高的为变化因子ScaleFactor
        if (widthFactor > heightFactor)
            scaleFactor = widthFactor; // scale to fit height
        else
            scaleFactor = heightFactor; // scale to fit width
        scaledWidth  = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        
        //移动图片到中心
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }
        else
            if (widthFactor < heightFactor)
            {
                thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
            }
    }
    UIGraphicsBeginImageContext(targetSize); // this will crop
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width  = scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    
    [sourceImage drawInRect:thumbnailRect];
    
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil) NSLog(@"could not scale image");
    //pop the context to get back to the default
    UIGraphicsEndImageContext();
    return newImage;
}


@end

//
//  ExamplePhotoViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/16.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "ExamplePhotoViewController.h"
#import "WBCameraViewController.h"

@interface ExamplePhotoViewController ()<WBCameraViewControllerDelegate>
@property(nonatomic,strong)UIImageView *cardFontImageView;
@property(nonatomic,strong)UIImageView *cardBackImageView;
@property(nonatomic,strong)UILabel *promptLabel1;
@property(nonatomic,strong)UILabel *promptLabel2;
@property(nonatomic,strong)UIButton *takePhotoBtn;
@end

@implementation ExamplePhotoViewController
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if (self.exampleStyle == ExamplePhotoSampleStyle) {
        self.title = @"示例";
        self.view.backgroundColor = [UIColor whiteColor];
        
    }else
    {
        self.navigationController.navigationBarHidden = YES;
        self.view.backgroundColor = [UIColor blackColor];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.promptLabel1];
    [self.view addSubview:self.cardFontImageView];
    [self.view addSubview:self.promptLabel2];
    [self.view addSubview:self.cardBackImageView];
    if (self.exampleStyle == ExamplePhotoTakeStyle) {
        [self.view addSubview:self.takePhotoBtn];
    }
}
#pragma mark--CreatUI
- (UILabel *)promptLabel1
{
    if (!_promptLabel1) {
        _promptLabel1 = [[UILabel alloc] init];
        _promptLabel1.font = FONT(15.0f);
        if (self.exampleStyle == ExamplePhotoSampleStyle) {
            _promptLabel1.frame = CGRectMake(15.0f, 0.0f, ScreenWidth-30.0f, 68.0f);
            _promptLabel1.text = @"请按下方示例拍摄2张实人证件照，照片越清晰，通过率越高喔";
            _promptLabel1.textColor = [UIColor blackColor];
        }else if(self.exampleStyle == ExamplePhotoTakeStyle)
        {
            _promptLabel1.frame = CGRectMake(15.0f, 20.0f, ScreenWidth-30.0f, 68.0f);
            _promptLabel1.textColor = [UIColor whiteColor];
            
            NSString *promptString = @"请确保身份证正反面信息清楚";
            NSRange range = [promptString rangeOfString:@"身份证正反面"];
            NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:promptString];
            [str addAttribute:NSForegroundColorAttributeName value:COLOR_HEXSTRING(ORANGE_COLOR) range:NSMakeRange(range.location, range.length)];
            _promptLabel1.attributedText = str;
            _promptLabel1.textAlignment = NSTextAlignmentCenter;
            
            CGFloat promptLabelWidth = [UILabel width:promptString heightOfFatherView:_promptLabel1.frame.size.height textFont:_promptLabel1.font];
            _promptLabel1.frame = CGRectMake((ScreenWidth-promptLabelWidth)*0.5, 20.0f, promptLabelWidth, _promptLabel1.frame.size.height);
            
            UIImage *promptImage = [UIImage imageNamed:@"prompt_take_photo"];
            UIImageView *promptImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, promptImage.size.width, promptImage.size.height)];
            promptImageView.center = CGPointMake(_promptLabel1.center.x-promptLabelWidth*0.5-5-promptImage.size.width*0.5, _promptLabel1.center.y);
            promptImageView.image = promptImage;
            [self.view addSubview:promptImageView];
            
            
        }
        _promptLabel1.numberOfLines = 0;
        
    }
    return _promptLabel1;
}
- (UILabel *)promptLabel2
{
    if (!_promptLabel2) {
        _promptLabel2 = [[UILabel alloc] init];
        _promptLabel2.font = FONT(15.0f);
        if (self.exampleStyle == ExamplePhotoSampleStyle) {
            _promptLabel2.frame = CGRectMake(15.0f, self.cardFontImageView.frame.size.height+self.cardFontImageView.frame.origin.y, ScreenWidth-30.0f, 15.0f);
        }else if(self.exampleStyle == ExamplePhotoTakeStyle)
        {
            _promptLabel2.frame = CGRectMake(15.0f, self.cardFontImageView.frame.size.height+self.cardFontImageView.frame.origin.y, ScreenWidth-30.0f, 12.0f);
            
        }
    }
    return _promptLabel2;
}
- (UIImageView *)cardFontImageView
{
    if (!_cardFontImageView) {
        _cardFontImageView = [[UIImageView alloc] initWithFrame:CGRectMake(15.0f, self.promptLabel1.frame.origin.y+self.promptLabel1.frame.size.height, ScreenWidth-30.0f, (ScreenWidth -30.0f)*0.6724138)];
        _cardFontImageView.image = [UIImage imageNamed:@"hsq_account_card_font"];
    }
    return _cardFontImageView;
}

- (UIImageView *)cardBackImageView
{
    if (!_cardBackImageView) {
        _cardBackImageView = [[UIImageView alloc] initWithFrame:CGRectMake(15.0f, self.promptLabel2.frame.origin.y+self.promptLabel2.frame.size.height, ScreenWidth-30.0f, (ScreenWidth -30.0f)*0.67)];
        _cardBackImageView.image = [UIImage imageNamed:@"hsq_account_card_back"];
    }
    return _cardBackImageView;
}
- (UIButton *)takePhotoBtn
{
    if (!_takePhotoBtn) {
        _takePhotoBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        _takePhotoBtn.frame = CGRectMake(15.0f, ScreenHeight-60.0f, ScreenWidth-30.0f, 40);
        _takePhotoBtn.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _takePhotoBtn.layer.cornerRadius = 20.0f;
        [_takePhotoBtn setTitle:@"我了解了，立即去拍照" forState:UIControlStateNormal];
        [_takePhotoBtn setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f] forState:UIControlStateNormal];
        _takePhotoBtn.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [_takePhotoBtn addTarget:self action:@selector(autoSkipByFiveSecond) forControlEvents:UIControlEventTouchUpInside];
    }
    return _takePhotoBtn;
}

//2秒后自动跳转
- (void)autoSkipByFiveSecond
{
    WBCameraViewController *cameraVC = [[WBCameraViewController alloc] init];
    cameraVC.delegate = self;
    [self.navigationController pushViewController:cameraVC animated:YES];
}
- (void)updataImageWithArray:(NSArray *)imageArr
{
    NSLog(@"im %@",imageArr);
    if ([self.delegate respondsToSelector:@selector(uploadImageWithArray:)]) {
        [self.delegate uploadImageWithArray:imageArr];
    }
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (self.exampleStyle == ExamplePhotoTakeStyle) {
        
        [self autoSkipByFiveSecond];
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  moreViewController.h
//  system_test_demo_baofoo
//
//  Created by zhouwufeng on 16/4/26.
//  Copyright © 2016年 baofoo.com. All rights reserved.
//

#import "BFBaseViewController.h"
@interface moreViewController : BFBaseViewController
@property (assign, nonatomic) id delegate;
@end

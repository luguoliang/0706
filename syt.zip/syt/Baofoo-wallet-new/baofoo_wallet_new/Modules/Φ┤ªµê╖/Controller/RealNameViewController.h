//
//  RealNameViewController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"
typedef enum
{
    RealNamePrimaryPeopleStyle = 1,//1初级实名认证
    RealNameHighPeopleExamineStyle = 2,//2高级实人审核中
    RealNameHignPeopleExamineNoPassStyle = 3,//3高级实人审核不通过
    RealNameHignPeopleStyle = 4,//4高级实人
    RealNamePrimaryMoneyStyle = 5,//5初级理财账户
    RealNameHighMoneyStyle = 6,//6高级理财账户
    RealNameHighMoneyExamineNoPassStyle = 7,//7高级理财账户不通过
    RealNameHighMoneyExamineStyle = 8//8高级理财账户审核中
}RealNameStyle;
@interface RealNameViewController : BFBaseViewController

@property(nonatomic,assign)RealNameStyle realNameStyle;
@end

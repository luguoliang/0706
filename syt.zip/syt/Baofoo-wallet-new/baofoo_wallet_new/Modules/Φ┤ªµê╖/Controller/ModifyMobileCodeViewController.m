//
//  ModifyMobileCodeViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/6/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "ModifyMobileCodeViewController.h"
#import "ModifyMobileResetViewController.h"

#import "BFReqAPI+Security.h"
#import "CustomTimerButtom.h"
@interface ModifyMobileCodeViewController ()
@property(nonatomic,strong)UILabel *topLabel;//提示文字
@property(nonatomic,strong)UITextField *messgeField;//验证码
@property(nonatomic,strong)CustomTimerButtom *messgeButton;//验证码按钮
@property(nonatomic,strong)UIButton *certainButton;//确定按钮
@end

@implementation ModifyMobileCodeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"修改绑定手机";
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    [self.view addSubview:self.topLabel];
    [self.view addSubview:self.messgeField];
    [self.view addSubview:self.certainButton];
}
#pragma mark--CreatUI
- (UILabel *)topLabel
{
    if (!_topLabel) {
        _topLabel = [[UILabel alloc] initWithFrame:CGRectMake(18.0f, 0.0f, ScreenWidth, 30.0f)];
        _topLabel.textColor = COLOR_HEXSTRING(@"#aaaaaa");
        _topLabel.font = FONT(13.0f);
        NSString*mobileStr = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].mobile;
        _topLabel.text = [NSString stringWithFormat:@"请输入手机号%@收到的短信验证码",mobileStr];;
    }
    return _topLabel;
}
- (UITextField *)messgeField
{
    if (!_messgeField) {
        _messgeField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, self.topLabel.frame.size.height+self.topLabel.frame.origin.y, ScreenWidth, 50.0f)];
        _messgeField.backgroundColor = [UIColor whiteColor];
        _messgeField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 80.0f, 50.0f) text:@"验证码"];
        _messgeField.leftViewMode = UITextFieldViewModeAlways;
        _messgeField.placeholder = @"短信验证码";
        _messgeField.keyboardType =  UIKeyboardTypeNumbersAndPunctuation;;
        _messgeField.font = FONT(16.0f);
        
        _messgeButton = [CustomTimerButtom buttonWithType:UIButtonTypeCustom];
        _messgeButton.frame = CGRectMake(0.0f, 0.0f, 65.0f, 50.0f);
        [_messgeButton setTitle:@"获取" forState:UIControlStateNormal];
        [_messgeButton setTitleColor:COLOR_HEXSTRING(BLUE_COLOR) forState:UIControlStateNormal];
        _messgeButton.titleLabel.font = FONT(14.0f);
        [_messgeButton addTarget:self action:@selector(getCodeMethod:) forControlEvents:UIControlEventTouchUpInside];
        _messgeField.rightView = _messgeButton;
        _messgeField.rightViewMode = UITextFieldViewModeAlways;
        _messgeField.font = FONT(16.0f);
        
        [_messgeField addTarget:self action:@selector(textFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
        
        UILabel *topLine = [self lineLabelWithFrame:CGRectMake(0.0F, 0.0f, ScreenWidth, 0.5f)];
        [_messgeField addSubview:topLine];
        
        UILabel *bottomLine = [self lineLabelWithFrame:CGRectMake(0.0f, _messgeField.frame.size.height-0.5f, ScreenWidth, 0.5f)];
        [_messgeField addSubview:bottomLine];
    }
    return _messgeField;
}
- (UILabel *)lineLabelWithFrame:(CGRect)rect
{
    UILabel *label = [[UILabel alloc] initWithFrame:rect];
    label.backgroundColor = COLOR_HEXSTRING(LINE_COLOR);
    return label;
}
- (UIView *)leftViewLabelWithFrame:(CGRect)rect text:(NSString *)text
{
    UIView *leftView = [[UIView alloc] initWithFrame:rect];
    UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, rect.size.width, rect.size.height)];
    leftLabel.font = FONT(16.0f);
    leftLabel.textColor = COLOR_HEXSTRING(BLACK_COLOR);
    leftLabel.text = text;
    leftLabel.textAlignment = NSTextAlignmentCenter;
    [leftView addSubview:leftLabel];
    return leftView;
}
- (UIButton *)certainButton
{
    if (!_certainButton) {
        _certainButton = [UIButton buttonWithType:UIButtonTypeSystem];
        _certainButton.frame = CGRectMake(15.0f, self.messgeField.frame.origin.y+self.messgeField.frame.size.height+27.0f, ScreenWidth-30.0f, 40);
        _certainButton.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _certainButton.enabled = NO;
        _certainButton.layer.cornerRadius = 20.0f;
        [_certainButton setTitle:@"确认" forState:UIControlStateNormal];
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _certainButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [_certainButton addTarget:self action:@selector(certainMethod) forControlEvents:UIControlEventTouchUpInside];
    }
    return _certainButton;
}
#pragma mark--方法
- (void)backMethod
{
    [self.navigationController popViewControllerAnimated:self.navigationController.viewControllers[1]];
}
- (void)getCodeMethod:(CustomTimerButtom *)btn
{
    __weakself__
    [self showProgress];
    [BFReqAPI reqVerifyCodeSendWithType:@"1" andMsg_type:@"2" block:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        if (!weakself) return ;
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                [btn startTimer];
                [weakself.messgeField becomeFirstResponder];
            }else
            {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:nil];
            }
        }
    }];
}
- (void)textFieldValueChange:(UITextField *)textField
{
    if (textField.text.length >= 6) {
        self.messgeField.text = [self.messgeField.text substringToIndex:6];
    }
    if (self.messgeField.text.length == 6) {
        _certainButton.enabled = YES;
        [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f] forState:UIControlStateNormal];
    }else
    {
        if (self.messgeField.text.length == 6) {
            _certainButton.enabled = NO;
            [_certainButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        }
    }
}
- (void)certainMethod
{
    [self.view endEditing:YES];
    NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:self.messgeField.text,@"dynamicCode",nil];
    
    __weakself__
    [self showProgress];
    [BFReqAPI reqValiPhoneCodeAtModifyMobileWithParams:userInfo block:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        if (!weakself) return ;
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                weakself.messgeField.text = @"";
                ModifyMobileResetViewController *rebind = [[ModifyMobileResetViewController alloc] init];
                [weakself.navigationController pushViewController:rebind animated:YES];
            }else
            {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:nil];
            }
        }
    }];
}
- (void)dealloc
{
    [_messgeButton stopTimer];
    _messgeButton = nil;
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  customtextfield.h
//  account
//
//  Created by 路国良 on 15/7/20.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTextfield : UITextField

@end

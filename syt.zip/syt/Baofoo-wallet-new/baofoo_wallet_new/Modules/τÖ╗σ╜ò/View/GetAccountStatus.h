//
//  GetAccountStatus.h
//  BaofooWallet
//
//  Created by 路国良 on 16/3/15.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GetAccountStatus : NSObject
/*
 ifHavenOpenVerifyGesture//是否开启了手势密码(yes:开启)
 ifVerifiedThroughGestures//是否验通过，暂保留
 getAccountLandingStatus//获取账户这一时刻的登陆状态(yes:登陆)
 setAccountLandingStatus:(BOOL)status//（设置账户的登陆状态，yes:登陆）
 */
+(GetAccountStatus*)sharedManager;

-(BOOL)ifHavenOpenVerifyGesture;

-(BOOL)ifVerifiedThroughGestures;

-(BOOL)getAccountLandingStatus;

-(void)setAccountLandingStatus:(BOOL)status;

@end

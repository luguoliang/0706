//
//  GetAccountStatus.m
//  BaofooWallet
//
//  Created by 路国良 on 16/3/15.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import "GetAccountStatus.h"
#define LOGIN_STATUS_IDENTIFIER @"isLoginApp"
@implementation GetAccountStatus
+(GetAccountStatus*)sharedManager{
    static GetAccountStatus*getStatus = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        getStatus = [[super allocWithZone:NULL] init];
    });
    return getStatus;
}
+(instancetype)allocWithZone:(struct _NSZone *)zone{
    return [self sharedManager];
}

-(BOOL)ifHavenOpenVerifyGesture{
//    operationDB*db = [operationDB sharedManager];
//    NSString*memberid = [db GetmemberId];
//    if([memberid isEqualToString:@""])return NO;
//    NSMutableDictionary *gestureDict = [[NSMutableDictionary alloc] initWithContentsOfFile:GESTURE_PASSWORD];
//    if (gestureDict == nil) return NO;
//    NSString *isOpen = [[gestureDict objectForKey:memberid] objectForKey:USER_OPEN];
//    if ([isOpen intValue]==0) return NO;
    return YES;
}
-(BOOL)ifVerifiedThroughGestures{
    return NO;
}

-(BOOL)getAccountLandingStatus{
    BOOL loginStatus = [[NSUserDefaults standardUserDefaults] boolForKey:LOGIN_STATUS_IDENTIFIER];
    return loginStatus;
}

-(void)setAccountLandingStatus:(BOOL)status{
    [[NSUserDefaults standardUserDefaults] setBool:status forKey:LOGIN_STATUS_IDENTIFIER];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
@end

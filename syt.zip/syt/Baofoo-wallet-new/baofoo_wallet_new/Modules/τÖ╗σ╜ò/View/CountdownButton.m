//
//  CountdownButton.m
//  aaa
//
//  Created by 路国良 on 15/8/13.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "CountdownButton.h"

@interface CountdownButton()
{
    NSTimer*timer;
    NSInteger  loadinter;
}
@end

@implementation CountdownButton

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.titleLabel.font = [UIFont systemFontOfSize:15.0f];
    }
    return self;
}
-(void)countDownBegins
{
    if (!timer) {
        timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timerclick)
                                               userInfo:nil repeats:YES];

    }
    loadinter = 59;
    [self setUserInteractionEnabled:NO];
}
-(void)stopCountdown
{
    [timer invalidate];
    timer = nil;
    [self setTitle:@"获取" forState:UIControlStateNormal];
}
-(void)timerclick
{
    NSLog(@"定时器:%ld",(long)loadinter);
    if (loadinter>=0) {
        [self setTitle:[NSString stringWithFormat:@"%ld秒",(long)loadinter] forState:UIControlStateNormal];
        loadinter--;
    }

    else
    {
       [self setTitle:@"获取" forState:UIControlStateNormal];
        [self setUserInteractionEnabled:YES];
    }
}
@end

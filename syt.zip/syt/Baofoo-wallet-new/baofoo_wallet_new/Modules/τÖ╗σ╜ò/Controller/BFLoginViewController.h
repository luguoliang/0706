//
//  BFLoginViewController.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/19.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"
@interface BFLoginViewController : BFBaseViewController
@property(nonatomic,copy) NSString *accountName;
@end

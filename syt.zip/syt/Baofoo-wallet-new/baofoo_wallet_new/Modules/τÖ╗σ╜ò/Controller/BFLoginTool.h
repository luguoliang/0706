//
//  BFLoginTool.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/4/11.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

UIKIT_EXTERN NSString *const LoginNotificationSuccess;
UIKIT_EXTERN NSString *const LoginNotificationFailure;
UIKIT_EXTERN NSString *const LoginNotificationCancel;
UIKIT_EXTERN NSString *const RegisterNotificationSuccess;
UIKIT_EXTERN NSString *const LoginOutNotification;
UIKIT_EXTERN NSString *const LoginNotificationHeadImageDownloadSuccess;

typedef NS_ENUM(NSInteger, CheckResult) {
    CheckResultSessionValid = 0, //session有效
    CheckResultSessionInvalidAutoLoginSuccessed, //session失效&&自动登录成功
    CheckResultSessionInvalidAutoLoginFailed //session失效&&自动登录失败
};

@interface BFLoginTool : NSObject
/**
 *  判断是否已经登录
 */
+ (BOOL)loggedIn;

/**
 *  退出登录
 */
+ (void)logout;
+ (void)logoutAndClernSqlData;

/**
 *  检查是否登录，如未登录需要弹出登陆界面
 */
+ (BOOL)checkLogin;

//登录成功通知
+ (void)loginSuccessed:(NSNotification *)notif;

#pragma mark - 进入登录界面

/**
 *  从AppDeleagate.window.rootViewController 弹出登录界面
 */
+ (void)toLoginWithAccountName:(NSString *)accountName;
+ (void)showLoginAlert:(NSString *)message;

#pragma mark - 登录
// 跳手势密码登录
+ (void)pushGesturePwdView:(UINavigationController *)navc;
// 登录成功后的处理方法
+ (void)loginSuccessActionWith:(id)responseObj andViewController:(UIViewController *)vc isForExchangeAccount:(BOOL)isExchangeAccount isForRegister:(BOOL)isForRegister;


@end

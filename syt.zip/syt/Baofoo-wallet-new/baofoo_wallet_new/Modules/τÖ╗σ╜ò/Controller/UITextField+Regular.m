//
//  UITextField+Regular.m
//  BaofooMWallet
//
//  Created by 国良 on 14-12-12.
//  Copyright (c) 2014年 国良. All rights reserved.
//

#import "UITextField+Regular.h"
#import <Foundation/NSPredicate.h>
@implementation UITextField (Regular);
-(void)PasswordRegularOperation
{
    NSString *regex = @"^[A-Za-z0-9!@#$%^&:;?,<>.,|()'_/]{6,20}$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
#pragma mark  过滤纯字母
    NSString *regex1 = @"^[A-Za-z]{6,20}$";
    NSPredicate *pred1 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex1];
#pragma mark 过滤纯数字
    NSString *regex2 = @"^[0-9]{6,20}$";
    NSPredicate *pred2 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex2];
#pragma mark 过滤纯符号
    NSString *regex3 = @"^[!@#$%^&:;?,<>.,|()'_/]{6,20}$";
    NSPredicate *pred3 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex3];
    
    if(![pred evaluateWithObject:self.text])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:@"密码必须由6-20位字母,数 字或符号任意两种，或三种组成" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        alertView.backgroundColor = [UIColor grayColor];
        [alertView show];
//        [self performSelector:@selector(dismissAlert:) withObject:alertView afterDelay:2.0];
       self.text = nil;
    }
    
    else if([pred1 evaluateWithObject: self.text])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"密码必须由6-20位字母,数字或符号任意两种，或三种组成" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
//        [self performSelector:@selector(dismissAlert:) withObject:alertView afterDelay:2.0];
        self.text = nil;
        
    }
    
    else if([pred2 evaluateWithObject: self.text])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"密码必须由6-20位字母,数字或符号任意两种，或三种组成" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
//        [self performSelector:@selector(dismissAlert:) withObject:alertView afterDelay:2.0];
        self.text = nil;
    }
    
    else if([pred3 evaluateWithObject: self.text])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"密码必须由6-20位字母,数字或符号任意两种，或三种组成" message:nil  delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
//        [self performSelector:@selector(dismissAlert:) withObject:alertView afterDelay:1.5];
       self.text = nil;
    }

}
#pragma mark 自动消失
-(void)dismissAlert:(UIAlertView*)alert
{
    if (alert) {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
#pragma mark 验证码
-(void)RegularOperationCode
{
    NSString *regex0 = @"^[0-9]{6,6}$";
    NSPredicate *pred0 = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex0];
    if (![pred0 evaluateWithObject: self.text]) {
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"验证码格式错误" message:nil delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
        [alertView show];
//        [self performSelector:@selector(dismissAlert:) withObject:alertView afterDelay:1.5];
       self.text = nil;
    }
    

}
#pragma mark 安全问题
-(void)ForgotPasswordRegularPayments
{
    //NSString *regex = @"^[A-Za-z0-9!@#$%^&:;?,<>.,|()'_/]{1,50}$";
    //[\u4e00-\u9fa5_a-zA-Z0-9_]{4,10}
//    NSString *regex = @"[\u4e00-\u9fa5_a-zA-Z0-9_]{6,20}";
//    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
//    if(![pred evaluateWithObject:self.text])
//    {
//        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:@"安全问题格式错误，请重新输入" delegate:nil cancelButtonTitle:nil otherButtonTitles:nil, nil];
//        alertView.backgroundColor = [UIColor grayColor];
//        [alertView show];
//        [self performSelector:@selector(dismissAlert:) withObject:alertView afterDelay:2.0];
//        self.text = nil;
   // }
}
#pragma mark 手机号码正则
-(void)checkPhoneNumberInput
{
    NSString * MOBILE = @"^1(3[0-9]|5[0-35-9]|8[025-9])\\d{8}$";
    NSString * CM = @"^1(34[0-8]|(3[5-9]|5[017-9]|8[278])\\d)\\d{7}$";
    NSString * CU = @"^1(3[0-2]|5[256]|8[56])\\d{8}$";
    NSString * CT = @"^1((33|53|8[09])[0-9]|349)\\d{7}$";
    NSPredicate *regextestmobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", MOBILE];
    NSPredicate *regextestcm = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CM];
    NSPredicate *regextestcu = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CU];
    NSPredicate *regextestct = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", CT];
    if (![regextestmobile evaluateWithObject:self.text] && ![regextestcm evaluateWithObject:self.text] && ![regextestcu evaluateWithObject:self.text] && ![regextestct evaluateWithObject:self.text]) {
        
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:@"手机号码输入格式错误" delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
        alertView.backgroundColor = [UIColor grayColor];
        [alertView show];
        //[self performSelector:@selector(dismissAlert:) withObject:alertView afterDelay:2.0];
        self.text = nil;
    }
 }
#pragma mark 身份证号正则
-(void)checkIDnumber
{
    NSString *regex = @"^(\\d{14}|\\d{17})(\\d|[xX])$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    if(![pred evaluateWithObject:self.text])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:@"身份证号格式错误，请重新输入" delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
        alertView.backgroundColor = [UIColor grayColor];
        [alertView show];
        //[self performSelector:@selector(dismissAlert:) withObject:alertView afterDelay:2.0];
        self.text = nil;
    }

}
#pragma mark 金额正则表达式
-(void)amountOfRegularExpress
{
    NSString *regex = @"^[0-9]+(.[0-9]{2})?$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    if(![pred evaluateWithObject:self.text])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:@"请输入正确的金额，最多两位小数" delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
        alertView.backgroundColor = [UIColor grayColor];
        [alertView show];
        //[self performSelector:@selector(dismissAlert:) withObject:alertView afterDelay:2.0];
        self.text = nil;
    }

}


#pragma mark zhm 
-(void)checkAccountName
{
    NSString *regex = @"^(\\d{14}|\\d{17})(\\d|[xX])$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    if(![pred evaluateWithObject:self.text])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:@"身份证号格式错误，请重新输入" delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
        alertView.backgroundColor = [UIColor grayColor];
        [alertView show];
//        [self performSelector:@selector(dismissAlert:) withObject:alertView afterDelay:2.0];
        self.text = nil;
    }

}
@end

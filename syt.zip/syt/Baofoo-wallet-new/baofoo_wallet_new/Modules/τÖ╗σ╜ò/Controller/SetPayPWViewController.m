//
//  SetPayPWViewController.m
//  BaofooWallet
//
//  Created by 路国良 on 15/4/15.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import "SetPayPWViewController.h"
#import "SetLogInPWViewController.h"
#import "UITextField+Regular.h"
#import "MBProgressHUD.h"
#import "BFKeyBoardView.h"
#import "BFGesturePwdViewController.h"
#import "BFNotSettedSecurityQuestionViewController.h"
@interface SetPayPWViewController ()<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate,BFKeyBoardViewDelegate>
{
    UITableView*_myTableView;
    UIButton*_nextBtn;
    UITextField *_payPaField;
    MBProgressHUD*HUD;
    BFKeyBoardView*_keyboard;
}

@end

@implementation SetPayPWViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _keyboard = [[[NSBundle mainBundle] loadNibNamed:@"BFKeyBoardView" owner:nil options:nil] lastObject];
    _keyboard.delegate = self;

    
    
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title = @"注册";
    _myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight) style:UITableViewStylePlain];
    _myTableView.backgroundColor = [UIColor colorWithRed:241.0f/250.0f green:241.0f/250.0f blue:241.0f/250.0f alpha:1.0];
    [self.view addSubview:_myTableView];
    _myTableView.dataSource = self;
    _myTableView.delegate = self;
    
    
    UIView*HeaderView  = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 30)];
    _myTableView.tableHeaderView = HeaderView;
    HeaderView.backgroundColor =[UIColor colorWithRed:241.0f/250.0f green:241.0f/250.0f blue:241.0f/250.0f alpha:1.0];//暗色
    UILabel*label = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 200, 20)];
    label.font = [UIFont systemFontOfSize:12.0];
    label.text = @"请设置支付密码 ";
    label.textColor = COLOR_HEXSTRING(@"#c9c9c9");
    [HeaderView addSubview:label];
    
    
    UIView*FooterView  = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 100.0f)];
    FooterView.backgroundColor =[UIColor colorWithRed:241.0f/250.0f green:241.0f/250.0f blue:241.0f/250.0f alpha:1.0];//暗色
    UILabel*label2 = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, ScreenWidth - 20, 50)];
    label2.font = [UIFont systemFontOfSize:14.0];
    label2.numberOfLines = 0;
    label2.text = @"支付密码由6位数字组成";
    [FooterView addSubview:label2];
    
    
    _myTableView.tableFooterView = FooterView;
    _nextBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _nextBtn.frame = CGRectMake(15.0f, 60.0f, ScreenWidth-30.0f, 40);
    _nextBtn.layer.cornerRadius = 20.0f;
    [_nextBtn.layer setMasksToBounds:YES];
    [_nextBtn addTarget:self action:@selector(loginBtn)forControlEvents:UIControlEventTouchUpInside];
    _nextBtn.backgroundColor = [UIColor colorWithRed:26.0f/255.0f green:165.0f/255.0f blue:249.0f/255.0f alpha:0.5f];
    [_nextBtn setTitle:@"下一步" forState:UIControlStateNormal];
    [_nextBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _nextBtn.enabled = NO;
    [FooterView addSubview:_nextBtn];
}

-(void)backBtn
{
    for (UIViewController *ViewControlView in self.navigationController.viewControllers ) {
        if ([ViewControlView isKindOfClass:[SetLogInPWViewController class]]) {
            [self.navigationController popToViewController:ViewControlView animated:YES];
            return;
        }
    }
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString*cellId = @"cell";
    UITableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    }
    
    
    //if (indexPath.row == 0) {
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    _payPaField = [[UITextField alloc] initWithFrame:CGRectMake(10, 5, ScreenHeight - 20, 30)];
    _payPaField.placeholder = @"支付密码";
    _payPaField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _payPaField.delegate = self;
    _payPaField.tag = 100;
    _payPaField.secureTextEntry = YES;
    _payPaField.returnKeyType = UIReturnKeyDone;
    _payPaField.inputView = _keyboard;
    
    [cell addSubview:_payPaField];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark -
-(void)loginBtn
{
    UITextField*text = (UITextField*)[_myTableView viewWithTag:100];
    [text resignFirstResponder];
    
    if (text.text.length == 0) {
//        _nextBtn.backgroundColor = [UIColor colorWithRed:247.0f/250.0f green:195.0f/250.0f blue:138.0f/250.0f alpha:1.0];//暗色
//        _nextBtn.enabled = NO;
    }
    else if ([_logPassdStr isEqualToString:_payPaField.text])
    {
        [UIAlertView showWithMessage:@"支付密码和登录密码不能相同" delegate:nil];
    }
    
    else if(text.text.length == 6)
    {
        BFNotSettedSecurityQuestionViewController *securityQuestionVC = [[BFNotSettedSecurityQuestionViewController alloc] init];
        securityQuestionVC.title = @"安全问题";
        securityQuestionVC.securityQuestionStyle = 1;//注册时进入
        securityQuestionVC.telCode = _vCodeStr;
        securityQuestionVC.regMobile = _pnumberStr;
        securityQuestionVC.regPass = _logPassdStr;
        securityQuestionVC.payPass = _payPaField.text;
        [self.navigationController pushViewController:securityQuestionVC animated:YES];
    }
}
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    [_keyboard setKeyBoardWith:textField];
    [_keyboard setKeyboardstytle:KeyboardstytlePassword];
    return YES;
}
//判断输入状态
- (void)judgeMethod
{
    if (_payPaField.text.length == 6) {
        _nextBtn.backgroundColor = [UIColor colorWithRed:26.0f/255.0f green:165.0f/255.0f blue:249.0f/255.0f alpha:1.0];
        _nextBtn.enabled = YES;
    }
    else
    {
        _nextBtn.backgroundColor = [UIColor colorWithRed:26.0f/255.0f green:165.0f/255.0f blue:249.0f/255.0f alpha:0.5];
        _nextBtn.enabled = NO;
    }
}
#pragma mark - keyboardViewDelegate
-(void)keyBoard:(BFKeyBoardView*)keyBoard didClickedButton:(UIButton*)button WithText:(UITextField*)textfield
{
    
    textfield.text  = [NSString stringWithFormat:@"%@%@",textfield.text,button.titleLabel.text];
    if (textfield.text.length>6) {
        textfield.text = [textfield.text substringToIndex:6];
    }
    [self judgeMethod];
    
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateButton:(UIButton*)button WithText:(UITextField*)textfield
{
    NSString*str = textfield.text;
    if ([str length] != 0) {
        str = [str substringToIndex:[str length]- 1];
        textfield.text  = str;
    }
    [self judgeMethod];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateFinished:(UIButton*)button WithText:(UITextField*)textfield
{
    [textfield resignFirstResponder];
}
- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [_keyboard myfinishedButton:nil];
    [self.view endEditing:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  BFPerfectionAccountInfoController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/20.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFPerfectionAccountInfoController.h"
#import "BFCustomActionSheetView.h"
#import "BFKeyBoardView.h"
#import "BFReqAPI+Account.h"
#import <IQKeyboardManager/IQKeyboardManager.h>

@interface BFPerfectionAccountInfoController ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UIAlertViewDelegate,BFKeyBoardViewDelegate,CustomActionSheetDelegate>

@property(nonatomic,strong)UITableView *perfectionAccountInfoTable;

@property(nonatomic,strong)UITextField *safeQuestionField;
@property(nonatomic,strong)UITextField *answerField;
@property(nonatomic,strong)UITextField *logPsdField;
@property(nonatomic,strong)UITextField *payPsdField;
@property(nonatomic,strong)UITextField *oldPsdField;

@property(nonatomic,strong)UIButton *saveButton;
@property(nonatomic,strong)UIButton *outButton;

@property(nonatomic,strong)NSMutableArray *tableArray;


@property(nonatomic,strong)BFCustomActionSheetView *questActionSheet;

@property(nonatomic,strong)BFKeyBoardView *keyboard;

@end

@implementation BFPerfectionAccountInfoController

- (void)viewDidLoad {
    [super viewDidLoad];
    
#pragma mark 设置导航条样式
    
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    
    self.navigationItem.title = @"完善账户信息";
    
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardHide)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    //将触摸事件添加到当前view
    [self.view addGestureRecognizer:tapGestureRecognizer];
    
    [self.view addSubview:self.perfectionAccountInfoTable];
    
    [self.view addSubview:self.saveButton];
    
    [self.view addSubview:self.outButton];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [[IQKeyboardManager sharedManager] setEnable:NO];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[IQKeyboardManager sharedManager] setEnable:YES];
}
#pragma mark--CreatUI
- (UITableView *)perfectionAccountInfoTable
{
    if (!_perfectionAccountInfoTable) {
        _perfectionAccountInfoTable = [[UITableView alloc] initWithFrame:CGRectMake(0, 0,ScreenWidth,ScreenWidth-188.0f) style:UITableViewStyleGrouped];
        _perfectionAccountInfoTable.delegate = self;
        _perfectionAccountInfoTable.dataSource = self;
        _perfectionAccountInfoTable.rowHeight = 50.0f;
        _perfectionAccountInfoTable.scrollEnabled = NO;
    }
    return _perfectionAccountInfoTable;
}

- (BFKeyBoardView *)keyboard
{
    if (!_keyboard) {
        _keyboard = [[[NSBundle mainBundle] loadNibNamed:@"BFKeyBoardView" owner:nil options:nil] lastObject];
        _keyboard.delegate = self;
    }
    return _keyboard;
}
- (NSMutableArray *)tableArray
{
    if (!_tableArray) {
        
        _tableArray = [[NSMutableArray alloc] initWithCapacity:0];
        
        if ([[self.dictionary objectForKey:@"isSetSafeQues"] isEqualToString:@"1"]) {
            [_tableArray addObject:@[self.safeQuestionField,self.answerField]];
        }
        if ([[self.dictionary objectForKey:@"isSetLoginPwd"] isEqualToString:@"1"])
        {
            [_tableArray addObject:@[self.logPsdField]];
        }
        
        if ([[self.dictionary objectForKey:@"isSetPayPwd"] isEqualToString:@"1"]&&[[self.dictionary objectForKey:@"isHasOldPayPwd"] isEqualToString:@"1"])
        {
            [_tableArray addObject:@[self.oldPsdField,self.payPsdField]];
        }
        if ([[self.dictionary objectForKey:@"isSetPayPwd"] isEqualToString:@"1"]&&[[self.dictionary objectForKey:@"isHasOldPayPwd"] isEqualToString:@"0"])
        {
            [_tableArray addObject:@[self.payPsdField]];
        }
        
    }
    return _tableArray;
}
- (BFCustomActionSheetView *)questActionSheet
{
    if (!_questActionSheet) {
        _questActionSheet = [[BFCustomActionSheetView alloc] initWithArray:self.safeQuestArray];
        _questActionSheet.delegate = self;
    }
    return _questActionSheet;
}

- (UITextField *)safeQuestionField
{
    if (!_safeQuestionField) {
        _safeQuestionField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _safeQuestionField.backgroundColor = [UIColor whiteColor];
        _safeQuestionField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 95.0f, 50.0f) text:@"安全问题"];
        _safeQuestionField.leftViewMode = UITextFieldViewModeAlways;
        _safeQuestionField.placeholder = @"选择安全问题";
        _safeQuestionField.font = BF_Font_16;
        _safeQuestionField.delegate = self;
        
        UIImage *arrowImage = [UIImage imageNamed:@"arrow_bottom.png"];
        
        UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 36.0f+arrowImage.size.width, 50.0f)];
        UIImageView *arrowImageView = [[UIImageView alloc] initWithFrame:CGRectMake(18.0f, (rightView.frame.size.height-arrowImage.size.height)*0.5, arrowImage.size.width, arrowImage.size.height)];
        arrowImageView.userInteractionEnabled = YES;
        arrowImageView.image = arrowImage;
        [rightView addSubview:arrowImageView];
        
        UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showAction)];
        gesture.numberOfTapsRequired = 1;
        gesture.numberOfTouchesRequired = 1;
        [rightView addGestureRecognizer:gesture];
        
        
        _safeQuestionField.rightView = rightView;
        _safeQuestionField.rightViewMode = UITextFieldViewModeAlways;
        
        [_safeQuestionField addTarget:self action:@selector(textFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
    }
    return _safeQuestionField;
}

- (UITextField *)answerField
{
    if (!_answerField) {
        _answerField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _answerField.backgroundColor = [UIColor whiteColor];
        _answerField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 95.0f, 50.0f) text:@"问题答案"];
        _answerField.leftViewMode = UITextFieldViewModeAlways;
        _answerField.placeholder = @"设置安全问题答案";
        _answerField.font = BF_Font_16;
        [_answerField addTarget:self action:@selector(textFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
    }
    return _answerField;
}

- (UITextField *)logPsdField
{
    if (!_logPsdField) {
        _logPsdField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _logPsdField.backgroundColor = [UIColor whiteColor];
        
        if (([self.dictionary[@"isSetSafeQues"] isEqualToString:@"1"]&&[self.dictionary[@"isSetLoginPwd"] isEqualToString:@"1"]&&[self.dictionary[@"isSetPayPwd"] isEqualToString:@"1"]&&[self.dictionary[@"isHasOldPayPwd"] isEqualToString:@"1"])||([self.dictionary[@"isSetSafeQues"] isEqualToString:@"1"]&&[self.dictionary[@"isSetLoginPwd"] isEqualToString:@"1"]&&[self.dictionary[@"isSetPayPwd"] isEqualToString:@"1"]&&[self.dictionary[@"isHasOldPayPwd"] isEqualToString:@"0"]))
        {
            _logPsdField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 110.0f, 50.0F) text:@"新登录密码"];
        }else
        {
            _logPsdField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 95.0f, 50.0F) text:@"登录密码"];
        }
        
        _logPsdField.leftViewMode = UITextFieldViewModeAlways;
        _logPsdField.placeholder = @"6-20位字母、数字或符号组成";
        _logPsdField.secureTextEntry = YES;
        _logPsdField.delegate = self;
        _logPsdField.font = BF_Font_16;
        [_logPsdField addTarget:self action:@selector(textFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
    }
    return _logPsdField;
}

- (UITextField *)oldPsdField
{
    if (!_oldPsdField) {
        _oldPsdField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _oldPsdField.backgroundColor = [UIColor whiteColor];
        _oldPsdField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 110.0f, 50.0F) text:@"现支付密码"];
        _oldPsdField.leftViewMode = UITextFieldViewModeAlways;
        _oldPsdField.placeholder = @"请输入当前支付密码";
        _oldPsdField.secureTextEntry = YES;
        _oldPsdField.delegate = self;
        _oldPsdField.font = BF_Font_16;
        [_oldPsdField addTarget:self action:@selector(textFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
    }
    return _oldPsdField;
}
- (UITextField *)payPsdField
{
    if (!_payPsdField) {
        _payPsdField = [[UITextField alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 50.0f)];
        _payPsdField.backgroundColor = [UIColor whiteColor];
        
        if ([self.dictionary[@"isHasOldPayPwd"] isEqualToString:@"1"]) {
            _payPsdField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 110.0f, 50.0F) text:@"新支付密码"];
            _payPsdField.placeholder = @"请输入新支付密码";
        }else
        {
            _payPsdField.leftView = [self leftViewLabelWithFrame:CGRectMake(0.0f, 0.0f, 95.0f, 50.0F) text:@"支付密码"];
            _payPsdField.placeholder = @"由6位数字组成";
        }
        _payPsdField.leftViewMode = UITextFieldViewModeAlways;
        
        _payPsdField.secureTextEntry = YES;
        _payPsdField.delegate = self;
        _payPsdField.font = BF_Font_16;
        _payPsdField.inputView = self.keyboard;
    }
    return _payPsdField;
}

- (UIButton *)saveButton
{
    if (!_saveButton) {
        _saveButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _saveButton.frame = CGRectMake(15.0f, ScreenHeight-188.0f, ScreenWidth-30.0f, 40);
        _saveButton.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _saveButton.layer.cornerRadius = 20.0f;
        [_saveButton setTitle:@"保存" forState:UIControlStateNormal];
        [_saveButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.5f] forState:UIControlStateNormal];
        _saveButton.enabled = NO;
        [_saveButton addTarget:self action:@selector(saveMethod) forControlEvents:UIControlEventTouchUpInside];
    }
    return _saveButton;
}
- (UIButton *)outButton
{
    if (!_outButton) {
        _outButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _outButton.frame = CGRectMake(15.0f, ScreenHeight-130.0f, ScreenWidth-30.0f, 40);
        _outButton.backgroundColor = COLOR_HEXSTRING(@"#bdbdbd");
        _outButton.layer.cornerRadius = 20.0f;
        [_outButton setTitle:@"暂不设置,退出" forState:UIControlStateNormal];
        [_outButton addTarget:self action:@selector(outMethod) forControlEvents:UIControlEventTouchUpInside];
    }
    return _outButton;
}



- (UIView *)leftViewLabelWithFrame:(CGRect)rect text:(NSString *)text
{
    UIView *leftView = [[UIView alloc] initWithFrame:rect];
    UILabel *leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, rect.size.width, rect.size.height)];
    leftLabel.font = BF_Font_16;
    leftLabel.textColor = COLOR_HEXSTRING(BLACK_COLOR);
    leftLabel.text = text;
    leftLabel.textAlignment = NSTextAlignmentCenter;
    [leftView addSubview:leftLabel];
    return leftView;
}

#pragma mark--方法
- (void)keyboardHide
{
    [self.view endEditing:YES];
}
//请求方法
- (void)requestPerfection:(NSDictionary  *)dict
{
    [self showProgress];
    __weakself__
    [BFReqAPI reqComplementedCustomerInfoWithParams:dict block:^(id responseObj, NSError *error) {
        if (responseObj) {
            if (ERROR_CODE == 1) {
                /*
                hud.mode = MBProgressHUDModeText;
                hud.labelText = dict[@"message"];
                
                operationDB*db = [operationDB sharedManager];
                if ([weakSelf_SC.dictionary[@"isSetSafeQues"] isEqualToString:@"1"]) {
                    [db UpsafeQuestion:self.safeQuestionField.text];
                }
                
                [MobClick event:@"fillInfoSuccess" attributes:@{@"fillInfoSuccess":[db GetmemberId]}];
                
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    
                    SetGesturePWViewController *gestureVC = [[SetGesturePWViewController alloc] init];
                    gestureVC.isComplete = YES;
                    [weakSelf_SC.navigationController pushViewController:gestureVC animated:YES];
                });
                 */
            }
            else {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
            }
        }
    }];
  
}

//保存
- (void)saveMethod
{
    NSMutableDictionary *perfectionDict = [[NSMutableDictionary alloc] initWithCapacity:0];
    
    
    
    if ([[self.dictionary objectForKey:@"isSetSafeQues"] isEqualToString:@"1"]) {
        [perfectionDict setObject:self.safeQuestionField.text forKey:@"safeQues"];
        [perfectionDict setObject:self.answerField.text forKey:@"safeAnswer"];
    }
    if ([[self.dictionary objectForKey:@"isSetLoginPwd"] isEqualToString:@"1"])
    {
        [perfectionDict setObject:self.logPsdField.text forKey:@"loginPwd"];
    }
    if ([[self.dictionary objectForKey:@"isSetPayPwd"] isEqualToString:@"1"]&&[[self.dictionary objectForKey:@"isHasOldPayPwd"] isEqualToString:@"1"])
    {
        [perfectionDict setObject:self.oldPsdField.text forKey:@"oldPayPwd"];
        [perfectionDict setObject:self.payPsdField.text forKey:@"payPwd"];
    }
    if ([[self.dictionary objectForKey:@"isSetPayPwd"] isEqualToString:@"1"]&&[[self.dictionary objectForKey:@"isHasOldPayPwd"] isEqualToString:@"0"])
    {
        [perfectionDict setObject:self.payPsdField.text forKey:@"payPwd"];
    }
    
    [self requestPerfection:perfectionDict];
}
//暂不保存
- (void)outMethod
{
//    NSLog(@"out");
//    operationDB *db = [operationDB sharedManager];
//    [MobClick event:@"fillInfoFail" attributes:@{@"fillInfoFail":[db GetmemberId]}];
//    [self dismissViewControllerAnimated:YES completion:^{
//        [[GetAccountStatus sharedManager] setAccountLandingStatus:NO];
//    }];
}
//监听输入框
- (void)textFieldValueChange:(UITextField *)textField
{
    [self judgeMethod];
}
//显示安全问题
- (void)showAction
{
    AppDelegate *delegate = [[UIApplication sharedApplication] delegate];
    [self.questActionSheet showInView:delegate.window];
}

- (void)judgeMethod
{
    BOOL isCanClick = NO;
    int canClickCount = 0;
    int allCount = 0;
    
    for (NSArray *rowArray in self.tableArray) {
        allCount +=rowArray.count;
        for (UITextField *textField in rowArray) {
            if (textField.text.length>0) {
                canClickCount +=1;
            }
        }
    }
    
    if (canClickCount == allCount) {
        isCanClick = YES;
    }else
    {
        isCanClick = NO;
    }
    
    if (isCanClick == YES) {
        [self.saveButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f] forState:UIControlStateNormal];
        self.saveButton.enabled = YES;
    }else
    {
        [self.saveButton setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.5f] forState:UIControlStateNormal];
        self.saveButton.enabled = NO;
    }
    
}
#pragma mark--UITextFieldDelegate
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField == self.payPsdField) {
        [_keyboard setKeyBoardWith:textField];
        _keyboard.keyboardstytle = KeyboardstytlePassword;
    }else if (textField == self.safeQuestionField)
    {
        [self showAction];
        return NO;
    }
    return YES;
}

#pragma mark - UITableViewDataSourceDelegate
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    NSArray *sectionArray = self.tableArray[indexPath.section];
    [cell.contentView addSubview:sectionArray[indexPath.row]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.tableArray.count;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *rowArray = self.tableArray[section];
    return rowArray.count;
}


-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if (section != self.tableArray.count-1) {
        return nil;
    }else
    {
        if ([self.dictionary[@"isHasOldPayPwd"] isEqualToString:@"1"]) {
            UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 45.0f)];
            UILabel *tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(18.0f, 8.0f, ScreenWidth-18.0f, 29.0f)];
            tipLabel.font = BF_Font_12;
            tipLabel.textColor = COLOR_HEXSTRING(@"#aaaaaa");
            tipLabel.numberOfLines = 0;
            tipLabel.text = @"为了优化支付体验，支付密码现只支持 6 位纯数字\n若忘记现支付密码，请登录 my.baofoo.com 找回";
            [footerView addSubview:tipLabel];
            return footerView;
        }else
        {
            return nil;
        }
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 35.0f)];
        
        UILabel *tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(18.0f, 0.0f, ScreenWidth-18.0f, 35.0f)];
        tipLabel.font = BF_Font_13;
        tipLabel.textColor = COLOR_HEXSTRING(@"#aaaaaa");
        tipLabel.text = @"为了保障账户资金安全，请务必完善以下信息哦 ~";
        [headerView addSubview:tipLabel];
        
        return headerView;
    }else
    {
        return nil;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section != self.tableArray.count-1) {
        return 0.01;
    }else
    {
        if ([self.dictionary[@"isHasOldPayPwd"] isEqualToString:@"1"]) {
            return 45.0f;
        }else
        {
            return 0.01f;
        }
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 35.0f;
    }else
    {
        return 7.5f;
    }
}

#pragma mark - UIAlertViewDelegate
- (void)clickedSheetButtonAtIndex:(NSUInteger)btnIndex
{
    if (btnIndex < _safeQuestArray.count) {
        self.safeQuestionField.text = [_safeQuestArray objectAtIndex:btnIndex];
        
    }
    
}
#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - BFKeyBoardViewDelegate
-(void)keyBoard:(BFKeyBoardView*)keyBoard didClickedButton:(UIButton*)button WithText:(UITextField*)textfield
{
    
    textfield.text  = [NSString stringWithFormat:@"%@%@",textfield.text,button.titleLabel.text];
    if (textfield.text.length >6) {
        textfield.text = [textfield.text substringToIndex:6];
    }
    [self judgeMethod];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateButton:(UIButton*)button WithText:(UITextField*)textfield
{
    NSString*str = textfield.text;
    if ([str length] != 0) {
        str = [str substringToIndex:[str length]- 1];
        textfield.text  = str;
    }
    [self judgeMethod];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateFinished:(UIButton*)button WithText:(UITextField*)textfield
{
    [textfield resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

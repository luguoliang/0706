//
//  BFLoginTranslation.h
//  登陆转场
//
//  Created by fanyingzhao on 15/5/20.
//  Copyright (c) 2015年 fanyingzhao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BFLoginTranslation : NSObject

@property (assign, nonatomic) BOOL reverse;

- (instancetype)initWithView:(UIView *)btnView andContainerView:(UIView *)containerView;
- (void)stopAnimation;
- (void)startAnimation;
@end

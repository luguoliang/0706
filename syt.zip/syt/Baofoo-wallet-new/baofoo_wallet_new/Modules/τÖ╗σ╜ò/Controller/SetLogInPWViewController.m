//
//  SetLogInPWViewController.m
//  BaofooWallet
//
//  Created by 路国良 on 15/4/15.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import "SetLogInPWViewController.h"
#import "UITextField+Regular.h"
#import "SetPayPWViewController.h"
@interface SetLogInPWViewController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>
{
    UITableView*_myTableView;
    UIButton*_nextBtn;
}

@end

@implementation SetLogInPWViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"注册";
    _myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight) style:UITableViewStylePlain];
    _myTableView.backgroundColor = [UIColor colorWithRed:241.0f/250.0f green:241.0f/250.0f blue:241.0f/250.0f alpha:1.0];
    [self.view addSubview:_myTableView];
    _myTableView.dataSource = self;
    _myTableView.delegate = self;
    
    
    UIView*HeaderView  = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 30)];
    _myTableView.tableHeaderView = HeaderView;
    HeaderView.backgroundColor =[UIColor colorWithRed:241.0f/250.0f green:241.0f/250.0f blue:241.0f/250.0f alpha:1.0];//暗色
    UILabel*label = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, 200, 20)];
    label.font = [UIFont systemFontOfSize:12.0];
    label.text = @"请设置登录密码 ";
    label.textColor = COLOR_HEXSTRING(@"#c9c9c9");
    [HeaderView addSubview:label];
    
    
    UIView*FooterView  = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    FooterView.backgroundColor =[UIColor colorWithRed:241.0f/250.0f green:241.0f/250.0f blue:241.0f/250.0f alpha:1.0];//暗色
    UILabel*label2 = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, ScreenWidth - 20, 50)];
    label2.font = [UIFont systemFontOfSize:14.0];
    label2.numberOfLines = 0;
    label2.text = @"由6-20位数字、字母或特殊符号组成，任意两种即可。";
    [FooterView addSubview:label2];
    _myTableView.tableFooterView = FooterView;
    
    _nextBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _nextBtn.frame = CGRectMake(15.0f, 60.0f, ScreenWidth-30.0f, 40);
    _nextBtn.layer.cornerRadius = 20.0f;
    [_nextBtn.layer setMasksToBounds:YES];
    [_nextBtn addTarget:self action:@selector(loginBtn)forControlEvents:UIControlEventTouchUpInside];
    _nextBtn.backgroundColor = [UIColor colorWithRed:26.0f/255.0f green:165.0f/255.0f blue:249.0f/255.0f alpha:0.5];
    _nextBtn.enabled = NO;
    [_nextBtn setTitle:@"下一步" forState:UIControlStateNormal];
    [_nextBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [FooterView addSubview:_nextBtn];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString*cellId = @"cell";
    UITableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    }
    
    
    //if (indexPath.row == 0) {
        
        UITextField* _logPaField = [[UITextField alloc] initWithFrame:CGRectMake(15, 5, AUTO_LENGTH(280.0f), 30)];
        _logPaField.placeholder = @"登录密码";
        [_logPaField setFont:[UIFont systemFontOfSize:15]];
        [_logPaField addTarget:self action:@selector(textfieldValueChange:) forControlEvents:UIControlEventEditingChanged];
        _logPaField.clearButtonMode = UITextFieldViewModeWhileEditing;
        _logPaField.delegate = self;
        _logPaField.tag = 100;
        _logPaField.returnKeyType = UIReturnKeyDone;
        _logPaField.secureTextEntry = YES;
        [cell.contentView addSubview:_logPaField];

    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    
}
-(void)textfieldValueChange:(UITextField*)textfield
{
    if ((textfield.text.length != 0)) {
        _nextBtn.backgroundColor = [UIColor colorWithRed:26.0f/255.0f green:165.0f/255.0f blue:249.0f/255.0f alpha:1.0f];
        _nextBtn.enabled = YES;
    }
    else
    {
        _nextBtn.backgroundColor = [UIColor colorWithRed:26.0f/255.0f green:165.0f/255.0f blue:249.0f/255.0f alpha:0.5];
        _nextBtn.enabled = NO;
    }
    
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField.text.length != 0) {
        [textField PasswordRegularOperation];
    }
    
}
#pragma mark -
-(void)loginBtn
{
    
    UITextField*text = (UITextField*)[_myTableView viewWithTag:100];
    [text resignFirstResponder];
    
    if (text.text.length == 0) {
        _nextBtn.backgroundColor = [UIColor colorWithRed:247.0f/250.0f green:195.0f/250.0f blue:138.0f/250.0f alpha:1.0];//暗色
        _nextBtn.enabled = NO;
    }
    
    else{

        SetPayPWViewController*payView = [[SetPayPWViewController alloc] init];
        payView.pnumberStr = _pnumberStr;
        UITextField *textfield = (UITextField*)[_myTableView viewWithTag:100];
        payView.logPassdStr = textfield.text;
        payView.vCodeStr = _vCodeStr;
        [self.navigationController pushViewController:payView animated:YES];
    }
    
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

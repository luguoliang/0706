//
//  SetPayPWViewController.h
//  BaofooWallet
//
//  Created by 路国良 on 15/4/15.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetPayPWViewController : BFBaseViewController
@property(nonatomic,copy)NSString*logPassdStr;
@property(nonatomic,copy)NSString*pnumberStr;
@property(nonatomic,copy)NSString*vCodeStr;
@end

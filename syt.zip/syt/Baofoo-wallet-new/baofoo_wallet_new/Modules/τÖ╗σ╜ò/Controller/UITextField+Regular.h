//
//  UITextField+Regular.h
//  BaofooMWallet
//
//  Created by 国良 on 14-12-12.
//  Copyright (c) 2014年 国良. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (Regular) 
-(void)PasswordRegularOperation;
-(void)RegularOperationCode;
-(void)ForgotPasswordRegularPayments;
-(void)checkPhoneNumberInput;
-(void)checkIDnumber;
-(void)checkAccountName;
-(void)amountOfRegularExpress;
@end

//
//  BFLoginViewController.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/5/19.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFLoginViewController.h"
#import "BFTabBarController.h"
#import "AppDelegate.h"
#import "BFCoreDataModelop.h"
#import "BFPerfectionAccountInfoController.h"
#import "BFWebViewController.h"
#import "BFLoginTranslation.h"
#import "BFLoginTool.h"
// 网络请求
#import "BFReqAPI+Login.h"

#import "CustomTextfield.h"
#import "CountdownButton.h"
#import "GetAccountStatus.h"
#import "BFApplicationModel.h"
#import "SetLogInPWViewController.h"


#define BUTTON_COLOR                      @"2e8fd3"
#define IMAGE_HEIGHT             (CGFloat)240
#define SCREEM_WIDTH             [UIScreen mainScreen].bounds.size.width
#define SCREEM_HEIGHT            [UIScreen mainScreen].bounds.size.height
#define LOG_IMAGEWIDTH           80
#define HIDEWIDTH                150
#define BLABNK                   37
#define EMAILdEFAULTFRAME        CGRectMake(35, BLABNK, SCREEM_WIDTH - 70, 45)
#define EMAILHIDEFRAME           CGRectMake((SCREEM_WIDTH - HIDEWIDTH),BLABNK, (SCREEM_WIDTH - 70), 45)

#define PNUMBERdEFAULTFRAME      CGRectMake(35, BLABNK, SCREEM_WIDTH - 70, 45)
#define PNUMBERHIDEFRAME         CGRectMake(-((SCREEM_WIDTH - 70) -HIDEWIDTH), BLABNK, (SCREEM_WIDTH - 70), 45)

#define PASSWORDDEFAULTFRAME     CGRectMake(35,BLABNK+40, SCREEM_WIDTH - 70, 45)
#define PASSWORDHIDEFRAME        CGRectMake((SCREEM_WIDTH - HIDEWIDTH), BLABNK+40, SCREEM_WIDTH - 70, 45)

#define MESSAGEdEFAULTFRAME      CGRectMake(35,BLABNK+40, SCREEM_WIDTH - 70, 45)
#define MESSAGEHIDEFRAME         CGRectMake(-((SCREEM_WIDTH - 70) -HIDEWIDTH),BLABNK+40, SCREEM_WIDTH - 70, 45)

#define SCROLLERHEIGHT           (IMAGE_HEIGHT - LOG_IMAGEWIDTH)/2
#define CENTERVIEWWDITH          190

#define netlogdefault            CGRectMake((CENTERVIEWWDITH-190)/2, 0, 190, 40)
#define netlogdehide             CGRectMake((CENTERVIEWWDITH - 60), 5, 60, 30)

#define netregistdefault         CGRectMake((CENTERVIEWWDITH-190)/2, 0, 190, 40)
#define netregisthide            CGRectMake(0, 5, 60, 30)

#define forgerdefault            CGRectMake((SCREEM_WIDTH - 190)/2, SCREEM_HEIGHT - IMAGE_HEIGHT - 100, CENTERVIEWWDITH, 30)
#define forgethide               CGRectMake((SCREEM_WIDTH - 120), SCREEM_HEIGHT - IMAGE_HEIGHT - 100, CENTERVIEWWDITH, 30)
#define agreedefault             CGRectMake((SCREEM_WIDTH - 190)/2,SCREEM_HEIGHT - IMAGE_HEIGHT - 100, CENTERVIEWWDITH, 30)
#define agreehide                CGRectMake(-(CENTERVIEWWDITH -120),(SCREEM_HEIGHT - IMAGE_HEIGHT - 100),CENTERVIEWWDITH,30)

@interface BFLoginViewController ()<UITextFieldDelegate>
{
    UIView*_scroollview,*_centerView;
    UIButton*_logButton,*_registButton,*_netLogButton,*_netRegistButton,*_forgetButton,*_visualButton,*_agreeButton;
    BOOL isVisual,ISKEYBOARD_SHOW,sameClick;
    CustomTextfield*_numberFiled,*_emailField;
    UITextField*_passwordTextField,*_messageCodeTextField;
    UIImageView*_triangleImageView;
    CountdownButton*_getmessageButton;
    //渐变layer
    CAGradientLayer *gradientLayer;
    CAGradientLayer *gradientLayer_2;
    NSArray *colorArray;
    NSString *colorId;
}
@property (strong, nonatomic) BFLoginTranslation* netLogBtnView;
@property (strong, nonatomic) BFLoginTranslation* netRegistBtnView;
@end

@implementation BFLoginViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    //状态栏颜色
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:NO];
    /*
     //在这儿首先判断数据库中是否存在缓存，若是存在取出里面的accountName，numberFiled.text = accountStr;
     */
    if (_accountName.length == 1) {// 切换账户的地方，传一个字符进来，清空账户输入框
        _numberFiled.text = @"";
    }else if(_accountName.length > 1){
        _numberFiled.text  = _accountName;
    }
    else {
        _numberFiled.text = ([[[BFCoreDataModelop alloc] init] getCurrentBFuserModel]).accountName;
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
     sameClick = YES;//这个bool动画中用到，用来阻止用户，同时点击登陆和注册
    [[GetAccountStatus sharedManager] setAccountLandingStatus:NO];//把登陆状态改了
    
    {
        colorId = [BFApplicationModel sharedInstance].lobbyTopBackgroundId?[BFApplicationModel sharedInstance].lobbyTopBackgroundId : @"0";
        colorArray = [[NSArray alloc]initWithObjects:
                               @[(__bridge id)UIColorRgb(82, 171, 255).CGColor, (__bridge id)UIColorRgb(82, 171, 255).CGColor],
                               @[(__bridge id)UIColorRgb(255, 159, 34).CGColor, (__bridge id)UIColorRgb(255, 159, 34).CGColor],
                               @[(__bridge id)UIColorRgb(253, 88, 70).CGColor, (__bridge id)UIColorRgb(253, 88, 70).CGColor],
                               @[(__bridge id)UIColorRgb(17, 196, 148).CGColor, (__bridge id)UIColorRgb(17, 196, 148).CGColor], nil];
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEM_WIDTH, IMAGE_HEIGHT)];
        headerView.backgroundColor = [UIColor getCurrentAppSystemColor];
        
        UIColor *bgColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"huawen"]];
        UIView *bgview = [[UIView alloc] initWithFrame:headerView.frame];
        [bgview setBackgroundColor:bgColor];
        [headerView addSubview:bgview];
        [self.view addSubview:headerView];
        
        UIImageView*logImageView = [[UIImageView alloc] initWithFrame:CGRectMake((SCREEM_WIDTH - LOG_IMAGEWIDTH)/2, (IMAGE_HEIGHT - LOG_IMAGEWIDTH)/2, LOG_IMAGEWIDTH, LOG_IMAGEWIDTH)];
        logImageView.image = [UIImage imageNamed:@"logo-2.png"];
        [headerView addSubview:logImageView];
    }
    {
        _scroollview = [[UIView alloc] initWithFrame:CGRectMake(0, IMAGE_HEIGHT, SCREEM_WIDTH, SCREEM_HEIGHT - IMAGE_HEIGHT)];
        [self.view addSubview:_scroollview];
        _scroollview.backgroundColor = [UIColor whiteColor];
        _logButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [_logButton setTintColor:[UIColor whiteColor]];
        _logButton.titleLabel.font= [UIFont systemFontOfSize:16.0f];
        [_logButton setTitle:@"登录" forState:UIControlStateNormal];
        [self.view addSubview:_logButton];
        _logButton.frame = CGRectMake(75, IMAGE_HEIGHT - 15-25+8, 60, 25);
        [_logButton addTarget:self action:@selector(log:) forControlEvents:UIControlEventTouchUpInside];
        _registButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [_registButton setTintColor:[UIColor whiteColor]];
        _registButton.titleLabel.font= [UIFont systemFontOfSize:15.0f];
        _registButton.alpha = 0.5f;
        [_registButton setTitle:@"注册" forState:UIControlStateNormal];
        [self.view addSubview:_registButton];
        _registButton.frame = CGRectMake(SCREEM_WIDTH - (60+75), IMAGE_HEIGHT - 15-25+8, 60, 25);
        [_registButton addTarget:self action:@selector(regist:) forControlEvents:UIControlEventTouchUpInside];
        _triangleImageView = [[UIImageView alloc] init];
        _triangleImageView.frame = CGRectMake(75 + 30 - 5.5,  - 5.5, 11, 5.5);
        _triangleImageView.image = [UIImage imageNamed:@"res_133.png"];
        [_scroollview addSubview:_triangleImageView];
        _numberFiled = [[CustomTextfield alloc] initWithFrame:EMAILdEFAULTFRAME];
        _numberFiled.textAlignment = NSTextAlignmentCenter;
        [_scroollview addSubview:_numberFiled];
        _numberFiled.placeholder = @"手机号码/邮箱";
        _numberFiled.delegate = self;
        _numberFiled.clearButtonMode = UITextFieldViewModeWhileEditing;
    }

    {
        _emailField = [[CustomTextfield alloc] initWithFrame:PNUMBERHIDEFRAME];
        [_scroollview addSubview:_emailField];
        _emailField.textAlignment = NSTextAlignmentCenter;
        _emailField.alpha = 0.0f;
        _emailField.placeholder = @"您的手机号码";
        _emailField.delegate = self;
        _emailField.hidden = YES;
        _emailField.alpha = 0.0f;
        _emailField.clearButtonMode = UITextFieldViewModeWhileEditing;
        _passwordTextField = [[CustomTextfield alloc] initWithFrame:PASSWORDDEFAULTFRAME];
        _passwordTextField.textAlignment = NSTextAlignmentCenter;
        [_scroollview addSubview:_passwordTextField];
        _passwordTextField.secureTextEntry = YES;
        _passwordTextField.placeholder = @"登录密码";
        _passwordTextField.delegate = self;
        _passwordTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
        //
        _messageCodeTextField = [[CustomTextfield alloc] initWithFrame:MESSAGEHIDEFRAME];
        _messageCodeTextField.textAlignment = NSTextAlignmentCenter;
        [_scroollview addSubview:_messageCodeTextField];
        _messageCodeTextField.placeholder = @"短信验证码";
        _messageCodeTextField.delegate = self;
        _messageCodeTextField.hidden = YES;
        _messageCodeTextField.alpha = 0.0f;
        _messageCodeTextField.rightViewMode = UITextFieldViewModeAlways;
        _messageCodeTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
        _messageCodeTextField.leftViewMode = UITextFieldViewModeAlways;
        _messageCodeTextField.clearButtonMode = UITextFieldViewModeNever;
    }
    
    {
        _getmessageButton = [CountdownButton buttonWithType:UIButtonTypeCustom];
        [_getmessageButton setTitleColor:[UIColor colorWithHexString:BUTTON_COLOR alpha:1.0f] forState:UIControlStateNormal];
        [_getmessageButton addTarget:self action:@selector(getCode:)forControlEvents:UIControlEventTouchUpInside];
        [_getmessageButton setTitle:@"获取" forState:UIControlStateNormal];
        _getmessageButton.frame = CGRectMake(0, 0, 60, 30);
        UIView*view = [[UIView alloc] init];
        view.frame = CGRectMake(0, 0, 60, 30);
        _messageCodeTextField.rightView = _getmessageButton;
        _messageCodeTextField.leftView  = view;
        _centerView = [[UIView alloc] initWithFrame:CGRectMake((SCREEM_WIDTH - 190)/2, CGRectGetMaxY(_messageCodeTextField.frame
                                                                                                     )+40, CENTERVIEWWDITH, 40)];
        if (SCREEM_HEIGHT<500) {
            _centerView = [[UIView alloc] initWithFrame:CGRectMake((SCREEM_WIDTH - 190)/2, CGRectGetMaxY(_messageCodeTextField.frame
                                                                                                         )+10, CENTERVIEWWDITH, 40)];
        }
        {
            _centerView.backgroundColor = [UIColor getCurrentAppSystemColor];
            
            _centerView.layer.cornerRadius = 20.0f;
            
            [_scroollview addSubview:_centerView];
            
            _netLogButton = [UIButton buttonWithType:UIButtonTypeSystem];
            [_netLogButton setTintColor:[UIColor whiteColor]];
            _netLogButton.titleLabel.font= [UIFont systemFontOfSize:16.0f];
            [_netLogButton setTitle:@"登录" forState:UIControlStateNormal];
            _netLogButton.alpha = 0.5f;
            [_centerView addSubview:_netLogButton];
            _netLogButton.frame = netlogdefault;
            [_netLogButton addTarget:self action:@selector(netlog:) forControlEvents:UIControlEventTouchUpInside];
            _netRegistButton = [UIButton buttonWithType:UIButtonTypeSystem];
            [_netRegistButton setTintColor:[UIColor whiteColor]];
            _netRegistButton.titleLabel.font= [UIFont systemFontOfSize:16.0f];
            [_netRegistButton setTitle:@"注册" forState:UIControlStateNormal];
            [_centerView addSubview:_netRegistButton];
            _netRegistButton.frame = netregisthide;
            [_netRegistButton addTarget:self action:@selector(netregist:) forControlEvents:UIControlEventTouchUpInside];
            _netRegistButton.hidden = YES;
            _netRegistButton.alpha = 0.5f;
            _forgetButton = [UIButton buttonWithType:UIButtonTypeSystem];
            [_forgetButton setTintColor:[UIColor blackColor]];
            _forgetButton.titleLabel.font= [UIFont systemFontOfSize:13.0f];
            [_forgetButton setTitle:@"忘记密码？" forState:UIControlStateNormal];
            [_forgetButton setTitleColor:[UIColor colorWithRed:56.0/255.0f green:56.0/255.0f blue:56.0/255.0f alpha:1.0f] forState:UIControlStateNormal];
//            [_scroollview addSubview:_forgetButton];
            _forgetButton.frame = forgerdefault;
            [_forgetButton addTarget:self action:@selector(forgetButton:) forControlEvents:UIControlEventTouchUpInside];
            _agreeButton = [UIButton buttonWithType:UIButtonTypeSystem];
            _agreeButton.frame = agreehide;
            [_agreeButton setTintColor:[UIColor blackColor]];
            _agreeButton.titleLabel.font= [UIFont systemFontOfSize:13.0f];
            _agreeButton.hidden = YES;
            _agreeButton.alpha = 0.0f;
        }
    }
    
    {
        UIButton*CallCustomerServicePhoneButton = [UIButton buttonWithType:UIButtonTypeSystem];
        CallCustomerServicePhoneButton.frame = CGRectMake(0, CGRectGetMaxY(_forgetButton.frame), SCREEM_WIDTH, 30);
        [CallCustomerServicePhoneButton setTitleColor:[UIColor colorWithHexString:@"c9c9c9" alpha:1.0f] forState:UIControlStateNormal];
        [CallCustomerServicePhoneButton setTitle:@"客服电话：021-68811008" forState:UIControlStateNormal];
        CallCustomerServicePhoneButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        CallCustomerServicePhoneButton.titleLabel.font= [UIFont systemFontOfSize:13.0f];
        [CallCustomerServicePhoneButton addTarget:self action:@selector(callPhone) forControlEvents:UIControlEventTouchUpInside];
        [_scroollview addSubview:CallCustomerServicePhoneButton];
        NSMutableAttributedString *AttributedStr = [[NSMutableAttributedString alloc]initWithString:@"同意《宝付自助服务协议》"];
        [AttributedStr addAttribute:NSForegroundColorAttributeName
                              value:[UIColor colorWithRed:169.0f/255.0f green:194.0f/255.0f blue:82.0f/255.0f alpha:1.0f]
                              range:NSMakeRange(2, 10)];
        [_agreeButton setAttributedTitle:AttributedStr forState:UIControlStateNormal];
        [_scroollview addSubview:_agreeButton];
        [_agreeButton addTarget:self action:@selector(agreeButton:) forControlEvents:UIControlEventTouchUpInside];
        [_numberFiled addTarget:self action:@selector(textfieldValueChange:) forControlEvents:UIControlEventEditingChanged];
        [_emailField addTarget:self action:@selector(textfieldValueChange:) forControlEvents:UIControlEventEditingChanged];
        [_passwordTextField addTarget:self action:@selector(textfieldValueChange:) forControlEvents:UIControlEventEditingChanged];
        [_messageCodeTextField addTarget:self action:@selector(textfieldValueChange:) forControlEvents:UIControlEventEditingChanged];
         _numberFiled.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        _emailField.keyboardType =  UIKeyboardTypeNumbersAndPunctuation;
        _messageCodeTextField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        {
            UIControl *control = [[UIControl alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
            [self.view addSubview:control];
            [self.view sendSubviewToBack:control];
            [control addTarget:self action:@selector(hiddenKeyboard) forControlEvents:UIControlEventTouchUpInside];
            UIControl *control2 = [[UIControl alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
            [_scroollview addSubview:control2];
            [_scroollview sendSubviewToBack:control2];
            [control2 addTarget:self action:@selector(hiddenKeyboard) forControlEvents:UIControlEventTouchUpInside];
        }
        ISKEYBOARD_SHOW = NO;

    }
    
    [self setLeftBarButtonItemAsDismissBtn];
    // Do any additional setup after loading the view.
}

- (void)setLeftBarButtonItemAsDismissBtn {
    UIButton *button = [UIButton createWithFrame:CGRectMake(0, 20, 60, 40) target:self action:@selector(touchUpInsideDismissBtn:)];
    UIImage *nImage = [UIImage imageNamed:@"btn_dismiss"];
    UIImage *hImage = [UIImage imageNamed:@"btn_dismiss"];
    [button setImage:nImage forState:UIControlStateNormal];
    [button setImage:hImage forState:UIControlStateHighlighted];
    [button.imageView setContentMode:UIViewContentModeScaleAspectFill];
    [button addTarget:self action:@selector(touchUpInsideDismissBtn:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}

//取消登录模块这个窗口
- (void)touchUpInsideDismissBtn:(UIButton *)button{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:LoginNotificationCancel object:nil userInfo:nil]];
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)callPhone
{
    UIWebView*callWebview =[[UIWebView alloc] init];
    NSURL *telURL =[NSURL URLWithString:@"tel:021-68811008"];//
    [callWebview loadRequest:[NSURLRequest requestWithURL:telURL]];
    [self.view addSubview:callWebview];
}
-(void)hiddenKeyboard
{
    [_numberFiled resignFirstResponder];
    [_emailField resignFirstResponder];
    [_passwordTextField resignFirstResponder];
    [_messageCodeTextField resignFirstResponder];
}
-(void)textfieldValueChange:(UITextField*)text
{
    if ((_numberFiled.text.length != 0)&&(_passwordTextField.text.length != 0)) {
        _netLogButton.alpha = 1.0f;
    }
    else
    {
        _netLogButton.alpha = 0.5f;
    }
    if ((_emailField.text.length != 0)&&(_messageCodeTextField.text.length != 0)) {
        _netRegistButton.alpha = 1.0f;
    }
    else
    {
        _netRegistButton.alpha = 0.5f;
    }
}

-(void)log:(UIButton*)button
{
    if (sameClick) {
        sameClick = NO;
        _numberFiled.hidden = NO;
        _passwordTextField.hidden = NO;
        _netLogButton.hidden = NO;
        _forgetButton.hidden = NO;
        _registButton.alpha = 0.5f;
        [_registButton setUserInteractionEnabled:NO];
        [UIView animateWithDuration:0.35
                         animations:^{
                             _logButton.titleLabel.font= [UIFont systemFontOfSize:16.0f];
                             _registButton.titleLabel.font= [UIFont systemFontOfSize:15.0f];
                             _triangleImageView.frame = CGRectMake(75 + 30 - 5.5,  - 5.5, 11, 5.5);
                             _numberFiled.frame = EMAILdEFAULTFRAME;
                             _numberFiled.alpha = 1.0f;
                             _emailField.frame = PNUMBERHIDEFRAME;
                             _emailField.alpha = 0.0f;
                             _passwordTextField.frame = PASSWORDDEFAULTFRAME;
                             _passwordTextField.alpha= 1.0f;
                             _messageCodeTextField.frame = MESSAGEHIDEFRAME;
                             _messageCodeTextField.alpha = 0.0f;
                             _netLogButton.frame = netlogdefault;
                             _netLogButton.alpha  = 0.5f;
                             _netRegistButton.frame = netregisthide;
                             _netRegistButton.alpha = 0.0f;
                             _forgetButton.frame = forgerdefault;
                             _forgetButton.alpha = 1.0f;
                             _agreeButton.frame = agreehide;
                             _agreeButton.alpha = 0.0f;
                             _logButton.alpha = 1.0f;
                         }
                         completion:^(BOOL finished) {
                            _emailField.hidden = YES;
                             _messageCodeTextField.hidden = YES;
                             _netRegistButton.hidden = YES;
                             _agreeButton.hidden = YES;
                             [_registButton setUserInteractionEnabled:YES];
                            if (ISKEYBOARD_SHOW) {
                                 [_numberFiled becomeFirstResponder];
                                 [_passwordTextField becomeFirstResponder];
                             }
                             sameClick = YES;
                             
                         }];
    }
}
-(void)regist:(UIButton*)button
{
    if (sameClick) {
        sameClick = NO;
        _emailField.hidden = NO;
        _messageCodeTextField.hidden = NO;
        _netRegistButton.hidden = NO;
        _agreeButton.hidden = NO;
        _logButton.alpha =  0.5f;
        [_logButton setUserInteractionEnabled:NO];
        [UIView animateWithDuration:0.35
                         animations:^{
                             _logButton.titleLabel.font= [UIFont systemFontOfSize:15.0f];
                             _registButton.titleLabel.font= [UIFont systemFontOfSize:16.0f];
                             _triangleImageView.frame = CGRectMake(SCREEM_WIDTH - (60+75)+30-5.5,-5.5, 11, 5.5);
                             _numberFiled.frame = EMAILHIDEFRAME;
                             _numberFiled.alpha = 0.0f;
                             _emailField.frame = PNUMBERdEFAULTFRAME;
                             _emailField.alpha = 1.0f;
                             _passwordTextField.frame = PASSWORDHIDEFRAME;
                             _passwordTextField.alpha= 0.0f;
                             _messageCodeTextField.frame = MESSAGEdEFAULTFRAME;
                             _messageCodeTextField.alpha = 1.0f;
                             _netLogButton.frame = netlogdehide;
                             _netLogButton.alpha = 0.0f;
                             _netRegistButton.frame = netregistdefault;
                             _netRegistButton.alpha = 0.5f;
                             _forgetButton.frame = forgethide;
                             _forgetButton.alpha = 0.0f;
                             _agreeButton.frame = agreedefault;
                             _agreeButton.alpha= 1.0f;
                             _registButton.alpha = 1.0f;
                         }
                         completion:^(BOOL finished) {
                             _numberFiled.hidden = YES;
                             _passwordTextField.hidden = YES;
                             _netLogButton.hidden = YES;
                             _forgetButton.hidden = YES;
                             [_logButton setUserInteractionEnabled:YES];
                            if (ISKEYBOARD_SHOW) {
                                 if (_emailField.text.length) {
                                 }
                                 [_emailField becomeFirstResponder];
                                 [_messageCodeTextField becomeFirstResponder];
                             }
                             sameClick = YES;
                             
                         }];
    }
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    
}
- (void) registerForKeyboardNotifications
{
}
-(void)removeForboardNotifications
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}
- (void) keyboardWasShown:(NSNotification *) notif
{
    NSDictionary* info = [notif userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    CGFloat height = kbSize.height;
    height = 252;
    CGFloat moveHegiht = height - ((SCREEM_HEIGHT - IMAGE_HEIGHT) - (CGRectGetMaxY(_messageCodeTextField.frame)+40))+CGRectGetHeight(_centerView.frame);
    if (moveHegiht>0) {
        _scroollview.frame = CGRectMake(0, IMAGE_HEIGHT - moveHegiht, SCREEM_WIDTH, SCREEM_HEIGHT - IMAGE_HEIGHT);
        _logButton.frame = CGRectMake(75, IMAGE_HEIGHT - 15-25+8 - moveHegiht, 60, 25);
        _registButton.frame = CGRectMake(SCREEM_WIDTH - (60+75),IMAGE_HEIGHT - 15-25+8 - moveHegiht, 60, 25);
    }
    ISKEYBOARD_SHOW = YES;
}
- (void) keyboardWasHidden:(NSNotification *) notif
{
    _scroollview.frame = CGRectMake(0, IMAGE_HEIGHT, SCREEM_WIDTH, SCREEM_HEIGHT - IMAGE_HEIGHT);
    _logButton.frame = CGRectMake(75, IMAGE_HEIGHT - 15-25+8, 60, 25);
    _registButton.frame = CGRectMake(SCREEM_WIDTH - (60+75), IMAGE_HEIGHT - 15-25+8, 60, 25);
    ISKEYBOARD_SHOW = NO;
}
-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:YES];
    [self removeForboardNotifications];
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    [self registerForKeyboardNotifications];
}
#pragma mark - 登陆
-(void)netlog:(UIButton*)button
{
    if (!_numberFiled.text.length) {
        [self showAlertMessage:@"请输入手机号码"];
    }
    else if (!_passwordTextField.text.length) {
        [self showAlertMessage:@"请输入密码"];
    }
    else{
        [self.view endEditing:YES];
        [self.netLogBtnView startAnimation];
        __weakself__
        
        [BFReqAPI reqLoginAccountWithUserName:_numberFiled.text andPassword:_passwordTextField.text block:^(id responseObj, NSError *error) {
            if (responseObj){
                if (!weakself) return ;
                [BFLoginTool loginSuccessActionWith:responseObj andViewController:weakself isForExchangeAccount:NO isForRegister:NO];
            }
            else {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
                [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:LoginNotificationFailure object:nil userInfo:nil]];
            }
            // 停止动画
            [self performSelector:@selector(finishTransition) withObject:nil afterDelay:1];
        }];
    }
}
#pragma mark - 注册
-(void)netregist:(UIButton*)button
{
    if (!_emailField.text.length) {
        [self showAlertMessage:@"请输入手机号码"];
    }
    else if (!_messageCodeTextField.text.length) {
        [self showAlertMessage:@"请获取短信验证码"];
    }
    else{
        NSDictionary *postDict = @{@"regMobile":_emailField.text,@"telCode":_messageCodeTextField.text};
        [self.view endEditing:YES];
        [self.netLogBtnView startAnimation];
        __weakself__
        [BFReqAPI registNewUserWithTheInformationToTheServerWithParameters:postDict block:^(id responseObj, NSError *error) {
            if (responseObj != nil) {
                if (ERROR_CODE == 1) {
                    SetLogInPWViewController *registView = [[SetLogInPWViewController alloc] init];
                    registView.pnumberStr = _emailField.text;
                    registView.vCodeStr = _messageCodeTextField.text;
                    [self.navigationController pushViewController:registView animated:YES];
                    
                }else
                {
                    [UIAlertView showWithMessage:responseObj[@"message"] delegate:weakself];
                }
            }
            // 停止动画
            [self performSelector:@selector(finishTransition) withObject:nil afterDelay:1];
        }];
    }
}

-(void)forgetButton:(UIButton*)button
{
    BFWebViewController*bfWebView = [[BFWebViewController alloc] init];
    bfWebView.natitle = @"忘记登陆密码";
    bfWebView.urlStr = [NSString stringWithFormat:@"%@%@",BFWalletBaseURL, forget_loginPassword];
     [self presentViewController:[[UINavigationController alloc] initWithRootViewController:bfWebView] animated:YES completion:nil];
}
-(void)agreeButton:(UIButton*)button
{
    NSLog(@"同意协议");
    //《宝付关联服务开通协议》
//    LoadProtocolViewController *protocolVC = [[LoadProtocolViewController alloc] init];
//    protocolVC.urlString = [NSString stringWithFormat:@"%@%@",BASE_URL,AGREEMENT_HELPSELF];
//    protocolVC.titleStr = @"宝付自助服务协议";
//    [self presentViewController:[[UINavigationController alloc] initWithRootViewController:protocolVC] animated:YES completion:nil];
}

#pragma regist
-(void)getCode:(CountdownButton*)btn
{
    if ((_emailField.text.length != 11)) {
        [UIAlertView showWithMessage:@"请先输入手机号" delegate:self];
    }
    else{
        __weakself__
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [BFReqAPI getCodeForRegistWithPhoneNo:_emailField.text block:^(id responseObj, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:weakself.view animated:YES];
            if (responseObj != nil) {
                if (ERROR_CODE == 1) {
                    [btn countDownBegins];
                    [_messageCodeTextField becomeFirstResponder];
                }else
                {
                    if (ERROR_CODE == -1)
                    {
                        NSString *str = [NSString stringWithFormat:@"手机号:%@\n已注册宝付账户",_emailField.text];
                        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:str message:nil delegate:self cancelButtonTitle:@"直接登录" otherButtonTitles:@"其它号注册", nil];
                        alertView.tag = 1000;
                        [alertView show];
                    }else
                    {
                         [UIAlertView showWithMessage:responseObj[@"message"] delegate:weakself];
                    }
                }
            }
        }];
    }
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSLog(@"buttonIndex = %ld",(long)buttonIndex);
    if (alertView.tag == 1000) {
        if (buttonIndex == 0) {
            [self log:nil];
            _numberFiled.text = _emailField.text;
        }
        else if (buttonIndex == 1)
        {
            _emailField.text = nil;
        }
    }
}
//登陆失败关闭页面
-(void)backMethod{
    //    [self.navigationController popViewControllerAnimated:YES];
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
    
    [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:LoginNotificationFailure object:nil userInfo:nil]];
    
}

-(void)showAlertMessage:(NSString*)meeeage{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:meeeage delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// loginBtnAnimation
- (void)finishTransition
{
    [self.netLogBtnView stopAnimation];
}
- (BFLoginTranslation *)netLogBtnView
{
    if (!_netLogBtnView) {
        _netLogBtnView = [[BFLoginTranslation alloc] initWithView:_centerView andContainerView:_scroollview];
    }
    return _netLogBtnView;
}


@end

//
//  BFLoginTool.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/4/11.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFLoginTool.h"
#import "AppDelegate.h"
#import "BFNavigationController.h"
#import "BFLoginViewController.h"
#import "BFGesturePwdViewController.h"
#import "BFPerfectionAccountInfoController.h"
#import <SDWebImage/NSData+ImageContentType.h>
#import "BFReqAPI+Account.h"

NSString *const LoginNotificationSuccess = @"LoginNotificationSuccess";
NSString *const LoginNotificationFailure = @"LoginNotificationFailure";
NSString *const LoginNotificationCancel = @"LoginNotificationCancel";
NSString *const RegisterNotificationSuccess = @"RegisterNotificationSuccess";
NSString *const LoginOutNotification         = @"LoginOutNotification";
NSString *const LoginNotificationHeadImageDownloadSuccess = @"LoginNotificationHeadImageDownloadSuccess";
@implementation BFLoginTool

#pragma mark - 检测登录信息

//是否已经登录
+ (BOOL)loggedIn{
    BFCoreDataModelop *op = [[BFCoreDataModelop alloc] init];
    BFCoreUserModel *m = [op getCurrentBFuserModel];
    return [m.isLoginSuccess boolValue];
//    return [[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isLoginSuccess boolValue];
}

//退出登录
+ (void)logout{
    BFCoreDataModelop *op = [[BFCoreDataModelop alloc] init];
    BFCoreUserModel *model = [op getCurrentBFuserModel];
    model.isLoginSuccess = [NSNumber numberWithBool:NO];
}

+ (void)logoutAndClernSqlData {
    BFCoreDataModelop *op = [[BFCoreDataModelop alloc] init];
    BFCoreUserModel *model = [op getCurrentBFuserModel];
    [op delegateUserWithName:model.memberId];
    //退出后，本地账号清除
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:@"memberId"];
    NSHTTPCookieStorage *cookieJar = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (NSHTTPCookie *cookie in [cookieJar cookies]) {
        [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:cookie];
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:LoginOutNotification object:nil userInfo:nil];
}

//检查是否登录，如未登录需要弹出登陆界面
+ (BOOL)checkLogin{
    if ([self loggedIn]) {
        DebugLog(@"BFLoginTool: Has logged in");
        return YES;
    }
    else {
        DebugLog(@"BFLoginTool: Has not logged in, jump to login");
        return NO;
    }
}

#pragma mark - 进入登录界面

+ (void)toLoginWithAccountName:(NSString *)accountName{
    
    NSHTTPCookieStorage *cookieJar = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (NSHTTPCookie *cookie in [cookieJar cookies]) {
        [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:cookie];
    }
    
    AppDelegate *deleagate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [[self class] toLogin:deleagate.window.rootViewController withAccountName:accountName?accountName:nil];
}
+ (void)toLogin:(UIViewController *)curViewController withAccountName:(NSString *)accountName{
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    BFLoginViewController *login = [[BFLoginViewController alloc] init];
    BFNavigationController *nav = [[BFNavigationController alloc] initWithRootViewController:login];
    if (accountName) {
        login.accountName = accountName;
    }
    [curViewController presentViewController:nav animated:YES completion:nil];
    
}

- (void)tagsAliasCallback:(int)iResCode tags:(NSSet*)tags alias:(NSString*)alias {
    NSLog(@"rescode: %d, \ntags: %@, \nalias: %@\n", iResCode, tags , alias);
}

+ (void)showLoginAlert:(NSString *)message{
    
    [BlockAlert showWithTitle:Alert_Title message:message cancelButtonTitle:Alert_Button_Confirm otherButtonTitles:nil operation:^(NSInteger index) {
        
        [BFLoginTool toLoginWithAccountName:nil];
    }];
}

+ (void)loginSuccessActionWith:(id)responseObj andViewController:(UIViewController *)vc isForExchangeAccount:(BOOL)isExchangeAccount isForRegister:(BOOL)isForRegister{
    if (ERROR_CODE == 1) {
        if (responseObj) {
            [[[BFCoreDataModelop alloc] init] insterUserinitWithDict:responseObj];
            BFCoreDataModelop *op = [[BFCoreDataModelop alloc] init];
            BFCoreUserModel *model = [op getCurrentBFuserModel];
            model.isLoginSuccess = [NSNumber numberWithBool:YES];
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
            dispatch_group_t group = dispatch_group_create();
            dispatch_group_async(group, queue, ^{

                NSString *urlStr = [NSString stringWithFormat:@"%@account/getHeadImage.do",BFWalletBaseURL];
                [BFReqAPI getImageWithUrl:urlStr success:^(UIImage *image) {
                    model.accountImage = UIImageJPEGRepresentation(image,1.0);
                    if (image) {
                        [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:LoginNotificationHeadImageDownloadSuccess object:nil userInfo:@{@"img":image}]];
                    }
                } failue:^(NSError *error) {
                    
                }];
            });
        }
        else
        {
            [UIAlertView showWithMessage:responseObj[@"message"] delegate:nil];
            [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:LoginNotificationFailure object:nil userInfo:nil]];
        }
        NSArray*array = [NSArray array];
        array  = @[[[responseObj objectForKey:@"isHasOldPayPwd"] stringValue],
                   [[responseObj objectForKey:@"isSetLoginPwd"] stringValue],
                   [[responseObj objectForKey:@"isSetPayPwd"] stringValue],
                   [[responseObj objectForKey:@"isSetSafeQues"] stringValue]];
        NSDictionary*dictionary = [NSDictionary dictionary];
        dictionary = @{@"isHasOldPayPwd":[[responseObj objectForKey:@"isHasOldPayPwd"] stringValue],
                       @"isSetLoginPwd":[[responseObj objectForKey:@"isSetLoginPwd"] stringValue],
                       @"isSetPayPwd":[[responseObj objectForKey:@"isSetPayPwd"] stringValue],
                       @"isSetSafeQues":[[responseObj objectForKey:@"isSetSafeQues"] stringValue]};
        if ([array containsObject:@"1"]) {
            NSLog(@"包含1");
            BFPerfectionAccountInfoController*perView = [[BFPerfectionAccountInfoController alloc] init];
            perView.dictionary = dictionary;
            [vc presentViewController:[[UINavigationController alloc] initWithRootViewController:perView] animated:YES completion:^{
            }];
        }
        [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:LoginNotificationSuccess object:nil userInfo:nil]];
        if (isExchangeAccount) {
            [vc.navigationController popToRootViewControllerAnimated:YES];
        }
        else {
            if (!isForRegister) {
                [vc dismissViewControllerAnimated:YES completion:nil];
            }
        }
    }
    else {
        [UIAlertView showWithMessage:responseObj[@"message"] delegate:nil];
        [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:LoginNotificationFailure object:nil userInfo:nil]];
    }
}


#pragma mark - 登录通知

//登录成功通知
+ (void)loginSuccessed:(NSNotification *)notif{
    //
    [[NSNotificationCenter defaultCenter] postNotificationName:LoginNotificationSuccess object:nil userInfo:notif?notif.userInfo:nil];
}

+ (void)pushGesturePwdView:(UINavigationController *)navc{
    BFGesturePwdViewController *gestureVC = [[BFGesturePwdViewController alloc]init];
    gestureVC.titleLabelMsg = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].memberName?[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].memberName:[NSString stringWithFormat:@"%@****%@",[[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].mobile substringToIndex:3],[[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].mobile substringFromIndex:7]];
    
    gestureVC.remindLabelMsg = @"绘制手势密码";
    gestureVC.optionType = LoginGesturePwd;
    [navc pushViewController:gestureVC animated:YES];
}

#pragma mark - 注册通知


+ (void)loginCancel:(NSNotification *)notif{
    //
    [[NSNotificationCenter defaultCenter] postNotificationName:LoginNotificationCancel object:nil userInfo:notif.userInfo];
}
@end

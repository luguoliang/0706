//
//  BFPerfectionAccountInfoController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/20.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

@interface BFPerfectionAccountInfoController : BFBaseViewController

@property(nonatomic,strong)NSDictionary*dictionary;

@property(nonatomic,strong)NSArray *safeQuestArray;

@end

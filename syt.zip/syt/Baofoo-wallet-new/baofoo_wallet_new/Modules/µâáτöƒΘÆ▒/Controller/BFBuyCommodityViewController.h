//
//  BFBuyCommodityViewController.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"
#import "BillsDetailModel.h"
@interface BFBuyCommodityViewController : BFBaseViewController
@property(nonatomic,copy)NSString *product_Id;//产品Id
//@property(nonatomic,copy)NSString *product_title;
@end

//
//  ValidatePaypsdViewController.h
//  BaofooWallet
//
//  Created by mac on 15/5/27.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ValidatePaypsdViewController : UIViewController
/**
 *  需要orderNo payId type name amount desc 放到一个字典里面就可以了
 */
@property(nonatomic,strong)NSDictionary *buyProduct_DataDict;//购买产品所需要的数据
/**
 *  用于购买成功显示
 */
@property(nonatomic,strong)NSDictionary *orderBuyDto;//产品购买成功显示
/**
 *  产品的名称 用于显示
 */

@end

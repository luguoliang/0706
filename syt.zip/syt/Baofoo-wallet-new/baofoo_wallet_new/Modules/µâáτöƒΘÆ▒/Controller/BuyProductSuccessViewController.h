//
//  BuyProductSuccessViewController.h
//  makr
//
//  Created by mac on 15/4/27.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BuyProductSuccessViewController : UIViewController
@property(nonatomic,copy)NSString *endTime;
@property(nonatomic,copy)NSString *buy_amount;
@property(nonatomic,copy)NSString *exp_expire_amount;
@property(nonatomic,copy)NSString *product_id;
@property(nonatomic,copy)NSString *state;
@property(nonatomic,copy)NSString *nameTitle;
@end

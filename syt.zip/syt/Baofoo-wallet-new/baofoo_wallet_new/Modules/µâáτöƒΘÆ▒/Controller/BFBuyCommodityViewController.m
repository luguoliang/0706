//
//  BFBuyCommodityViewController.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/23.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBuyCommodityViewController.h"
#import "BuyProductSuccessViewController.h"
#import "BFModifyLoginPwdViewController.h"
#import "PreBuyModel.h"
#import "PrimaryVerifiedController.h"
#import "AppDelegate.h"
#import <CommonCrypto/CommonDigest.h>
#import "BFKeyBoardView.h"
#import "CheckoutCounteView.h"
#import "PaymentMethodViewController.h"
#import "BFReqAPI+checkout.h"
#import "PopUpView.h"
#import "ValidatePaypsdViewController.h"
#import "ChargeSucessViewController.h"
#import "BFSecurityCenterViewModel.h"
#import "BFWebViewController.h"
#pragma mark--protocolUI
#import <CoreText/CoreText.h>
#import "NSString+WBAttributedMarkup.h"

#import "WBAttributedStyleAction.h"
#import "WBHotspotLabel.h"
#import "BFReqAPI+Security.h"
@interface BFBuyCommodityViewController ()<UITextFieldDelegate,UIScrollViewDelegate,UIAlertViewDelegate,BFKeyBoardViewDelegate,myCheckoutCounteViewDelegate,PopUpViewDelegate>
{
    UILabel *_timeLabel,*_beginLabel,*_surplusLabel,*_increaseLabel;
    
    NSString *_allIncome;//总收益
    NSString *_balance;//余额
    UILabel *_showInfoLabel1,*_showInfoLabel2;//显示收益 余额信息
    UIButton *_goRechargeBtn;//去充值按钮
    BOOL _isShow;//控制输入0
    NSInteger _isFirstBuy;//记录是否第一次购买 0第一次购买 1不是第一次购买
    BFKeyBoardView*_keyboard;//安全键盘
    CheckoutCounteView*checkoutView;//收银台
    NSMutableDictionary*_checkoutDict;
    __block  NSMutableDictionary*_repeatedTranDict;//反复选择的代金券
    MBProgressHUD*HUD;
    UIButton *backBtn;
    NSDictionary*postOrderBuyDto;
    PopUpView* popView;
}
@property(nonatomic,unsafe_unretained)BOOL newProtocol;
@property(nonatomic,strong)NSArray *protocolObjArray;
@property(nonatomic,strong)NSMutableArray *protocolTitlesArray;

@property(nonatomic,copy)NSString *sign;//找回支付密码的签名
@property(nonatomic,copy)NSString *next;//跳转下一步
@property(nonatomic,copy)NSString *op;//找回方式
@property(nonatomic,copy)NSString *mobile;//绑定手机号
@property(nonatomic,copy)NSString *other;//是否显示列表

@property(nonatomic,strong)UIScrollView *rootViewScrollView;
@property(nonatomic,strong)UIView *infoView;
@property(nonatomic,strong)UITextField *moneyField;
@property(nonatomic,strong)UITextField *psdField;
@property(nonatomic,strong)WBHotspotLabel *authorityView;
@property(nonatomic,strong)UIButton *buyBtn;
@property(nonatomic,strong)UIView *showInfoView;
@property(nonatomic,strong)PreBuyModel *detail;
@end
@implementation BFBuyCommodityViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:NO];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:NO];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self.moneyField becomeFirstResponder];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginSucessful) name:LoginNotificationSuccess object:nil];
    _keyboard = [[[NSBundle mainBundle] loadNibNamed:@"BFKeyBoardView" owner:nil options:nil] lastObject];
    _keyboard.delegate = self;
    [USER_D setObject:@"0" forKey:@"isFirstBuy"];//设定为第一次购买 需求要协议一直出现
    [USER_D synchronize];
    self.view.backgroundColor = COLOR_HEXSTRING(@"#f1eff6");
    self.automaticallyAdjustsScrollViewInsets = NO;
    _isFirstBuy = [[USER_D objectForKey:@"isFirstBuy"] intValue];
    if ([USER_D objectForKey:@"isFirstBuy"] == nil) {
        _isFirstBuy = 0;
    }
    [self setLeftBarButtonItemTarget:self action:@selector(backBtn)];
    [self creatUI];
    [self requestProtocolList];
    [self refreshUI];
}
-(void)backBtn
{
    
    for (NSInteger i=0; i<self.navigationController.viewControllers.count; i++) {
        
        NSInteger a = self.navigationController.viewControllers.count -i-1;
        UIViewController *vc = self.navigationController.viewControllers[a];
        if ([vc isKindOfClass:[BFWebViewController class]]) {
            [self.navigationController popToViewController:vc animated:YES];
            break;
        }
    }
}

- (void)creatUI
{
    _isShow = NO;
    
    [self.view addSubview:self.rootViewScrollView];
    [self.rootViewScrollView addSubview:self.infoView];
    [self.rootViewScrollView addSubview:self.moneyField];
    [self.rootViewScrollView addSubview:self.showInfoView];
    [self.rootViewScrollView addSubview:self.buyBtn];
    [self.rootViewScrollView addSubview:self.authorityView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector (keyboardShow:)
                                                 name: UIKeyboardDidShowNotification object:nil];
    //注册键盘隐藏通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector (keyboardHide:)
                                                 name: UIKeyboardDidHideNotification object:nil];
}
#pragma mark--刷新UI
- (void)refreshUI
{
    NSDictionary *postDict = @{@"productId":self.product_Id};
    __weakself__
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [BFReqAPI reqAtPreBuyProductWithParams:postDict block:^(id responseObj, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:weakself.view animated:YES];
        if (responseObj != nil) {
            if (ERROR_CODE==1) {
                NSDictionary *obj = responseObj[@"obj"];
                [weakself settingUI:obj];
            }else
            {
                if (ERROR_CODE == -10) {
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:CROWD_OUT_MESSAGE delegate:self cancelButtonTitle:@"重新登录" otherButtonTitles:nil, nil];
                    [alert show];
                    alert.tag = 500;
                }else
                {
                    [UIAlertView showWithMessage:responseObj[@"message"] delegate:nil];
                }
            }
            
        }
    }];
}
- (void)settingUI:(NSDictionary *)obj
{
    PreBuyModel *detail = [PreBuyModel parserStatusWithDictionary:[obj objectForKey:@"productPreDto"]];
    self.detail = detail;
    
    self.title = self.detail.product_name;
    
    NSString *total_money = [self.detail.total_money intValue]>=10000?[NSString stringWithFormat:@"%@万元",[NSString moneyNumAndChangeformat:[NSString stringWithFormat:@"%d",[self.detail.total_money intValue]/10000] isDisplayPoint:NO]]:[NSString stringWithFormat:@"%@元",[NSString moneyNumAndChangeformat:self.detail.total_money isDisplayPoint:NO]];
    
    _timeLabel.text = [NSString stringWithFormat:@"%@天",self.detail.buy_time_count];
    _beginLabel.text = [NSString stringWithFormat:@"%@元",[NSString moneyNumAndChangeformat:self.detail.buy_amount_begin isDisplayPoint:NO]];
    _surplusLabel.text = [NSString stringWithFormat:@"%@元/%@",[NSString moneyNumAndChangeformat:self.detail.canBuyMoney isDisplayPoint:NO],total_money];
    _moneyField.placeholder = [NSString stringWithFormat:@"%@元起购 每%@元累加",[NSString moneyNumAndChangeformat:self.detail.buy_amount_begin isDisplayPoint:NO],[NSString moneyNumAndChangeformat:self.detail.increase_amount isDisplayPoint:NO]];
    
    if ([self.detail.limit_amount intValue] == -1) {
        _showInfoLabel2.hidden = YES;
    }else
    {
        NSString *xeString = [NSString moneyNumAndChangeformat:self.detail.limit_amount isDisplayPoint:YES];
        
        NSMutableAttributedString *infoString2 = [NSMutableAttributedString threeStringWithText1:@"限购金额  " text2:xeString text3:@"元" text1Color:COLOR_HEXSTRING(@"#969696") text2Color:COLOR_HEXSTRING(ORANGE_COLOR)  text3Color:COLOR_HEXSTRING(@"#969696") font1:FONT_LIGHT(13.0f) font2:FONT_LIGHT(13.0f) font3:FONT_LIGHT(13.0f)];
        _showInfoLabel2.attributedText = infoString2;
    }
}
#pragma mark--请求协议
- (NSMutableArray *)protocolTitlesArray
{
    if (!_protocolTitlesArray) {
        _protocolTitlesArray = [[NSMutableArray alloc] initWithCapacity:0];
    }
    return _protocolTitlesArray;
}
- (void)requestProtocolList
{
}
- (void)settingProtocolUI:(NSArray *)obj
{
    
    if (obj.count>0) {
        self.protocolObjArray = obj;
        
        [self.protocolTitlesArray removeAllObjects];
        for (NSDictionary *protocolDict in obj) {
            [self.protocolTitlesArray addObject:[NSString stringWithFormat:@"《%@》",protocolDict[@"protocol_name"]]];
        }
        
        NSMutableDictionary* style3 = [[NSMutableDictionary alloc] initWithDictionary:
                                       @{@"body":FONT(12.0f),
                                         
                                         
                                         @"link": COLOR_HEXSTRING(GREEN_COLOR)}];
        
        NSString *tabString = @"同意";
        NSString *realString = @"同意";
        __weakself__
        for (int i=0; i<self.protocolTitlesArray.count; i++) {
            [style3 setObject:[WBAttributedStyleAction styledActionWithAction:^{
                NSLog(@"%d",i);
                NSDictionary *protocolDict = weakself.protocolObjArray[i];
                NSString *protocolURL = [NSString stringWithFormat:@"%@%@?protocolId=%@",BFWalletBaseURL,protocol_showProtocolTemplate,protocolDict[@"protocol_id"]];
                BFWebViewController *webVC = [[BFWebViewController alloc] init];
                webVC.urlStr = protocolURL;
                webVC.isOrdinaryWeb = YES;
                [webVC setLeftNavgationBtn];
                [weakself presentViewController:[[UINavigationController alloc] initWithRootViewController:webVC] animated:YES completion:nil];
            }] forKey:[NSString stringWithFormat:@"protocol%d",i]];
            tabString = [NSString stringWithFormat:@"%@ <protocol%d>%@</protocol%d>",tabString,i,self.protocolTitlesArray[i],i];
            realString = [NSString stringWithFormat:@"%@ %@",realString,self.protocolTitlesArray[i]];
        }
        
        
        self.authorityView.attributedText = [tabString attributedStringWithStyleBook:(NSDictionary *)style3];
        CGFloat labelHeight = [UILabel height:realString widthOfFatherView:ScreenWidth-30.0f textFont:FONT(12.0f)];
        self.authorityView.frame = CGRectMake(self.authorityView.frame.origin.x, self.authorityView.frame.origin.y, self.authorityView.frame.size.width, labelHeight<20?20:labelHeight);
        [self.rootViewScrollView addSubview:self.authorityView];
        
    }else
    {
        [self.authorityView removeFromSuperview];
    }
}

#pragma mark--监听键盘弹起
//键盘升起
- (void)keyboardShow:(NSNotification *)noti
{
    NSValue *value = [noti.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardFrame = [value CGRectValue];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:[[noti.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue]];
    [UIView setAnimationCurve:7];
    
    CGFloat contentOffSetY = __textField.frame.origin.y+__textField.frame.size.height+keyboardFrame.size.height-_rootViewScrollView.frame.size.height;
    if (contentOffSetY < 0) {
        self.rootViewScrollView.contentOffset = CGPointMake(0, 0);
    }else
    {
        self.rootViewScrollView.contentOffset = CGPointMake(0, contentOffSetY);
    }
    
    [UIView commitAnimations];
    
}
//键盘下降
- (void)keyboardHide:(NSNotification *)noti
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:[[noti.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue]];
    [UIView setAnimationCurve:7];
    self.rootViewScrollView.contentOffset = CGPointMake(0, 0);
    [UIView commitAnimations];
}

//滑动视图
- (UIScrollView *)rootViewScrollView
{
    if (!_rootViewScrollView) {
        _rootViewScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0.0f, ScreenWidth, ScreenHeight-64)];
        _rootViewScrollView.backgroundColor = COLOR_HEXSTRING(@"#f1eff6");
        _rootViewScrollView.contentSize = CGSizeMake(ScreenWidth, ScreenHeight-64);
        _rootViewScrollView.alwaysBounceVertical = YES;
        _rootViewScrollView.delegate = self;
    }
    return _rootViewScrollView;
}
//信息视图
- (UIView *)infoView
{
    if (!_infoView) {
        CGFloat labelWidth = AUTO_LENGTH(150.0f);
        CGFloat labelHeight = AUTO_LENGTH(80.0f/3);
        _infoView = [[UIView alloc] initWithFrame:CGRectMake(0, 0.0f, ScreenWidth, AUTO_LENGTH(100.0f))];
        _infoView.backgroundColor = [UIColor whiteColor];
        UILabel *label1 = [self creatLabelWithFrame:CGRectMake(18.0f, 10.0f, labelWidth, labelHeight)];
        label1.text = @"投资期限";
        [_infoView addSubview:label1];
        
        UILabel *label2 = [self creatLabelWithFrame:CGRectMake(18.0f, labelHeight+10.0f, labelWidth, labelHeight)];
        label2.text = @"起购金额";
        [_infoView addSubview:label2];
        //        UILabel *label3 = [self creatLabelWithFrame:CGRectMake(10, 2*labelHeight, labelWidth, labelHeight)];
        //        label3.text = @"递增金额";
        //        [_infoView addSubview:label3];
        UILabel *label4 = [self creatLabelWithFrame:CGRectMake(18.0f, 2*labelHeight+10.0f, labelWidth, labelHeight)];
        label4.text = @"剩余金额/融资总额";
        [_infoView addSubview:label4];
        
        _timeLabel = [self creatLabelWithFrame:CGRectMake(ScreenWidth-18.0f-labelWidth, 10.0f, labelWidth, labelHeight)];
        _timeLabel.textAlignment = NSTextAlignmentRight;
        _timeLabel.textColor = COLOR_HEXSTRING(ORANGE_COLOR);
        _timeLabel.text = @"0天";
        [_infoView addSubview:_timeLabel];
        
        _beginLabel = [self creatLabelWithFrame:CGRectMake(ScreenWidth-18.0f-labelWidth, labelHeight+10.0f, labelWidth, labelHeight)];
        _beginLabel.textAlignment = NSTextAlignmentRight;
        _beginLabel.text = @"0元";
        _beginLabel.textColor = COLOR_HEXSTRING(ORANGE_COLOR);
        [_infoView addSubview:_beginLabel];
        
        //        _increaseLabel = [self creatLabelWithFrame:CGRectMake(ScreenWidth-10-labelWidth, 2*labelHeight, labelWidth, labelHeight)];
        //        _increaseLabel.textAlignment = NSTextAlignmentRight;
        //        _increaseLabel.text = [NSString stringWithFormat:@"%@元",self.detail.increase_amount];
        //
        //        [_infoView addSubview:_increaseLabel];
        
        _surplusLabel = [self creatLabelWithFrame:CGRectMake(ScreenWidth-18.0f-labelWidth, 2*labelHeight+10.0f, labelWidth, labelHeight)];
        _surplusLabel.textAlignment = NSTextAlignmentRight;
        _surplusLabel.text = @"0元";
        _surplusLabel.textColor = COLOR_HEXSTRING(ORANGE_COLOR);
        [_infoView addSubview:_surplusLabel];
        
        //画四条线
        //        UILabel *lineLabel1 = [self lineLabelWithFrame:CGRectMake(0.0f, label1.frame.origin.y, ScreenWidth, 0.5f)];
        //        [_infoView addSubview:lineLabel1];
        //
        //        UILabel *lineLabel2 = [self lineLabelWithFrame:CGRectMake(15.5f, label2.frame.origin.y, ScreenWidth-15.5f, 0.5f)];
        //        [_infoView addSubview:lineLabel2];
        //
        //        UILabel *lineLabel3 = [self lineLabelWithFrame:CGRectMake(15.5f, label4.frame.origin.y, ScreenWidth-15.5f, 0.5f)];
        //        [_infoView addSubview:lineLabel3];
        
        UILabel *lineLabel4 = [self lineLabelWithFrame:CGRectMake(0.0f, _infoView.frame.size.height-0.5f, ScreenWidth, 0.5f)];
        [_infoView addSubview:lineLabel4];
    }
    return _infoView;
}
//画线
- (UILabel *)lineLabelWithFrame:(CGRect)rect
{
    UILabel *label = [[UILabel alloc] initWithFrame:rect];
    label.backgroundColor = COLOR_HEXSTRING(LINE_COLOR);
    return label;
}

- (UILabel *)creatLabelWithFrame:(CGRect)rect
{
    UILabel *label = [[UILabel alloc] initWithFrame:rect];
    label.font = FONT_LIGHT(14.0f);
    label.textColor = COLOR_HEXSTRING(@"#9ea0a4");
    return label;
}
//金钱输入框
- (UITextField *)moneyField
{
    if (!_moneyField)
    {
        
        _moneyField = [[UITextField alloc] initWithFrame:CGRectMake(0, _infoView.frame.origin.y+_infoView.frame.size.height, ScreenWidth, 50.0f)];
        _moneyField.borderStyle = UITextBorderStyleNone;
        _moneyField.placeholder = @"0元起购 每0元累加";
        CGFloat leftViewWidth = [UILabel width:@"起购金额" heightOfFatherView:50.0f textFont:FONT_LIGHT(15.0f)];
        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 36.0f+leftViewWidth, 50.0f)];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(18.0f, 0, leftViewWidth, 50.0f)];
        label.font = FONT_LIGHT(15.0f);
        label.textColor = COLOR_HEXSTRING(@"#000000");
        label.text = @"购买金额";
        [leftView addSubview:label];
        _moneyField.leftView = leftView;
        _moneyField.leftViewMode=UITextFieldViewModeAlways;
        _moneyField.clearButtonMode = UITextFieldViewModeWhileEditing;
        _moneyField.keyboardType = UIKeyboardTypeNumberPad;
        [_moneyField addTarget:self action:@selector(changeValue:) forControlEvents:UIControlEventEditingChanged];
        _moneyField.backgroundColor = [UIColor whiteColor];
        _moneyField.font = FONT_LIGHT(15.0f);
        _moneyField.delegate = self;
        _moneyField.inputView = _keyboard;
        //        UILabel *lineLabel1 = [self lineLabelWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 0.5f)];
        //        [_moneyField addSubview:lineLabel1];
        
        UILabel *lineLabel2 = [self lineLabelWithFrame:CGRectMake(0.0f, _moneyField.frame.size.height-0.5f, ScreenWidth, 0.5f)];
        [_moneyField addSubview:lineLabel2];
    }
    return _moneyField;
}
-(UIView *)showInfoView
{
    if (!_showInfoView) {
        
        CGFloat labelWidth = (ScreenWidth-36.0f)*0.5;
        
        _showInfoView = [[UIView alloc] initWithFrame:CGRectMake(0,  _moneyField.frame.origin.y+_moneyField.frame.size.height, ScreenWidth, 37.0f)];
        _showInfoView.backgroundColor = [UIColor whiteColor];
        
        _showInfoLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(18.0f, 0, labelWidth+50.0f, 37.0f)];
        _showInfoLabel1.textColor = COLOR_HEXSTRING(PROMT_COLOR);
        _showInfoLabel1.font = FONT_LIGHT(13.0f);
        [_showInfoView addSubview:_showInfoLabel1];
        
        NSMutableAttributedString *infoString1 = [NSMutableAttributedString threeStringWithText1:@"预期总收益  " text2:@"0.00" text3:@"元" text1Color:COLOR_HEXSTRING(@"#969696") text2Color:COLOR_HEXSTRING(ORANGE_COLOR)  text3Color:COLOR_HEXSTRING(@"#969696") font1:FONT_LIGHT(13.0f) font2:FONT_LIGHT(13.0f) font3:FONT_LIGHT(13.0f)];
        _showInfoLabel1.attributedText = infoString1;
        
        
        _showInfoLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(ScreenWidth-18.0f-labelWidth, 0, labelWidth, 37.0f)];
        _showInfoLabel2.textColor = COLOR_HEXSTRING(PROMT_COLOR);
        _showInfoLabel2.font = FONT_LIGHT(13.0f);
        _showInfoLabel2.textAlignment = NSTextAlignmentRight;
        [_showInfoView addSubview:_showInfoLabel2];
        
        //获取限额数值 为0显示0.00
        NSString *xeString = [NSString moneyNumAndChangeformat:self.detail.limit_amount isDisplayPoint:YES];
        
        NSMutableAttributedString *infoString2 = [NSMutableAttributedString threeStringWithText1:@"限购金额  " text2:xeString text3:@"元" text1Color:COLOR_HEXSTRING(@"#969696") text2Color:COLOR_HEXSTRING(ORANGE_COLOR)  text3Color:COLOR_HEXSTRING(@"#969696") font1:FONT(13.0f) font2:FONT(13.0f) font3:FONT_LIGHT(13.0f)];
        _showInfoLabel2.attributedText = infoString2;
        
    }
    return _showInfoView;
}
//密码输入框
- (UITextField *)psdField
{
    if (!_psdField) {
        _psdField = [[UITextField alloc] initWithFrame:CGRectMake(0, _showInfoView.frame.origin.y+_showInfoView.frame.size.height, ScreenWidth, 40.0f)];
        _psdField.borderStyle = UITextBorderStyleNone;
        _psdField.placeholder = @"请输入账户支付密码";
        CGFloat leftViewWidth = [UILabel width:@"支付密码" heightOfFatherView:40.0f textFont:FONT_LIGHT(14.0f)];
        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20.0f+leftViewWidth, 40.0f)];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, 0, leftViewWidth, 40.0f)];
        label.text = @"支付密码";
        label.font = FONT_LIGHT(14.0f);
        label.textColor = COLOR_HEXSTRING(@"#434343");
        [leftView addSubview:label];
        _psdField.leftView = leftView;
        _psdField.leftViewMode=UITextFieldViewModeAlways;
        _psdField.clearButtonMode = UITextFieldViewModeWhileEditing;
        _psdField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        _psdField.backgroundColor = [UIColor whiteColor];
        [_psdField addTarget:self action:@selector(changeValue:) forControlEvents:UIControlEventEditingChanged];
        _psdField.secureTextEntry = YES;
        _psdField.font = FONT_LIGHT(14.0f);
        _psdField.delegate = self;
        _psdField.inputView = _keyboard;
        
        UILabel *lineLabel1 = [self lineLabelWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, 0.5f)];
        [_psdField addSubview:lineLabel1];
        
        UILabel *lineLabel2 = [self lineLabelWithFrame:CGRectMake(0.0f, _psdField.frame.size.height-0.5f, ScreenWidth, 0.5f)];
        [_psdField addSubview:lineLabel2];
    }
    return _psdField;
}
//权限视图
- (WBHotspotLabel *)authorityView
{
    if (!_authorityView) {
        _authorityView = [[WBHotspotLabel alloc] init];
        _authorityView.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
        _authorityView.font = FONT(12.0f);
        _authorityView.textColor = [UIColor blackColor];
        _authorityView.textAlignment = NSTextAlignmentLeft;
        _authorityView.numberOfLines = 0;
        
        _authorityView.frame = CGRectMake(15, self.buyBtn.frame.origin.y+self.buyBtn.frame.size.height+10, ScreenWidth-15, 20.0f);
        
    }
    return _authorityView;
}
//按钮方法
- (void)doSomething:(UIButton *)sender
{
    switch (sender.tag) {
        case 100:
        {
            if (sender.selected == YES) {
                sender.selected = NO;
            }else
            {
                sender.selected = YES;
            }
            [self judgeMethod];
        }
            break;
        case 200:
        {
            //《宝付关联服务开通协议》
            
            
        }
            break;
        case 300:
        {
            //《慧生钱服务协议》
            
        }
            break;
        default:
            break;
    }
}
//确认购买按钮
- (UIButton *)buyBtn
{
    if (!_buyBtn) {
        _buyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _buyBtn.frame = CGRectMake(15.0f, self.showInfoView.frame.origin.y+self.showInfoView.frame.size.height+23.0f, ScreenWidth-30.0f, 40.0f);
        [_buyBtn setTitle:@"同意协议并购买" forState:UIControlStateNormal];
        [_buyBtn setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
        _buyBtn.titleLabel.font = FONT_LIGHT(16.0f);
        _buyBtn.backgroundColor = COLOR_HEXSTRING(BLUE_COLOR);
        _buyBtn.enabled = NO;
        _buyBtn.layer.cornerRadius = 20.0f;
        [_buyBtn addTarget:self action:@selector(judgeMoneyToBuy) forControlEvents:UIControlEventTouchUpInside];
    }
    return _buyBtn;
}
#pragma mark--购买 充值方法
- (void)buySomething:(UIButton *)sender
{
    AppDelegate *delegate = [[UIApplication sharedApplication] delegate];
    [MBProgressHUD showHUDAddedTo:delegate.window animated:YES];
    [self showOPenUpView];
}
-(void)showOPenUpView
{
    
    NSDictionary *postDict = @{@"random_key":self.detail.randomKey,@"money":_moneyField.text,@"productId":self.product_Id};
    popView = [[PopUpView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight) WithDict:postDict withDelegate:self];
    
}
#pragma mark  - popUpViewDelegate
-(void)PopUpView:(PopUpView*)PopUpView didClickedClosedButton:(UIButton*)button JumptoViewController:(ChargeSucessViewController*)controller
{
    //    [self.navigationController pushViewController:controller animated:YES];
    
    ChargeSucessViewController*cha = [[ChargeSucessViewController alloc] init];
    [self.navigationController pushViewController:cha animated:YES];
}

-(void)determineWhetherOpenCashRegister
{
    UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
    [MBProgressHUD hideAllHUDsForView:window  animated:YES];
    
    [window addSubview:popView];
}

-(void)failtoOpenTheCashRegisterWithStr:(NSString *)str
{
    UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
    [MBProgressHUD hideAllHUDsForView:window  animated:YES];
    if ([str isEqualToString:CROWD_OUT_MESSAGE]) {
        UIAlertView*alertView = [[UIAlertView alloc] initWithTitle:nil message:str delegate:self cancelButtonTitle:@"重新登录" otherButtonTitles:nil, nil];
        alertView.tag = 500;
        [alertView show];
    }else if ([str isEqualToString:@"您尚未实名认证，为保障账户资金安全，请认证后再购买理财产品"])
    {
        UIAlertView*alertView = [[UIAlertView alloc] initWithTitle:nil message:str delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        alertView.tag = 100;
        [alertView show];
    }
    else
    {
        UIAlertView*alertView = [[UIAlertView alloc] initWithTitle:nil message:str delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [self refreshUI];//刷新实际金额
    }
    
}
-(void)AddBankCardWith:(NSDictionary *)dict
{
    NSLog(@"添加银行卡");
    NSLog(@"dict = %@",dict);
    ValidatePaypsdViewController *validate = [[ValidatePaypsdViewController alloc] init];
    validate.buyProduct_DataDict = dict;
    [self.navigationController pushViewController:validate animated:YES];
}

-(void)popUpViewForgetPassWord
{
    [self getPayPwd];
}

-(void)closedCashRegister{
    NSLog(@"点击按钮关闭收银台回调");
    [self refreshUI];
    [BFReqAPI reqCloseCheckoutWithParams:@{@"orderId":@""} block:^(id responseObj, NSError *error) {
        if (responseObj !=nil) {
            
            NSLog(@"%@",responseObj);
        }
    }];
}
#pragma mark - 找回支付密码
- (void)getPayPwd
{
    //找回支付密码
    [self showProgress];
    __weakself__
    [BFReqAPI reqInitFindPayPwdBlock:^(id responseObj, NSError *error) {
        [weakself hideProgress];
        if (responseObj) {
            if (ERROR_CODE == 1) {
                NSDictionary *dict = [NSDictionary dictionaryWithDictionary:responseObj[@"obj"]];
                
                //保存初始化前面
                [USER_D setObject:dict[@"sign"] forKey:@"initSign"];
                [USER_D synchronize];
                
                [BFSecurityCenterViewModel handleSecurityCenterJumpLogicWithType:[BFSecurityCenterViewModel payPwdValiTypeFromStr:dict[@"next"]] andParams:dict fromViewController:weakself];
            }
            else {
                [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
            }
        }
        else {
            [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
        }
    }];
    
}


#pragma mark--确认购买方法
- (void)judgeMoneyToBuy
{
    if ([_moneyField.text intValue]<=0) {
        //判断输入的是不是0
        [UIAlertView showWithMessage:@"购买金额不能为0，请输入正确的购买金额" delegate:nil];
    }else if([_moneyField.text intValue]<[self.detail.buy_amount_begin intValue])
    {
        [UIAlertView showWithMessage:@"您的购买金额必须大于等于起购金额" delegate:nil];
    }else if ([_moneyField.text intValue]>[self.detail.canBuyMoney intValue])
    {
        [UIAlertView showWithMessage:@"请输入正确的购买金额：起购金额+递增金额的整数倍" delegate:nil];
    }else if ((([_moneyField.text integerValue]-[self.detail.buy_amount_begin integerValue])/(double)[self.detail.increase_amount integerValue]) > (([_moneyField.text integerValue]-[self.detail.buy_amount_begin integerValue])/[self.detail.increase_amount integerValue]))
    {
        [UIAlertView showWithMessage:@"请输入正确的购买金额：起购金额+递增金额的整数倍" delegate:nil];
    }else
    {
        [_moneyField resignFirstResponder];
        
        [self buySomething:nil];
    }
}
#pragma mark--UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 100) {
        if (buttonIndex == 0) {
            PrimaryVerifiedController *primaryVC = [PrimaryVerifiedController new];
            primaryVC.dismissOrPop = 1;//莫泰返回
            [self presentViewController:[[UINavigationController alloc] initWithRootViewController:primaryVC] animated:YES completion:nil];
        }
    }
    else if (alertView.tag == 0000)
    {
        if (buttonIndex == 1) {
            PrimaryVerifiedController*prView = [[PrimaryVerifiedController alloc] init];
            prView.money = @"money";
            prView.dismissOrPop = 1;
            [self presentViewController:[[UINavigationController alloc] initWithRootViewController:prView] animated:YES completion:nil];
        }
    }
    else
    {
        if (buttonIndex == 0) {
            BFCoreUserModel *model = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel];
            model.access_token = @"";
            model.isLoginSuccess = [NSNumber numberWithBool:NO];
            [self performSelector:@selector(goLoginMethod) withObject:nil afterDelay:0.5];
            
        }else
        {
            BFModifyLoginPwdViewController *changeView  = [[BFModifyLoginPwdViewController alloc] init];
            changeView.modifyLoginPassWordType = ModifyTypeWithBumped;
            [self.navigationController pushViewController:changeView animated:YES];
        }
    }
}

- (void)goLoginMethod
{
    [BFLoginTool toLoginWithAccountName:nil];
}

- (void)loginSucessful {
    [self refreshUI];
    [self requestProtocolList];
}

- (void)logoutSucessful {
    [self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma mark--UIScrollViewDelegate
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
    //    [self judgeMethod];
}
#pragma mark--UITextFieldDelegate
static UITextField *__textField;
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField == _moneyField)
    {
        __textField = _moneyField;
    }else
    {
        __textField = _psdField;
    }
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self judgeMethod];
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString * toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    NSUInteger charLen = toBeString.length;
    if (textField == _moneyField) {
        if ( charLen>10) {
            return NO;
        }
        
    }else
    {
        if (charLen>20) {
            return NO;
        }
    }
    return YES;
}
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField==self.psdField) {
        NSLog(@"tag = 101");
        [_keyboard setKeyBoardWith:textField];
        _keyboard.keyboardstytle = KeyboardstytlePassword;
    }else
    {
        _keyboard.keyBoardNumberStatus = @"0";
        [_keyboard setKeyBoardWith:textField];
        _keyboard.keyboardstytle = KeyboardstytlePhoneNumber;
    }
    return YES;
}

#pragma mark--实时监测输入框
- (void)changeValue:(UITextField *)textField
{
    if ([textField.text intValue] == 0) {
        textField.text = @"";
    }
    [self judgeMethod];
    [self updateControlFrame];
}

#pragma mark--判断按钮的高亮
- (void)judgeMethod
{
    //    UIButton *button = (UIButton *)[self.rootViewScrollView viewWithTag:100];
    if (_moneyField.text.length>0)
    {
        self.buyBtn.enabled = YES;
        [self.buyBtn setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:1.0f] forState:UIControlStateNormal];
    }else
    {
        self.buyBtn.enabled = NO;
        [self.buyBtn setTitleColor:[UIColor colorWithRed:1.0f green:1.0f blue:1.0f alpha:0.3f] forState:UIControlStateNormal];
    }
}
#pragma mark--更新frame
- (void)updateControlFrame
{
    
    NSString *preMoney = [NSString preMoneyWithBuyMoney:[self.moneyField.text integerValue] yearRate:[self.detail.year_rate doubleValue]/100+[self.detail.extra_rate doubleValue]/100 day:[self.detail.buy_time_count integerValue]];
    
    NSMutableAttributedString *infoString1 = [NSMutableAttributedString threeStringWithText1:@"预期总收益  " text2:[NSString stringWithFormat:@"%@",[NSString moneyNumAndChangeformat:preMoney isDisplayPoint:YES]] text3:@"元" text1Color:COLOR_HEXSTRING(@"#969696") text2Color:COLOR_HEXSTRING(ORANGE_COLOR) text3Color:COLOR_HEXSTRING(@"#969696") font1:FONT_LIGHT(13.0f) font2:FONT_LIGHT(13.0f) font3:FONT_LIGHT(13.0f)];
    _showInfoLabel1.attributedText = infoString1;
    
    
}
#pragma mark - BFKeyBoardViewDelegate
-(void)keyBoard:(BFKeyBoardView*)keyBoard didClickedButton:(UIButton*)button WithText:(UITextField*)textfield
{
    
    textfield.text  = [NSString stringWithFormat:@"%@%@",textfield.text,button.titleLabel.text];
    if (textfield == self.moneyField) {
        if (textfield.text.length >= 9) {
            textfield.text = [textfield.text substringToIndex:9];
        }
        if ([textfield.text intValue] == 0) {
            textfield.text = @"";
        }else if (textfield.text.length>0) {
            [self judgeMethod];
            [self updateControlFrame];
        }
        
    }
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateButton:(UIButton*)button WithText:(UITextField*)textfield
{
    NSString*str = textfield.text;
    if ([str length] != 0) {
        str = [str substringToIndex:[str length]- 1];
        textfield.text  = str;
    }
    [self judgeMethod];
    [self updateControlFrame];
    
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateFinished:(UIButton*)button WithText:(UITextField*)textfield
{
    [textfield resignFirstResponder];
}


- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidHideNotification object:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

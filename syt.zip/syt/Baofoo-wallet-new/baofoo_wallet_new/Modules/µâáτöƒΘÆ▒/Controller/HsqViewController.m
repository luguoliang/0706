//
//  HsqViewController.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/5.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "HsqViewController.h"
#import "MJRefresh.h"
#import "BFReqAPI+HSQ.h"
#import "BFReloadView.h"
#import "Bills.h"
#import "BFWebViewController.h"
#import "ProductCell.h"
#import "WBRefreshGifHeader.h"
#import "BFModifyLoginPwdViewController.h"
#import "UILabel+SizeLabel.h"

#define   MAKE_MONEY_DATA [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/makeMoney.plist"]

@interface HsqViewController ()<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate,BFReloadViewDelegate>

{
    NSString *_creat_time;
    CGFloat scrollViewHeight;
    CGFloat heightForFooter;
    CGFloat bilsViewHeight;
    CGFloat _startContengOfsety;
    CGFloat _WillEndContengOfsety;
    CGFloat _endContengOfsety;
    CGFloat billsSectionNumber;
    UIView*_headerView;
    NSMutableArray*billsArray;
    UIView*_AnimationView;
    NSString*memberID;
    NSMutableArray*_imageUrlArr;
    NSMutableArray*_allArr;
    
    UIPageControl *_pageControl;//点
    
    NSString *_product_typeString;//标识定期
    NSString *_type_String;//标识 活期 定期
    BOOL _isFirst;
    
}
@property(nonatomic,strong)UIButton *rightBtn;//导航栏右边按钮
@property(nonatomic,strong)UITableView *regularTableView;
@property(nonatomic,strong)UIView *currentView,*bgview;
@property(nonatomic,strong)UIImageView *imageview;

#pragma mark--断网页面
@property(nonatomic,strong)BFReloadView *reloadView;

@end

@implementation HsqViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"慧生钱";
    _isFirst = YES;
    UIBarButtonItem *myMoneyBtnItem = [[UIBarButtonItem alloc]initWithCustomView:self.rightBtn];
    self.navigationItem.rightBarButtonItem = myMoneyBtnItem;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:[[UIView alloc] init]];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    memberID = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].memberId;//
    
    billsArray = [[NSMutableArray alloc] initWithCapacity:0];//保存bills的模型
    [self initData];
    
    [self.view addSubview:self.regularTableView];//
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(pushOrderMessage:) name:@"pushOrderMessage" object:nil];
    _type_String = @"定期";
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    // 添加底纹
    [self.navigationController.navigationBar addSubview:self.bgview];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:NO];
    [self setNavBarImage:[UIImage createImageWithColor:[UIColor getCurrentAppSystemColor]] titleColor:[UIColor whiteColor]];
    if (_isFirst == NO) {
        [self headerRereshing];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:YES];
    [self.bgview removeFromSuperview];
    [self setNavBarImage:[UIImage imageNamed:@"navbar_white_bg"] titleColor:[UIColor blackColor]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark--UICeratUI

- (UIView *)bgview {
    if (!_bgview) {
        UIColor *bgColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"huawen"]];
        _bgview = [[UIView alloc] initWithFrame:CGRectMake(0, -20, ScreenWidth, 64)];
        [_bgview setBackgroundColor:bgColor];
    }
    return _bgview;
}
- (BFReloadView *)reloadView
{
    if (!_reloadView) {
        _reloadView = [[BFReloadView alloc] init];
        _reloadView.delegate = self;
    }
    _reloadView.frame = CGRectMake(0, 0, ScreenWidth, CGRectGetHeight(self.regularTableView.frame));
    return _reloadView;
}
- (void)reloadTheView
{
    [self.regularTableView.header beginRefreshing];
}
- (UIButton *)rightBtn
{
    if (!_rightBtn) {
        _rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        //        _rightBtn.frame = CGRectMake(0.0f, 0.0f, 25.0f, 25.0f);
        //        [_rightBtn setImage:[UIImage imageNamed:@"hsq_main_money"] forState:UIControlStateNormal];
        _rightBtn.frame = CGRectMake(0.0f, 0.0f, 50.0f, 25.0f);
        [_rightBtn setTitle:@"我的理财" forState:UIControlStateNormal];
        _rightBtn.titleLabel.font = BF_Font_(12);
        [_rightBtn setTitleColor:UIColorWhite() forState:UIControlStateNormal];
        [_rightBtn addTarget:self action:@selector(manageMoney) forControlEvents:UIControlEventTouchUpInside];
    }
    return _rightBtn;
}

- (void)manageMoney
{
    __weakself__
//    [[AppSkipManager sharedManager] judgeLoginStatusWithController:self loginSuccess:^{
//        
//    } loginFaile:^{
//        
//    } completion:^{
//        [weakself.navigationController pushViewController:[ManageMoneyViewController new] animated:YES];
//    }];
}

- (void)initData
{
    NSDictionary *dataDict = [NSDictionary dictionaryWithContentsOfFile:MAKE_MONEY_DATA];
    if (dataDict != nil) {
        NSData *data = dataDict[memberID];
        if (data != nil) {
            NSDictionary *dict  = [NSJSONSerialization JSONObjectWithData:dataDict[memberID] options:NSJSONReadingMutableLeaves error:nil];
            NSArray*array = [[dict objectForKey:@"obj"] objectForKey:@"productIndexDtos"];
            for (NSDictionary *dict in array) {
                Bills *bills = [Bills billsWithDict:dict];
                [billsArray addObject:bills];
            }
            _creat_time = [[billsArray lastObject] create_time];
            if ([_creat_time isKindOfClass:[NSNull class]]||_creat_time == nil) {
                _creat_time = @"";
            }
        }else
        {
            _creat_time = @"";
        }
        
    }else
    {
        _creat_time = @"";
    }
}

- (void)delayPush
{
    BFWebViewController *webVC = [BFWebViewController new];
    webVC.urlStr = [NSString stringWithFormat:@"%@%@",HSQBaseURL,app_push_index];
    webVC.title = @"";
    [self.navigationController pushViewController:webVC animated:YES];
}


//tableView
- (UITableView *)regularTableView
{
    if (!_regularTableView) {
        //mytableView
        _regularTableView  = [[UITableView alloc] initWithFrame:CGRectMake(0, 0.0f, ScreenWidth, ScreenHeight-49.0f-64.0f) style:UITableViewStyleGrouped];
        _regularTableView.delegate = self;
        _regularTableView.dataSource = self;
        //        _regularTableView.separatorStyle = UITableViewCellAccessoryNone;
        _regularTableView.separatorColor = COLOR_HEXSTRING(GRAY_COLOR);
        _regularTableView.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
        _regularTableView.showsHorizontalScrollIndicator = NO;
        _regularTableView.showsVerticalScrollIndicator = NO;
        [_regularTableView registerClass:[ProductCell class] forCellReuseIdentifier:@"productCell"];
        
        // 设置回调（一旦进入刷新状态，就调用target的action，也就是调用self的loadNewData方法）
        WBRefreshGifHeader *header = [WBRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(headerRereshing)];
        
        // 隐藏时间
        header.lastUpdatedTimeLabel.hidden = YES;
        
        // 隐藏状态
        header.stateLabel.hidden = YES;
        
        // 马上进入刷新状态
        [header beginRefreshing];
        
        // 设置header
        _regularTableView.header = header;
        
        __weakself__
        _regularTableView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
            [weakself footerRereshing];
        }];
    }
    return _regularTableView;
}

#pragma mark - UITableViewDataSource

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //    BillsCell *billsCell = [tableView dequeueReusableCellWithIdentifier:BillsID];
    ProductCell *cell = [tableView dequeueReusableCellWithIdentifier:@"productCell"];
    [cell loadProductInfo:billsArray[indexPath.row]];
    
    return cell;
}
#pragma mark -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return billsArray.count;
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.01;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return AUTO_LENGTH(90.0f);
}
#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.regularTableView.header endRefreshing];
    
    [self hidenCustomTabBar];
    
    if (![[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isLoginSuccess boolValue]) {
        [BFLoginTool toLoginWithAccountName:nil];
    }else
    {
        Bills *bill = billsArray[indexPath.row];
        BFWebViewController *detailVC = [BFWebViewController new];
        detailVC.product_id = bill.product_Id;
        detailVC.urlStr =[NSString stringWithFormat:@"%@%@#%@",HSQBaseURL,app_hsq_hsqdetail,bill.product_Id];
        [self.navigationController pushViewController:detailVC animated:YES];
    }
    
}


#pragma mark -
-(void)hidenCustomTabBar
{
    if (_callback) {
        _callback(@"1");
    }
}
-(void)apperCustonTabBar
{
    if (_callback) {
        _callback(@"");
    }
}

#pragma mark--打开推送消息
- (void)pushOrderMessage:(NSNotification *)notification
{
    UINavigationController *nav = self.tabBarController.selectedViewController;
    if ([nav.viewControllers[0] isKindOfClass:[HsqViewController class]]) {
        [self performSelector:@selector(delayPush) withObject:nil afterDelay:0.5];
    }
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 1000) {
        if (buttonIndex == 0) {
            [self pushOrderMessage:nil];
            [USER_D setBool:NO forKey:@"isOpenNotificationMessage"];
            [USER_D synchronize];
        }
        
    }else
    {
        if (buttonIndex == 0) {
            [self performSelector:@selector(goLoginMethod) withObject:nil afterDelay:0.25];
            
        }else
        {
            [self performSelector:@selector(goModifyPsdMethod) withObject:nil afterDelay:0.25];
        }
    }
    
}
- (void)goLoginMethod
{
    BFCoreUserModel *model = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel];
    model.access_token = @"";
    model.isLoginSuccess = [NSNumber numberWithBool:NO];
    [BFLoginTool toLoginWithAccountName:nil];
}
- (void)goModifyPsdMethod
{
    BFModifyLoginPwdViewController *modifyLoginPwdVC  = [[BFModifyLoginPwdViewController alloc] init];
    modifyLoginPwdVC.modifyLoginPassWordType = ModifyTypeWithBumped;
    [self.navigationController pushViewController:modifyLoginPwdVC animated:YES];
}

#pragma mark - 刷新
//下拉刷新
-(void)headerRereshing
{
    _isFirst = NO;
    [self.reloadView removeFromSuperview];
    NSDictionary *postDict = @{@"endTime":_creat_time};
    __weakself__
    
    [BFReqAPI reqUpdateDataForDownRefreshWithParams:postDict block:^(id responseObj, NSError *error) {
        [_regularTableView.header endRefreshing];
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                //将数据通过plist缓存到本地
                NSArray*array = [[responseObj objectForKey:@"obj"] objectForKey:@"productIndexDtos"];
                
                NSError *parseError = nil;
                NSData  *jsonData = [NSJSONSerialization dataWithJSONObject:responseObj options:NSJSONWritingPrettyPrinted error:&parseError];
                if (!IsEmptyString(memberID)) {
                    [@{memberID:jsonData} writeToFile:MAKE_MONEY_DATA atomically:YES];
                }
                //刷新的时候去除所有的数据再重新添加
                [billsArray removeAllObjects];
                for (NSDictionary *dict in array) {
                    Bills *bills = [Bills billsWithDict:dict];
                    [billsArray addObject:bills];
                }
                //最后一次请求的时间
                _creat_time = [[billsArray lastObject] create_time];
                if (_creat_time == nil||[_creat_time isKindOfClass:[NSNull class]]) {
                    _creat_time = @"";
                }
                //回到主线程里面刷新UI
                [_regularTableView reloadData];//最好先刷新table再停止
                [_regularTableView.footer resetNoMoreData];
            }else
            {
                if (ERROR_CODE == -10) {
                    [[[UIAlertView alloc] initWithTitle:nil message:CROWD_OUT_MESSAGE delegate:weakself cancelButtonTitle:@"重新登录" otherButtonTitles:nil, nil] show];
                }else
                {
                    [UIAlertView showWithMessage:responseObj[@"message"] delegate:self];
                }
            }
        }else
        {
            if (billsArray.count==0) {
                [weakself.view addSubview:weakself.reloadView];
            }
        }
    }];
}
//上拉加载
-(void)footerRereshing
{
    NSDictionary *postDict = @{@"endTime":_creat_time};
    __weakself__
    [BFReqAPI reqUpdateDataForUpRefreshWithParams:postDict block:^(id responseObj, NSError *error) {
        [_regularTableView.footer endRefreshing];
        if (responseObj != nil) {
            if (ERROR_CODE==1)
            {
                NSDictionary *obj = responseObj[@"obj"];
                if (![obj isKindOfClass:[NSNull class]])
                {
                    NSArray*array = obj[@"productIndexDtos"];
                    //保存数据到plist文件
                    NSError *parseError = nil;
                    NSData  *jsonData = [NSJSONSerialization dataWithJSONObject:responseObj options:NSJSONWritingPrettyPrinted error:&parseError];
                    if (!IsEmptyString(memberID)){
                        [@{memberID:jsonData} writeToFile:MAKE_MONEY_DATA atomically:YES];
                    }
                    for (NSDictionary *dict in array)
                    {
                        Bills *bills = [Bills billsWithDict:dict];
                        [billsArray addObject:bills];
                    }
                    //最后一次刷新时间
                    _creat_time = [[billsArray lastObject] create_time];
                    if (_creat_time == nil||[_creat_time isKindOfClass:[NSNull class]]) {
                        _creat_time = @"";
                    }
                    //回到主线程刷新UI
                    [_regularTableView reloadData];
                }
                
            }else//没有数据的时候修改文字属性并刷新UI
            {
                [_regularTableView.footer noticeNoMoreData];
                if (ERROR_CODE == -10) {
                    [[[UIAlertView alloc] initWithTitle:nil message:CROWD_OUT_MESSAGE delegate:weakself cancelButtonTitle:@"重新登录" otherButtonTitles:nil, nil] show];
                }
                
            }
        }
    }];
}

@end

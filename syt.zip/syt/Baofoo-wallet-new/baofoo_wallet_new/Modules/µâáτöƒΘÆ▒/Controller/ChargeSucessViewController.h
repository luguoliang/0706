//
//  ChargeSucessViewController.h
//  aaa
//
//  Created by 路国良 on 15/8/5.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChargeSucessViewController : UIViewController

@end

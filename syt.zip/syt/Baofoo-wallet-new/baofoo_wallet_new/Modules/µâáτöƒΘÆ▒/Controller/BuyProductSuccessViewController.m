//
//  BuyProductSuccessViewController.m
//  makr
//
//  Created by mac on 15/4/27.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "BuyProductSuccessViewController.h"
#import "BuySuccessView.h"
@interface BuyProductSuccessViewController ()
@property(nonatomic,strong)BuySuccessView *successView;//购买成功界面
@property(nonatomic,strong)UIButton *completeBtn;//完成按钮
@property(nonatomic,strong)UIScrollView *rootViewScrollView;//geng
@end

@implementation BuyProductSuccessViewController
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationItem setHidesBackButton:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.nameTitle;
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.view.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
    [self.view addSubview:self.rootViewScrollView];
    [self.rootViewScrollView addSubview:self.successView];
    [self.rootViewScrollView addSubview:self.completeBtn];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"NSNotificationBuySuccess" object:nil];
}
//滑动视图
- (UIScrollView *)rootViewScrollView
{
    if (!_rootViewScrollView) {
        _rootViewScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0.0f, ScreenWidth, ScreenHeight-64)];
        _rootViewScrollView.backgroundColor = COLOR_HEXSTRING(@"#f1eff6");
        _rootViewScrollView.contentSize = CGSizeMake(ScreenWidth, ScreenHeight-64);
        _rootViewScrollView.alwaysBounceVertical = YES;
    }
    return _rootViewScrollView;
}

- (BuySuccessView *)successView
{
    if (!_successView) {
        _successView = [[[NSBundle mainBundle] loadNibNamed:@"BuySuccessView" owner:nil options:nil] lastObject];
        _successView.frame = CGRectMake(0, 0, ScreenWidth, 230.0f);
        _successView.timeLabel.text = [NSString stringWithFormat:@"%@ 还本付息",self.endTime];
        _successView.buyMoneyLabel.text = [NSString stringWithFormat:@"%@元",self.buy_amount];
        
        NSLog(@"我购买成功的金额是 %@",self.exp_expire_amount);
        double amount = [self.exp_expire_amount doubleValue];
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = NSNumberFormatterDecimalStyle;
        self.exp_expire_amount = [formatter stringFromNumber:[NSNumber numberWithDouble:amount]];
        
        _successView.getMoneyLabel.attributedText = [NSMutableAttributedString stringWithText1:[NSString stringWithFormat:@"%@",self.exp_expire_amount] text2:@"元" text1Color:COLOR_HEXSTRING(RED_COLOR) text2Color:COLOR_HEXSTRING(BLACK_COLOR) font1:FONT_LIGHT(14.0f) font2:FONT_LIGHT(14.0f)];
    }
    return _successView;
}
//确认购买按钮
- (UIButton *)completeBtn
{
    if (!_completeBtn) {
        _completeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _completeBtn.frame = CGRectMake(0, _successView.frame.origin.y+_successView.frame.size.height+20.0f, ScreenWidth, 40.0f);
        [_completeBtn setTitle:@"完成" forState:UIControlStateNormal];
        [_completeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _completeBtn.backgroundColor = COLOR_HEXSTRING(@"#5caefc");
        [_completeBtn addTarget:self action:@selector(completeSomething) forControlEvents:UIControlEventTouchUpInside];
    }
    return _completeBtn;
}
- (void)completeSomething
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

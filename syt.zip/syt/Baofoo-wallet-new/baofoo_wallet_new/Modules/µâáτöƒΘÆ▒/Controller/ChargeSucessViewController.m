//
//  ChargeSucessViewController.m
//  aaa
//
//  Created by 路国良 on 15/8/5.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "ChargeSucessViewController.h"
#import "UIColor+Hexadecimal.h"
#import "FormatterString.h"
#define SCREE_W        self.view.frame.size.width
#define SCREE_H        self.view.frame.size.height
#define BUTTON_COLOR   @"2e8fd3"
#define VIEW_COLOR     @"efeff4"
#define BUTTON_X       (50+80+100+23+64)
#define BUTTON_HEIGHT   40
#define BUTTON_WIDTH    293
#define HeaderInSection 0.00001f
#define FOOTVIEW_HEIGHT  57
#define HEADERVIEW_HEIGHT 92
#define ALPHACOLOR      @"b5b5b5"
#define GOARY_COLOR     @"ececec"
#import "CashRegisterLocationCache.h"
@interface ChargeSucessViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView*tableView;
    UIView*_bufferView1;
    UIView*_bufferView2;
    UIView*_roundView1;
    UIView*_roundView2;
    UIView*_roundView3;
    NSTimer*timer;
    float  loadinter;
    UILabel*_moneyL;
    UILabel*_productLabel;
    UILabel*_endtimeLabel;
    NSDictionary*temDictionary;
}
@end

@implementation ChargeSucessViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    temDictionary = [NSDictionary dictionaryWithDictionary:[[CashRegisterLocationCache sharedManager] getDisplayCashRegisterCachetDict]];
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [backBtn setFrame:CGRectMake(0, 0, 0, 0)];
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    self.navigationItem.leftBarButtonItem = backItem;
    self.navigationItem.title = temDictionary[@"obj"][@"product_name"];
    self.view.backgroundColor = [UIColor colorWithHexString:VIEW_COLOR alpha:1.0f];
    UIView*headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREE_W, HEADERVIEW_HEIGHT)];
//    headerView.backgroundColor = [UIColor whiteColor];
    headerView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:headerView];
    
    
    _bufferView1 = [[UIView alloc] initWithFrame:CGRectMake(45, 69, (SCREE_W - 90)/2, 2.5f)];
    _bufferView1.frame = CGRectMake(45, 69, 0, 2.5f);
    _bufferView1.backgroundColor = [UIColor colorWithHexString:BLUE_COLOR alpha:1.0f];

    _bufferView2 = [[UIView alloc] initWithFrame:CGRectMake(45, 69, (SCREE_W - 90), 2.5f)];
    _bufferView2.backgroundColor = [UIColor colorWithHexString:GOARY_COLOR alpha:1.0f];
    [headerView addSubview:_bufferView2];
    [headerView addSubview:_bufferView1];

    _roundView1 = [[UIView alloc] initWithFrame:CGRectMake(45-1, 69-(7.5 - 2.5)/2, 7.5, 7.5)];
    _roundView1.backgroundColor = [UIColor colorWithHexString:GOARY_COLOR alpha:1.0f];
    _roundView1.layer.cornerRadius = 7.5/2;
    [headerView addSubview:_roundView1];

    _roundView2 = [[UIView alloc] initWithFrame:CGRectMake(45+SCREE_W - 90 - 7.5+1, 69-(7.5 - 2.5)/2, 7.5, 7.5)];
    _roundView2.backgroundColor = [UIColor colorWithHexString:GOARY_COLOR alpha:1.0f];
    _roundView2.layer.cornerRadius = 7.5/2;
    [headerView addSubview:_roundView2];

    _roundView3 = [[UIView alloc] initWithFrame:CGRectMake((SCREE_W - 7.5)/2, 69-(7.5 - 2.5)/2, 7.5, 7.5)];
    _roundView3.backgroundColor = [UIColor colorWithHexString:GOARY_COLOR alpha:1.0f];
    _roundView3.layer.cornerRadius = 7.5/2;
    [headerView addSubview:_roundView3];
    
     UILabel*statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(23, 23, SCREE_W/2 - 26, 13.5)];
    statusLabel.text = @"购买成功";
    statusLabel.font = [UIFont systemFontOfSize:16.0F];
    statusLabel.textAlignment = NSTextAlignmentLeft;
    statusLabel.textColor = [UIColor colorWithHexString:BLUE_COLOR alpha:1.0f];
    [headerView addSubview:statusLabel];
    
    
    UILabel*startimeLabel  = [[UILabel alloc] initWithFrame:CGRectMake(23, CGRectGetMaxY(statusLabel.frame)+6.5, SCREE_W/2 - 26, 13.5)];
    startimeLabel.text = temDictionary[@"obj"][@"create_time"];
    startimeLabel.font = [UIFont systemFontOfSize:12.0F];
    startimeLabel.textAlignment = NSTextAlignmentLeft;
    startimeLabel.textColor = [UIColor colorWithHexString:BLUE_COLOR alpha:1.0f];
    [headerView addSubview:startimeLabel];

    UILabel*bengLabel = [[UILabel alloc] initWithFrame:CGRectMake((SCREE_W - (SCREE_W/2 - 26))/2, 23, SCREE_W/2 - 26, 13.5)];
    bengLabel.text = @"起息日";
    bengLabel.textAlignment = NSTextAlignmentCenter;
    bengLabel.font = [UIFont systemFontOfSize:16.0F];
    [headerView addSubview:bengLabel];
    
    
    UILabel*bengLabel2  = [[UILabel alloc] initWithFrame:CGRectMake((SCREE_W - (SCREE_W/2 - 26))/2, CGRectGetMaxY(statusLabel.frame)+6.5, SCREE_W/2 - 26, 13.5)];
    bengLabel2.text = temDictionary[@"obj"][@"startTime"];
    bengLabel2.font = [UIFont systemFontOfSize:12.0F];
    bengLabel2.textAlignment = NSTextAlignmentCenter;
    [headerView addSubview:bengLabel2];
    
    _productLabel = [[UILabel alloc] initWithFrame:CGRectMake(SCREE_W - (23+(SCREE_W/2 - 26)), 23, SCREE_W/2 - 26, 13.5)];
    _productLabel.text = @"结息日";
    _productLabel.font = [UIFont systemFontOfSize:16.0F];
    _productLabel.textAlignment = NSTextAlignmentRight;
//    productLabel.textColor = [UIColor colorWithHexString:@"a1bf3a" alpha:1.0f];
    [headerView addSubview:_productLabel];
    
    
    _endtimeLabel  = [[UILabel alloc] initWithFrame:CGRectMake(SCREE_W - (23+(SCREE_W/2 - 26)), CGRectGetMaxY(statusLabel.frame)+6.5, SCREE_W/2 - 26, 13.5)];
    _endtimeLabel.text = temDictionary[@"obj"][@"endTime"];
    _endtimeLabel.font = [UIFont systemFontOfSize:12.0F];
    _endtimeLabel.textAlignment = NSTextAlignmentRight;
//    endtimeLabel.textColor = [UIColor colorWithHexString:@"a1bf3a" alpha:1.0f];
    [headerView addSubview:_endtimeLabel];

    
    
    
    
    
    
    UIView*linde = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(headerView.frame), SCREE_W, 0.5f)];
    linde.backgroundColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0f];
    [self.view addSubview:linde];
    
    UILabel*labelll = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(linde.frame), SCREE_W, 35)];
    labelll.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:labelll];
    labelll.text = @"产品到期后1到2个工作日内本息自动返还至账户余额";
    labelll.textAlignment = NSTextAlignmentCenter;
    labelll.textColor = [UIColor colorWithHexString:@"ff722c" alpha:1.0f];
    labelll.font = [UIFont systemFontOfSize:12.0f];
    UIView*linde3 = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(linde.frame)+35, SCREE_W, 0.5f)];
    linde3.backgroundColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0f];
    [self.view addSubview:linde3];
    
    
    
    
    UIView*footView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(linde3.frame), SCREE_W, FOOTVIEW_HEIGHT)];
    footView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:footView];
    
    UILabel*bankcardLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, SCREE_W/2 - 15, (FOOTVIEW_HEIGHT-30)/2)];
    bankcardLabel.text = @"购买金额";
    bankcardLabel.font = [UIFont systemFontOfSize:14.0f];
    bankcardLabel.textColor = [UIColor colorWithHexString:ALPHACOLOR alpha:1.0f];
    [footView addSubview:bankcardLabel];
    
    UILabel*moneyLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(bankcardLabel.frame)+10, SCREE_W/2 - 15, (FOOTVIEW_HEIGHT-30)/2)];
    moneyLabel.text = @"预期总收益";
    moneyLabel.font = [UIFont systemFontOfSize:14.0f];
    moneyLabel.textColor = [UIColor colorWithHexString:ALPHACOLOR alpha:1.0f];
    [footView addSubview:moneyLabel];

    UILabel*banknameLabel = [[UILabel alloc] initWithFrame:CGRectMake(SCREE_W - (SCREE_W/2), 10, SCREE_W/2 - 15, (FOOTVIEW_HEIGHT-30)/2)];
    banknameLabel.text = [NSString stringWithFormat:@"%@元",[[FormatterString sharedManager] formatterStringWithString:temDictionary[@"obj"][@"buy_amount"]]];
    
    banknameLabel.textAlignment = NSTextAlignmentRight;
    banknameLabel.font = [UIFont systemFontOfSize:14.0f];
    [footView addSubview:banknameLabel];
    
    _moneyL = [[UILabel alloc] initWithFrame:CGRectMake(SCREE_W - (SCREE_W/2), CGRectGetMaxY(banknameLabel.frame)+10, SCREE_W/2 - 15, (FOOTVIEW_HEIGHT-30)/2)];
    _moneyL.text = [NSString stringWithFormat:@"%@元",[[FormatterString sharedManager] formatterStringWithString:temDictionary[@"obj"][@"exp_expire_amount"]]];
    _moneyL.textAlignment = NSTextAlignmentRight;
    _moneyL.font = [UIFont systemFontOfSize:14.0f];
    [footView addSubview:_moneyL];
    
    UIView*linde2 = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(footView.frame), SCREE_W, 0.5f)];
    [self.view addSubview:linde2];
    linde2.backgroundColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0f];

    [self setnavigationBar];
    // Do any additional setup after loading the view.
}

-(void)setnavigationBar
{
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [rightButton setFrame:CGRectMake(0, 0, 30, 20)];
    [rightButton addTarget:self action:@selector(rightBtn) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setTitle:@"完成" forState:UIControlStateNormal];
    [rightButton setTitleColor:[UIColor colorWithHexString:@"ff722c" alpha:1.0f] forState:UIControlStateNormal];
    rightButton.titleLabel.font = [UIFont systemFontOfSize:12.0f];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithCustomView:rightButton];
    self.navigationItem.rightBarButtonItem = rightItem;
}

-(void)rightBtn
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    
//    _roundView1.backgroundColor = [UIColor colorWithHexString:BLUE_COLOR alpha:1.0f];
//    [UIView animateWithDuration:0.5 animations:^{
//        _bufferView1.frame = CGRectMake(45, 69, (SCREE_W - 90), 2.5f);
//    } completion:^(BOOL finished) {
//        _roundView2.backgroundColor = [UIColor colorWithHexString:BLUE_COLOR alpha:1.0f];
//        _productLabel.textColor = [UIColor colorWithHexString:BLUE_COLOR alpha:1.0f];
//        _endtimeLabel.textColor = [UIColor colorWithHexString:BLUE_COLOR alpha:1.0f];
//    }];
    
    
    _roundView1.backgroundColor = [UIColor colorWithHexString:BLUE_COLOR alpha:1.0f];
    [UIView animateWithDuration:0.5 animations:^{
        _bufferView1.frame = CGRectMake(45, 69, (SCREE_W - 90)/4, 2.5f);
    } completion:^(BOOL finished) {
//        _roundView2.backgroundColor = [UIColor colorWithHexString:BLUE_COLOR alpha:1.0f];
//        _productLabel.textColor = [UIColor colorWithHexString:BLUE_COLOR alpha:1.0f];
//        _endtimeLabel.textColor = [UIColor colorWithHexString:BLUE_COLOR alpha:1.0f];
    }];

    
}

-(void)animatiom1
{
    
}

-(void)timerclick
{
    NSLog(@"定时器");
    if (loadinter < 10086.86) {
        _moneyL.text = [NSString stringWithFormat:@"%f",loadinter];
        loadinter = loadinter+0.01;
    }
    
    else
    {
        
    }
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    return cell;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 1;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return HeaderInSection;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return HeaderInSection;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        return 92.0f;
    }else
        return 57.50f;
}
-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self performSelector:@selector(deselect) withObject:nil afterDelay:0.1f];
}

- (void)deselect
{
    [tableView deselectRowAtIndexPath:[tableView indexPathForSelectedRow] animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

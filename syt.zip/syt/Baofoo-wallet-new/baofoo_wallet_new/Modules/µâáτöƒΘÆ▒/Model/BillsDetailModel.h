//
//  BillsDetailModel.h
//  makr
//
//  Created by mac on 15/4/23.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <Foundation/Foundation.h>
@class ProductDtoModel;

@interface BillsDetailModel : NSObject
@property(nonatomic,copy)NSString *buy_amount_begin;//起投金额
@property(nonatomic,copy)NSString *buy_time_count;//投资期限
@property(nonatomic,copy)NSString *extra_rate;//额外年化率
@property(nonatomic,copy)NSString *product_id;
@property(nonatomic,copy)NSString *millionExpExpireAmount;//万元预期总收益
@property(nonatomic,copy)NSString *product_name;//名称
@property(nonatomic,copy)NSString *product_tag;
@property(nonatomic,copy)NSString *product_type_tag;//标签
@property(nonatomic,copy)NSString *rate;//已购
@property(nonatomic,copy)NSString *remainingTime;//剩余时间
@property(nonatomic,copy)NSString *total_money;
@property(nonatomic,copy)NSString *year_rate;//预期年化率

+ (BillsDetailModel *)parserStatusWithDictionary:(NSDictionary *)dict;
@end

/*
 "buy_amount_begin" = 1;
 "buy_time_count" = 365;
 "extra_rate" = 0;
 id = 135;
 millionExpExpireAmount = 10000;
 "product_name" = "\U6d4b\U8bd5027";
 "product_tag" = 30;
 "product_type_tag" = "\U7968";
 rate = 1;
 remainingTime = 10034051542;
 "total_money" = 10000;
 "year_rate" = 100;
 */


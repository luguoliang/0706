//
//  BillsDetailModel.m
//  makr
//
//  Created by mac on 15/4/23.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "BillsDetailModel.h"

@implementation BillsDetailModel
+(BillsDetailModel *)parserStatusWithDictionary:(NSDictionary *)dict
{
    BillsDetailModel *details = [[BillsDetailModel alloc] init];
    details.buy_amount_begin        = [details getNSString:dict[@"buy_amount_begin"]];
    details.buy_time_count          = [details getNSString:dict[@"buy_time_count"]];
    details.extra_rate              = [details getNSString:dict[@"extra_rate"]];
    details.product_id              = [details getNSString:dict[@"id"]];
    details.millionExpExpireAmount  = [details getNSString:dict[@"millionExpExpireAmount"]];
    details.product_name            = [details getNSString:dict[@"product_name"]];
    details.product_tag             = [details getNSString:dict[@"product_tag"]];
    details.product_type_tag        = [details getNSString:dict[@"product_type_tag"]];
    details.rate                    = [details getNSString:dict[@"rate"]];
    details.remainingTime           = [details getNSString:dict[@"remainingTime"]];
    details.total_money             = [details getNSString:dict[@"total_money"]];
    details.year_rate               = [details getNSString:dict[@"year_rate"]];
    
    return details;
}
- (NSString *)getNSString:(NSString *)string
{
    return [NSString stringWithFormat:@"%@",string];
}
@end




//
//  HsqCellModel.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/4/6.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "HsqListCellModel.h"

@implementation HsqListCellModel
-(id)initWithDict:(NSDictionary *)dict{
    if (self = [super init]) {
        self.year_rate          = dict[@"year_rate"];
        self.extra_rate         = dict[@"extra_rate"];
        self.total_money        = dict[@"total_money"];
        self.rate               = dict[@"rate"];
        self.product_tag        = dict[@"product_tag"];
        self.product_type_tag   = dict[@"product_type_tag"];
        self.buy_time_count     = dict[@"buy_time_count"];
        self.product_name       = dict[@"product_name"];
        self.product_Id         = dict[@"id"];
        self.create_time        = dict[@"create_time"];
    }
    return self;
}

+(id)hsqWithDict:(NSDictionary *)dict{
    
    return [[self alloc] initWithDict:dict];
}
@end

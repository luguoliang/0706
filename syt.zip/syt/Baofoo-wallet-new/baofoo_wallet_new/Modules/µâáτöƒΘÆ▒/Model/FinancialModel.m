//
//  FinancialModel.m
//  makr
//
//  Created by mac on 15/4/27.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "FinancialModel.h"

@implementation FinancialModel
+ (FinancialModel *)parserStatusWithDictionary:(NSDictionary *)dict
{
    FinancialModel *financialModel = [[FinancialModel alloc] init];
    financialModel.endTime = dict[@"endTime"];
    financialModel.exp_expire_amount = dict[@"exp_expire_amount"];
    financialModel.buy_amount = dict[@"buy_amount"];
    financialModel.product_name = dict[@"product_name"];
    financialModel.product_id = dict[@"product_id"];
    financialModel.startTime = dict[@"startTime"];
    financialModel.state = dict[@"state"];
    financialModel.product_type_tag = dict[@"product_type_tag"];
    financialModel.is_haveProtocol = dict[@"is_haveProtocol"];
    financialModel.order_id = dict[@"order_id"];
    return financialModel;
}
@end

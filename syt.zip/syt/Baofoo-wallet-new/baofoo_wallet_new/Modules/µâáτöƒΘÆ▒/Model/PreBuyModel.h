//
//  PreBuyModel.h
//  makr
//
//  Created by mac on 15/4/27.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PreBuyModel : NSObject



@property(nonatomic,copy)NSString *buy_amount_begin;//起投金额
@property(nonatomic,copy)NSString *buy_time_count;// 投资期限天
@property(nonatomic,copy)NSString *canBuyMoney;// 可以购买金额
@property(nonatomic,copy)NSString *extra_rate;// 额外收益
@property(nonatomic,copy)NSString *product_id;//产品ID
@property(nonatomic,copy)NSString *increase_amount;//递增金额
@property(nonatomic,copy)NSString *limit_amount;//限额 如果限额为负数 表示没有限额限制
@property(nonatomic,copy)NSString *product_name;// 产品名称
@property(nonatomic,copy)NSString *randomKey;//随机数
@property(nonatomic,copy)NSString *total_money;// 筹集资金集，最多多少
@property(nonatomic,copy)NSString *year_rate;// 年化收益







+ (PreBuyModel *)parserStatusWithDictionary:(NSDictionary *)dict;
@end

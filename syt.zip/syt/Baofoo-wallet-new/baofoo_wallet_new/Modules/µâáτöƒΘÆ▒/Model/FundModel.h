//
//  FundModel.h
//  BaofooWallet
//
//  Created by 吴斌 on 16/3/18.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FundModel : NSObject
@property(nonatomic,copy)NSString *type;//标示基金产品和票据产品 fund基金 hsq基金
@property(nonatomic,copy)NSString *click;//跳转接口
@property(nonatomic,copy)NSString *dueTime;//投资期限
@property(nonatomic,copy)NSString *product_id;//产品id
@property(nonatomic,copy)NSString *name;//产品名称
@property(nonatomic,copy)NSString *rate;//预期年化收益率
@property(nonatomic,copy)NSString *sort;//产品排序
@property(nonatomic,copy)NSString *tag;//产品状态
@property(nonatomic,copy)NSString *typeTag;//产品类型
@property(nonatomic,copy)NSString *buyMinMoney;//起购金额
@property(nonatomic,copy)NSString *code;//基金编码
@property(nonatomic,copy)NSString *progress;//票据产品进度
@property(nonatomic,copy)NSString *totleMoney;//融资总额
@property(nonatomic,copy)NSString *extraRate;//额外收益
@property(nonatomic,copy)NSString *showTags;//额外收益

+ (FundModel *)parserStatusWithDictionary:(NSDictionary *)dict;
@end

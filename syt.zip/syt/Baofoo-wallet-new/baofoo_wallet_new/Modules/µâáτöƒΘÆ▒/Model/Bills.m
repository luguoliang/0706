//
//  Bills.m
//  makr
//
//  Created by 路国良 on 15/4/16.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "Bills.h"

@implementation Bills
+(id)billsWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}
-(id)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.buy_amount_begin   = [self getNSString:dict[@"buy_amount_begin"]];
        self.year_rate          = [self getNSString:dict[@"year_rate"]];
        self.extra_rate         = [self getNSString:dict[@"extra_rate"]];
        self.total_money        = [self getNSString:dict[@"total_money"]];
        self.rate               = [self getNSString:dict[@"rate"]];
        self.product_tag        = [self getNSString:dict[@"product_tag"]];
        self.product_type_tag   = [self getNSString:dict[@"product_type_tag"]];
        self.buy_time_count     = [self getNSString:dict[@"buy_time_count"]];
        self.product_name       = [self getNSString:dict[@"product_name"]];
        self.product_Id         = [self getNSString:dict[@"id"]];
        self.create_time        = [self getNSString:dict[@"create_time"]];
        self.showTags           = [self getNSString:dict[@"showTags"]];
    }
    return self;
}
- (NSString *)getNSString:(NSString *)string
{
    
    string = [NSString stringWithFormat:@"%@",string];
    if ([string isKindOfClass:[NSNull class]]||[string isEqualToString:@"<null>"]||[string isEqualToString:@"(null)"]) {
        string = @"";
    }
    return string;
}
@end

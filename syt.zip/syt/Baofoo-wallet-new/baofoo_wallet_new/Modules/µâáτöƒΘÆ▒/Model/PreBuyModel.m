//
//  PreBuyModel.m
//  makr
//
//  Created by mac on 15/4/27.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "PreBuyModel.h"

@implementation PreBuyModel
+ (PreBuyModel *)parserStatusWithDictionary:(NSDictionary *)dict
{
    PreBuyModel *model = [[PreBuyModel alloc] init];
    model.buy_amount_begin  = [model getNSString:dict[@"buy_amount_begin"]];
    model.buy_time_count    = [model getNSString:dict[@"buy_time_count"]];
    model.canBuyMoney       = [model getNSString:dict[@"canBuyMoney"]];
    model.extra_rate        = [model getNSString:dict[@"extra_rate"]];
    model.product_id        = [model getNSString:dict[@"id"]];
    model.limit_amount      = [model getNSString:dict[@"limit_amount"]];
    model.product_name      = [model getNSString:dict[@"product_name"]];
    model.randomKey         = [model getNSString:dict[@"randomKey"]];
    model.total_money       = [model getNSString:dict[@"total_money"]];
    model.year_rate         = [model getNSString:dict[@"year_rate"]];
    model.increase_amount   = [model getNSString:dict[@"increase_amount"]];
    
    return model;
}

- (NSString *)getNSString:(NSString *)string
{
    return [NSString stringWithFormat:@"%@",string];
}
@end

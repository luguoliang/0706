//
//  Bills.h
//  makr
//
//  Created by 路国良 on 15/4/16.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Bills : NSObject
@property(nonatomic,copy)NSString *buy_amount_begin;//起购金额
@property(nonatomic,copy)NSString*buy_time_count;//投资期限
@property(nonatomic,copy)NSString*year_rate;//年率化
@property(nonatomic,copy)NSString*extra_rate;//年率+号
@property(nonatomic,copy)NSString*total_money;//总额
@property(nonatomic,copy)NSString*rate;//进度
@property(nonatomic,copy)NSString*product_tag;//产品标签,在售(10)、新手标（20）、推荐（30）、售罄（40)、收益中(50)、本息已返还(60)
@property(nonatomic,copy)NSString*showTags;
@property(nonatomic,copy)NSString*product_type_tag;//产品类型标签(票、基金）
@property(nonatomic,copy)NSString*product_name;//票据通1期
@property(nonatomic,copy)NSString *product_Id;//产品Id
@property(nonatomic,copy)NSString *create_time;//时间

/*
 
 "buy_time_count" = 90;
 "create_time" = 20150805113244;
 "extra_rate" = 0;
 id = 155;
 "product_name" = "\U63a8\U8350002";
 "product_tag" = 40;
 "product_type_tag" = "\U7968";
 rate = 100;
 "total_money" = 10000;
 "year_rate" = 8;
 */
-(id)initWithDict:(NSDictionary*)dict;
+(id)billsWithDict:(NSDictionary*)dict;
@end

//
//  FundModel.m
//  BaofooWallet
//
//  Created by 吴斌 on 16/3/18.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import "FundModel.h"

@implementation FundModel

+ (FundModel *)parserStatusWithDictionary:(NSDictionary *)dict
{
    FundModel *fundModel = [[FundModel alloc] init];

    fundModel.type = [fundModel getNSString:dict[@"type"]];
    fundModel.click = [fundModel getNSString:dict[@"click"]];
    fundModel.dueTime = [fundModel getNSString:dict[@"dueTime"]];
    fundModel.product_id = [fundModel getNSString:dict[@"id"]];
    fundModel.name = [fundModel getNSString:dict[@"name"]];
    fundModel.rate = [fundModel getNSString:dict[@"rate"]];
    fundModel.sort = [fundModel getNSString:dict[@"sort"]];
    fundModel.tag = [fundModel getNSString:dict[@"tag"]];
    fundModel.typeTag = [fundModel getNSString:dict[@"typeTag"]];
    fundModel.buyMinMoney = [fundModel getNSString:dict[@"buyMinMoney"]];
    fundModel.code = [fundModel getNSString:dict[@"code"]];
    fundModel.progress = [fundModel getNSString:dict[@"progress"]];
    fundModel.totleMoney = [fundModel getNSString:dict[@"totleMoney"]];
    fundModel.extraRate = [fundModel getNSString:dict[@"extraRate"]];
    fundModel.showTags = [fundModel getNSString:dict[@"showTags"]];
    return fundModel;
}

- (NSString *)getNSString:(NSString *)string
{
    string = [NSString stringWithFormat:@"%@",string];
    if ([string isKindOfClass:[NSNull class]]||[string isEqualToString:@"<null>"]||[string isEqualToString:@"(null)"]) {
        string = @"";
    }
    return string;
}
@end

//
//  FinancialModel.h
//  makr
//
//  Created by mac on 15/4/27.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FinancialModel : NSObject
@property(nonatomic,copy)NSString *endTime;//到期日期
@property(nonatomic,copy)NSString *exp_expire_amount;//预计到期利息
@property(nonatomic,copy)NSString *buy_amount;//申购份额
@property(nonatomic,copy)NSString *product_name;//产品名称
@property(nonatomic,copy)NSString *product_id;//产品ID
@property(nonatomic,copy)NSString *state;//首页展示状态 10募集中 20计息中 30赎回中 40已完成
@property(nonatomic,copy)NSString *startTime;//起息日期
@property(nonatomic,copy)NSString *product_type_tag;// 产品类型标签
@property(nonatomic,copy)NSString *is_haveProtocol;//是否有协议按钮
@property(nonatomic,copy)NSString *order_id;//订单号

+ (FinancialModel *)parserStatusWithDictionary:(NSDictionary *)dict;
@end

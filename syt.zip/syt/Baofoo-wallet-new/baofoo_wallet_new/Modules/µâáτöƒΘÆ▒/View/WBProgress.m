//
//  WBProgress.m
//  BaofooWallet
//
//  Created by 吴斌 on 16/4/25.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import "WBProgress.h"
#define DefaultLineWidth 5

@interface WBProgress ()

@property (nonatomic,strong) CAShapeLayer *backgroundLayer;
@property (nonatomic,strong) CAShapeLayer *progressLayer;
@property (nonatomic,strong) UIImageView *progressImageView;

@property (nonatomic,assign) CGFloat sumSteps;
@property (nonatomic,strong) NSTimer *timer;
@property (nonatomic,assign) WBProgressViewStyle style;

@property (nonatomic,assign)CGFloat sum;
@end
@implementation WBProgress

//默认样式 none
-(instancetype) initWithFrame:(CGRect)frame
{
    return [self initWithFrame:frame style:WBProgressViewStyleNone];
    
}
- (instancetype) initWithFrame:(CGRect)frame style:(WBProgressViewStyle)style
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self setBackgroundColor:[UIColor clearColor]];
        
        self.style = style;
        [self layoutViews:style];
        
        //init default variable
        self.GapWidth = 10.0;
        if (WBProgressViewStyleImageSegment == style) {
            self.backgourndLineWidth = 3;
            self.progressLineWidth = 3;
        }
        else{
            self.backgourndLineWidth = DefaultLineWidth;
            self.progressLineWidth = DefaultLineWidth;
        }
        
        self.Percentage = 0;
        self.offset = 0;
        self.sumSteps = 0;
        self.step = 0.1;
        self.timeDuration = 5.0;
    }
    return self;
}

- (instancetype) initWithFrame:(CGRect)frame style:(WBProgressViewStyle)style withImage:(UIImage *)image
{
    self.image = (style == WBProgressViewStyleImageSegment) ? image :nil;
    return [self initWithFrame:frame style:style];
}

-(void) layoutViews:(WBProgressViewStyle)style
{
    [self.progressLabel setTextColor:[UIColor whiteColor]];
    self.progressLabel.textAlignment = NSTextAlignmentCenter;
    self.progressLabel.font = [UIFont systemFontOfSize:15];
    [self addSubview:self.progressLabel];
    
    if (!_backgroundLayer) {
        _backgroundLayer = [CAShapeLayer layer];
        _backgroundLayer.frame = self.bounds;
        _backgroundLayer.fillColor = nil;
        _backgroundLayer.strokeColor = [UIColor brownColor].CGColor;
    }
    
    if (!_progressLayer) {
        _progressLayer = [CAShapeLayer layer];
        _progressLayer.frame = self.bounds;
        _progressLayer.fillColor = nil;
        _progressLayer.strokeColor = [UIColor whiteColor].CGColor;
    }
    
    
    switch (style) {
        case WBProgressViewStyleNone:
            
            break;
        case WBProgressViewStyleSquareSegment:
            _backgroundLayer.lineCap = kCALineCapSquare;
            _backgroundLayer.lineJoin = kCALineCapSquare;
            
            _progressLayer.lineCap = kCALineCapSquare;
            _progressLayer.lineJoin = kCALineCapSquare;
            
            [self.progressImageView removeFromSuperview];
            self.progressImageView = nil;
            break;
            
        case WBProgressViewStyleRoundSegment:
            _backgroundLayer.lineCap = kCALineCapRound;
            _backgroundLayer.lineJoin = kCALineCapRound;
            
            _progressLayer.lineCap = kCALineCapRound;
            _progressLayer.lineJoin = kCALineCapRound;
            [self.progressImageView removeFromSuperview];
            self.progressImageView = nil;
            break;
        case WBProgressViewStyleImageSegment:
            
//            [_progressLabel removeFromSuperview];
//            _progressLabel = nil;
            
            self.progressImageView.frame = self.bounds;
            CGFloat imageViewHeight = CGRectGetHeight(self.progressImageView.frame);
            self.progressImageView.layer.cornerRadius = imageViewHeight/2;
            self.progressImageView.layer.masksToBounds = YES;
            self.progressImageView.image = self.image;
            [self addSubview:self.progressImageView];
            
            _backgroundLayer.lineCap = kCALineCapSquare;
            _backgroundLayer.lineJoin = kCALineCapSquare;
            
            _progressLayer.lineCap = kCALineCapSquare;
            _progressLayer.lineJoin = kCALineCapSquare;
            
            [self bringSubviewToFront:self.progressLabel];
            
            break;
        default:
            break;
    }
    
    [self.layer addSublayer:_backgroundLayer];
    [self.layer addSublayer:_progressLayer];
    
    
}
#pragma mark - draw circleLine
-(void) setBackgroundCircleLine:(WBProgressViewStyle)style
{
    UIBezierPath *path = [UIBezierPath bezierPath];
    if (style == WBProgressViewStyleNone ||  style == WBProgressViewStyleImageSegment) {
        path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(self.center.x - self.frame.origin.x,
                                                                 self.center.y - self.frame.origin.y)
                                              radius:(self.bounds.size.width - _backgourndLineWidth)/ 2 - _offset
                                          startAngle:0
                                            endAngle:M_PI*2
                                           clockwise:YES];
    }
    else
    {
        static float minAngle = 0.0081;
        
        for (int i = 0; i < ceil(360 / _GapWidth)+1; i++) {
            CGFloat angle = (i * (_GapWidth + minAngle) * M_PI / 180.0);
            
            if (i == 0) {
                angle = minAngle * M_PI/180.0;
            }
            
            if (angle >= M_PI *2) {
                angle = M_PI *2;
            }
            UIBezierPath *path1 = [UIBezierPath bezierPathWithArcCenter:CGPointMake(self.center.x - self.frame.origin.x,
                                                                                    self.center.y - self.frame.origin.y)
                                                                 radius:(self.bounds.size.width - _backgourndLineWidth)/ 2 - _offset
                                                             startAngle:-M_PI_2 +(i *_GapWidth * M_PI / 180.0)
                                                               endAngle:-M_PI_2 + angle
                                                              clockwise:YES];
            
            [path appendPath:path1];
            
        }
        
    }
    
    
    
    
    _backgroundLayer.path = path.CGPath;
    
}

-(void)setProgressCircleLine:(WBProgressViewStyle)style
{
    UIBezierPath *path = [UIBezierPath bezierPath];
    if (style == WBProgressViewStyleNone || style == WBProgressViewStyleImageSegment) {
        path = [UIBezierPath bezierPathWithArcCenter:CGPointMake(self.center.x - self.frame.origin.x,
                                                                 self.center.y - self.frame.origin.y)
                                              radius:(self.bounds.size.width - _progressLineWidth)/ 2 - _offset
                                          startAngle:-M_PI_2
                                            endAngle:-M_PI_2 + M_PI *2
                                           clockwise:YES];
    }
    else
    {
        static float minAngle = 0.0081;
        for (int i = 0; i < ceil(360 / _GapWidth *_Percentage)+1; i++) {
            CGFloat angle = (i * (_GapWidth + minAngle) * M_PI / 180.0);
            
            if (i == 0) {
                angle = minAngle * M_PI/180.0;
            }
            
            if (angle >= M_PI *2) {
                angle = M_PI *2;
            }
            UIBezierPath *path1 = [UIBezierPath bezierPathWithArcCenter:CGPointMake(self.center.x - self.frame.origin.x,
                                                                                    self.center.y - self.frame.origin.y)
                                                                 radius:(self.bounds.size.width - _progressLineWidth)/ 2 - _offset
                                                             startAngle:-M_PI_2 +(i *_GapWidth * M_PI / 180.0)
                                                               endAngle:-M_PI_2 + angle
                                                              clockwise:YES];
            
            [path appendPath:path1];
            
        }
        
    }
    //    NSLog(@"path:%@",path);
    _progressLayer.path = path.CGPath;
}


#pragma mark - setter and getter methond

-(UILabel *)progressLabel
{
    if(!_progressLabel)
    {
        _progressLabel = [[UILabel alloc] initWithFrame:CGRectMake((self.bounds.size.width - 100)/2, (self.bounds.size.height - 100)/2, 100, 100)];
    }
    return _progressLabel;
}
- (UIImageView *)progressImageView
{
    if (!_progressImageView) {
        _progressImageView = [[UIImageView alloc] init];
    }
    return _progressImageView;
}
-(void)setBackgourndLineWidth:(CGFloat)backgourndLineWidth
{
    _backgourndLineWidth = backgourndLineWidth;
    _backgroundLayer.lineWidth = backgourndLineWidth;
}

-(void)setProgressLineWidth:(CGFloat)progressLineWidth
{
    _progressLineWidth = progressLineWidth;
    _progressLayer.lineWidth = progressLineWidth;
    [self setBackgroundCircleLine:self.style];
    [self setProgressCircleLine:self.style];
}

-(void)setPercentage:(CGFloat)Percentage
{
    _Percentage = Percentage;
    [self setProgressCircleLine:self.style];
    [self setBackgroundCircleLine:self.style];
    ;
}

-(void)setBackgroundStrokeColor:(UIColor *)backgroundStrokeColor
{
    _backgroundStrokeColor = backgroundStrokeColor;
    _backgroundLayer.strokeColor = backgroundStrokeColor.CGColor;
}

-(void)setProgressStrokeColor:(UIColor *)progressStrokeColor
{
    _progressStrokeColor = progressStrokeColor;
    _progressLayer.strokeColor = progressStrokeColor.CGColor;
    
}

-(void)setDigitTintColor:(UIColor *)digitTintColor
{
    _digitTintColor = digitTintColor;
    _progressLabel.textColor = digitTintColor;
}

-(void)setGapWidth:(CGFloat)GapWidth
{
    _GapWidth = GapWidth;
    [self setBackgroundCircleLine:self.style];
    [self setProgressCircleLine:self.style];
    
}
-(void)setLineWidth:(CGFloat)lineWidth
{
    _lineWidth = lineWidth;
    
    _progressLineWidth = lineWidth;
    _progressLayer.lineWidth = lineWidth;
    
    _backgourndLineWidth = lineWidth;
    _backgroundLayer.lineWidth = lineWidth;
}


-(void)setImage:(UIImage *)image
{
    _image = image;
    [self layoutViews:WBProgressViewStyleImageSegment];
}

-(void)setTimeDuration:(CGFloat)timeDuration
{
    _timeDuration = timeDuration;
    [self setProgress:1.0 Animated:YES];
}
#pragma mark - progress animated YES or NO
-(void)setProgress:(CGFloat)Percentage Animated:(BOOL)animated
{
    self.sumSteps = 0;
    self.Percentage = Percentage;
    
    if (animated) {
        
        CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
        animation.fromValue = [NSNumber numberWithFloat:0.0];
        if (self.style ==  WBProgressViewStyleNone || self.style == WBProgressViewStyleImageSegment) {
            animation.toValue = [NSNumber numberWithFloat:_Percentage];
            _progressLayer.strokeEnd = _Percentage;
        }
        else
        {
            animation.toValue = [NSNumber numberWithFloat:1.0];
        }
        
        animation.duration = self.timeDuration;
        
        //start timer
        [NSThread detachNewThreadSelector:@selector(startTimer) toTarget:self withObject:nil];
        
        
        [_progressLayer addAnimation:animation forKey:@"strokeEndAnimation"];
        
    } else {
        [CATransaction begin];
        [CATransaction setDisableActions:YES];
        _progressLayer.strokeEnd = _Percentage;
        _progressLabel.text = [NSString stringWithFormat:@"%.0f%%",_Percentage*100];
        [CATransaction commit];
    }
}

- (void)startTimer
{
    _timer = [NSTimer scheduledTimerWithTimeInterval:_step
                                              target:self
                                            selector:@selector(numberAnimation:)
                                            userInfo:nil
                                             repeats:YES];
    [[NSRunLoop currentRunLoop] run];
}
-(void)numberAnimation:(NSTimer *)timer
{
    
    
    _sumSteps += _step;
    _sum =  (_Percentage*_sumSteps) /self.timeDuration ;
    
    if (_sumSteps > self.timeDuration) {
        [timer invalidate];
        timer = nil;
        return;
    }
    [self performSelectorOnMainThread:@selector(setLabelText) withObject:nil waitUntilDone:YES];

   
}
- (void)setLabelText
{
    if (self.Percentage == 999) {
        
    }else
    {
        if (![self.progressLabel.text isEqualToString:@"抢购"]&&![self.progressLabel.text isEqualToString:@"申购"]) {
            self.progressLabel.text = [NSString stringWithFormat:@"%.0f%%",_sum *100];
            
        }
    }
    
}
@end

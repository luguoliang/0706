//
//  BuySuccessView.h
//  makr
//
//  Created by mac on 15/4/27.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BuySuccessView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *successImageView;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *buyMoneyLabel;
@property (weak, nonatomic) IBOutlet UILabel *getMoneyLabel;

@end

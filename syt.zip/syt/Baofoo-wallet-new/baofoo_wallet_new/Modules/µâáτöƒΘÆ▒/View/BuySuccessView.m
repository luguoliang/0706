//
//  BuySuccessView.m
//  makr
//
//  Created by mac on 15/4/27.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "BuySuccessView.h"
#import "NSString+DetailString.h"
@implementation BuySuccessView

- (void)layoutSubviews
{
    [super layoutSubviews];
    _successImageView.layer.cornerRadius = self.successImageView.frame.size.height/2;
    _successImageView.layer.masksToBounds = YES;
}

@end

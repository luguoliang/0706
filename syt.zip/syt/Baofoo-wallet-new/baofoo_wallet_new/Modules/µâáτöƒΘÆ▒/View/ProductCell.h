//
//  ProductCell.h
//  BaofooWallet
//
//  Created by mac on 15/5/13.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Bills.h"
#import "FundModel.h"
@interface ProductCell : UITableViewCell
- (void)loadProductInfo:(id)bill;
@end

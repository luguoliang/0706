//
//  CheckoutCounteView.m
//  moneyTest
//
//  Created by 路国良 on 15/6/1.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//
#import "CheckoutCounteView.h"
#import <UIKit/UIKit.h>
//#import "PaymentMethodViewController.h"
//#import "PayMentViewController.h"
#import "CustomTimerButtom.h"//短信验证码
#import <CommonCrypto/CommonDigest.h>
#import "BFKeyBoardView.h"
#import "BFReqAPI+Security.h"
#import "RSAEntryPtion.h"
#import "MBProgressHUD.h"
@interface CheckoutCounteView ()<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate,UITextFieldDelegate,BFKeyBoardViewDelegate>
{
    UITableView*_myTableView;
    UITextField*_pasdWField;
    UITextField*_messageField;
    UIButton*_certernButton;
    UILabel*_moneyLabel;
    UILabel*_pswdLabel;//输入支付密码label
    UILabel*_messgeLabel;//输入短信验证码label
    UIView*_accountPayView;//账户余额支付和选择支付方式
    UIView*_psaView;//支付密码输入和忘记密码按钮
    UIView*_messageView;//短信验证码和收不到短信帮助
    UIView*_headerView;//头部视图
    UIView*_footerView;//尾部视图
    UIView*_bankCordView;//银行卡支付
    NSString*_certanStatus;//确认按钮的状态
     CustomTimerButtom*_timeBtn;//短信验证码
    NSString*complexMoney;//除去红包后所需要支付的金额
    NSDictionary*_postsafeCardDict;//要发送的安全卡
    
    NSDictionary*_messageReceiveDict;//短信验证码收到的数据
    NSDictionary*_postDefaultVouchDict;//需要发送的代金券
    NSDictionary*_postAccountBalanceDict;//需要发送的账户余额
    UIAlertView *_sucessView;//支付成功自动隐藏
    BFKeyBoardView*_keyboard;
    MBProgressHUD*HUD;
    UIButton* paymentMethod;
    UIView*_myView;
    /*
     certanStatus ＝ 0//有安全卡，下一步
     certanStatus ＝ 1//有安全卡，验证支付密码
     certanStatus ＝ 2//有安全卡，验证短信验证码＋确认支付
     certanStatus ＝ 3//账户余额支付
    */
}
@end
@implementation CheckoutCounteView
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
//        _keyboard = [[[NSBundle mainBundle] loadNibNamed:@"keyBoardView" owner:nil options:nil] lastObject];
//        _keyboard.delegate = self;
        self.backgroundColor = [[UIColor grayColor] colorWithAlphaComponent:0.5];
        _myTableView = [[UITableView alloc] initWithFrame:CGRectMake(20, 36.0f, self.frame.size.width - 40, 260) style:UITableViewStyleGrouped];
        _myTableView.delegate = self;
        _myTableView.dataSource = self;
        _myTableView.layer.cornerRadius = 5;
        _myTableView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];
        _myTableView.scrollEnabled = NO;
//        _myTableView.separatorColor
        [self addSubview:_myTableView];
        [self _addTableView];
#pragma makr - 定义头视图
        _headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0,self.frame.size.width - 40 , 40)];
        _headerView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];
        _myTableView.tableHeaderView = _headerView;
        //    headerView.backgroundColor = [UIColor purpleColor];
        //添加关闭按钮
        [_headerView addSubview:[self _setClosedButton]];
        //添加输入支付密码和短信验证码label
        [_headerView addSubview:[self _setPasdwLabel]];
        [_headerView addSubview:[self _setMessageLabel]];
#pragma mark - 定义尾视图
        _footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0,self.frame.size.width - 40 , 220)];
        _myTableView.tableFooterView = _footerView;
        _myTableView.tableHeaderView = _headerView;
        _moneyLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, self.frame.size.width - 40, 40)];
//        _moneyLabel.backgroundColor = [UIColor blueColor];￼
       _moneyLabel.textColor = [UIColor colorWithRed:255.0f/255.0f green:102.0f/255.0f blue:46.0f/255.0f alpha:1.0f];
        _moneyLabel.font = [UIFont systemFontOfSize:20.0f];
        //收不到
        [self _setCanreceive];
    }
    return self;
}
-(void)test
{
    UIButton*button = [UIButton buttonWithType:UIButtonTypeCustom];
    [self addSubview:button];
    UITextField*textfield = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
    [self addSubview:textfield];
    UILabel*label= [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
    [self addSubview:label];
    UITableView*tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
    [self addSubview:tableView];
    
}
-(void)_setCanreceive{
//    CGRect rect = CGRectMake(<#CGFloat x#>, <#CGFloat y#>, <#CGFloat width#>, <#CGFloat height#>)
//    _myView = [[UIView alloc] initWithFrame:CGRectMake(20, 100, self.frame.size.width - 40, 250)];
    
    _myView = [[UIView alloc] initWithFrame:CGRectMake(20, 100, self.frame.size.width - 40, 250)];
    
    [self addSubview:_myView];
    
    
//    [_myTableView addSubview:_myView];
    _myView.layer.cornerRadius = 5.0f;
    _myView.hidden  = YES;
    _myView.backgroundColor = [UIColor whiteColor];
    //1,
    UILabel*label1 = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, CGRectGetWidth(_myView.frame) - 20, 40)];
    label1.text = @"收不到验证码";
    label1.textAlignment = NSTextAlignmentCenter;
    label1.font = [UIFont systemFontOfSize:14.0f];
    [_myView addSubview:label1];
    UIImageView*myimageView = [[UIImageView alloc] initWithFrame:CGRectMake(_myView.frame.size.width - 40, 5, 30, 30)];
//    myimageView.backgroundColor = [UIColor blueColor];
    myimageView.image = [UIImage imageNamed:@"a82.png"];
    [_myView addSubview:myimageView];
    UIControl *control   = [[UIControl alloc] initWithFrame:CGRectMake(_myView.frame.size.width - 50, 0, 50, 50)];
    [control addTarget:self action:@selector(controlclosed) forControlEvents:UIControlEventTouchUpInside];
    [_myView addSubview:control];
    
    UILabel*line = [[UILabel alloc] initWithFrame:CGRectMake(10,CGRectGetMaxY(label1.frame) , CGRectGetWidth(_myView.frame) - 20, 0.5)];
    line.backgroundColor = [UIColor grayColor];
    [_myView addSubview:line];
    //2,
    UILabel*label2 = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(line.frame), CGRectGetWidth(_myView.frame) - 20, 40)];
    label2.text = @"短信验证码发送至你的银行预留手机号";
    label2.numberOfLines = 0;
    label2.font = [UIFont systemFontOfSize:14.0f];
    //    label2.textAlignment = NSTextAlignmentCenter;
    [_myView addSubview:label2];
    //3,
    UILabel*label3 = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(label2.frame), CGRectGetWidth(_myView.frame) - 20, 40)];
    label3.text = @"1,请确认当前是否使用银行预留的手机号码 ";
    label3.numberOfLines = 0;
    label3.font = [UIFont systemFontOfSize:14.0f];
    //    label2.textAlignment = NSTextAlignmentCenter;
    [_myView addSubview:label3];
    //4，
    UILabel*label4 = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(label3.frame), CGRectGetWidth(_myView.frame) - 20, 40)];
    label4.text = @"2,请检查短信是否被手机安全软件拦截";
    label4.numberOfLines = 0;
    label4.font = [UIFont systemFontOfSize:14.0f];
    //    label2.textAlignment = NSTextAlignmentCenter;
    [_myView addSubview:label4];
    //5
    UILabel*label5 = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(label4.frame), CGRectGetWidth(_myView.frame) - 20, 40)];
    label5.text = @"3,若预留手机号已停用，请联系银行客服咨询";
    label5.numberOfLines = 0;
    label5.font = [UIFont systemFontOfSize:14.0f];
    //    label2.textAlignment = NSTextAlignmentCenter;
    [_myView addSubview:label5];
    //5,
    UILabel*label6 = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(label5.frame), CGRectGetWidth(_myView.frame) - 20, 40)];
    label6.text = [NSString stringWithFormat:@"4,获取更多帮助，请拨打客服热线:%@",telNumber];
    label6.numberOfLines = 0;
    label6.font = [UIFont systemFontOfSize:14.0f];
    //    label2.textAlignment = NSTextAlignmentCenter;
    [_myView addSubview:label6];
     _myView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];
//    [_myTableView addSubview:label6];
}
-(void)controlclosed
{
   _myView.hidden = YES;
}
-(void)timeButton:(CustomTimerButtom*)button
{
    [button startTimer];
    [self getVerifcationCode];//发送短信验证码
}
-(void)_addTableView
{
    CAKeyframeAnimation* animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    animation.duration = 0.5;
    NSMutableArray *values = [NSMutableArray array];
    
    
    [self addSubview:_myTableView];
    [_myTableView maskView];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.1, 0.1, 0.1)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.2, 1.2, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(0.9, 0.9, 1.0)]];
    [values addObject:[NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)]];
    animation.values = values;
    [_myTableView.layer addAnimation:animation forKey:nil];
//    [_myTableView changePaymentMethod];

}
//设置金额的label
-(void)_setMoneyLabelWithDefaultVouchDict:(NSDictionary *)DefaultVouchDict WithamountMoney:(NSString *)amountMoney
{
    _moneyLabel.text = @"4,950+50元红包 ";
    _moneyLabel.textAlignment = NSTextAlignmentCenter;
    _moneyLabel.font = [UIFont systemFontOfSize:20.0f];
    _moneyLabel.textColor = [UIColor colorWithRed:255.0f/255.0f green:102.0f/255.0f blue:46.0f/255.0f alpha:1.0f];
    complexMoney = @"";
    if (DefaultVouchDict.count !=0) {
        double db1 = [DefaultVouchDict[@"balance"] doubleValue];
        double db2 = [amountMoney doubleValue];
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = kCFNumberFormatterDecimalStyle;
#pragma mark - 综合金额小于0时
        if ((db2 - db1)<=0) {
             NSString*balance =DefaultVouchDict[@"balance"];
            _moneyLabel.text = [NSString stringWithFormat:@"%@元红包",balance];
            _certanStatus = @"3";
        }
        else{
        NSString *string = [formatter stringFromNumber:[NSNumber numberWithDouble:db2 - db1]];
        string  = [string stringByReplacingOccurrencesOfString:@"￥" withString:@""];
        complexMoney = string;
        NSString*balance =DefaultVouchDict[@"balance"];
        _moneyLabel.text = @"";
        _moneyLabel.text = [NSString stringWithFormat:@"%@+%@元红包",complexMoney,balance];
        _postDefaultVouchDict = [NSDictionary dictionaryWithDictionary:DefaultVouchDict];//////////////需要发送的代金券
        }
        _postDefaultVouchDict = [NSDictionary dictionaryWithDictionary:DefaultVouchDict];//////////////需要发送的代金券
    }
    else
    {
        _moneyLabel.text = [NSString stringWithFormat:@"%@元",amountMoney];
         complexMoney = amountMoney;
    }
}
//设置关闭按钮
-(UIButton*)_setClosedButton
{
    UIButton*colsedButton = [UIButton buttonWithType:UIButtonTypeCustom];
    colsedButton.frame = CGRectMake(5, 4, 35, 35);
    colsedButton.alpha = 0.8;
    [colsedButton setBackgroundImage:[UIImage imageNamed:@"a82.png"] forState:UIControlStateNormal];
    [colsedButton addTarget:self action:@selector(closedButton:) forControlEvents:UIControlEventTouchUpInside];
    [colsedButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    return colsedButton;
}
//设置输入支付密码label和俄输入短信验证码label
-(UILabel*)_setPasdwLabel
{
    _pswdLabel = [[UILabel alloc] initWithFrame:CGRectMake(40, 0, self.frame.size.width - 120, 40)];
    _pswdLabel.text = @"请输入支付密码";
//    .backgroundColor = [UIColor colorWithRed:43.0f/255.0f green:43.0f/255.0f blue:43.0f/255.0f alpha:1.0f];
    _pswdLabel.textColor = [UIColor colorWithRed:43.0f/255.0f green:43.0f/255.0f blue:43.0f/255.0f alpha:1.0f];
    _pswdLabel.font = [UIFont systemFontOfSize:15.0f];
    _pswdLabel.textAlignment = NSTextAlignmentCenter;
    _pswdLabel.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
    return _pswdLabel;
}
-(UILabel*)_setMessageLabel
{
    _messgeLabel = [[UILabel alloc] initWithFrame:CGRectMake(40, 0, self.frame.size.width - 120, 40)];
    _messgeLabel.frame = CGRectMake(self.frame.size.width, 0,self.frame.size.width - 120, 40);
    _messgeLabel.text = @"请输入短信验证码";
    _messgeLabel.backgroundColor = [UIColor whiteColor];
    _messgeLabel.textAlignment = NSTextAlignmentCenter;
    _messgeLabel.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
    return _messgeLabel;
}
//选择支付方式label
-(UIButton*)_setPaymenthodbutton
{
    paymentMethod = [UIButton buttonWithType:UIButtonTypeSystem];
    paymentMethod.frame = CGRectMake(0, -10, self.frame.size.width - 40, 30);
    [paymentMethod setTitle:@"选择支付方式 >" forState:UIControlStateNormal];//nextButton
    [paymentMethod setTintColor:[UIColor colorWithRed:43.0f/255.0f green:43.0f/255.0f blue:43.0f/255.0f alpha:1.0f]];
//    [paymentMethod setTitleColor:[UIColor colorWithRed:43.0f/255.0f green:43.0f/255.0f blue:43.0f/255.0f alpha:1.0f] forState:UIControlStateNormal];
    [paymentMethod addTarget:self action:@selector(paymentMethod:) forControlEvents:UIControlEventTouchUpInside];
    [paymentMethod setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    return paymentMethod;
}
//账户余额和更换支付方式按钮
-(UIView*)_setaccountPayLabel
{
    _accountPayView = [[UIView alloc] initWithFrame:CGRectMake(0, -10, self.frame.size.width - 40, 30)];
    _accountPayView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
    _accountPayView.frame = CGRectMake(self.frame.size.width, 0, self.frame.size.width - 40, 30);
    _accountPayView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
    UILabel*balanceLabel  = [[UILabel alloc] initWithFrame:CGRectMake((self.frame.size.width - 40)*0.5 - 70, 0, 100, 30)];
//    balanceLabel.font = [UIFont systemFontOfSize:15.0f];
    balanceLabel.textColor = [UIColor colorWithRed:43.0f/255.0f green:43.0f/255.0f blue:43.0f/255.0f alpha:1.0];
    balanceLabel.font = [UIFont systemFontOfSize:15.0f];
//    balanceLabel.backgroundColor = [UIColor blueColor];
    balanceLabel.text = @"账户余额支付,";
    balanceLabel.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
    [_accountPayView addSubview:balanceLabel];
    UIButton*changeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    changeButton.frame = CGRectMake(CGRectGetMaxX(balanceLabel.frame) - 5 , 0, 40, 30);
    [changeButton setTitle:@"更换" forState:UIControlStateNormal];//nextButton
    [changeButton setTitleColor:[UIColor colorWithRed:32.0f/250.0f green:166.0f/250.0f blue:249.0f/250.0f alpha:1.0] forState:UIControlStateNormal];
    [changeButton addTarget:self action:@selector(paymentMethod:) forControlEvents:UIControlEventTouchUpInside];
    //    [changeButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    
    
     _accountPayView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];
    
    [_accountPayView addSubview:changeButton];
    return _accountPayView;
}
//银行卡支付和更换支付方式按钮
-(UIView*)_setbankCordPayViewsafeCardDict:(NSDictionary *)safeCardDict
{
    //这儿取出安全卡，或者为选座位安全卡的快捷卡
    _postsafeCardDict = [NSDictionary dictionaryWithDictionary:safeCardDict];
    
    
#pragma mark - 
    
    _bankCordView = [[UIView alloc] initWithFrame:CGRectMake(0, -10, self.frame.size.width - 40, 30)];
    _bankCordView.frame = CGRectMake(self.frame.size.width, -10, self.frame.size.width - 40, 30);
    
//    _bankCordView.frame = CGRectMake(0, 0, self.frame.size.width - 40, 30);
    
    _bankCordView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
//    UILabel*balanceLabel  = [[UILabel alloc] initWithFrame:CGRectMake((self.frame.size.width - 40)*0.5 - 120, -10, 160, 30)];
    
     UILabel*balanceLabel  = [[UILabel alloc] initWithFrame:CGRectMake((self.frame.size.width - 40)*0.5 - 100, 0, 160, 30)];
//    balanceLabel.textAlignment = NSTextAlignmentRight;
    balanceLabel.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
    
    
    balanceLabel.font = [UIFont systemFontOfSize:15.0f];
    balanceLabel.textColor = [UIColor colorWithRed:43.0f/255.0f green:43.0f/255.0f blue:43.0f/255.0f alpha:1.0];
    balanceLabel.text = @"工商银行储蓄卡尾号1234支付,";
    balanceLabel.text = [NSString stringWithFormat:@"%@%@支付,",safeCardDict[@"name"],[safeCardDict[@"desc"] substringToIndex:6]];
    [_bankCordView addSubview:balanceLabel];
    UIButton*changeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    changeButton.frame = CGRectMake(CGRectGetMaxX(balanceLabel.frame), 0, 40, 30);
    [changeButton setTitle:@"更换" forState:UIControlStateNormal];//nextButton
    [changeButton addTarget:self action:@selector(paymentMethod:) forControlEvents:UIControlEventTouchUpInside];
    //    [changeButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [_bankCordView addSubview:changeButton];
    _bankCordView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
    return _bankCordView;
}
//支付密码输入框和忘记密码按钮
-(UIView*)_setPasdfield
{
    _keyboard = [[[NSBundle mainBundle] loadNibNamed:@"keyBoardView" owner:nil options:nil] lastObject];
    _keyboard.delegate = self;
    _psaView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_accountPayView.frame), self.frame.size.width - 40, 70)];
    _psaView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
    _pasdWField = [[UITextField alloc] initWithFrame:CGRectMake(10, 0, self.frame.size.width - 60, 40)];
    _pasdWField.delegate = self;
    _pasdWField.placeholder = @"支付密码";
    _pasdWField.borderStyle = UITextBorderStyleRoundedRect;
    _pasdWField.textAlignment = NSTextAlignmentCenter;
    _pasdWField.delegate = self;
    [_psaView addSubview:_pasdWField];
    _pasdWField.secureTextEntry = YES;
    _pasdWField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _pasdWField.inputView = _keyboard;
    UIButton*forgetpasd = [UIButton buttonWithType:UIButtonTypeSystem];
    forgetpasd.frame = CGRectMake(CGRectGetWidth(_pasdWField.frame) - 60, CGRectGetMaxY(_pasdWField.frame), 80, 30);
    [forgetpasd setTitle:@"忘记密码?" forState:UIControlStateNormal];//nextButton
    [forgetpasd addTarget:self action:@selector(forgetpasd:) forControlEvents:UIControlEventTouchUpInside];
    [forgetpasd setTitleColor:[UIColor colorWithRed:32.0f/250.0f green:166.0f/250.0f blue:249.0f/250.0f alpha:1.0] forState:UIControlStateNormal];
    [_psaView addSubview:forgetpasd];
    return _psaView;
}
//短信验证码和收不到短信帮助框
-(UIView*)_setmessagecode
{
    _messageView = [[UIView alloc] initWithFrame:CGRectMake(0,-10, self.frame.size.width - 40, 110)];
    _messageView.frame = CGRectMake(self.frame.size.width,-10, self.frame.size.width - 40, 110);
    _messageView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
    _messageField = [[UITextField alloc] initWithFrame:CGRectMake(10, 30, self.frame.size.width - 60, 40)];
    _messageField.tag = 010;
    _messageField.delegate = self;
    _messageField.placeholder = @"短信验证码";
    _messageField.borderStyle = UITextBorderStyleRoundedRect;
    _messageField.delegate = self;
    _messageField.inputView = _keyboard;
    [_messageView addSubview:_messageField];
    _timeBtn = [CustomTimerButtom buttonWithType:UIButtonTypeRoundedRect];
    _timeBtn.frame = CGRectMake(0,0,90,40);
    [_timeBtn setTitle:@"获取" forState:UIControlStateNormal];
    [_timeBtn setTintColor:[UIColor blueColor]];
    [_timeBtn addTarget:self action:@selector(timeButton:) forControlEvents:UIControlEventTouchUpInside];
    _messageField.rightViewMode= UITextFieldViewModeAlways;
    _messageField.rightView = _timeBtn;
    
    
    UILabel*label = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(_messageField.frame), 210, 30)];
    label.text = [NSString stringWithFormat:@"短信已发送至%@的手机,",_postsafeCardDict[@"preMobile"]];
    
    NSLog(@"_postsafeCardDict = %@",_postsafeCardDict);
    
    label.font = [UIFont systemFontOfSize:13.0f];
//    label.backgroundColor = [UIColor blackColor];
    [_messageView addSubview:label];
    UIButton*helpButton = [UIButton buttonWithType:UIButtonTypeSystem];
    helpButton.frame = CGRectMake(CGRectGetMaxX(label.frame), CGRectGetMaxY(_messageField.frame), 60, 30);
    [helpButton setTitle:@"收不到？" forState:UIControlStateNormal];//nextButton
    [helpButton addTarget:self action:@selector(helpButton:) forControlEvents:UIControlEventTouchUpInside];
    [helpButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [_messageView addSubview:helpButton];
    return _messageView;
}
//确定按钮
-(UIButton*)_setCerten
{
    _certernButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _certernButton.frame = CGRectMake(10, CGRectGetMaxY(_messageView.frame)+10, self.frame.size.width - 60, 40);
    [_certernButton setTitle:@"确认支付" forState:UIControlStateNormal];//nextButton
    [_certernButton addTarget:self action:@selector(certernButton:) forControlEvents:UIControlEventTouchUpInside];
    [_certernButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    _certernButton.backgroundColor = [UIColor colorWithRed:0.0f/255.0f green:146.0f/255.0f blue:207.0f/255.0f alpha:1.0];
    _certernButton.layer.cornerRadius = 5.0f;
    [_certernButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    return _certernButton;
}
//
-(void)certernButton:(UIButton*)button
{
    NSLog(@"确认支付");
    if([complexMoney isEqual:@"0"])
    {
        _certanStatus = @"3";
    }
    if ([_certanStatus isEqual:@"0"]) {//有安全卡，下一步
        if (_pasdWField.text.length == 0) {
            [self lockAnimationForView:_pasdWField];
        }
        else{
        [_certernButton setTitle:@"确认支付" forState:UIControlStateNormal];//nextButton
        [self verifyPaymentPassword:_pasdWField];//验证支付密码
        }
    }
    else if ([_certanStatus isEqual:@"1"])//有安全卡，验证支付密码
    {
        
        if (_pasdWField.text.length == 0) {
            [self lockAnimationForView:_pasdWField];
        }
        else{
        
        [_certernButton setTitle:@"确认支付" forState:UIControlStateNormal];//nextButton
        [self smsVerificationCodeBankCardOrOalanceDict:_postsafeCardDict];//安全卡传入
        //验证短信验证码并，确认支付
        NSLog(@"下一步,验证短信验证码并确认支付");
        }
    }
    else if ([_certanStatus isEqualToString:@"2"])//有安全卡，验证短信验证码＋确认支付
    {
        
        if (_messageField.text.length == 0) {
            [self lockAnimationForView:_messageField];
        }
        else{

        [_certernButton setTitle:@"确认支付" forState:UIControlStateNormal];//nextButton
            [self smsVerificationCodeBankCardOrOalanceDict:_postsafeCardDict];//传入安全卡
        }
        //验证短信验证码 + 确认支付
#pragma mark - 在这儿验证短信验证码
//        [self smsVerificationCodeBankCardOrOalanceDict:_postsafeCardDict];//传入安全卡
    }
     else if ([_certanStatus isEqualToString:@"3"])//有安全卡，验证短信验证码＋确认支付
    {
        
        if (_pasdWField.text.length == 0) {
            [self lockAnimationForView:_pasdWField];
        }
        else{
        [_certernButton setTitle:@"确认支付" forState:UIControlStateNormal];//nextButton
        
        //验证短信验证码 + 确认支付
#pragma mark - 余额支付
        [self smsVerificationCodeBankCardOrOalanceDict:_postAccountBalanceDict];//传入账户余额
        }
    }
    else if (_certanStatus.length == 0)
    {
        NSLog(@"_certanStatus = nil");
        [self lockAnimationForView:paymentMethod];
    }
//    [_certernButton setTitle:@"确认支付" forState:UIControlStateNormal];//nextButton
}
-(void)lockAnimationForView:(UIView*)view
{
    CALayer *lbl = [view layer];
    CGPoint posLbl = [lbl position];
    CGPoint y = CGPointMake(posLbl.x-10, posLbl.y);
    CGPoint x = CGPointMake(posLbl.x+10, posLbl.y);
    CABasicAnimation * animation = [CABasicAnimation animationWithKeyPath:@"position"];
    [animation setTimingFunction:[CAMediaTimingFunction
                                  functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    [animation setFromValue:[NSValue valueWithCGPoint:x]];
    [animation setToValue:[NSValue valueWithCGPoint:y]];
    [animation setAutoreverses:YES];
    [animation setDuration:0.08];
    [animation setRepeatCount:3];
    [lbl addAnimation:animation forKey:nil];
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    NSLog(@"开始滑动");
    [_pasdWField resignFirstResponder];
    [_messageField resignFirstResponder];
}
//-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
//{
//    NSLog(@"开始拖动");
//}
-(NSString*)md5:(NSString *)str
{
    const char *cStr = [str UTF8String];
    unsigned char result[16];
    CC_MD5(cStr, strlen(cStr), result); // This is the md5 call
    NSString *s1tr = [NSString stringWithFormat:
                      @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                      result[0], result[1], result[2], result[3],
                      result[4], result[5], result[6], result[7],
                      result[8], result[9], result[10], result[11],
                      result[12], result[13], result[14], result[15]
                      ];
    return s1tr;
}


#pragma mark -  验证支付密码
-(void)verifyPaymentPassword:(UITextField*)textfield
{
    
    HUD = [MBProgressHUD showHUDAddedTo:self animated:YES];
    HUD.dimBackground = NO;
    HUD.color = [UIColor blackColor];
    [HUD hide:YES afterDelay:60];    //
    
    [MBProgressHUD showHUDAddedTo:self animated:YES];
    __weakself__
    NSString*md5Str = [self md5:textfield.text];
    [BFReqAPI reqValiPayPwdAtCheckOutWithPwd:md5Str block:^(id responseObj, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:weakself animated:YES];
        if (!weakself) return ;
        if (responseObj != nil) {
            if (ERROR_CODE == 1) {
                NSLog(@"下一步,支付密码验证，弹出短信验证码");
                _certanStatus = @"2";//_certanStatus ＝ 2下一步验证短信验证码m ,+ 支付
#pragma mark - 验证支付密码
                [UIView animateWithDuration:0.5 animations:^{
                    _accountPayView.frame = CGRectMake(0, -10, self.frame.size.width - 40, 30);
                    _bankCordView.frame = CGRectMake(0, -10, self.frame.size.width - 40, 30);//银行卡
                    _messageView.frame = CGRectMake(0,-10, self.frame.size.width - 40, 110);
                    _messgeLabel.frame  = CGRectMake(40, 0, self.frame.size.width - 120, 40);
                } completion:^(BOOL finished) {
                    
                    //#pragma mark - 验证短信验证码
                    //                [self smsVerificationCode];//
                    [HUD hide:YES];
                    [self timeButton:_timeBtn];
                    [_pasdWField resignFirstResponder];
                    [_messageField becomeFirstResponder];
                }];
            }else
            {
                [HUD hide:YES];
                [UIAlertView showWithMessage:[responseObj objectForKey:@"message"] delegate:nil];
            }
        }
    }];
}
#pragma mark - 验证短信验证码 + 确认支付
-(void)smsVerificationCodeBankCardOrOalanceDict:(NSDictionary*)BankCardOrOalanceDict
{
//    [_messageField resignFirstResponder];
    [_keyboard myfinishedButton:nil];
    HUD = [MBProgressHUD showHUDAddedTo:self animated:YES];
    HUD.dimBackground = NO;
    HUD.color = [UIColor blackColor];
    [HUD hide:YES afterDelay:60];    //
    NSDictionary*payListDict = [NSDictionary dictionaryWithDictionary:self.payListDictionary];//打开收银台时的数据
    NSString*orderNo = payListDict[@"orderNo"];//打开收银台时的orderNo
//    NSString*payPassword = _pasdWField.text;//支付密码
    
    NSString*payPassword = [self md5:_pasdWField.text];//支付密码
    NSString*businessType = payListDict[@"businessType"];//业务类型
    //
    NSString*tradeNo = _messageReceiveDict[@"tradeNo"];//充值交易号 //用于充值平台,发送短信验证码时，收到的
    NSString*businessNo = _messageReceiveDict[@"businessNo"];//充值业务号
    NSString*verCode = _messageField.text;//短信验证码
#pragma mark - 银行卡
    NSString*amount = BankCardOrOalanceDict[@"balance"];
    //计算银行卡余额
    if (_postDefaultVouchDict.count != 0) {
        //1,取出支付总额
        double amount1 = [payListDict[@"amount"] doubleValue];
        //2,取出代金券面值
        double balance1 = [_postDefaultVouchDict[@"balance"] doubleValue];
        double doub3 = amount1 - balance1;
        //3,计算银行卡或者余额所需要支付的金额
//        NSString*amountstr = [NSString stringWithFormat:@"%f",(amount1 - balance1)];
//        amount = amountstr;
        NSNumber *number  = [NSNumber numberWithDouble:(amount1 - balance1)];
        amount = [number stringValue];
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = NSNumberFormatterDecimalStyle;
        NSString *string = [formatter stringFromNumber:[NSNumber numberWithDouble:doub3]];
        amount = [NSString stringWithFormat:@"%@",number];
        NSLog(@"Formatted number string:%@",string);
    }
    else
    {
        amount = _payListDictionary[@"amount"];
    }
    NSString*cardId = BankCardOrOalanceDict[@"cardId"];//卡ID
    NSString*payId = BankCardOrOalanceDict[@"payId"];//支付ID
    NSString*type = BankCardOrOalanceDict[@"payType"];//支付类别
    NSString*name = BankCardOrOalanceDict[@"name"];//支付名称
//    NSString*amount = BankCardOrOalanceDict[@"balance"];//金额／／／／／／
//    NSString*amount = am;//金额／／／／／／
    NSString*desc = BankCardOrOalanceDict[@"desc"];//
    NSDictionary*bankCardDict = [NSDictionary dictionaryWithObjectsAndKeys:
                                 cardId,@"cardId",
                                 payId,@"payId",
                                 type,@"type",
                                 name,@"name",
                                 amount,@"amount",
                                 desc,@"desc",
                                 nil];
    
#pragma mark - _postDefaultVouchDict//默认的代金券
    NSDictionary*postVouchCardDict = [NSDictionary dictionaryWithObjectsAndKeys:
                                      _postDefaultVouchDict[@"cardId"],@"cardId",
                                      _postDefaultVouchDict[@"payId"],@"payId",
                                      _postDefaultVouchDict[@"payType"],@"type",
                                      _postDefaultVouchDict[@"name"],@"name",
                                      _postDefaultVouchDict[@"balance"],@"amount",
//                                      _postDefaultVouchDict[@"desc"],@"desc",nil];
                                       nil];
     NSMutableArray*confirmPayList = [NSMutableArray array];
    if (postVouchCardDict.count == 0) {
//         confirmPayList = @[bankCardDict];
        confirmPayList = [NSMutableArray arrayWithObjects:bankCardDict, nil];
    }
    else if (postVouchCardDict.count != 0)
    {
        double amount1 = [payListDict[@"amount"] doubleValue];
        //2,取出代金券面值
        double balance1 = [_postDefaultVouchDict[@"balance"] doubleValue];
        double doub3 = amount1 - balance1;
        if (doub3 < 0) {
        confirmPayList = [NSMutableArray arrayWithObjects:postVouchCardDict, nil];
        }        else{
        confirmPayList = [NSMutableArray arrayWithObjects:bankCardDict,postVouchCardDict, nil];
        }
    }
#pragma makr -    ///////////////////
    NSLog(@"confirmPayList = %@",confirmPayList);
    NSDictionary*jsonDict = [NSDictionary dictionaryWithObjectsAndKeys:confirmPayList,@"confirmPayList",orderNo,@"orderNo",payPassword,@"payPassword",businessType,@"businessType",tradeNo,@"tradeNo",businessNo,@"businessNo",verCode,@"verCode",nil];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:jsonDict options:NSJSONWritingPrettyPrinted error:nil];
    NSString *encryption = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *encryptionStr = [RSAEntryPtion stringWithRSAEncryPtion:[encryption base64EncodedString]];
    NSString*spStr = @"cashPlatform/confirmPay.do?v=2.0&sp=%@";
    NSString*urlStr = [NSString stringWithFormat:@"%@%@",BFWalletBaseURL,spStr];
//    NSString*str = @"http://10.0.20.122:8080/cashPlatform/confirmPay.do?v=2.0&sp=%@";
    NSString *dataStr = [NSString stringWithFormat:urlStr,encryptionStr];
    NSURL *url = [[NSURL alloc] initWithString:dataStr];
    if (url == nil) {
        NSLog(@"url错误");
    }
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (connectionError != nil) {
                NSLog(@"Error on load = %@",connectionError);
            }
            if ([response isKindOfClass:[NSURLResponse class]]) {
                NSHTTPURLResponse*httpResponse = (NSHTTPURLResponse*)response;
                if (httpResponse.statusCode != 200) {
                NSLog(@"httpResponse.statusCode = %ld",(long)httpResponse.statusCode);
                }
            }
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
           if ([[[dict objectForKey:@"code"] stringValue] isEqualToString:@"1"])
            {
                HUD.hidden = YES;
                _sucessView = [[UIAlertView alloc] initWithTitle:@"支付成功" message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:nil, nil];
                _sucessView.tag = 010;
                [_sucessView show];
                [self performSelector:@selector(sucessHideAlertView) withObject:nil afterDelay:2.0f];
            }
                else{
                HUD.hidden = YES;
                if (dict.count == 0) {
                UIAlertView *alview = [[UIAlertView alloc] initWithTitle:nil message:@"网络请求失败，请稍后再试" delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
                [alview show];
                    }
                else{
                    if ([dict[@"message"] length] == 0) {
                            UIAlertView *alview = [[UIAlertView alloc] initWithTitle:@"服务器正在维护" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                            [alview show];
                        }
                else{
                           UIAlertView *alview = [[UIAlertView alloc] initWithTitle:[dict objectForKey:@"message"] message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                            [alview show];
                        }
                        
                    }
            }
        });
        
    }];
}

#pragma mark - 发送验证码
-(void)getVerifcationCode
{
    
    //amountMoney
    NSString*cardId = _postsafeCardDict[@"cardId"];//银行卡ID
    NSString*mobile = _postsafeCardDict[@"preMobile"];//手机号
    //银行卡信息
     NSDictionary*payListDict = [NSDictionary dictionaryWithDictionary:self.payListDictionary];//打开收银台时的数据
    //
//    NSString*amount = @"";//金额（银行卡使用金额）
    NSString*orderNo = payListDict[@"orderNo"];//业务类型
    NSString*businessType = payListDict[@"businessType"];//业务类型
    NSString*payId = _postsafeCardDict[@"payId"];//银行id
    NSString*name = _postsafeCardDict[@"name"];//银行名称
    NSString*type = _postsafeCardDict[@"payType"];//银行卡类型(银行卡,安全卡,快捷卡)
    NSString*desc = _postsafeCardDict[@"desc"];//描述
    NSDictionary *userIndo = [[NSDictionary alloc] initWithObjectsAndKeys:cardId,@"cardId",complexMoney,@"amount",mobile,@"mobile",orderNo,@"orderNo",businessType,@"businessType",payId,@"payId",name,@"name",type,@"type",desc,@"desc",nil];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:userIndo options:NSJSONWritingPrettyPrinted error:nil];
    NSString *encryption = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *encryptionStr = [RSAEntryPtion stringWithRSAEncryPtion:[encryption base64EncodedString]];
    NSString*spStr = @"cashPlatform/sendVerficateCode.do?v=2.0&sp=%@";
    NSString*urlStr = [NSString stringWithFormat:@"%@%@",BFWalletBaseURL,spStr];
    NSString *dataStr = [NSString stringWithFormat:urlStr,encryptionStr];
    NSURL *url = [[NSURL alloc] initWithString:dataStr];
    
    
//    NSURL *url = [[NSURL alloc] initWithString:dataStr];
    if (url == nil) {
        NSLog(@"url错误");
    }
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (connectionError != nil) {
                NSLog(@"Error on load = %@",connectionError);
            }
            if ([response isKindOfClass:[NSURLResponse class]]) {
                NSHTTPURLResponse*httpResponse = (NSHTTPURLResponse*)response;
                if (httpResponse.statusCode != 200) {
                    NSLog(@"httpResponse.statusCode = %ld",(long)httpResponse.statusCode);
                }
            }
            NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
            if ([[[dict objectForKey:@"code"] stringValue] isEqualToString:@"1"])
            {
                _messageReceiveDict = [NSDictionary dictionaryWithDictionary:dict[@"obj"]];
                        /////
                [self displayMessageMobile];
            }
            else{
                [_timeBtn stopTimer];
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:@"网络请求出错,请稍候再试" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                [alertView show];
                
            }
        });
        
    }];

}



-(void)createBUtton:(NSString*)title
{
    
}
-(void)sucessHideAlertView
{
    [_sucessView dismissWithClickedButtonIndex:0 animated:YES];
#pragma makr  - 调用代理回调
    [_delegate sucessPayCallBack];
}
//收不到短信验证码帮助按钮
-(void)helpButton:(UIButton*)button
{
    NSLog(@"收不到短信验证码帮助按钮");
    _myView.hidden = NO;
    [_messageField resignFirstResponder];
}
//忘记支付密码
-(void)forgetpasd:(UIButton*)button
{
    NSLog(@"忘记支付密码");
 [_delegate forgetPasword];
}
//选择支付方式
-(void)paymentMethod:(UIButton*)button
{
    NSLog(@"选择支付方式");
    [_delegate selectPaymentMethod];
}
//关闭按钮
-(void)closedButton:(UIButton*)button
{
    NSLog(@"点击关闭按钮");
    UIAlertView*alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"亲，就差一点就成功了哦,确认放弃付款?" delegate:self cancelButtonTitle:@"否" otherButtonTitles:@"是", nil];
    alertView.delegate = self;
    [alertView show];
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        NSArray *views = [self subviews];
        for(UIView* vi in views)
        {
            [vi removeFromSuperview];
        }
        [_delegate removeCalled];
    }
}
#pragma mark - UITableViewDataSource
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString*index = @"mycell";
    UITableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:index];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:index];
    }
    return cell;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 50;
}
-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return _moneyLabel;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [UIView animateWithDuration:0.5 animations:^{
        //        _messageView.frame = CGRectMake(0,0, self.frame.size.width - 40, 100);
        //        _messgeLabel.frame  = CGRectMake(40, 0, self.frame.size.width - 120, 40);//短信验证码和收不到
        _myTableView.frame = CGRectMake(20, 100, self.frame.size.width - 40, 250);
        
    } completion:^(BOOL finished) {
        
    }];

    return YES;
}
#pragma mark -  //选择支付方式，已有快捷卡和没有快捷卡时初始化出现
-(void)changePaymentMethodWithDefaultVouchDict:(NSDictionary *)DefaultVouchDict WithamountMoney:(NSString *)amountMoney
{
    NSLog(@"选择支付方式");
    
    //设置选择支付方式按钮
    [_footerView addSubview:[self _setPaymenthodbutton]];
    //设置选择支付方式和更换按钮
    [_footerView addSubview:[self _setaccountPayLabel]];
    //银行卡支付
    [_footerView addSubview:[self _setbankCordPayViewsafeCardDict:nil]];
    //设置输入支付密码输入和忘记密码按钮
    [_footerView addSubview:[self _setPasdfield]];
    //设置短信验证码输入框
    [_footerView addSubview:[self _setmessagecode]];
    //设置确定按钮
    [_footerView addSubview:[self _setCerten]];
     _footerView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
#pragma makr - 设置金额label
//    [self _setMoneyLabel];
    [self _setMoneyLabelWithDefaultVouchDict:DefaultVouchDict WithamountMoney:amountMoney];
    
    [self _addTableView];
}
#pragma mark -  //银行卡支付，已有安全卡时初始化出现,安全卡支付
-(void)bankCardPaymentWithDefaultVouchDict:(NSDictionary *)DefaultVouchDict WithsafeCardDict:(NSDictionary *)safeCardDict WithamountMoney:(NSString *)amountMoney
{
    	NSLog(@"银行卡支付");
#pragma makr - 定义头视图
    
    [_footerView addSubview:[self _setPaymenthodbutton]];
    //设置选择支付方式和更换按钮
    [_footerView addSubview:[self _setaccountPayLabel]];
    //银行卡支付
    [_footerView addSubview:[self _setbankCordPayViewsafeCardDict:safeCardDict]];
//    _bankCordView.frame = CGRectMake(0, 0, self.frame.size.width - 40, 30);
    _bankCordView.frame = CGRectMake(0, -10, self.frame.size.width - 40, 30);
    _bankCordView.backgroundColor = [UIColor whiteColor];
    _bankCordView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
    
    //设置输入支付密码输入和忘记密码按钮
    [_footerView addSubview:[self _setPasdfield]];
    //设置短信验证码输入框
    [_footerView addSubview:[self _setmessagecode]];
    //设置确定按钮
    [_footerView addSubview:[self _setCerten]];
    [_certernButton setTitle:@"下一步" forState:UIControlStateNormal];
    NSLog(@"_certanStatus = %@",_certanStatus);
//    [_certernButton setTitle:@"确认支付" forState:UIControlStateNormal];//nextButton
    _certanStatus = @"0";
    
    

#pragma makr - 计算金额
    [self _setMoneyLabelWithDefaultVouchDict:DefaultVouchDict WithamountMoney:amountMoney];
     _footerView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
    _postDefaultVouchDict = [NSDictionary dictionaryWithDictionary:DefaultVouchDict];//////////////需要发送的代金券
}

#pragma makr -  账户余额支付
-(void)balancePaymentMethodWithDefaultVouchDict:(NSDictionary *)DefaultVouchDict WithamountMoney:(NSString *)amountMoney WithAccountBalanceDict:(NSDictionary *)AccountBalanceDict////
{
    NSLog(@"选择支付方式");
    _certanStatus = @"3";//账户余额支付
     [_certernButton setTitle:@"确认支付" forState:UIControlStateNormal];//nextButton
    //设置选择支付方式按钮
    [_footerView addSubview:[self _setPaymenthodbutton]];
    //设置选择支付方式和更换按钮
    [_footerView addSubview:[self _setaccountPayLabel]];
    _accountPayView.frame = CGRectMake(0, -10, self.frame.size.width - 40, 30);
    //银行卡支付
    [_footerView addSubview:[self _setbankCordPayViewsafeCardDict:nil]];//
    //设置输入支付密码输入和忘记密码按钮
//    [_footerView addSubview:[self _setPasdfield]];
//    //设置短信验证码输入框
//    [_footerView addSubview:[self _setmessagecode]];
//    //设置确定按钮
//    [_footerView addSubview:[self _setCerten]];
#pragma makr - 设置金额label
    //    [self _setMoneyLabel];
    
    _postAccountBalanceDict = [NSDictionary dictionaryWithDictionary:AccountBalanceDict];//余额
    [self _setMoneyLabelWithDefaultVouchDict:DefaultVouchDict WithamountMoney:amountMoney];//
    
//    [self _addTableView];
_footerView.backgroundColor = [UIColor colorWithRed:248.0f/255.0f green:248.0f/255.0f blue:248.0f/255.0f alpha:1.0f];;
}

#pragma mark - 短信验证码接受成功
-(void)messageCodeRecuSucess
{
    NSLog(@"短信验证码发送成功");
}

#pragma mark - 获取短信验证码
-(void)getMessageCode
{
    [UIView animateWithDuration:0.5 animations:^{
        _messageView.frame = CGRectMake(0,0, self.frame.size.width - 40, 100);
        _messgeLabel.frame  = CGRectMake(40, 0, self.frame.size.width - 120, 40);//短信验证码和收不到
        
    } completion:^(BOOL finished) {
        
    }];
}
#pragma makr  － 短信发送成功时
-(void)displayMessageMobile
{
     [UIView animateWithDuration:0.5 animations:^{
//        _messageView.frame = CGRectMake(0,0, self.frame.size.width - 40, 100);
//        _messgeLabel.frame  = CGRectMake(40, 0, self.frame.size.width - 120, 40);//短信验证码和收不到
        
    } completion:^(BOOL finished) {
        
    }];
}
#pragma mark - UITextFieldDelegate
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    

    [UIView animateWithDuration:0.5 animations:^{
         _myTableView.frame = CGRectMake(20, 16.0f, self.frame.size.width - 40, 250);
      } completion:^(BOOL finished) {
        
    }];
    if (textField.tag == 010) {
    _keyboard.keyBoardNumberStatus = @"0";
    }
    [_keyboard setKeyBoardWith:textField];
    
    _keyboard.keyboardstytle = KeyboardstytlePassword;
    return YES;
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedButton:(UIButton *)button WithText:(UITextField *)textfield
{
//    textfield.text  = [NSString stringWithFormat:@"%@%@",textfield.text,button.titleLabel.text];
    NSString*str  = [NSString stringWithFormat:@"%@%@",textfield.text,button.titleLabel.text];
    if (textfield.text.length  >= 6) {
        NSLog(@"输入的好多呀");
        textfield.text = [str substringToIndex:6];
        NSLog(@"textfield.text = %@",textfield.text);
//        textfield.enabled = NO;
        
    
    }
    else
    {
         NSLog(@"输入的好少呀");
//        textfield.enabled = YES;
        textfield.text  = [NSString stringWithFormat:@"%@%@",textfield.text,button.titleLabel.text];

    }
    
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateButton:(UIButton *)button WithText:(UITextField *)textfield
{
    NSString*str = textfield.text;
    if ([str length] != 0) {
        str = [str substringToIndex:[str length]- 1];
        textfield.text  = str;
    }
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateFinished:(UIButton *)button WithText:(UITextField *)textfield
{
//    _myTableView.frame = CGRectMake(20, 100, self.frame.size.width - 40, 250);
    [UIView animateWithDuration:0.5 animations:^{
        //        _messageView.frame = CGRectMake(0,0, self.frame.size.width - 40, 100);
        //        _messgeLabel.frame  = CGRectMake(40, 0, self.frame.size.width - 120, 40);//短信验证码和收不到
        _myTableView.frame = CGRectMake(20, 34.0f, self.frame.size.width - 40, 250);
        
    } completion:^(BOOL finished) {
        
    }];

    
    [textfield resignFirstResponder];
}



@end

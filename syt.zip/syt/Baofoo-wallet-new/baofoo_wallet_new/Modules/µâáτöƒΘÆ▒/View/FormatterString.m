//
//  FormatterStr.m
//  aaa
//
//  Created by 路国良 on 15/8/4.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "FormatterString.h"

@implementation FormatterString

+(FormatterString*)sharedManager
{
    static FormatterString*sharedSingleton = nil;
    
    static dispatch_once_t predicate;
    
    dispatch_once(&predicate, ^{
        
        sharedSingleton = [[super allocWithZone:NULL] init];
    });
    return sharedSingleton;
}

+(instancetype)allocWithZone:(struct _NSZone *)zone
{
    return [self sharedManager];
}

-(NSString*)formatterStringWithString:(NSString *)str
{
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    
    formatter.numberStyle = kCFNumberFormatterDecimalStyle;
    
//    NSString *string = [formatter stringFromNumber:[NSNumber numberWithDouble:[str floatValue]]];
    
     NSString *string = [formatter stringFromNumber:[NSNumber numberWithDouble:[str doubleValue]]];
    return [self rangeOfString:string];
}

-(NSString*)rangeOfString:(NSString*)str
{
    NSMutableString*mustr = [NSMutableString stringWithString:str];
    if ([mustr rangeOfString:@"."].location == NSNotFound) {
        [mustr appendString:@".00"];
    }
    NSString*strr = [NSString stringWithFormat:@"%@",mustr];
    return strr;
}

-(NSString*)getcCurrentSystemtime
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:@"yyyyMMddHHmmss"];
    
    NSString *tradeDate = [dateFormatter stringFromDate:[NSDate date]];
    
    return tradeDate;
}
@end

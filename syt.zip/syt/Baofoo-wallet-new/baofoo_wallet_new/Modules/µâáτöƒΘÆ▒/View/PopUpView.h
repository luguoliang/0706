//
//  PopUpView.h
//  aaa
//
//  Created by 路国良 on 15/8/4.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

//Copyright (c) 2015年 baofoo. All rights reserved.
#import <UIKit/UIKit.h>

@class PopUpView;

@class ChargeSucessViewController;

@protocol PopUpViewDelegate <NSObject>

-(void)PopUpView:(PopUpView*)PopUpView didClickedClosedButton:(UIButton*)button JumptoViewController:(ChargeSucessViewController*)controller;

//-(void)openPopUpView:(PopUpView *)popUpView Sucessful:(void (^)(NSDictionary *))Sucessful failure:(void (^)(NSString *))failure;
-(void)determineWhetherOpenCashRegister;//判断请求打开收银台是否成功

-(void)failtoOpenTheCashRegisterWithStr:(NSString*)str;//判断请求打开收银台是否成功

-(void)AddBankCardWith:(NSDictionary*)dict;

-(void)popUpViewForgetPassWord;

-(void)closedCashRegister;//点击关闭按钮关闭收银台
@end

@interface PopUpView : UIView

@property(strong,nonatomic) void (^callback) (NSString *my);

@property(nonatomic,assign)id<PopUpViewDelegate>delegate;

@property(nonatomic,copy) NSDictionary*affrtrntDict;//random,money,productionid 传入的数据

-(void)closed;
//-(void)openPopUpView:(PopUpView *)popUpView Sucessful:(void (^)(NSDictionary *))Sucessful failure:(void (^)(NSString *))failure;
//-(NSString*)open
- (instancetype)initWithFrame:(CGRect)frame WithDict:(NSDictionary*)dict withDelegate:(id)controller;
@end

//
//  WBTappableLabel.m
//  BaofooWallet
//
//  Created by 吴斌 on 16/4/14.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import "WBTappableLabel.h"

@implementation WBTappableLabel
-(void)setOnTap:(void (^)(CGPoint))onTap
{
    _onTap = onTap;
    UITapGestureRecognizer* tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapped:)];
    [self addGestureRecognizer:tapGesture];
    self.userInteractionEnabled = YES;
}

-(void)tapped:(UITapGestureRecognizer*)gesture
{
    if (gesture.state == UIGestureRecognizerStateRecognized) {
        CGPoint pt = [gesture locationInView:self];
        if (self.onTap) {
            self.onTap(pt);
        }
    }
}
@end

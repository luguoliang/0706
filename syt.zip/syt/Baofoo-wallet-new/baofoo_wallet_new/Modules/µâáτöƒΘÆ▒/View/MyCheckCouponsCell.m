//
//  MyCheckCouponsCell.m
//  moneyTest
//
//  Created by 路国良 on 15/6/4.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "MyCheckCouponsCell.h"

@implementation MyCheckCouponsCell

- (void)awakeFromNib {
    self.iconImageView.layer.cornerRadius = 22.0f;
//    self.firstImageView.image = [UIImage imageNamed:@"MyCheckOut_firstsection_blue.png"];
//    self.lastImageView.image = [UIImage imageNamed:@"MyCheckOut_laststsection_blue.png"];
//    _firstImageView.translatesAutoresizingMaskIntoConstraints = NO;
//    _lastImageView.translatesAutoresizingMaskIntoConstraints = NO;
//    _face_money = [[UILabel alloc] init];
//    _face_money.textColor = [UIColor whiteColor];
//    _face_money.font = [UIFont systemFontOfSize:20.0f];
//#pragma 过期时间
//    _end_time = [[UILabel alloc] init];
//    _end_time.font = [UIFont systemFontOfSize:13.0];
//    _end_time.textColor = [UIColor whiteColor];
//    _end_time.translatesAutoresizingMaskIntoConstraints = NO;
//    [_lastImageView addSubview:_end_time];
//    NSLayoutConstraint*laebl1x = [NSLayoutConstraint constraintWithItem:_lastImageView attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:_end_time attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
//    [_lastImageView addConstraint:laebl1x];
//    NSLayoutConstraint*laebl1y = [NSLayoutConstraint constraintWithItem:_lastImageView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:_end_time attribute:NSLayoutAttributeBottom multiplier:1.0 constant:14];
//    [_lastImageView addConstraint:laebl1y];
//    //
//#pragma mark - 金额
//    [_firstImageView addSubview:_face_money];
//    _face_money.translatesAutoresizingMaskIntoConstraints = NO;
//    NSLayoutConstraint*facex = [NSLayoutConstraint constraintWithItem:_firstImageView attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:_face_money attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0];
//    [self.contentView addConstraint:facex];
//    NSLayoutConstraint*faceY = [NSLayoutConstraint constraintWithItem:_firstImageView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:_face_money attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:0];
//    [_firstImageView addConstraint:faceY];
//    //
//#pragma mark － 产品名称
//    _voucher_name = [[UILabel alloc] init];
//    _voucher_name.textColor = [UIColor whiteColor];
//    _voucher_name.translatesAutoresizingMaskIntoConstraints = NO;
//    [_lastImageView  addSubview:_voucher_name];
//    NSLayoutConstraint*voucherx = [NSLayoutConstraint constraintWithItem:_end_time attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:_voucher_name attribute:NSLayoutAttributeLeft multiplier:1.0 constant:0];
//    [self.contentView addConstraint:voucherx];
//    NSLayoutConstraint*vouchery = [NSLayoutConstraint constraintWithItem:_lastImageView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:_voucher_name attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:18];
//    [self.contentView addConstraint:vouchery];
//#pragma mark -
//    _laebl
//    = [[UILabel alloc] init];
//    _laebl.translatesAutoresizingMaskIntoConstraints = NO;
//    //    laebl.text = @"收银台选此券即可使用";
//    _laebl.text = @"满100元可使用";
//    _laebl.font = [UIFont systemFontOfSize:13.0];
//    _laebl.textColor = [UIColor whiteColor];
//    [_lastImageView addSubview:_laebl];
//    NSLayoutConstraint*laeblx = [NSLayoutConstraint constraintWithItem:_end_time attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:_laebl attribute:NSLayoutAttributeLeft multiplier:1.0 constant:0];
//    [self.contentView addConstraint:laeblx];
//    NSLayoutConstraint*laebly = [NSLayoutConstraint constraintWithItem:_lastImageView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:_laebl attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:-5];
//    [self.contentView addConstraint:laebly];
//    
//#pragma mark -
//    
//    _myImageView = [[UIImageView alloc] init];
//    _myImageView.translatesAutoresizingMaskIntoConstraints = NO;
//    [_lastImageView addSubview:_myImageView];
//    //
//    NSLayoutConstraint*myimageViewx = [NSLayoutConstraint constraintWithItem:_lastImageView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:_myImageView attribute:NSLayoutAttributeRight multiplier:1.0 constant:8];
//    [_lastImageView addConstraint:myimageViewx];
//    NSLayoutConstraint*myimageViewy = [NSLayoutConstraint constraintWithItem:_lastImageView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:_myImageView attribute:NSLayoutAttributeCenterY multiplier:1.0 constant:15];
//    [_lastImageView addConstraint:myimageViewy];
//#pragma mark -
//    NSLayoutConstraint*myimageViewh = [NSLayoutConstraint constraintWithItem:_firstImageView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:_myImageView attribute:NSLayoutAttributeWidth multiplier:2.5  constant:0];
//    [self.contentView addConstraint:myimageViewh];
//    NSLayoutConstraint*myimageVieww = [NSLayoutConstraint constraintWithItem:_firstImageView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:_myImageView attribute:NSLayoutAttributeHeight multiplier:2.8 constant:0];
//    [self.contentView addConstraint:myimageVieww];
  }

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    //    self.myImageView.backgroundColor = [UIColor grayColor];
    NSLog(@"点击了");
    // Configure the view for the selected state
}

@end

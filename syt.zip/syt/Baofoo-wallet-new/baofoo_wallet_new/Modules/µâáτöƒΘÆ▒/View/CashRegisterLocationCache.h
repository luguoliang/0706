//
//  CashRegisterLocationCache.h
//  BaofooWallet
//
//  Created by 路国良 on 15/9/6.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CashRegisterLocationCache;

@interface CashRegisterLocationCache : NSObject

+(CashRegisterLocationCache*)sharedManager;

-(void)saveCashRegisterCacheDict:(NSMutableDictionary*)dict;

-(NSMutableDictionary*)geCashRegisterCachetDict;

-(void)saveOriginalCashRegisterCacheDict:(NSMutableDictionary*)dict;

-(NSMutableDictionary*)getOriginalCashRegisterCachetDict;

-(void)saveDisPlayCashRegisterCacheDict:(NSDictionary*)dict;

-(NSDictionary*)getDisplayCashRegisterCachetDict;

-(void)clearCashRegister;

@end

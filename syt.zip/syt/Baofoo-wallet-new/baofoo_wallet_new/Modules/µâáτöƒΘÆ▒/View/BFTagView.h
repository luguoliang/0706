//
//  BFTagView.h
//  BaofooWallet
//
//  Created by 吴斌 on 16/4/27.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BFTagView : UIView
@property(nonatomic,strong)NSArray *tagArr;
@property(nonatomic,strong)NSMutableArray *tagLabelArr;//存放tagLabel;
- (void)cleanAllTags;
@end

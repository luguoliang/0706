//
//  FormatterStr.h
//  aaa
//
//  Created by 路国良 on 15/8/4.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface FormatterString : NSObject

+(FormatterString*)sharedManager;

-(NSString*)formatterStringWithString:(NSString*)str;

-(NSString*)getcCurrentSystemtime;

@end

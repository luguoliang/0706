//
//  ChangeVouchersView.m
//  aaa
//
//  Created by 路国良 on 15/8/19.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "ChangeVouchersView.h"
#import "UIColor+Hexadecimal.h"
#import "FormatterString.h"
#import "BFKeyBoardView.h"
#import "CustomImageView.h"
#import "CountdownButton.h"
#import "MyCheckCouponsCell.h"
#import "CashRegisterLocationCache.h"
#import "UILabel+SizeLabel.h"
//#import "Makr_Header.h"
#define SCREE_W                           self.frame.size.width
#define SCREE_H                           self.frame.size.height
#define LINE_COLOR                        @"dcdcdc"
#define BUTTON_COLOR                      @"2e8fd3"
#define VIEW_COLOR                        @"efeff4"
#define SHOW_HEIGHT                       80.0f
#define TITLEHEIGHT                       45.0F

@interface ChangeVouchersView()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView*_myTableView;
    NSMutableDictionary*temDataDictinary;
    NSIndexPath *selectIndexPath;
    UIButton*nextButton;
    UIImageView*backImageVeiw;
    UIView *backview;
}

@end

@implementation ChangeVouchersView

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        UIView*line3 = [[UIView alloc] initWithFrame:CGRectMake(0, TITLEHEIGHT, SCREE_W, 0.5f)];
        line3.backgroundColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0];
        [self addSubview:line3];
        
        UIButton*redwalletButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:redwalletButton];
        [redwalletButton addTarget:self action:@selector(backredwalletButton:) forControlEvents:UIControlEventTouchUpInside];
        redwalletButton.frame = CGRectMake(0, 0, TITLEHEIGHT, TITLEHEIGHT);
        [redwalletButton setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
        [redwalletButton setTitleEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
        [redwalletButton setImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
        
        
        
        UILabel*titleLabel3  = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(redwalletButton.frame), 0, SCREE_W - CGRectGetMaxX(redwalletButton.frame)*2, TITLEHEIGHT)];
        titleLabel3.text = @"使用红包";
        [self addSubview:titleLabel3];
        titleLabel3.textAlignment = NSTextAlignmentCenter;
        
        
        temDataDictinary = [NSMutableDictionary dictionary];
        _myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0,CGRectGetMaxY(line3.frame), SCREE_W,SCREE_H - (CGRectGetMaxY(line3.frame) + SHOW_HEIGHT)) style:UITableViewStylePlain];
        _myTableView.showsVerticalScrollIndicator = NO;
        [self addSubview:_myTableView];
        
        UIView*footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREE_W, 0.5)];
        footView.backgroundColor = [UIColor colorWithHexString:@"dcdcdc" alpha:1.0f];
        _myTableView.tableFooterView = footView;
        nextButton = [UIButton buttonWithType:UIButtonTypeSystem];
        nextButton.frame = CGRectMake((SCREE_W - 100),0, 100, TITLEHEIGHT);
        [self addSubview:nextButton];
        nextButton.titleLabel.font = [UIFont systemFontOfSize:12.0f];
        [nextButton setTintColor:[UIColor colorWithHexString:BUTTON_COLOR alpha:1.0f]];
        [nextButton setTitle:@"暂不使用红包" forState:UIControlStateNormal];
        [nextButton addTarget:self action:@selector(nextButton:) forControlEvents:UIControlEventTouchUpInside];
        backview = [[UIView alloc] initWithFrame:CGRectMake((SCREE_W - 150)/2,(SCREE_H - CGRectGetMaxY(line3.frame) - 150)/2, 150,150)];
        backview.userInteractionEnabled = YES;
        UIImage *image = [UIImage imageNamed:@"red_nopackage.png"];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        imageView.frame = CGRectMake((backview.frame.size.width-image.size.width)*0.5, (backview.frame.size.height-image.size.height)*0.5-30.0f, image.size.width, image.size.height);
        [backview addSubview:imageView];
        CGFloat labelHeight = [UILabel height:@"还没有红包哦~" widthOfFatherView:backview.frame.size.height textFont:FONT(13.0f)];
        UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, imageView.frame.origin.y+imageView.frame.size.height, backview.frame.size.width, labelHeight)];
        label1.font = FONT(13.0f);
        label1.text = @"还没有红包哦~";
        label1.textAlignment = NSTextAlignmentCenter;
        [backview addSubview:label1];
        [self addSubview:backview];
        backview.hidden = YES;
    }
    return self;
}
-(void)nextButton:(UIButton*)button
{
    NSMutableDictionary*temd = [NSMutableDictionary dictionaryWithDictionary:[[CashRegisterLocationCache sharedManager] getOriginalCashRegisterCachetDict]];

    for (int i = 0 ;i < [temd[@"redWallert"] count];i++) {
        
        if ([[temd[@"redWallert"][i][@"isDefault"] stringValue] isEqualToString:@"1"]) {
            NSMutableDictionary*dd = [NSMutableDictionary dictionaryWithDictionary:temd[@"redWallert"][i]];
            
            [dd setValue:[NSNumber numberWithInt:0] forKey:@"isDefault"];
            NSLog(@"i = %d",i);
            
            NSMutableArray*redarray = [NSMutableArray arrayWithArray:temDataDictinary[@"redWallert"]];//redWallertArray
            [redarray replaceObjectAtIndex:i withObject:dd];
            
            [temd setObject:redarray forKey:@"redWallert"];
        }
    }

   [self DataProcessing:temd];
    
    [_myTableView reloadData];

}

-(void)setDisPlayViewWith:(NSMutableDictionary *)dict

{
    temDataDictinary=dict;
    
    if ([dict[@"redWallert"] count]) {
        
        _myTableView.delegate = self;
        
        _myTableView.dataSource = self;
    }
    else
    {
        backview.hidden =NO;
        
        _myTableView.hidden = YES;
        
        nextButton.hidden = YES;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell = nil;
    MyCheckCouponsCell*couponscell = [[[NSBundle mainBundle] loadNibNamed:@"MyCheckCouponsCell" owner:nil options:nil] lastObject];
    
    NSMutableDictionary*dc = temDataDictinary[@"redWallert"][indexPath.row];
    if (([[dc[@"isDefault"] stringValue] isEqualToString:@"1"])) {
        selectIndexPath = indexPath;
    }
    if ([selectIndexPath isEqual:indexPath]) {
        couponscell.selectImageView.image = [UIImage imageNamed:@"select.png"];
    }
    couponscell.iconImageView.image = [UIImage imageNamed:@"vocherCoupons.png"];
    cell = couponscell;
    couponscell.nameLabel.text = temDataDictinary[@"redWallert"][indexPath.row][@"name"];
    NSString*str = [temDataDictinary[@"redWallert"][indexPath.row][@"balance"] stringValue];
    couponscell.face_moneyLabel.text = [NSString stringWithFormat:@"%@元",str];
    couponscell.face_moneyLabel.textColor = [UIColor colorWithHexString:@"ff722c" alpha:1.0f];
    NSDictionary*de = [self JsonParsing:temDataDictinary[@"redWallert"][indexPath.row][@"desc"]];
    couponscell.conditionLabel.text = de[@"filed1"];
    couponscell.conditionLabel2.text = de[@"filed2"];
    couponscell.end_timeLabel.text = [NSString stringWithFormat:@"%@-%@",de[@"start_time"],de[@"end_time"]];
    
    if (!([self Determinewhetherthereisadefaultred])) {
        
        couponscell.selectImageView.image = [UIImage imageNamed:@""];
    }

    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (selectIndexPath) {
        MyCheckCouponsCell *cell = (MyCheckCouponsCell*)[tableView cellForRowAtIndexPath:selectIndexPath];
        cell.selectImageView.image = [UIImage imageNamed:@""];
    }
    MyCheckCouponsCell *cell = (MyCheckCouponsCell*)[tableView cellForRowAtIndexPath:indexPath];
    cell.selectImageView.image = [UIImage imageNamed:@"select.png"];
    selectIndexPath = indexPath;
    [self performSelector:@selector(deselect) withObject:nil afterDelay:0.1f];
    NSMutableDictionary*dc = temDataDictinary[@"redWallert"][indexPath.row];
    NSMutableDictionary*dcs  = [NSMutableDictionary dictionaryWithDictionary:dc];
    if (([[dcs[@"isUse"] stringValue] isEqualToString:@"1"])) {
        //before change the default "isdefault" should change the default value
        [self changdefaaultwith:temDataDictinary];
        
        
        NSNumber *nu = [NSNumber numberWithInt:1];
        
        [dcs setObject:nu forKey:@"isDefault"];
        
        NSMutableArray*redarray = [NSMutableArray arrayWithArray:temDataDictinary[@"redWallert"]];//redWallertArray
        
        [redarray replaceObjectAtIndex:indexPath.row withObject:dcs];
        
        [temDataDictinary setObject:redarray forKey:@"redWallert"];
        
        [self DataProcessing:temDataDictinary];

    }
    else
    {
        [self showAlertView:nil];
    }
    
}

-(void)changdefaaultwith:(NSMutableDictionary*)dict
{
    for (int i = 0 ;i < [dict[@"redWallert"] count];i++) {

        if ([[dict[@"redWallert"][i][@"isDefault"] stringValue] isEqualToString:@"1"]) {
            NSMutableDictionary*dd = [NSMutableDictionary dictionaryWithDictionary:dict[@"redWallert"][i]];
            
            [dd setValue:[NSNumber numberWithInt:0] forKey:@"isDefault"];
            NSLog(@"i = %d",i);
            
            NSMutableArray*redarray = [NSMutableArray arrayWithArray:temDataDictinary[@"redWallert"]];//redWallertArray
            [redarray replaceObjectAtIndex:i withObject:dd];
            
            [temDataDictinary setObject:redarray forKey:@"redWallert"];
        }
    }
}


-(BOOL)Determinewhetherthereisadefaultred

{
    BOOL ishave = NO;
    
    NSArray*arr = [[CashRegisterLocationCache sharedManager] getOriginalCashRegisterCachetDict][@"redWallert"];
    
    for(NSDictionary*dc in arr)
    {
        if ([[dc[@"isDefault"] stringValue] isEqualToString:@"1"]) {
            ishave = YES;
        }
    }
    return ishave;
}

#warning 这儿，
-(void)DataProcessing:(NSMutableDictionary*)dict//
{
    [[CashRegisterLocationCache sharedManager] saveOriginalCashRegisterCacheDict:dict];
    [_delegate ChangeVouchersView:self didChangeRedWalletWithDict:dict];
    [self backredwalletButton:nil];
}

-(void)showAlertView:(NSString*)string

{
    UIAlertView*alert = [[UIAlertView alloc] initWithTitle:@"" message:@"当前红包不满足使用条件，请选择其它红包" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
    
}
- (void)deselect
{
    [_myTableView deselectRowAtIndexPath:[_myTableView indexPathForSelectedRow] animated:YES];
}

-(NSDictionary*)JsonParsing:(NSString*)jsonDescStr
{
    NSData *data = [jsonDescStr dataUsingEncoding:NSUTF8StringEncoding];
    NSArray*array = [NSJSONSerialization JSONObjectWithData:data options:(NSJSONReadingMutableLeaves) error:nil];
    return [array lastObject];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [temDataDictinary[@"redWallert"] count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 77;
}
-(void)backredwalletButton:(UIButton*)button
{
    [_delegate ChangeVouchersView:self didClickedBackButton:button];
}
@end

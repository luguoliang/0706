//
//  ProductCell.m
//  BaofooWallet
//
//  Created by mac on 15/5/13.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import "ProductCell.h"
#import "WBProgress.h"
#import "BFTagView.h"
#import "UILabel+SizeLabel.h"
#import "NSMutableAttributedString+MutableString.h"


#define NAME_FONT 15.0f//产品名称字体
#define DETAIL_FONT 15.0f//数据右下标字体
#define DATA_FONT 30.0f //数据字体
#define PROMT_FONT 9.0f//提示文字字体

#define SHOU_QING_COLOR @"#dcdcdc"//售罄标签颜色
#define SHOU_YI_COLOR @"#a3e28d"//收益中颜色
#define FAN_HUAN_COLOR @"#ffc26c"//售罄提示颜色

@interface ProductCell()
{
    UIView *contentView;
    UILabel *product_nameLabel;//产品名称
    BFTagView *tagView;
//    UILabel *typeLabel;//产品类别
    
    UIImageView *product_typeImageView;//产品标识
    UIImageView *product_tagImageView;//产品标签（在售，售罄）
    UILabel *buy_time_countLabel;//投资期限
    UILabel *year_rateandextra_rate;//预期年化
//    YYProgress *myCustomProgress;//购买进度条
    WBProgress *progress;//系统进度条
    UILabel *rateLabel;//购买比例
    
    //提示文字
    UILabel *promtLabel1;
    UILabel *promtLabel2;
}
@end
@implementation ProductCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);//cell的背景颜色
        
        //父视图
        contentView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, ScreenWidth, AUTO_LENGTH(90))];
        contentView.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:contentView];

        
        product_nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(AUTO_LENGTH(12), AUTO_LENGTH(7), AUTO_LENGTH(200), AUTO_LENGTH(17.5))];
        
        product_nameLabel.textColor = COLOR_HEXSTRING(BLACK_COLOR);
        product_nameLabel.font = FONT_LIGHT(AUTO_LENGTH(NAME_FONT));
        [contentView addSubview:product_nameLabel];
        
//        typeLabel = [[UILabel alloc] init];
//        typeLabel.layer.borderWidth = 0.5;
//        typeLabel.layer.masksToBounds = YES;
//        typeLabel.layer.cornerRadius = 2;
//        typeLabel.font = FONT_LIGHT(AUTO_LENGTH(10.0f));
//        typeLabel.textAlignment = NSTextAlignmentCenter;
//        [contentView addSubview:typeLabel];
        tagView = [[BFTagView alloc] init];
        tagView.backgroundColor = [UIColor clearColor];
        [contentView addSubview:tagView];
       
        buy_time_countLabel = [[UILabel alloc] init];
//        buy_time_countLabel.backgroundColor = [UIColor redColor];
        buy_time_countLabel.textColor = COLOR_HEXSTRING(ORANGE_COLOR);
        buy_time_countLabel.font = FONT_LIGHT(AUTO_LENGTH(DATA_FONT));
        buy_time_countLabel.textAlignment = NSTextAlignmentLeft;
        [contentView addSubview:buy_time_countLabel];
        
        year_rateandextra_rate = [[UILabel alloc] init];
//        year_rateandextra_rate.backgroundColor = [UIColor blueColor];
        year_rateandextra_rate.textColor = COLOR_HEXSTRING(ORANGE_COLOR);
        year_rateandextra_rate.font = FONT_LIGHT(AUTO_LENGTH(DATA_FONT));
        year_rateandextra_rate.textAlignment = NSTextAlignmentLeft;
        [contentView addSubview:year_rateandextra_rate];
        
        promtLabel1 = [[UILabel alloc] init];
//        [promtLabel1 setBackgroundColor:[UIColor blueColor]];
        promtLabel1.textColor = COLOR_HEXSTRING(PROMT_COLOR);
        promtLabel1.font = FONT_LIGHT(AUTO_LENGTH(PROMT_FONT));
        promtLabel1.textAlignment = NSTextAlignmentLeft;
        [contentView addSubview:promtLabel1];
        
        promtLabel2 = [[UILabel alloc] init];
        promtLabel2.textColor = COLOR_HEXSTRING(PROMT_COLOR);
        promtLabel2.font = FONT_LIGHT(AUTO_LENGTH(PROMT_FONT));
        promtLabel2.textAlignment = NSTextAlignmentLeft;
        [contentView addSubview:promtLabel2];
        
        
        progress = [[WBProgress alloc] initWithFrame:CGRectMake(ScreenWidth-AUTO_LENGTH(78), contentView.frame.size.height-AUTO_LENGTH(70), AUTO_LENGTH(58), AUTO_LENGTH(58))];
        progress.backgroundStrokeColor = COLOR_HEXSTRING(GRAY_COLOR);
        progress.progressStrokeColor = COLOR_HEXSTRING(ORANGE_COLOR);
        progress.progressLineWidth = AUTO_LENGTH(2.5);
        progress.backgourndLineWidth = AUTO_LENGTH(2.5);
        progress.timeDuration = 0.6;
        progress.digitTintColor = COLOR_HEXSTRING(ORANGE_COLOR);
        [contentView addSubview:progress];
        
        
    }
    return self;
}

- (void)loadProductInfo:(id)bill
{
    Bills *product = (Bills *)bill;
    CGFloat nameLabelWidth = [UILabel width:product.product_name heightOfFatherView:product_nameLabel.frame.size.height textFont:product_nameLabel.font];
    product_nameLabel.frame = CGRectMake(product_nameLabel.frame.origin.x, product_nameLabel.frame.origin.y, nameLabelWidth, product_nameLabel.frame.size.height);
    product_nameLabel.text = product.product_name;//
    CGFloat typeLabelHeight = AUTO_LENGTH(16);
    tagView.frame = CGRectMake(CGRectGetMaxX(product_nameLabel.frame)+AUTO_LENGTH(10), product_nameLabel.frame.origin.y, ScreenWidth-CGRectGetMaxX(product_nameLabel.frame), typeLabelHeight);
    NSArray *tagArr = nil;
    if (![product.showTags isEqualToString:@""]) {
        tagArr = [product.showTags componentsSeparatedByString:@"|"];
    }
    
    if (tagArr.count>0) {
        [tagView cleanAllTags];
        tagView.tagArr = tagArr;
        [contentView addSubview:tagView];
        
    }else
    {
        [tagView cleanAllTags];
        [tagView removeFromSuperview];
    }
    CGFloat labelWidth1 = AUTO_LENGTH(140.0f);
    CGFloat labelWidth2 = AUTO_LENGTH(80.0f);
    
    CGFloat dataHeight = [UILabel height:product.buy_time_count widthOfFatherView:labelWidth1 textFont:FONT_LIGHT(AUTO_LENGTH(DATA_FONT))];
    CGFloat promtHeight = [UILabel height:@"投资期限" widthOfFatherView:labelWidth1 textFont:FONT_LIGHT(AUTO_LENGTH(PROMT_FONT))];
    
    NSString *year_rate = [NSString stringWithFormat:@"%.1f",[product.year_rate floatValue]];
    NSArray *moneyArray = [year_rate componentsSeparatedByString:@"."];
    year_rate = moneyArray[0];
    
    NSString *extra_rate = nil;
    
    //预期年化
    year_rateandextra_rate.frame = CGRectMake(AUTO_LENGTH(20.0f), CGRectGetMaxY(product_nameLabel.frame)+AUTO_LENGTH(10), labelWidth1, dataHeight);
    if (![[[NSNumber numberWithFloat:[product.extra_rate floatValue]] stringValue] isEqualToString:@"0"]) {
        extra_rate = [NSString stringWithFormat:@".%@+%.1f%%",moneyArray[1],[product.extra_rate floatValue]];
    }
    else{
        extra_rate = [NSString stringWithFormat:@".%@%%",moneyArray[1]];
    }
    year_rateandextra_rate.attributedText = [NSMutableAttributedString stringWithText1:year_rate text2:extra_rate text1Color:COLOR_HEXSTRING(ORANGE_COLOR) text2Colot:COLOR_HEXSTRING(ORANGE_COLOR) font1:FONT_LIGHT(AUTO_LENGTH(DATA_FONT)) font2:FONT_LIGHT(AUTO_LENGTH(DETAIL_FONT))];
    
    //投资期限
    buy_time_countLabel.frame = CGRectMake(labelWidth1, year_rateandextra_rate.frame.origin.y, labelWidth2, dataHeight);
    
    buy_time_countLabel.attributedText = [NSMutableAttributedString stringWithText1:product.buy_time_count text2:@"天" text1Color:COLOR_HEXSTRING(ORANGE_COLOR) text2Colot:COLOR_HEXSTRING(ORANGE_COLOR)font1:FONT_LIGHT(AUTO_LENGTH(DATA_FONT)) font2:FONT_LIGHT(AUTO_LENGTH(DETAIL_FONT))];
    

    promtLabel2.frame = CGRectMake(year_rateandextra_rate.frame.origin.x, buy_time_countLabel.frame.origin.y+buy_time_countLabel.frame.size.height-1.0f , labelWidth1, promtHeight);
    promtLabel2.text = @"年化收益";
    
    promtLabel1.frame = CGRectMake(buy_time_countLabel.frame.origin.x, promtLabel2.frame.origin.y, labelWidth2, promtHeight);
    promtLabel1.text = @"投资期限";
    
#pragma mark - 售罄产品设置
    CGFloat floatValue = [product.rate floatValue]/100.0;
    if([product.product_tag intValue]<40)
    {
        progress.progressStrokeColor = COLOR_HEXSTRING(ORANGE_COLOR);
        progress.image = [UIImage createImageWithColor:[UIColor whiteColor]];
        progress.backgroundStrokeColor = COLOR_HEXSTRING(GRAY_COLOR);
        progress.digitTintColor = COLOR_HEXSTRING(ORANGE_COLOR);
        [progress setProgress:floatValue Animated:YES];
    }else if ([product.product_tag intValue]==40) {
//            [self changeColor];
        progress.digitTintColor = [UIColor whiteColor];
        progress.backgroundStrokeColor = COLOR_HEXSTRING(SHOU_QING_COLOR);
        progress.progressStrokeColor = COLOR_HEXSTRING(SHOU_QING_COLOR);
        progress.image = [UIImage imageNamed:@"home_round_gray"];
        progress.Percentage = 999;
        progress.progressLabel.text = @"售罄";
    }else if([product.product_tag intValue]==50)
    {
        progress.digitTintColor = [UIColor whiteColor];
        progress.backgroundStrokeColor = COLOR_HEXSTRING(SHOU_YI_COLOR);
        progress.progressStrokeColor = COLOR_HEXSTRING(SHOU_YI_COLOR);
        progress.image = [UIImage imageNamed:@"home_round_green"];
        progress.Percentage = 999;
        progress.progressLabel.text = @"收益中";
    }else if([product.product_tag intValue]==60)
    {
        progress.digitTintColor = [UIColor whiteColor];
        progress.backgroundStrokeColor = COLOR_HEXSTRING(FAN_HUAN_COLOR);
        progress.progressStrokeColor = COLOR_HEXSTRING(FAN_HUAN_COLOR);
        progress.image = [UIImage imageNamed:@"home_round_orange"];
        progress.Percentage = 999;
        progress.progressLabel.text = @"已返还";
    }
    
    self.selectedBackgroundView = [[UIView alloc] initWithFrame:contentView.frame];
    self.selectedBackgroundView.backgroundColor = COLOR_HEXSTRING(@"#f5f5f5");
//    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

-(void)changeColor
{
    year_rateandextra_rate.textColor = COLOR_HEXSTRING(@"#c9c9c9");;
    buy_time_countLabel.textColor = COLOR_HEXSTRING(@"#c9c9c9");;
    promtLabel1.textColor = COLOR_HEXSTRING(PROMT_COLOR);
    promtLabel2.textColor = COLOR_HEXSTRING(PROMT_COLOR);
    
}

@end

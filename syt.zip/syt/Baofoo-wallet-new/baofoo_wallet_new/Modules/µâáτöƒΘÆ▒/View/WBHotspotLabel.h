//
//  WBHotspotLabel.h
//  BaofooWallet
//
//  Created by 吴斌 on 16/4/14.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import "WBTappableLabel.h"

@interface WBHotspotLabel : WBTappableLabel

@end

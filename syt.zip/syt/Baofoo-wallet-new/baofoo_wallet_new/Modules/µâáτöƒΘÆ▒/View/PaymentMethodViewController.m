//
//  PaymentMethodViewController.m
//  checkoutcounter
//
//  Created by 路国良 on 15/5/28.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//
#import "PaymentMethodViewController.h"
#import "BFBuyCommodityViewController.h"
#import "ValidatePaypsdViewController.h"
#define selectColor  [UIColor colorWithRed:138.0f/250.0f green:204.0f/250.0f blue:246.0f/250.0f alpha:1.0];
#define defaultColor  [UIColor colorWithRed:46.0f/250.0f green:143.0f/250.0f blue:211.0f/250.0f alpha:1.0];
#define backgroundColors  [UIColor colorWithRed:247.0f/255.0f green:247.0f/255.0f blue:247.0f/255.0f alpha:1.0f];
@interface PaymentMethodViewController ()<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate,UIAlertViewDelegate>
{
    UITableView*_myTableView;
    UIView*_detailView;
    UIView*_orderFormView;//账单总额视图
    UIView*_VouchersView;//使用代金券
    UIView*_ComplexView;//综合金额账单
    UILabel*_detailLabel;//描述
    NSIndexPath *selectIndexPath;
    UIButton*footButton;
    NSMutableArray*_countArray;//银行卡
    NSMutableDictionary*_DefaultVouchDicts;//默认显示的代金券
    NSMutableArray*_array;//保存银行卡模型
    NSString*ishaveVouch;//有否有可使用代金券
    NSString*_totalOrderStrs;//支付总额
    NSString*_complexMoney;//使用账户或者安全卡支付的总额
    UILabel*complexMoneyLabel;//使用账户或者安全卡支付的总额
    NSString*isbalanceStr;//余额是否可用
    NSString*payType;//判断有没有安全卡
    NSString*_vouchersStr;
    UILabel*label5;//代金券金额
    NSDictionary*_selectDict;
}
@end
@implementation PaymentMethodViewController
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    //1.是否有代金券
    if([ishaveVouch isEqualToString:@"0"])//没有代金券
    {
        NSString*str1 = _totalOrderStrs;//总额
        _complexMoney = str1;
    }
    else//有代金券
    {
        NSString*str1 = _totalOrderStrs;//总额
        NSString*str2 = _DefaultVouchDicts[@"balance"];//代金券
        label5.text = [NSString stringWithFormat:@"%@元",[_DefaultVouchDicts[@"balance"] stringValue]];
        double db1 = [str1 doubleValue];
        double db2 = [str2 doubleValue];
        double db3 = db1 - db2;
        if (db3 <= 0) {
            _complexMoney = @"0";
        }
        else{
        
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = kCFNumberFormatterDecimalStyle;
        NSString *string = [formatter stringFromNumber:[NSNumber numberWithDouble:db3]];
        string  = [string stringByReplacingOccurrencesOfString:@"￥" withString:@""];
        _complexMoney = string;
        }
    }
    complexMoneyLabel.text = [NSString stringWithFormat:@"%@元",_complexMoney];
    //2.综合金额_complexMoney
    //3.余额是否可用
    NSString*str = [[_countArray objectAtIndex:0][@"balance"] stringValue];//获取余额
    double db1 = [str doubleValue];
    double db2 = [_complexMoney doubleValue];
    if (db1 < db2) {
        isbalanceStr = @"0";//"账户余额不足"
    }
    else
    {
        isbalanceStr = @"1";//"账户余额可用"
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _selectDict = [NSDictionary dictionary];//添加银行卡时用到
    _complexMoney = [NSString stringWithFormat:@""];
#pragma mark - 没有代金券
    _DefaultVouchDicts = [NSMutableDictionary dictionary];
    _DefaultVouchDicts = self.DefaultVouchDict;
    if (_DefaultVouchDicts.count == 0) {
        ishaveVouch = @"0";//没有代金券
    }
    else
    {
        ishaveVouch = @"1";
    }
    _countArray = [NSMutableArray array];
    _countArray = self.bankCards;
    NSLog(@"_countArray = %@",_countArray);
    
#pragma mark - 判断有没有代金券
    self.navigationItem.title = @"选择支付方式";
    self.view.backgroundColor = backgroundColors;
    [self _setorderFormViewWith:nil];//订单总额显示
    if ([ishaveVouch isEqualToString:@"0"]) {
        [self _setnoVouchWich:nil];//没有代金券
    }
    else
    {
        [self _setVouchWith:_DefaultVouchDicts];//代金券显示
    }
#pragma mark - 判断有没有安全卡
    payType = @"0";
    for (NSDictionary*dc in _countArray) {
        if ([dc[@"payType"] isEqualToString:@"301"]) {
            NSLog(@"有安全卡");
            payType = @"301";
        }
    }
    _myTableView =[[UITableView alloc] initWithFrame:CGRectMake(0,CGRectGetMaxY(_ComplexView.frame), self.view.frame.size.width, (self.view.frame.size.height - (CGRectGetMaxY(_ComplexView.frame) - 40-64.0f) )) style:UITableViewStylePlain];
    [self.view addSubview:_myTableView];
    _myTableView.delegate = self;
    _myTableView.dataSource = self;
    _myTableView.showsVerticalScrollIndicator = NO;
    //确认
    footButton = [UIButton buttonWithType:UIButtonTypeCustom];
    footButton.frame = CGRectMake(0, self.view.frame.size.height - 40-64, self.view.frame.size.width, 40);
    footButton.enabled = NO;
    [self.view addSubview:footButton];
    [footButton addTarget:self action:@selector(footbutton:) forControlEvents:UIControlEventTouchUpInside];
    [footButton setTitle:@"确认" forState:UIControlStateNormal];
    [footButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    footButton.backgroundColor = selectColor;
    UIView*footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, CGRectGetMaxY(_ComplexView.frame) + 500)];
    footView.backgroundColor = backgroundColors
    _myTableView.tableFooterView = footView;
}
#pragma mark - 设置订单总额
-(void)_setorderFormViewWith:(NSMutableDictionary*)dict
{
    //订单总额
    _orderFormView = [[UIView alloc] initWithFrame:CGRectMake(0, 0.0f, self.view.frame.size.width, 40)];
    _orderFormView.backgroundColor = [UIColor whiteColor];
    _orderFormView.layer.borderWidth = 1.0;
    _orderFormView.layer.borderColor = [UIColor colorWithRed:247.0f/255.0f green:247.0f/255.0f blue:247.0f/255.0f alpha:1.0f].CGColor;
    _orderFormView.backgroundColor = [UIColor colorWithRed:244.0f/255.0f green:251.0f/255.0f blue:255.0f/255.0f alpha:1.0f];
    [self.view addSubview:_orderFormView];
    UILabel*label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 90, 40)];
    label.textColor = [UIColor redColor];
    label.text = @"订单总额";
    [_orderFormView addSubview:label];
    label.font = [UIFont systemFontOfSize:14.0f];
    UILabel*moneyLabel = [[UILabel alloc] initWithFrame:CGRectMake(100, 0, self.view.frame.size.width - 110, 40)];
    moneyLabel.text = @"5,000元";
    _totalOrderStrs = self.totalOrderStr;
    moneyLabel.text = [NSString stringWithFormat:@"%@元",_totalOrderStrs];
    moneyLabel.textColor = [UIColor redColor];
    moneyLabel.textAlignment = NSTextAlignmentRight;
    moneyLabel.font = [UIFont systemFontOfSize:14.0f];
    [_orderFormView addSubview:moneyLabel];
}
#pragma mark - 没有代金券
-(void)_setnoVouchWich:(NSMutableDictionary*)dict
{
    _VouchersView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_orderFormView.frame) + 20, self.view.frame.size.width, 40)];
    _VouchersView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_VouchersView];
    UILabel*label3 = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 120, 40)];
    label3.backgroundColor = [UIColor whiteColor];
    label3.text = @"暂无红包可用";
    label3.font = [UIFont systemFontOfSize:14.0f];
    [_VouchersView addSubview:label3];
    label5 = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(label3.frame), 0, self.view.frame.size.width - 150, 40)];
    UIImageView*myimageView = [[UIImageView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(label5.frame), 10, 12, 20)];
    myimageView.image = [UIImage imageNamed:@"click_arrow.png"];
    [_VouchersView addSubview:myimageView];
    [label5 setTextColor:[UIColor redColor]];
    label5.font = [UIFont systemFontOfSize:14.0f];
    label5.textAlignment = NSTextAlignmentRight;
    [_VouchersView addSubview:label5];
    UIControl*control = [[UIControl alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 40)];
    [_VouchersView addSubview:control];
    [control addTarget:self action:@selector(controlclickd) forControlEvents:UIControlEventTouchUpInside];
    //详情描述
    _detailView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_VouchersView.frame), self.view.frame.size.width, 20)];
    UILabel*detailLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, self.view.frame.size.width- 20, 20)];
    detailLabel.font = [UIFont systemFontOfSize:13.0f];
    detailLabel.alpha = 0.5;
    detailLabel.backgroundColor = backgroundColors;
    detailLabel.numberOfLines = 0;
    [_detailView addSubview:detailLabel];
    _detailView.backgroundColor = backgroundColors;
    [self.view addSubview:_detailView];
    _ComplexView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_detailView.frame), self.view.frame.size.width, 40)];
    _ComplexView.layer.borderWidth = 1.0;
    _ComplexView.layer.borderColor = [UIColor colorWithRed:247.0f/255.0f green:247.0f/255.0f blue:247.0f/255.0f alpha:1.0f].CGColor;
    _ComplexView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_ComplexView];
    UILabel*label4 = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 170, 40)];
    label4.text = @"使用账户余额或安全卡支付";
    [_ComplexView addSubview:label4];
    label4.font = [UIFont systemFontOfSize:14.0f];
#pragma makr - 计算综合金额
    complexMoneyLabel = [[UILabel alloc] initWithFrame:CGRectMake(180, 0, self.view.frame.size.width - 190, 40)];
    complexMoneyLabel.text = [NSString stringWithFormat:@"%@元",_complexMoney];
    complexMoneyLabel.textColor = [UIColor redColor];
    complexMoneyLabel.textAlignment = NSTextAlignmentRight;
    complexMoneyLabel.font = [UIFont systemFontOfSize:14.0f];
    [_ComplexView addSubview:complexMoneyLabel];
}
#pragma mark - 设置代金券
-(void)_setVouchWith:(NSMutableDictionary*)dict
{
    _VouchersView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_orderFormView.frame) + 20, self.view.frame.size.width, 40)];
    _VouchersView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_VouchersView];
    UILabel*label3 = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 120, 40)];
    label3.backgroundColor = [UIColor whiteColor];
    label3.text = @"使用理财产品红包";
    label3.font = [UIFont systemFontOfSize:14.0f];
    [_VouchersView addSubview:label3];
    label5 = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(label3.frame), 0, self.view.frame.size.width - 150, 40)];
    UIImageView*myimageView = [[UIImageView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(label5.frame), 12, 10, 17)];
    myimageView.image = [UIImage imageNamed:@"click_arrow.png"];
    [_VouchersView addSubview:myimageView];
    label5.text = @"50元";
    label5.text = [NSString stringWithFormat:@"%@元",dict[@"balance"]];
    //    if (_vouchersStr.length) {
    //        label5.text = _vouchersStr;
    //    }
    [label5 setTextColor:[UIColor redColor]];
    label5.font = [UIFont systemFontOfSize:14.0f];
    label5.textAlignment = NSTextAlignmentRight;
    [_VouchersView addSubview:label5];
    UIControl*control = [[UIControl alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 40)];
    [_VouchersView addSubview:control];
    [control addTarget:self action:@selector(controlclickd) forControlEvents:UIControlEventTouchUpInside];
    //详情描述
    _detailView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_VouchersView.frame), self.view.frame.size.width, 50)];
    UILabel*detailLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, self.view.frame.size.width- 20, 50)];
    detailLabel.font = [UIFont systemFontOfSize:13.0f];
    detailLabel.alpha = 0.5;
    detailLabel.backgroundColor = backgroundColors;
    detailLabel.text = @"每次启动收银台,慧生钱将默认匹配您最近有效期可使用的红包，您也可以手动选择其他红包";
    detailLabel.numberOfLines = 0;
    [_detailView addSubview:detailLabel];
    _detailView.backgroundColor = backgroundColors;
    [self.view addSubview:_detailView];
    _ComplexView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_detailView.frame), self.view.frame.size.width, 40)];
    _ComplexView.layer.borderWidth = 1.0;
    _ComplexView.layer.borderColor = [UIColor colorWithRed:247.0f/255.0f green:247.0f/255.0f blue:247.0f/255.0f alpha:1.0f].CGColor;
    _ComplexView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_ComplexView];
    UILabel*label4 = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 170, 40)];
    label4.text = @"使用账户余额或安全卡支付";
    [_ComplexView addSubview:label4];
    label4.font = [UIFont systemFontOfSize:14.0f];
#pragma makr - 计算综合金额
    complexMoneyLabel = [[UILabel alloc] initWithFrame:CGRectMake(180, 0, self.view.frame.size.width - 190, 40)];
    
    complexMoneyLabel.text = [NSString stringWithFormat:@"%@元",[self getForMatStringwithStr:_complexMoney]];
    complexMoneyLabel.textColor = [UIColor redColor];
    complexMoneyLabel.textAlignment = NSTextAlignmentRight;
    complexMoneyLabel.font = [UIFont systemFontOfSize:14.0f];
    [_ComplexView addSubview:complexMoneyLabel];
}
//更换代金券
-(void)controlclickd
{
    
}
//确认选择按钮
-(void)footbutton:(UIButton*)button
{
    NSLog(@"确认选择支付方式按钮");
    NSLog(@"selectIndexPath = %ld",(long)selectIndexPath.row);
    NSLog(@"countArray.count)  = %lu",(unsigned long)_countArray.count);
    if (selectIndexPath.row == 0) {
#pragma mark - 选择余额支付后回调
        if (_callbackBalance) {
            _callbackBalance(_DefaultVouchDicts);
        }
//        for (UIViewController*controlView in self.navigationController.viewControllers) {
//            if ([controlView isKindOfClass:[BuyCommodityViewController class]]) {
//                [self.navigationController popToViewController:controlView animated:YES];
//            }
//        }
        [self.navigationController popViewControllerAnimated:YES];
    }
    else
    {
        if (![payType isEqualToString:@"301"]) {//不存在安全卡
            if (selectIndexPath.row == (_countArray.count)) {
                NSLog(@"最后一项余额支付");
                [self addNewBankCard];//添加银行卡
            }
            else
            {
                NSLog(@"弹出快捷卡");// 快捷卡支付
                [self changeSafeCardBankPay];
            }
        }
        else//安全卡支付
        {
            [self safeCardBankPay];//选择安全卡后回传
        }
    }
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat yOffset  = scrollView.contentOffset.y;
    //            NSLog(@"yOffset===%f",yOffset);
    CGFloat h1 = 50 - yOffset;
    CGFloat h2 = 20 - yOffset;
    if (h1 < 0) {
        h1 = 0.0;
    }
    if (h2 < 0) {
        h2 = 0;
    }
    if ([ishaveVouch isEqualToString:@"0"]) {
        _VouchersView.frame = CGRectMake(0, CGRectGetMaxY(_orderFormView.frame) + h2, self.view.frame.size.width, 40);
        _detailView.frame = CGRectMake(0, CGRectGetMaxY(_VouchersView.frame), self.view.frame.size.width, h2);
        _ComplexView.frame = CGRectMake(0, CGRectGetMaxY(_detailView.frame), self.view.frame.size.width, 40);
        _myTableView.frame = CGRectMake(0,CGRectGetMaxY(_ComplexView.frame), self.view.frame.size.width, self.view.frame.size.height);
        
    }
    else{
        _VouchersView.frame = CGRectMake(0, CGRectGetMaxY(_orderFormView.frame) + h2, self.view.frame.size.width, 40);
        _detailView.frame = CGRectMake(0, CGRectGetMaxY(_VouchersView.frame), self.view.frame.size.width, h1);
        _ComplexView.frame = CGRectMake(0, CGRectGetMaxY(_detailView.frame), self.view.frame.size.width, 40);
        _myTableView.frame = CGRectMake(0,CGRectGetMaxY(_ComplexView.frame), self.view.frame.size.width, self.view.frame.size.height);
    }
    
}
#pragma mark - UITabelViewDelegate
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    if ([selectIndexPath isEqual:indexPath]) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textLabel.font = [UIFont systemFontOfSize:14.0f];
    cell.detailTextLabel.font = [UIFont systemFontOfSize:11.0f];
    cell.detailTextLabel.alpha = 0.5;
#pragma mark - 有安全卡
    if ([payType isEqualToString:@"301"]) {
        if (indexPath.row == 0) {//section == 0
            cell.textLabel.text = [NSString stringWithFormat:@"%@支付",[_countArray objectAtIndex:indexPath.row][@"name"]];
            if ([isbalanceStr isEqualToString:@"0"]) {
                

                cell.detailTextLabel.text = [NSString stringWithFormat:@"余额%@元   余额不足",[self getForMatStringwithStr:[[_countArray objectAtIndex:indexPath.row][@"balance"] stringValue]]];
                cell.accessoryType = UITableViewCellAccessoryNone;
                cell.textLabel.alpha = 0.5;
            }
            else{
                cell.detailTextLabel.text = [NSString stringWithFormat:@"余额%@元   余额可支付",[self getForMatStringwithStr:[[_countArray objectAtIndex:indexPath.row][@"balance"] stringValue]]];
            }
            cell.imageView.image = [UIImage imageNamed:@"payment_balabce.png"];
        }//section == 0
        else//section == 1
        {
            cell.textLabel.text = [NSString stringWithFormat:@"%@支付",[_countArray objectAtIndex:(indexPath.row)][@"name"]];
            NSString*desc = [_countArray objectAtIndex:(indexPath.row)][@"desc"];
            NSArray *descArray = [desc componentsSeparatedByString:@"|"];
            cell.textLabel.text = [NSString stringWithFormat:@"%@%@  %@",[_countArray objectAtIndex:(indexPath.row)][@"name"],descArray[0],descArray[1]];
            NSNumber *number = descArray[2];
            if ([number integerValue] > 0) {
                
            cell.detailTextLabel.text = [NSString stringWithFormat:@"本次可用额度  %@元",[self getForMatStringwithStr:descArray[2]]];
            }
            else
            {
            cell.detailTextLabel.text = @"";
            }
//            cell.detailTextLabel.text = [desc stringByReplacingOccurrencesOfString:@"|" withString:@"   "];
            cell.imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[_countArray objectAtIndex:indexPath.row][@"payId"]]];
        }
    }
    //没有安全卡
    else
    {
        if (indexPath.row == 0) {
            cell.textLabel.text = [NSString stringWithFormat:@"%@支付",[_countArray objectAtIndex:indexPath.row][@"name"]];
            cell.imageView.image = [UIImage imageNamed:@"payment_balabce.png"];
            if ([isbalanceStr isEqualToString:@"0"]) {
                cell.detailTextLabel.text = [NSString stringWithFormat:@"余额%@元   余额不足",[self getForMatStringwithStr:[[_countArray objectAtIndex:indexPath.row][@"balance"] stringValue]]];
                cell.accessoryType = UITableViewCellAccessoryNone;
                cell.textLabel.alpha = 0.5;
            }
            else{
                
//                NSString*str = [self getForMatStringwithStr:[[_countArray objectAtIndex:indexPath.row][@"balance"] stringValue]];
                cell.detailTextLabel.text = [NSString stringWithFormat:@"余额%@元",[self getForMatStringwithStr:[[_countArray objectAtIndex:indexPath.row][@"balance"] stringValue]]];
            }
        }
        else if(indexPath.row == _countArray.count)
        {
            cell.textLabel.text = @"添加银行卡支付";
            cell.detailTextLabel.text = @"只能添加一张银行卡进行充值、消费和提现";
            cell.imageView.image = [UIImage imageNamed:@"payment_bankCard.png"];
        }
        else
        {
            cell.textLabel.text = [NSString stringWithFormat:@"%@支付",[_countArray objectAtIndex:(indexPath.row)][@"name"]];
            NSString*desc = [_countArray objectAtIndex:(indexPath.row)][@"desc"];
            

            NSArray *descArray = [desc componentsSeparatedByString:@"|"];
            cell.textLabel.text = [NSString stringWithFormat:@"%@%@  %@",[_countArray objectAtIndex:(indexPath.row)][@"name"],descArray[0],descArray[1]];
            NSNumber *number = descArray[2];
            if ([number integerValue] > 0) {
                cell.detailTextLabel.text = [NSString stringWithFormat:@"本次可用额度  %@元",[self getForMatStringwithStr:descArray[2]]];
            }
            else
            {
                cell.detailTextLabel.text = @"";
            }
            
//            cell.detailTextLabel.text = [desc stringByReplacingOccurrencesOfString:@"|" withString:@"   "];
            NSString*str = [_countArray objectAtIndex:indexPath.row][@"payId"];
            cell.imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.png",[_countArray objectAtIndex:indexPath.row][@"payId"]]];
        }
    }
    return cell;
}

-(NSString*)getForMatStringwithStr:(NSString*)str
{
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.numberStyle = NSNumberFormatterDecimalStyle;
    double i = [str doubleValue];
    NSString *string = [formatter stringFromNumber:[NSNumber numberWithDouble:i]];
    return string;

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (selectIndexPath) {
        UITableViewCell *cell = [tableView cellForRowAtIndexPath:selectIndexPath];
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
#pragma mark - 判断代金券金额是否大于支付金额
    NSString*str1 = _totalOrderStrs;//总额
    NSString*str2 = _DefaultVouchDicts[@"balance"];//代金券
//    label5.text = [NSString stringWithFormat:@"%@元",[_DefaultVouchDicts[@"balance"] stringValue]];
    double db1 = [str1 doubleValue];
    double db2 = [str2 doubleValue];
    double db3 = db1 - db2;
    if (db3 <= 0) {
//        _complexMoney = @"0";
        cell.accessoryType = UITableViewCellAccessoryNone;
        [self certainBtnChangeColor:NO];
    }
else
{
    cell.accessoryType = UITableViewCellAccessoryCheckmark;
}
//
    
    
//    cell.accessoryType = UITableViewCellAccessoryCheckmark;
    selectIndexPath = indexPath;
#pragma mark - 有安全卡
    if ([payType isEqualToString:@"301"]) {
#pragma makr - 账户余额
        if (indexPath.row == 0) {
            //判断支付余额是否可用
            if ([isbalanceStr isEqualToString:@"0"]) {//判断余额是否可用
                [self certainBtnChangeColor:NO];
                NSLog(@"余额不足不能支付");
                cell.accessoryType = UITableViewCellAccessoryNone;
            }
            //余额可用
            else
            {
                NSLog(@"余额支付");
                [self certainBtnChangeColor:YES];
                NSString*str1 = _totalOrderStrs;//总额
                NSString*str2 = _DefaultVouchDicts[@"balance"];//代金券
//                label5.text = [NSString stringWithFormat:@"%@元",[_DefaultVouchDicts[@"balance"] stringValue]];
                double db1 = [str1 doubleValue];
                double db2 = [str2 doubleValue];
                double db3 = db1 - db2;
                if (db3 <= 0) {
                    //        _complexMoney = @"0";
//                    cell.accessoryType = UITableViewCellAccessoryNone;
                    [self certainBtnChangeColor:NO];
                }
                else
                {
//                    cell.accessoryType = UITableViewCellAccessoryCheckmark;
                }

                
                
            }
        }
#pragma mark - 安全卡支付(有安全卡时只传一张安全卡，不在显示其它快捷卡)
#warning 安全卡支付
        else if (indexPath.row == 1)
        {
            [self certainBtnChangeColor:YES];
            NSString*str1 = _totalOrderStrs;//总额
            NSString*str2 = _DefaultVouchDicts[@"balance"];//代金券
//            label5.text = [NSString stringWithFormat:@"%@元",[_DefaultVouchDicts[@"balance"] stringValue]];
            double db1 = [str1 doubleValue];
            double db2 = [str2 doubleValue];
            double db3 = db1 - db2;
            if (db3 <= 0) {
                //        _complexMoney = @"0";
//                cell.accessoryType = UITableViewCellAccessoryNone;
                [self certainBtnChangeColor:NO];
            }
            else
            {
//                cell.accessoryType = UITableViewCellAccessoryCheckmark;
            }
        }
#pragma mark - 其它快捷卡支付
        else
        {
        }
    }
#pragma makr - 没有安全卡
    else
    {
        //判断余额是否可用
        if (indexPath.row == 0) {
            if ([isbalanceStr isEqualToString:@"0"]) {//余额不足不能支付
                [self certainBtnChangeColor:NO];
                cell.accessoryType = UITableViewCellAccessoryNone;
            }
            //余额可用
            else
            {
#pragma mark - 选择余额支付后回调
                [self certainBtnChangeColor:YES];
                NSString*str1 = _totalOrderStrs;//总额
                NSString*str2 = _DefaultVouchDicts[@"balance"];//代金券
//                label5.text = [NSString stringWithFormat:@"%@元",[_DefaultVouchDicts[@"balance"] stringValue]];
                double db1 = [str1 doubleValue];
                double db2 = [str2 doubleValue];
                double db3 = db1 - db2;
                if (db3 <= 0) {
                    //        _complexMoney = @"0";
//                    cell.accessoryType = UITableViewCellAccessoryNone;
                    [self certainBtnChangeColor:NO];
                }
                else
                {
//                    cell.accessoryType = UITableViewCellAccessoryCheckmark;
                }

            }
        }
        //添加银行卡
        else if(indexPath.row == _countArray.count)
        {
            NSLog(@"添加银行卡");
            selectIndexPath = indexPath;
            footButton.backgroundColor = defaultColor;
            footButton.enabled = YES;
            
            NSString*str1 = _totalOrderStrs;//总额
            NSString*str2 = _DefaultVouchDicts[@"balance"];//代金券
//            label5.text = [NSString stringWithFormat:@"%@元",[_DefaultVouchDicts[@"balance"] stringValue]];
            double db1 = [str1 doubleValue];
            double db2 = [str2 doubleValue];
            double db3 = db1 - db2;
            if (db3 <= 0) {
                //        _complexMoney = @"0";
//                cell.accessoryType = UITableViewCellAccessoryNone;
                [self certainBtnChangeColor:NO];
            }
            else
            {
//                cell.accessoryType = UITableViewCellAccessoryCheckmark;
            }

            
            
        }
        else//其它快捷卡支付
        {
            [self certainBtnChangeColor:YES];
            NSString*str1 = _totalOrderStrs;//总额
            NSString*str2 = _DefaultVouchDicts[@"balance"];//代金券
//            label5.text = [NSString stringWithFormat:@"%@元",[_DefaultVouchDicts[@"balance"] stringValue]];
            double db1 = [str1 doubleValue];
            double db2 = [str2 doubleValue];
            double db3 = db1 - db2;
            if (db3 <= 0) {
                //        _complexMoney = @"0";
//                cell.accessoryType = UITableViewCellAccessoryNone;
                [self certainBtnChangeColor:NO];
            }
            else
            {
//                cell.accessoryType = UITableViewCellAccessoryCheckmark;
            }

        }
    }
    
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([payType isEqualToString:@"301"]) {
        return _countArray.count;
    }
    else
        return _countArray.count +1;
}
#pragma mark - 改变确认按钮颜色
-(void)certainBtnChangeColor:(BOOL)ststus
{
    if (ststus) {
        footButton.backgroundColor = defaultColor;
        footButton.enabled = YES;
    }
    else
    {
        footButton.backgroundColor = selectColor;
        footButton.enabled = NO;
    }
}
#pragma mark - 添加银行卡
-(void)addNewBankCard
{
    NSLog(@"添加银行卡");
    NSString*amount = @"";
    ValidatePaypsdViewController*ValidateView =[[ValidatePaypsdViewController alloc] init];
    NSMutableDictionary*dicts = [NSMutableDictionary dictionaryWithDictionary:_selectDict];
    if (!dicts.count) {
        dicts = self.DefaultVouchDict;
    }
    if (!dicts.count) {//没有代金券
        //        amount = self.totalOrderStr;
        amount = (NSString*)[NSString stringWithFormat:@"%@",self.totalOrderStr];
    }
    else
    {
        double amount1 = [self.totalOrderStr doubleValue];
        //2,取出代金券面值
        double balance1 = [dicts[@"balance"] doubleValue];
        double doub3 = amount1 - balance1;
        //3,计算银行卡或者余额所需要支付的金额
        NSNumber *number  = [NSNumber numberWithDouble:(amount1 - balance1)];
        amount = [number stringValue];
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        formatter.numberStyle = NSNumberFormatterDecimalStyle;
        NSString *string = [formatter stringFromNumber:[NSNumber numberWithDouble:doub3]];
        amount = string;
    }
    NSLog(@"amount = %@",amount);
    
    NSString*amounts = (NSString*)amount;
    
    NSDictionary*mydict = [[NSDictionary alloc] initWithObjectsAndKeys:amounts,@"amount",self.orderNo,@"orderNo",dicts[@"payId"],@"payId",dicts[@"payType"],@"type",dicts[@"name"],@"name",dicts[@"desc"],@"desc",dicts[@"cardId"],@"cardId",dicts[@"balance"],@"balance", nil];
    
    
    NSLog(@"dict = %@",mydict);
    ValidateView.buyProduct_DataDict = mydict;
    [self.navigationController pushViewController:ValidateView animated:YES];
}
#pragma mark - 选择快捷卡作为安全卡支付
-(void)changeSafeCardBankPay
{
    UIAlertView*alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"慧生钱只能绑定或添加一张常用银行卡作为账户安全卡进行充值、消费和提现。确认使用该卡？" delegate:self cancelButtonTitle:@"添加新卡" otherButtonTitles:@"使用当前卡",nil];
    [alertView show];
}
#pragma mark - 直接安全卡支付
-(void)safeCardBankPay
{
    NSLog(@"直接安全卡支付");
    NSDictionary*selectbankDict = [NSDictionary dictionary];
    selectbankDict = [_countArray objectAtIndex:1];// 得到安全卡后回传，也可以不传
    NSLog(@"_DefaultVouchDicts  = %@",_DefaultVouchDicts);
    NSDictionary*selectVouchersDict = [NSDictionary dictionaryWithDictionary:_DefaultVouchDicts];
    if (_callbackParms) {
        _callbackParms(selectbankDict,selectVouchersDict);////////在这儿也要把红包传回去
    }
    for (UIViewController*controlView in self.navigationController.viewControllers) {
        if ([controlView isKindOfClass:[BFBuyCommodityViewController class]]) {
            [self.navigationController popToViewController:controlView animated:YES];
        }
    }
}
#pragma mark - UIAlertViewDelegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
#pragma 添加银行卡
        NSLog(@"添加新卡");
        [self addNewBankCard];
    }
    else{
        NSLog(@"使用当前卡");
        NSLog(@"selectIndexPath = %ld",(long)selectIndexPath.row);
        NSDictionary*selectbankDict = [NSDictionary dictionary];
        selectbankDict = [_countArray objectAtIndex:(selectIndexPath.row)];
#pragma makr - 选择快捷卡后回调,
        NSLog(@"_DefaultVouchDicts  = %@",_DefaultVouchDicts);
        NSDictionary*selectVouchersDict = [NSDictionary dictionaryWithDictionary:_DefaultVouchDicts];
        if (_callbackParms) {
            _callbackParms(selectbankDict,selectVouchersDict);////////在这儿也要把红包传回去
        }
        for (UIViewController*controlView in self.navigationController.viewControllers) {
            if ([controlView isKindOfClass:[BFBuyCommodityViewController class]]) {
                [self.navigationController popToViewController:controlView animated:YES];
            }
        }
    }
    
}
@end

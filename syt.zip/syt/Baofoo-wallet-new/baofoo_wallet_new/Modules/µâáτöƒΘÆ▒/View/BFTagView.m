//
//  BFTagView.m
//  BaofooWallet
//
//  Created by 吴斌 on 16/4/27.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import "BFTagView.h"
#import "UILabel+SizeLabel.h"
#define tag_label_font FONT_LIGHT(AUTO_LENGTH(10.0f))
@implementation BFTagView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.tagLabelArr = [[NSMutableArray alloc] initWithCapacity:0];
       
    }
    return self;
}
- (void)layoutSubviews
{
    [super layoutSubviews];
    if ([self.tagLabelArr count]==0)
    {

        [self.tagArr enumerateObjectsUsingBlock:^(NSString *tagName, NSUInteger idx, BOOL *stop) {
            if (tagName.length>0) {
                [self creatLabelWithTagName:tagName];
            }
        }];
    }
}
- (void)setTagArr:(NSArray *)tagArr
{
    _tagArr = tagArr;
    [self setNeedsLayout];
}
- (void)setCorner:(UILabel *)label
{
    label.layer.borderWidth = 1;
    label.layer.cornerRadius = 4;
    label.layer.masksToBounds = YES;
    label.font = tag_label_font;
    label.textAlignment = NSTextAlignmentCenter;
}
- (void)setLabelType:(NSInteger)type label:(UILabel *)label
{
    UIColor *borderColor = nil;
    UIColor *textColor = nil;
    UIColor *backGroundColor = nil;
    switch (type) {
        case 1:
            borderColor = COLOR_HEXSTRING(@"#ffe8e4");
            textColor = COLOR_HEXSTRING(@"#ff6b50");
            backGroundColor = COLOR_HEXSTRING(@"#fff7f6");
            break;
        case 2:
            borderColor = COLOR_HEXSTRING(@"#e4f4fd");
            textColor = COLOR_HEXSTRING(@"#4eb8f4");
            backGroundColor = COLOR_HEXSTRING(@"#f6fbfe");
            break;
        case 3:
            borderColor = COLOR_HEXSTRING(@"#fef4df");
            textColor = COLOR_HEXSTRING(@"#fbb52a");
            backGroundColor = COLOR_HEXSTRING(@"#fffbf4");
            break;
        case 4:
            borderColor = COLOR_HEXSTRING(@"#ffe9df");
            textColor = COLOR_HEXSTRING(@"#ff722c");
            backGroundColor = COLOR_HEXSTRING(@"#fef7f3");
            break;
        case 5:
            borderColor = COLOR_HEXSTRING(@"#eff5e2");
            textColor = COLOR_HEXSTRING(@"#95be3e");
            backGroundColor = COLOR_HEXSTRING(@"#f9fbf5");
            break;
        default:
            break;
    }
    label.layer.borderColor = borderColor.CGColor;
    label.textColor = textColor;
    label.backgroundColor = backGroundColor;
}
- (UILabel *)creatLabelWithTagName:(NSString *)tagName
{
    CGFloat tagLabelHeight = AUTO_LENGTH(16);
    CGFloat labelWidth = [UILabel width:tagName heightOfFatherView:tagLabelHeight textFont:tag_label_font]+AUTO_LENGTH(2);
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, labelWidth, tagLabelHeight)];
    [self setCorner:label];
    NSArray *nameArr = [tagName componentsSeparatedByString:@":"];
    [self setLabelType:[nameArr[1] integerValue] label:label];
    label.text = nameArr[0];
    [self.tagLabelArr addObject:label];
    [self updateLabelFrame];
    return label;
}
static CGFloat __labelWidthWithIntervalX = 0;
static CGFloat __labelHeightWithIntervalY = 0;

//更新标签的坐标
- (void)updateLabelFrame
{
    for (int i=0; i<self.tagLabelArr.count; i++) {
        UILabel *label = self.tagLabelArr[i];
        
        label.frame = CGRectMake(__labelWidthWithIntervalX, 0, label.frame.size.width, label.frame.size.height);
        __labelWidthWithIntervalX = __labelWidthWithIntervalX+label.frame.size.width+AUTO_LENGTH(5);
        [self addSubview:label];
    }
    //设置完毕之后将间距初始化
    __labelWidthWithIntervalX = 0;
    __labelHeightWithIntervalY = 0;
}
- (void)cleanAllTags
{
    for (__block UILabel *label in self.tagLabelArr) {
        [label removeFromSuperview];
        __block UILabel *myLabel = label;
        myLabel = nil;
    }
    [self.tagLabelArr removeAllObjects];
}
@end

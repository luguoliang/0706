//
//  BFReloadView.m
//  BaofooWallet
//
//  Created by 吴斌 on 16/3/25.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import "BFReloadView.h"
#import "WBLinkTextView.h"
@interface BFReloadView()
{
    UIImageView *reloadImageView;
    WBLinkTextView *reloadLabel;
    UIButton *backgroundBtn;
}
@end
@implementation BFReloadView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = COLOR_HEXSTRING(@"#efeff4");
        
        reloadImageView = [[UIImageView alloc] init];
        [self addSubview:reloadImageView];
        
        reloadLabel = [[WBLinkTextView alloc] init];
        reloadLabel.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
        reloadLabel.font = BF_Font_(10);
        reloadLabel.textColor = COLOR_HEXSTRING(@"#797979");
        reloadLabel.textAlignment = NSTextAlignmentCenter;
        NSString * string = @"网络好像链接不上了，重新加载 ";
        reloadLabel.text = string;
        NSString  *stringToLink = @"重新加载";
        [reloadLabel linkString:stringToLink
                  defaultAttributes:[@{NSForegroundColorAttributeName:COLOR_HEXSTRING(BLUE_COLOR)}mutableCopy]
              highlightedAttributes:[@{NSForegroundColorAttributeName:COLOR_HEXSTRING(BLUE_COLOR)}mutableCopy]
                         tapHandler:[self exampleHandlerWithTitle:@"Link a single string"]];
        [self addSubview:reloadLabel];
        
        backgroundBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [backgroundBtn addTarget:self action:@selector(reloadAction) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:backgroundBtn];
    }
    return self;
}
- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat width = CGRectGetWidth(self.frame);
    CGFloat height = CGRectGetHeight(self.frame);
    
    CGFloat imageWidth = 82;
    CGFloat imageHeight = 76;
    reloadImageView.frame = CGRectMake((width-imageWidth)*0.5, height*0.5-imageHeight, imageWidth, imageHeight);
    reloadImageView.image = [UIImage imageNamed:@"dw_01.png"];
    
    reloadLabel.frame = CGRectMake(0, CGRectGetMaxY(reloadImageView.frame), width, 20);
    
    backgroundBtn.frame = self.bounds;
}
//关键字点击
- (LinkedStringTapHandler)exampleHandlerWithTitle:(NSString *)title
{
    LinkedStringTapHandler exampleHandler = ^(NSString *linkedString) {
        
        if ([linkedString isEqualToString:@"重新加载"]) {
            if ([self.delegate respondsToSelector:@selector(reloadTheView)]) {
                [self.delegate reloadTheView];
            }
        }
    };
    
    return exampleHandler;
}
- (void)reloadAction
{
    if ([self.delegate respondsToSelector:@selector(reloadTheView)]) {
        [self.delegate reloadTheView];
    }
}
@end

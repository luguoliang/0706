//
//  CheckoutCounteView.h
//  moneyTest
//
//  Created by 路国良 on 15/6/1.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>
//@class KeyBoardView;

@protocol myCheckoutCounteViewDelegate <NSObject>
@required
-(void)selectPaymentMethod;//选择代金券
-(void)removeCalled;//关闭收银台
-(void)sucessPayCallBack;//支付成功回调
-(void)forgetPasword;//忘记支付密码
@end

@interface CheckoutCounteView : UIView
@property(strong,nonatomic) void (^callback) (NSString *my);
#pragma mark - 没有安全卡
-(void)changePaymentMethodWithDefaultVouchDict:(NSDictionary*)DefaultVouchDict WithamountMoney:(NSString*)amountMoney;//选择支付方式，已有快捷卡和没有快捷卡时初始化出现
#pragma mark -  已有安全卡
-(void)bankCardPaymentWithDefaultVouchDict:(NSDictionary*)DefaultVouchDict WithsafeCardDict:(NSDictionary*)safeCardDict WithamountMoney:(NSString*)amountMoney;//银行卡支付，已有安全卡时初始化出现
#pragma mark - 账户余额支付
-(void)balancePaymentMethodWithDefaultVouchDict:(NSDictionary *)DefaultVouchDict WithamountMoney:(NSString *)amountMoney WithAccountBalanceDict:(NSDictionary*)AccountBalanceDict;//选择账户余额支付
-(void)getMessageCode;//获取短信验证码
@property(nonatomic,assign)id<myCheckoutCounteViewDelegate> delegate;
@property(nonatomic,copy)NSString*certanStatu;
@property(nonatomic,copy)NSDictionary*payListDictionary;
@end

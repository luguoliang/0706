//
//  VerifyPasswordView.h
//  aaa
//
//  Created by 路国良 on 15/8/18.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@class VerifyPasswordView;

@protocol VerifyPasswordViewDelegate <NSObject>

-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword didClickedClosedButton:(UIButton*)button;

-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword didClickedChangePayMentControlButton:(UIButton*)button;

-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword didClickedNextButtonButton:(UIButton*)button;

-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword VerifiedbyButton:(UIButton*)button;

-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword FailurebyButton:(UIButton*)button;

-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword HavePaymentCompletionButton:(UIButton*)button;

-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword ShowKeyboardButton:(UIButton*)button;

-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword HideKeyboardButton:(UIButton*)button;

-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword forgetPassword:(UIButton*)button;

@end

@interface VerifyPasswordView : UIView

@property(nonatomic,retain)id<VerifyPasswordViewDelegate>delegate;

-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword didClickedEnterButton:(UIButton*)button;

-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword didClickedDeleteButton:(UIButton*)button;

-(void)setDisPlayViewWith:(NSMutableDictionary*)dict;

- (instancetype)initWithFrame:(CGRect)frame WithDict:(NSMutableDictionary*)dict;

@end

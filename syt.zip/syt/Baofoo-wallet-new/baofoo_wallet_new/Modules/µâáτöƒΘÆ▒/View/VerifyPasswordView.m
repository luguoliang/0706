//
//  VerifyPasswordView.m
//  aaa
//
//  Created by 路国良 on 15/8/18.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "VerifyPasswordView.h"
#import "UIColor+Hexadecimal.h"
#import "FormatterString.h"
#import "BFKeyBoardView.h"
#import "CashRegisterLocationCache.h"
#import "CashRegisterNetRequest.h"
#import "CustomImageView.h"
#import "CountdownButton.h"
#import "MBProgressHUD.h"
#import "BFReqAPI+Checkout.h"

#define SCREE_W                           self.frame.size.width
#define SCREE_H                           self.frame.size.height
#define BUTTON_COLOR                      @"2e8fd3"
#define VIEW_COLOR                        @"efeff4"
#define SHOW_HEIGHT                       80.0f
#define TITLEHEIGHT                       45.0F
#define PASSWORDNUMBER                    6
#define paymentframeDisplay               CGRectMake(0, CGRectGetMaxY(moneyLabel.frame), SCREE_W, 50)
#define paymentframeHide                  CGRectMake(-SCREE_W, CGRectGetMaxY(moneyLabel.frame), SCREE_W, 50)
#define textfieldViewframeDisplay         CGRectMake(20, CGRectGetMaxY(buttonView.frame)+13, SCREE_W - 20*2,  ((SCREE_W - 20*2) - 5*0.5)/6)
#define textfieldViewframeHide            CGRectMake(-(SCREE_W - 20*2 - 20), CGRectGetMaxY(buttonView.frame)+13, SCREE_W - 20*2,  ((SCREE_W - 20*2) - 5*0.5)/6)
#define messageHaveSendframeDisplay       CGRectMake(10,CGRectGetMaxY(moneyLabel.frame)+13, SCREE_W - 20, 21)
#define messageHaveSendframeHide          CGRectMake(10+(SCREE_W - 20),CGRectGetMaxY(moneyLabel.frame)+13, SCREE_W - 20, 21)
#define messageCodeFieldframeDisplay      CGRectMake(20, CGRectGetMaxY(payMentMethodButton.frame)+13, SCREE_W - 20*2,  ((SCREE_W - 20*2) - 5*0.5)/6))
#define messageCodeFieldframeHide         CGRectMake(20+(SCREE_W - 20*2), CGRectGetMaxY(paymentMethodLabel.frame)+13, SCREE_W - 20*2,  ((SCREE_W - 20*2) - 5*0.5)/6)
#define titleLabel1frameDisplay           CGRectMake(CGRectGetMaxX(closedButton.frame), 0, SCREE_W - CGRectGetMaxX(closedButton.frame)*2, TITLEHEIGHT)
#define titleLabel1frameHide              CGRectMake(-((SCREE_W - CGRectGetMaxX(closedButton.frame)*2) - CGRectGetMaxX(closedButton.frame)), 0, (SCREE_W - CGRectGetMaxX(closedButton.frame)*2), TITLEHEIGHT)
#define titleLabel2frameDisplay           CGRectMake(CGRectGetMaxX(closedButton.frame), 0, SCREE_W - CGRectGetMaxX(closedButton.frame)*2, TITLEHEIGHT)
#define titleLabel2frameHide              CGRectMake(CGRectGetMaxX(closedButton.frame)+SCREE_W - CGRectGetMaxX(closedButton.frame)*2, 0, SCREE_W - CGRectGetMaxX(closedButton.frame)*2, TITLEHEIGHT)

#define forgetPsdButtonframeDisplay       CGRectMake(30, CGRectGetMaxY(messageCodeField.frame), SCREE_W - 30*2, 30)

#define forgetPsdButtonframeHide          CGRectMake(30+(SCREE_W - 30*2), CGRectGetMaxY(messageCodeField.frame), SCREE_W - 30*2, 30)

#define cantreceiveMessageframeDisplay    CGRectMake(30, CGRectGetMaxY(textfieldView.frame), SCREE_W - 30*2, 30)

#define cantreceiveMessageframeHide       CGRectMake(-((SCREE_W - 30*2) - 30), CGRectGetMaxY(textfieldView.frame), SCREE_W - 30*2, 30)

#define QuotalabelframeDisplay            CGRectMake(30, CGRectGetMaxY(textfieldView.frame),SCREE_W - 30*2, 30)

#define QuotalabelframeHide               CGRectMake(-(SCREE_W - 30*2), CGRectGetMaxY(textfieldView.frame), SCREE_W - 30*2, 30)

#define title1                            @"确认支付"

#define title2                            @"下一步"

#define LOADING                           @"正在支付..."

#define SUCESS                            @"支付成功"

@interface VerifyPasswordView()<UITextFieldDelegate>
{
    UIView*textfieldView;//输入框
    UILabel*moneyLabel;//金额
    UILabel*paymentMethodLabel;//选择支付方式
    UIButton *buttonView;
    UILabel*payMentMethodButtonLabel;//选择支付方式
    UIView*payMentMethodView;//选择支付方式
    UIButton*nextButton;
    BFKeyBoardView*_keyboard;
    UITextField*textField;
    NSMutableArray*passWordEnterMutableArray;
    NSMutableArray*roundArray;//输入符号
    BOOL KEYBOARDIS_SHOW;//
    UILabel*PaymentStatus;//支付状态
    CustomImageView*payStatusImageVeiw;//支付动画
    UILabel*messageHaveSend;//title
    UITextField*messageCodeField;
    CountdownButton* countButton;
    UILabel*titleLabel1;//输入支付密码
    UILabel*titleLabel2;//输入短信验证码
    UIButton*closedButton;
    UIButton*forgetPsdButton;
    UIButton*cantreceiveMessageButton;
    UILabel*Quotalabel;
}
@end
@implementation VerifyPasswordView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithFrame:(CGRect)frame WithDict:(NSMutableDictionary*)dict
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        closedButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:closedButton];
        [closedButton addTarget:self action:@selector(closed:) forControlEvents:UIControlEventTouchUpInside];
        closedButton.frame = CGRectMake(10, 0, TITLEHEIGHT, TITLEHEIGHT);
        [closedButton setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
        [closedButton setTitleEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
        [closedButton setImage:[UIImage imageNamed:@"closed.png"] forState:UIControlStateNormal];
        UIView*line1 = [[UIView alloc] initWithFrame:CGRectMake(0, TITLEHEIGHT, SCREE_W, 0.5f)];
        line1.backgroundColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0];
        [self addSubview:line1];
        titleLabel1  = [[UILabel alloc] initWithFrame:titleLabel1frameDisplay];
        [self addSubview:titleLabel1];
        titleLabel1.text = @"请输入支付密码";
        [self addSubview:titleLabel1];
        titleLabel1.textAlignment = NSTextAlignmentCenter;
        
        titleLabel2  = [[UILabel alloc] initWithFrame:titleLabel2frameHide];
        [self addSubview:titleLabel2];
        titleLabel2.text = @"请输入短信验证码";
        titleLabel2.textAlignment = NSTextAlignmentCenter;
        titleLabel2.alpha = 0.0f;
        
        UILabel *promptMoneyLabel = [[UILabel alloc] initWithFrame:CGRectMake(18.0f, CGRectGetMaxY(line1.frame), 70, 50)];
        promptMoneyLabel.textAlignment = NSTextAlignmentLeft;
        promptMoneyLabel.font = [UIFont systemFontOfSize:15];
        promptMoneyLabel.text = @"订单总额";
        [self addSubview:promptMoneyLabel];
       
        moneyLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(promptMoneyLabel.frame), CGRectGetMaxY(line1.frame), SCREE_W-18-CGRectGetMaxX(promptMoneyLabel.frame), 50)];
        moneyLabel.textAlignment = NSTextAlignmentRight;
        moneyLabel.font =[UIFont systemFontOfSize:30.0f];
        moneyLabel.textColor = [UIColor colorWithHexString:@"ff722c" alpha:1.0f];
        moneyLabel.adjustsFontSizeToFitWidth = YES;
        [self calculatePaymentAomunt:dict];///////////////
        [self addSubview:moneyLabel];
        
        UILabel *line2 = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(moneyLabel.frame)-0.5, SCREE_W, 0.5)];
        line2.backgroundColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0];
        [self addSubview:line2];
        
        buttonView = [UIButton buttonWithType:UIButtonTypeCustom];
        [buttonView addTarget:self action:@selector(changePayMentControl:) forControlEvents:UIControlEventTouchUpInside];
        buttonView.frame = CGRectMake(0, CGRectGetMaxY(moneyLabel.frame), SCREE_W, 50);
        [self addSubview:buttonView];
        

        UILabel *buttonPromptLabel = [[UILabel alloc] initWithFrame:CGRectMake(18.0f, 0, 100, 50)];
        buttonPromptLabel.textAlignment = NSTextAlignmentLeft;
        buttonPromptLabel.font = [UIFont systemFontOfSize:15];
        buttonPromptLabel.text = @"支付方式";
        buttonPromptLabel.textColor = [UIColor blackColor];
        [buttonView addSubview:buttonPromptLabel];
        
        UIImage *arrowImage = [UIImage imageNamed:@"right_arrow"];
        
        payMentMethodButtonLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(buttonPromptLabel.frame), 0, SCREE_W-CGRectGetMaxX(buttonPromptLabel.frame)-11-arrowImage.size.width-18, 50)];
        payMentMethodButtonLabel.textAlignment = NSTextAlignmentRight;
        payMentMethodButtonLabel.font = [UIFont systemFontOfSize:15];
        payMentMethodButtonLabel.textColor = [UIColor blackColor];
        payMentMethodButtonLabel.text = @"选择支付方式";
        [buttonView addSubview:payMentMethodButtonLabel];
        UIImageView *arrowImageView = [[UIImageView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(payMentMethodButtonLabel.frame)+11, (50-arrowImage.size.height)*0.5, arrowImage.size.width, arrowImage.size.height)];
        arrowImageView.image = arrowImage;
        [buttonView addSubview:arrowImageView];
        [self analysisMethodOfPaymentForm:dict];//////////////
        //选择支付方式
//        payMentMethodButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        payMentMethodButton.frame = CGRectMake(CGRectGetMaxX(buttonPromptLabel.frame), 0, labelWidth+100, 50);
//        [payMentMethodButton addTarget:self action:@selector(changePayMentControl:) forControlEvents:UIControlEventTouchUpInside];
//        [buttonView addSubview:payMentMethodButton];
//        [payMentMethodButton setImage:[UIImage imageNamed:@"right_arrow"] forState:UIControlStateNormal];
//        [self analysisMethodOfPaymentForm:dict];//////////////
//        payMentMethodButton.titleLabel.font = [UIFont systemFontOfSize:15.0f];
//        [payMentMethodButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//        [payMentMethodButton setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
//
//        [payMentMethodButton layoutIfNeeded];
//        UIImage*image = [UIImage imageNamed:@"right_arrow"];
//        [payMentMethodButton setTitleEdgeInsets:UIEdgeInsetsMake(0, -image.size.width, 0, image.size.width)];
//        [payMentMethodButton setImageEdgeInsets:UIEdgeInsetsMake(0, payMentMethodButton.titleLabel.bounds.size.width, 0, -payMentMethodButton.titleLabel.bounds.size.width)];
        
        UILabel *line3 = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(buttonView.frame)-0.5, SCREE_W, 0.5)];
        line3.backgroundColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0];
        [self addSubview:line3];
        
        //模拟输入框
        textfieldView = [[UIView alloc] init];
        textfieldView.frame = textfieldViewframeDisplay;
        textfieldView.backgroundColor = [UIColor colorWithHexString:@"f8f8f8" alpha:1.0f];
        textfieldView.layer.cornerRadius = 5.0f;
        textfieldView.layer.borderColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0f].CGColor;
        textfieldView.layer.borderWidth = 0.5f;
        textfieldView.clipsToBounds = YES;
        [self addSubview:textfieldView];
        CGFloat W = ((SCREE_W - 20*2) - 5*0.5)/PASSWORDNUMBER;
        for (int i = 1; i< PASSWORDNUMBER; i ++) {
            UIView*line = [[UIView alloc] initWithFrame:CGRectMake((W*i + 0.5*(i - 1)),0,0.5,W)];
            [textfieldView addSubview:line];
            line.backgroundColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0f];
        }
        roundArray = [NSMutableArray array];
        for (int i = 0;i<PASSWORDNUMBER; i++) {
            UIImageView*im = [[UIImageView alloc] initWithFrame:CGRectMake(((W - 10)/2)+W*i+0.5*i, (W - 10)/2, 10, 10)];
            im.backgroundColor = [UIColor clearColor];
            im.layer.masksToBounds = YES;
            im.layer.cornerRadius = 5.0f;
            [roundArray addObject:im];
            //        [textfieldView addSubview:im];
        }
        for (UIImageView*im in roundArray) {
            [textfieldView addSubview:im];
        }
        
        
        nextButton = [UIButton buttonWithType:UIButtonTypeSystem];
        nextButton.frame = CGRectMake((SCREE_W - 293)/2, CGRectGetMaxY(textfieldView.frame)+28.5, 293, 40);
        [self addSubview:nextButton];
        nextButton.backgroundColor = [UIColor colorWithHexString:BUTTON_COLOR alpha:1.0f];
        nextButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [nextButton setTintColor:[UIColor whiteColor]];
        nextButton.layer.masksToBounds = YES;
        nextButton.layer.cornerRadius = 20.0f;
//        [nextButton setTitle:@"下一步" forState:UIControlStateNormal];
        //    nextButton.titleLabel.alpha = 0.5f;
        //    [nextButton setUserInteractionEnabled:NO];
        [self setnextButtonTitleWith:dict];
        [nextButton addTarget:self action:@selector(nextButton:) forControlEvents:UIControlEventTouchUpInside];
        
        payStatusImageVeiw = [[CustomImageView alloc] initWithFrame:CGRectMake((SCREE_W - 80)/2, CGRectGetMaxY(nextButton.frame)+40, 80, 80)];
//        [self addSubview:payStatusImageVeiw];
        
        PaymentStatus = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(payStatusImageVeiw.frame)+12, SCREE_W - 20, 14)];
        PaymentStatus.textColor = [UIColor colorWithHexString:@"0099ff" alpha:1.0f];
        PaymentStatus.font = [UIFont systemFontOfSize:15.0f];
        PaymentStatus.textAlignment = NSTextAlignmentCenter;
        [self addSubview:PaymentStatus];
        
        //短信验证码验证
        
        //短信验证码已发送至＊＊＊手机号
        messageHaveSend = [[UILabel alloc] init];
        messageHaveSend.frame = messageHaveSendframeHide;
        messageHaveSend.textAlignment = NSTextAlignmentCenter;
        messageHaveSend.font = [UIFont systemFontOfSize:15.0f];
        messageHaveSend.alpha = 0.0f;
        [self addSubview:messageHaveSend];
        messageCodeField = [[UITextField alloc] init];
        messageCodeField.frame = messageCodeFieldframeHide;
        messageCodeField.placeholder = @"短信验证码";
        messageCodeField.font = [UIFont systemFontOfSize:15.0f];
        messageCodeField.backgroundColor = [UIColor colorWithHexString:@"f8f8f8" alpha:1.0f];
        [self addSubview:messageCodeField];
        messageCodeField.delegate = self;
        messageCodeField.textAlignment = NSTextAlignmentCenter;
        [messageCodeField setUserInteractionEnabled:NO];
        messageCodeField.layer.cornerRadius = 5.0f;
        messageCodeField.layer.borderColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0f].CGColor;
        messageCodeField.layer.borderWidth = 0.5f;
        messageCodeField.clipsToBounds = YES;
        messageCodeField.alpha = 0.0f;
        countButton = [CountdownButton buttonWithType:UIButtonTypeCustom];
        countButton.frame = CGRectMake(0, 0, 100, ((SCREE_W - 20*2) - 5*0.5)/6);
        [countButton setTitleColor:[UIColor colorWithHexString:BUTTON_COLOR alpha:1.0f] forState:UIControlStateNormal];
        //
        [countButton setTitle:@"获取" forState:UIControlStateNormal];
        countButton.titleLabel.font =[UIFont systemFontOfSize:15.0f];
        [countButton addTarget:self action:@selector(countbutton:) forControlEvents:UIControlEventTouchUpInside];
        messageCodeField.rightView = countButton;
        UIView*right = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 100, ((SCREE_W - 20*2) - 5*0.5)/6)];
        messageCodeField.leftView = right;
        messageCodeField.leftViewMode = UITextFieldViewModeAlways;
        messageCodeField.rightViewMode = UITextFieldViewModeAlways;

        forgetPsdButton = [UIButton buttonWithType:UIButtonTypeSystem];
        forgetPsdButton.frame = forgetPsdButtonframeHide;
        [forgetPsdButton setTitle:@"收不到短信验证码" forState:UIControlStateNormal];
        forgetPsdButton.titleLabel.font = [UIFont systemFontOfSize:12.0f];
        [forgetPsdButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        forgetPsdButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        forgetPsdButton.alpha = 0.0f;
        [forgetPsdButton addTarget:self action:@selector(forgetPsdButton:) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:forgetPsdButton];
        
        Quotalabel = [[UILabel alloc] initWithFrame:QuotalabelframeDisplay];
        Quotalabel.hidden= YES;
        NSDictionary*DC = [[CashRegisterLocationCache sharedManager] geCashRegisterCachetDict];
        NSDictionary*safecard =        DC[@"payment"][@"safecard"];
        
        NSDictionary*defaultbankcard = DC[@"payment"][@"defaultbankcard"];

        if (safecard.count) {
            
            if ([[safecard[@"isDefault"] stringValue] isEqualToString:@"1"]) {
                
                Quotalabel.hidden = NO;
                
                NSArray*array = [safecard[@"desc"] componentsSeparatedByString:@"|"];
             
//                Quotalabel.attributedText= [self arrributeStringWithString:[NSString stringWithFormat:@"单笔限额%@元",[[FormatterString sharedManager] formatterStringWithString:array[2]]]];
                Quotalabel.attributedText= [self arrributeStringWithString:[NSString stringWithFormat:@"单笔限额%@元",[self test:array[2]]]];
            }
        }
        
        if (defaultbankcard.count) {
            
            NSArray*array = [defaultbankcard[@"desc"] componentsSeparatedByString:@"|"];
            
            Quotalabel.hidden = NO;
   //            Quotalabel.attributedText= [self arrributeStringWithString:[NSString stringWithFormat:@"单笔限额%@元",[[FormatterString sharedManager] formatterStringWithString:array[2]]]];
            Quotalabel.attributedText= [self arrributeStringWithString:[NSString stringWithFormat:@"单笔限额%@元",[self test:array[2]]]];
            
        }
        
        Quotalabel.textAlignment = NSTextAlignmentLeft;
        
        Quotalabel.font = [UIFont systemFontOfSize:12.0f];

        [self addSubview:Quotalabel];
        
        cantreceiveMessageButton = [UIButton buttonWithType:UIButtonTypeSystem];
        cantreceiveMessageButton.frame = cantreceiveMessageframeDisplay;
        [cantreceiveMessageButton setTitle:@"忘记密码?" forState:UIControlStateNormal];
        [cantreceiveMessageButton addTarget:self action:@selector(forgetPassword) forControlEvents:UIControlEventTouchUpInside];
        cantreceiveMessageButton.titleLabel.font = [UIFont systemFontOfSize:12.0f];
        [cantreceiveMessageButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        cantreceiveMessageButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        [self addSubview:cantreceiveMessageButton];

        
        passWordEnterMutableArray = [NSMutableArray array];
    }
    return self;
}

-(NSMutableAttributedString*)arrributeStringWithString:(NSString*)string
{
    NSMutableAttributedString*attributeStr = [[NSMutableAttributedString alloc] initWithString:string];
    [attributeStr addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"ff722c" alpha:1.0f] range:NSMakeRange(4, string.length - 5)];
    return attributeStr;
}

-(void)forgetPsdButton:(UIButton*)button
{
    NSString*str = @"1、请确认当前手机号是否为银行预留手机号\n2、请检查短信是否被手机安全软件拦截\n3、若预留手机号已停用，请联系银行客服\n4、需要获取更多帮助，请拨打客服热线：021-68811008";
    
    UIAlertView*alert = [[UIAlertView alloc] initWithTitle:@"收不到短信验证码" message:str delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    
    [alert show];
    

}

-(void)setDisPlayViewWith:(NSMutableDictionary*)dict
{
    [self calculatePaymentAomunt:dict];
    [self analysisMethodOfPaymentForm:dict];
    [self setnextButtonTitleWith:dict];
}
-(void)calculatePaymentAomunt:(NSMutableDictionary*)dict

{
    NSString*balnce = dict[@"amount"];
    
    NSString*wallet = dict[@"payment"][@"dfredwallet"][@"balance"];
    
    if (wallet) {
        
        NSLog(@"可以使用代金券");
        
        double d = [balnce doubleValue] - [wallet doubleValue];
        
        if (d<=0) {

            moneyLabel.text = [NSString stringWithFormat:@"%@ 元红包",[self test:wallet]];
        }
        else
        {
            balnce = [NSString stringWithFormat:@"%f",d];

            moneyLabel.text = [NSString stringWithFormat:@"%@ + %@ 元红包",[self test:balnce],wallet];
        }
    }
    else{
        
        moneyLabel.text = [NSString stringWithFormat:@"%@ 元",[self test:balnce]];
    }
    
  
}

-(NSString*)test:(NSString*)str
{
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    
    formatter.numberStyle = kCFNumberFormatterDecimalStyle;
    
    NSString *string = [formatter stringFromNumber:[NSNumber numberWithDouble:[str doubleValue]]];
    
    return string;
}

-(BOOL)AnalyzingRedEnvelopeisGreaterThanTotalPurchaseWith:(NSMutableDictionary*)dict//判断红包金额是否大于支付金额
{
    NSString*balnce = dict[@"amount"];
    
    NSString*wallet = dict[@"payment"][@"dfredwallet"][@"balance"];
    
    if (wallet) {
        
    double d = [balnce doubleValue] - [wallet doubleValue];
    
    if (d<=0) {
        
        return YES;
    }
    else
    {
        return NO;
    }
        
        
    }
    else
    {
        return NO;
    }
}

-(void)analysisMethodOfPaymentForm:(NSMutableDictionary*)dict
{
    
     Quotalabel.hidden = YES;
    
    NSDictionary*safecard =        dict[@"payment"][@"safecard"];
    
    NSDictionary*defaultbankcard = dict[@"payment"][@"defaultbankcard"];
    
    NSDictionary*dfbalance =       dict[@"payment"][@"dfbalance"];
    
    
    NSString*paymentStr = [NSString string];
    
    if (safecard.count) {
        
     
        
        NSArray*array = [safecard[@"desc"] componentsSeparatedByString:@"|"];
        
        paymentStr = [NSString stringWithFormat:@"%@(%@)",safecard[@"name"],array[0]];
        
        
        if ([[safecard[@"isDefault"] stringValue] isEqualToString:@"1"]) {
            
            Quotalabel.hidden = NO;
            
            NSArray*array = [safecard[@"desc"] componentsSeparatedByString:@"|"];
            
            Quotalabel.attributedText= [self arrributeStringWithString:[NSString stringWithFormat:@"单笔限额%@元",[self test:array[2]]]];
        }

//        Quotalabel.attributedText= [self arrributeStringWithString:[NSString stringWithFormat:@"单笔限额%@元",[[FormatterString sharedManager] formatterStringWithString:array[2]]]];
    }
    
    if (defaultbankcard.count) {
        
        NSArray*array = [defaultbankcard[@"desc"] componentsSeparatedByString:@"|"];
        Quotalabel.hidden = NO;
        
//        Quotalabel.attributedText= [self arrributeStringWithString:[NSString stringWithFormat:@"单笔限额%@元",[[FormatterString sharedManager] formatterStringWithString:array[2]]]];
        Quotalabel.attributedText= [self arrributeStringWithString:[NSString stringWithFormat:@"单笔限额%@元",[self test:array[2]]]];
        
        if (paymentStr.length) {
            
//            paymentStr = [NSString stringWithFormat:@"%@+%@(%@)",paymentStr,defaultbankcard[@"name"],array[1]];
        }
        else
        {
            paymentStr = [NSString stringWithFormat:@"%@(%@)",defaultbankcard[@"name"],array[0]];
        }
    }
    if (dfbalance.count) {
        
        if (paymentStr.length) {
            
            paymentStr = [NSString stringWithFormat:@"%@+余额",paymentStr];
        }
        
        else{
            
            paymentStr = @"账户余额";
        }
    }
    
    if ([self AnalyzingRedEnvelopeisGreaterThanTotalPurchaseWith:dict ]) {
        
        paymentStr = @"红包";
    }
    paymentStr = [NSString stringWithFormat:@"%@ ",paymentStr];
    
    if (([paymentStr isEqualToString:@" "])) {
        
        paymentStr = @"选择支付方式";
    }
    
    paymentStr = [NSString stringWithFormat:@"%@   ",paymentStr];
    
    payMentMethodButtonLabel.text = paymentStr;
//    [payMentMethodButton setTitle:paymentStr forState:UIControlStateNormal];
    
}
-(void)setnextButtonTitleWith:(NSMutableDictionary*)dict
{
    NSDictionary*safecard =        dict[@"payment"][@"safecard"];
    NSDictionary*defaultbankcard = dict[@"payment"][@"defaultbankcard"];
    if (safecard) {
        
        if ([[safecard[@"isDefault"] stringValue] isEqualToString:@"1"]) {
            
            [self SettingsButtonArrowWithString:title2];
        }
        else{
            
            if ([[defaultbankcard[@"isDefault"] stringValue] isEqualToString:@"1"]) {//[[safecard[@"isDefault"] stringValue] isEqualToString:@"1"]//defaultbankcard
                NSLog(@"银行卡支付");
                [self SettingsButtonArrowWithString:title2];
            }
            else{
                
                [self SettingsButtonArrowWithString:title1];
            }

            
            
            
            
            
            
            
            
//        [self SettingsButtonArrowWithString:title1];
        }
    }
 
    else
    {
        if (defaultbankcard) {
            NSLog(@"银行卡支付");
            [self SettingsButtonArrowWithString:title2];
        }
        else{
        
        [self SettingsButtonArrowWithString:title1];
        }
    }

}

-(void)SettingsButtonArrowWithString:(NSString*)str
{
//    [payMentMethodButton layoutIfNeeded];
    [nextButton setTitle:str forState:UIControlStateNormal];
//    UIImage*image = [UIImage imageNamed:@"change.png"];
//    [payMentMethodButton setTitleEdgeInsets:UIEdgeInsetsMake(0, -image.size.width, 0, image.size.width)];
//    [payMentMethodButton setImageEdgeInsets:UIEdgeInsetsMake(0, payMentMethodButton.titleLabel.bounds.size.width, 0, -payMentMethodButton.titleLabel.bounds.size.width)];
}

//短信验证码
-(void)countbutton:(CountdownButton*)button
{
    NSMutableDictionary*dict = [[CashRegisterLocationCache sharedManager] geCashRegisterCachetDict];
    //以下代码拼接请求参数
    NSString*bankAccount;
    NSString*amount;
    NSString*cardId;
    NSString*mobile;
    NSString*orderNo;
    NSString*businessType ;
    NSString*payId ;
    NSString*name ;
    NSString*type;
    NSString*desc;
    
    if ([self subStringWith:dict[@"payment"][@"defaultbankcard"][@"desc"]]) {
        
        bankAccount =     [self subStringWith:dict[@"payment"][@"defaultbankcard"][@"desc"]];
        amount =          dict[@"amount"];
        cardId =          dict[@"payment"][@"defaultbankcard"][@"cardId"];
        mobile =          dict[@"payment"][@"defaultbankcard"][@"preMobile"];
        orderNo =         dict[@"orderNo"];
        businessType =    dict[@"businessType"];
        payId =           dict[@"payment"][@"defaultbankcard"][@"payId"];
        name =            dict[@"payment"][@"defaultbankcard"][@"name"];
        type =            dict[@"payment"][@"defaultbankcard"][@"payType"];
        desc =            dict[@"payment"][@"defaultbankcard"][@"desc"];
    }
    else
    {
        bankAccount =     [self subStringWith:dict[@"payment"][@"safecard"][@"desc"]];
        amount =          dict[@"amount"];
        cardId =          dict[@"payment"][@"safecard"][@"cardId"];
        mobile =          dict[@"payment"][@"safecard"][@"preMobile"];
        orderNo =         dict[@"orderNo"];
        businessType =    dict[@"businessType"];
        payId =           dict[@"payment"][@"safecard"][@"payId"];
        name =            dict[@"payment"][@"safecard"][@"name"];
        type =            dict[@"payment"][@"safecard"][@"payType"];
        desc =            dict[@"payment"][@"safecard"][@"desc"];
    }
    amount = [self ComputingNetPaymentAmount:dict];
    NSDictionary *userIndo1 = [[NSDictionary alloc] initWithObjectsAndKeys:bankAccount,@"bankAccount",cardId,@"cardId",amount,@"amount",mobile,@"mobile",orderNo,@"orderNo",businessType,@"businessType",payId,@"payId",name,@"name",type,@"type",desc,@"desc",nil];
    //以上代码拼接请求参数
    
    [BFReqAPI CashRegisterVerGetMessageCodeFormServerWithParameters:userIndo1 block:^(id responseObj, NSError *error) {
        [button countDownBegins];
         NSString*tradeNo =    responseObj[@"obj"][@"tradeNo"];
         NSString*businessNo = responseObj[@"obj"][@"businessNo"];
        [dict setValue:tradeNo forKey:@"tradeNo"];
        [dict setValue:businessNo forKey:@"businessNo"];
        [[CashRegisterLocationCache sharedManager] saveCashRegisterCacheDict:dict];
    }];
    
//    
//    [[CashRegisterNetRequest sharedManager] CashRegisterVerGetMessageCodeWith:temdict Sucessful:^(NSDictionary *d) {
//        
//        [MBProgressHUD hideHUDForView:self animated:YES];
//        
//        [button countDownBegins];
//        
//        NSString*tradeNo =    d[@"obj"][@"tradeNo"];
//        
//        NSString*businessNo = d[@"obj"][@"businessNo"];
//    
//        [temdict setValue:tradeNo forKey:@"tradeNo"];
//        
//        [temdict setValue:businessNo forKey:@"businessNo"];
//        
//        [[CashRegisterLocationCache sharedManager] saveCashRegisterCacheDict:temdict];
//
//    } failure:^(NSString *s) {
//        
//        NSLog(@"s = %@",s);
//        
//        [MBProgressHUD hideHUDForView:self animated:YES];
//    }];
}

// subStringWith  ComputingNetPaymentAmount  //数据处理函数
-(NSString*)subStringWith:(NSString*)str
{
    NSArray*array = [str componentsSeparatedByString:@"|"];
    
    return array[0];
}

-(NSString*)ComputingNetPaymentAmount:(NSDictionary*)dict
{
    NSString*str;
    if (dict[@"payment"][@"dfredwallet"]) {
        NSNumber*dered = dict[@"payment"][@"dfredwallet"][@"balance"];
        NSNumber*amount = dict[@"amount"];
        NSNumber*an =   [NSNumber numberWithInt:([amount integerValue] - [dered integerValue])];
        str = [an stringValue];
    }
     else
    {
        str = dict[@"amount"];
    }
    return str;
}

-(void)lockAnimationForView:(UIView*)view
{
    CALayer *lbl = [view layer];
    CGPoint posLbl = [lbl position];
    CGPoint y = CGPointMake(posLbl.x-10, posLbl.y);
    CGPoint x = CGPointMake(posLbl.x+10, posLbl.y);
    CABasicAnimation * animation = [CABasicAnimation animationWithKeyPath:@"position"];
    [animation setTimingFunction:[CAMediaTimingFunction
                                  functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    [animation setFromValue:[NSValue valueWithCGPoint:x]];
    [animation setToValue:[NSValue valueWithCGPoint:y]];
    [animation setAutoreverses:YES];
    [animation setDuration:0.08];
    [animation setRepeatCount:3];
    [lbl addAnimation:animation forKey:nil];
}

-(void)nextButton:(UIButton*)button
{
    if (!([self ifSharkTheView])) {
        
        [self nextAction];
    }
 }

-(BOOL)ifSharkTheView
{
    BOOL isShark = NO;
    
    if ([self ToDetermineWhetherAbankCard]) {//banks pay
        
        if (([nextButton.titleLabel.text isEqualToString:title2])) {// nextButton
            
            if ((passWordEnterMutableArray.count != 6)) {
                
                [self lockAnimationForView:textfieldView];
                
                return YES;
            }
            
             else if ([payMentMethodButtonLabel.text rangeOfString:@"选择支付方式"].location != NSNotFound)
            
            {
                [self lockAnimationForView:payMentMethodButtonLabel];
                
                return YES;
            }
        }
        
        else
        {
            if (!(messageCodeField.text.length)) {
                [self lockAnimationForView:messageCodeField];
                return YES;
            }
        }
    }
    else
    {
        
        if ((passWordEnterMutableArray.count != 6)) {
            
            [self lockAnimationForView:textfieldView];
            
            return YES;
        }
        
        else if ([payMentMethodButtonLabel.text rangeOfString:@"选择支付方式"].location != NSNotFound)
        {
            [self lockAnimationForView:payMentMethodButtonLabel];
            
            return YES;
        }
    }

    return isShark;
}

-(void)nextAction

{
    [_delegate verifyPassword:self HideKeyboardButton:nil];
    
    if (([nextButton.titleLabel.text isEqualToString:title1])) {//Confirm Payment
        
        [self confirmPayment:nil];
    }
    else
    {
        [self verifyPayment];//Next
    }

}
//账户余额支付时验证支付密码,

-(void)verifyPayment
{
    
    NSMutableString*payPassword = [NSMutableString string];
    
    for (NSString*str in passWordEnterMutableArray) {
        
        [payPassword appendString:str];
    }
    
    NSLog(@"payPassword = %@",payPassword);
    
    NSDictionary*dict = @{@"payPassword":payPassword};
    
    [BFReqAPI CashRegisterConfirmPaymentToServerWithParameters:dict block:^(id responseObj, NSError *error) {
        if (error) {
//            UIAlertView*alert = [[UIAlertView alloc] initWithTitle:nil message:error delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
//            
//            [alert show];
            [self setallclear];
            [passWordEnterMutableArray removeAllObjects];
            [_delegate verifyPassword:self ShowKeyboardButton:nil];

        }
        
        else{
            [self paymentPasswordAuthenticationThrough];
        }
    }];
    
    
    
//    [MBProgressHUD showHUDAddedTo:self animated:YES];
//    
//    [[CashRegisterNetRequest sharedManager] CashRegisterVerPasswordWith:dict Sucessful:^(NSDictionary *d) {
//        
//    [MBProgressHUD hideHUDForView:self animated:YES];
//                                                                                                                                                     
//        NSLog(@"d = %@",d);
//        
//        NSLog(@"支付密码验证通过");
//        
//        [MBProgressHUD hideHUDForView:self animated:YES];
//        
//        [self paymentPasswordAuthenticationThrough];
//        
//    } failure:^(NSString *s) {
//        
//        [passWordEnterMutableArray removeAllObjects];
//        
//        [self setallclear];
//        
//        [MBProgressHUD hideHUDForView:self animated:YES];
//        
//        UIAlertView*alert = [[UIAlertView alloc] initWithTitle:nil message:s delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
//        
//        [alert show];
//        
//        [_delegate verifyPassword:self ShowKeyboardButton:nil];
//        
//    }];
    
}

//确认支付
-(void)confirmPayment:(NSDictionary*)dict
{
    
    
    if ((messageCodeField.text.length)) {
        
        [messageCodeField resignFirstResponder];
    }
     [self arepPaying];
    
    NSMutableDictionary*temDict = [[CashRegisterLocationCache sharedManager] geCashRegisterCachetDict];
    
    NSMutableString*payPasswords = [NSMutableString string];
    
    for (NSString*str in passWordEnterMutableArray) {
        
        [payPasswords appendString:str];
    }
    
    NSLog(@"payPassword = %@",payPasswords);
    
    [temDict setObject:payPasswords forKey:@"payPassword"];
    
    
    if (messageCodeField.text.length) {
        
        [temDict setObject:messageCodeField.text forKey:@"verCode"];
    }
    
    NSDictionary*safecard = temDict[@"payment"][@"safecard"];
      if (safecard) {
        
        if (!([[safecard[@"isDefault"] stringValue] isEqualToString:@"1"])) {
        
            NSMutableDictionary*payment  = [NSMutableDictionary dictionaryWithDictionary:temDict[@"payment"]];
            
            [payment removeObjectForKey:@"safecard"];
            
            [temDict setObject:payment forKey:@"payment"];
        }
    }
    
    //以下是拼接网络参数
    //
    NSString*orderNo =                   dict[@"orderNo"];//交易号
    NSString*businessType =              dict[@"businessType"];//业务类型
    NSString*tradeNo =                   dict[@"tradeNo"];//充值交易号，验证短信验证码时获得
    NSString*businessNo =                dict[@"businessNo"];//充值业务号,短信验证获得
    NSString*verCode  =                  dict[@"verCode"];//短信验证码
    NSString*payPassword =               [self md5:dict[@"payPassword"]];
    
    NSMutableArray*confirmPayList = [NSMutableArray array];
    
    if ([[dict objectForKey:@"payment"] objectForKey:@"dfbalance"]) {
        
        NSString*balance = [self ComputingNetPaymentAmount:dict];
        NSDictionary*temDict = [self combinedConfirmPayListDataWith:dict[@"payment"][@"dfbalance"] Withamount:balance];
        
        
        [confirmPayList addObject:temDict];
    }
    if ([[dict objectForKey:@"payment"] objectForKey:@"dfredwallet"]) {
        
        NSDictionary*temDict = [self combinedConfirmPayListDataWith:dict[@"payment"][@"dfredwallet"] Withamount:dict[@"payment"][@"dfredwallet"][@"balance"]];
        
        [confirmPayList addObject:temDict];
    }
    
#warning 这种逻辑下，默认卡和安全卡不会同时出现
    
    
    if ([[dict objectForKey:@"payment"] objectForKey:@"safecard"]) {
        
        NSString*balance = [self ComputingNetPaymentAmount:dict];
        NSDictionary*temDict = [self combinedConfirmPayListDataWith:dict[@"payment"][@"safecard"] Withamount:balance];
        
        [confirmPayList addObject:temDict];
    }
    
    else{
        
        if ([[dict objectForKey:@"payment"] objectForKey:@"defaultbankcard"]) {
            
            NSString*balance = [self ComputingNetPaymentAmount:dict];
            NSDictionary*temDict = [self combinedConfirmPayListDataWith:dict[@"payment"][@"defaultbankcard"] Withamount:balance];
            
            [confirmPayList addObject:temDict];
        }
        
    }
    
    //    if ([[dict objectForKey:@"payment"] objectForKey:@"safecard"]) {
    //
    //        NSDictionary*temDict = [self combinedConfirmPayListDataWith:dict[@"payment"][@"safecard"] Withamount:dict[@"amount"]];
    //
    //        [confirmPayList addObject:temDict];
    //    }
    
    NSLog(@"confirmPayList = %@",confirmPayList);
    
    NSDictionary*jsonDict1 = [NSDictionary dictionaryWithObjectsAndKeys:confirmPayList,@"confirmPayList",orderNo,@"orderNo",payPassword,@"payPassword",businessType,@"businessType",tradeNo,@"tradeNo",businessNo,@"businessNo",verCode,@"verCode",nil];
    
 //   以上是拼接请求参数
    //
    
    [BFReqAPI CashRegisterConfirmPaymentWithPostOrgetData:jsonDict1 block:^(id responseObj, NSError *error) {
        if (error) {
            [self failurePayStateWithStr:error];
            
            if ([self ToDetermineWhetherAbankCard]) {
                
                if (([nextButton.titleLabel.text isEqualToString:title2])) {//
                    
                    [self clearInputView];
                    
                    [_delegate verifyPassword:self ShowKeyboardButton:nil];
                }
                else
                {
                    messageCodeField.text = nil;
                    
                    [messageCodeField becomeFirstResponder];
                }
            }
            else
            {
                [self clearInputView];
                [_delegate verifyPassword:self ShowKeyboardButton:nil];
            }

        }
        else{
            [self paymentStatusSucess];
        }
    }];
    
    
    
    
    
//    
//    [MBProgressHUD showHUDAddedTo:self animated:YES];
//    [[CashRegisterNetRequest sharedManager] CashRegisterConfirmPaymentWithPostOrgetData:temDict Sucessful:^(NSDictionary *d) {
//        [MBProgressHUD hideHUDForView :self animated:YES];
//    [self paymentStatusSucess];
//
//      
//    } failure:^(NSString *s) {
//     [MBProgressHUD hideHUDForView :self animated:YES];
//        [self failurePayStateWithStr:s];
//        
//        if ([self ToDetermineWhetherAbankCard]) {
//            
//            if (([nextButton.titleLabel.text isEqualToString:title2])) {//
//                
//                [self clearInputView];
//                
//                [_delegate verifyPassword:self ShowKeyboardButton:nil];
//            }
//            else
//            {
//                messageCodeField.text = nil;
//
//                [messageCodeField becomeFirstResponder];
//            }
//        }
//        else
//        {
//            [self clearInputView];
//            [_delegate verifyPassword:self ShowKeyboardButton:nil];
//        }
//   
//    }];
}


-(NSDictionary*)combinedConfirmPayListDataWith:(NSDictionary*)dict Withamount:(NSString*)amount
{
    NSDictionary*temDict = [NSDictionary dictionary];
    temDict =  @{@"cardId":  dict[@"cardId"],
                 @"payId":   dict[@"payId"],
                 @"type":    dict[@"payType"],
                 @"name":    dict[@"name"],
                 @"amount":  amount,
                 @"desc":    dict[@"desc"]};
    return temDict;
}
-(NSString*)md5:(NSString *)str
{
    const char *cStr = [str UTF8String];
    unsigned char result[16];
    CC_MD5(cStr, strlen(cStr), result);
    NSString *s1tr = [NSString stringWithFormat:
                      @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                      result[0], result[1], result[2], result[3],
                      result[4], result[5], result[6], result[7],
                      result[8], result[9], result[10], result[11],
                      result[12], result[13], result[14], result[15]
                      ];
    return s1tr;
}


-(void)clearInputView

{
    [passWordEnterMutableArray removeAllObjects];
    
    [self setallclear];
}
-(BOOL)ToDetermineWhetherAbankCard
{
    BOOL ishave = NO;
    NSDictionary*dc = [[CashRegisterLocationCache sharedManager] geCashRegisterCachetDict];
    NSDictionary*safecard =          dc[@"payment"][@"safecard"];
    NSDictionary*defaultbankcard =   dc[@"payment"][@"defaultbankcard"];
   if (safecard) {
       
        if ([[safecard[@"isDefault"] stringValue] isEqualToString:@"1"]) {
            
            return YES;
        }
    }
    
    else
    {
        if (defaultbankcard) {

            return YES;
        }
        else{

        }
    }
    return ishave;
}

-(void)SettingSMSVerificationCodeDisplayInterface

{
    if ([[CashRegisterLocationCache sharedManager] geCashRegisterCachetDict][@"payment"][@"safecard"]) {
        
        messageHaveSend.text = [NSString stringWithFormat:@"短信已发送至%@",[[CashRegisterLocationCache sharedManager] geCashRegisterCachetDict][@"payment"][@"safecard"][@"preMobile"]];
    }
    else
    {
        messageHaveSend.text = [NSString stringWithFormat:@"短信已发送至%@",[[CashRegisterLocationCache sharedManager] geCashRegisterCachetDict][@"payment"][@"defaultbankcard"][@"preMobile"]];
    }
}

//银行卡支付

-(void)paymentPasswordAuthenticationThrough
{
    [self SettingSMSVerificationCodeDisplayInterface];
    [messageCodeField setUserInteractionEnabled:YES];
    [UIView animateWithDuration:0.5 animations:^{
        buttonView.frame =   paymentframeHide;
        buttonView.alpha =   0.0f;
        textfieldView.alpha =         0.0f;
        messageHaveSend.alpha =       1.0f;
        messageCodeField.alpha =      1.0f;
        cantreceiveMessageButton.alpha = 0.0f;
        Quotalabel.alpha= 0.0f;
        forgetPsdButton.alpha = 1.0f;
        textfieldView.frame =         textfieldViewframeHide;
        messageCodeField.frame =      textfieldViewframeDisplay;
        messageHaveSend.frame =       messageHaveSendframeDisplay;
        cantreceiveMessageButton.frame = cantreceiveMessageframeHide;
        Quotalabel.frame = QuotalabelframeHide;
        forgetPsdButton.frame = forgetPsdButtonframeDisplay;
    } completion:^(BOOL finished) {
        [nextButton setTitle:title1 forState:UIControlStateNormal];
        titleLabel1.text = @"请输入短信验证码";
        /*
         验证方法，定义临时的延时执行方法
         */
        [messageCodeField becomeFirstResponder];//Enter the box begins to respond
        
        [self countbutton:countButton];//Start the countdown
        
        [_delegate verifyPassword:self VerifiedbyButton:nil];
    }];
    
}

-(void)arepPaying
{
    payStatusImageVeiw = [[CustomImageView alloc] initWithFrame:CGRectMake((SCREE_W - 80)/2, CGRectGetMaxY(nextButton.frame)+40, 80, 80)];
    [self addSubview:payStatusImageVeiw];
    
    PaymentStatus = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(payStatusImageVeiw.frame)+12, SCREE_W - 20, 14)];
    PaymentStatus.textColor = [UIColor colorWithHexString:@"0099ff" alpha:1.0f];
    PaymentStatus.font = [UIFont systemFontOfSize:15.0f];
    PaymentStatus.textAlignment = NSTextAlignmentCenter;
    [self addSubview:PaymentStatus];
    
    
    PaymentStatus.text = LOADING;
    
    PaymentStatus.textColor = [UIColor colorWithHexString:@"0099ff" alpha:1.0f];
    
    [payStatusImageVeiw loading];
}
-(void)paymentStatusSucess
{
    [payStatusImageVeiw sucess];
    
    PaymentStatus.text = SUCESS;
    
    PaymentStatus.textColor = [UIColor colorWithHexString:@"0099ff" alpha:1.0f];
    
    [self performSelector:@selector(PaymentcCompletion) withObject:nil afterDelay:2.0f];
}
-(void)failurePayStateWithStr:(NSString*)message
{
    [payStatusImageVeiw failure];
    
    PaymentStatus.text = message;
    
    PaymentStatus.textColor = [UIColor colorWithHexString:@"ff6600" alpha:1.0f];
    
    [self performSelector:@selector(showTextFieldagen) withObject:nil afterDelay:2.5f];
}

-(void)showTextFieldagen
{

    [self remoivepayStatusImageVeiw];
}

-(void)PaymentcCompletion
{
    [_delegate verifyPassword:self HavePaymentCompletionButton:nil];
}

-(void)remoivepayStatusImageVeiw
{
    [UIView animateWithDuration:0.5 animations:^{
        
        payStatusImageVeiw.alpha  = 0.0f;
        
        PaymentStatus.alpha = 0.0f;
        
    } completion:^(BOOL finished) {
        
       PaymentStatus.textColor = [UIColor colorWithHexString:@"0099ff" alpha:1.0f];
        
        [payStatusImageVeiw removeFromSuperview];
        
        [PaymentStatus removeFromSuperview];
//
    }];
}


-(void)closed:(UIButton*)button
{
    
    UIAlertView*alert  = [[UIAlertView alloc] initWithTitle:@"" message:@"亲，就差一点就完成支付了哦，确认要放弃付款？" delegate:self cancelButtonTitle:@"否" otherButtonTitles:@"是", nil];
    [alert show];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 1:
    [_delegate verifyPassword:self didClickedClosedButton:nil];
            [[CashRegisterLocationCache sharedManager] clearCashRegister];
            break;
            
        default:
            break;
    }
}

-(void)changePayMentControl:(UIButton*)button
{
    [_delegate verifyPassword:self didClickedChangePayMentControlButton:button];
}

-(void)verifyPassword:(VerifyPasswordView *)verfiyPassword didClickedDeleteButton:(UIButton *)button
{
    if (passWordEnterMutableArray.count>0) {
        [passWordEnterMutableArray removeLastObject];
        [self enterNumber:passWordEnterMutableArray.count];
        NSLog(@"enterArray = %@",passWordEnterMutableArray);
    }

}

-(void)verifyPassword:(VerifyPasswordView *)verfiyPassword didClickedEnterButton:(UIButton *)button
{
    if (passWordEnterMutableArray.count<PASSWORDNUMBER) {
        [passWordEnterMutableArray addObject:button.titleLabel.text];
        [self enterNumber:passWordEnterMutableArray.count];
        
        NSLog(@"enterArray = %@",passWordEnterMutableArray);
    }

}

-(CGFloat)verifyPassword:(VerifyPasswordView *)verfiyPassword getMoveHeight:(CGFloat)height
{
    CGFloat f = SCREE_H - (CGRectGetMaxY(textfieldView.frame)+28.5+40) - SHOW_HEIGHT;
    return f;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [messageCodeField resignFirstResponder];
    return YES;
}
-(void)enterNumber:(NSInteger)number
{
    [self setallclear];
    for (int i = 0; i<number; i++) {
        [(UIImageView*)roundArray[i] setBackgroundColor:[UIColor blackColor]];
    }
}
-(void)setallclear
{
    for (UIImageView*im in roundArray) {
        im.backgroundColor = [UIColor clearColor];
    }
}
-(void)forgetPassword
{
    [_delegate verifyPassword:self forgetPassword:nil];
}
@end

//
//  ChangeVouchersView.h
//  aaa
//
//  Created by 路国良 on 15/8/19.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ChangeVouchersView;

@protocol ChangeVouchersViewDelegate <NSObject>

-(void)ChangeVouchersView:(ChangeVouchersView*)ChangeVouchers didClickedBackButton:(UIButton*)button;

-(void)ChangeVouchersView:(ChangeVouchersView*)ChangeVouchers didChangeRedWalletWithDict:(NSMutableDictionary*)dict;

@end

@interface ChangeVouchersView : UIView

@property(nonatomic,retain) id<ChangeVouchersViewDelegate>delegate;

-(void)setDisPlayViewWith:(NSMutableDictionary*)dict;

- (instancetype)initWithFrame:(CGRect)frame With:(NSMutableDictionary*)dict;
@end

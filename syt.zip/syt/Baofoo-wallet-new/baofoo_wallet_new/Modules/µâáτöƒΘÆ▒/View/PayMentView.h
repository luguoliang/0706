//
//  PayMentView.h
//  aaa
//
//  Created by 路国良 on 15/8/17.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PayMentView;

@protocol PayMentViewDelegate <NSObject>

@required

-(void)payMent:(PayMentView*)payView didClickedBackButton:(UIButton*)button;

//-(void)payMent:(PayMentView*)payView didClickedBackButton:(UIButton*)button WithDict:(NSMutableDictionary*)dict;

-(void)payMent:(PayMentView*)payView didClickedSelectPaymentButton:(NSMutableDictionary*)dict;

//-(void)payMent:(PayMentView*)payView didClickedChangeVouchers:(UIControl*)control;


-(void)payMent:(PayMentView*)payView addBankCardWith:(NSDictionary*)dict;

@end

@interface PayMentView : UIView

@property(nonatomic,retain)id<PayMentViewDelegate>delegate;

-(void)setDisPlayViewWith:(NSMutableDictionary*)dict;

@end

//
//  WBAttributedStyleAction.h
//  BaofooWallet
//
//  Created by 吴斌 on 16/4/14.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WBAttributedStyleAction : NSObject
@property (readwrite, copy) void (^action) ();

- (instancetype)initWithAction:(void (^)())action;
+(NSArray*)styledActionWithAction:(void (^)())action;
-(NSArray*)styledAction;
@end

//
//  CustomImageView.m
//  aaa
//
//  Created by 路国良 on 15/8/12.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "CustomImageView.h"
#import <UIKit/UIKit.h>
@interface CustomImageView ()
{
    NSTimer    *loadtimer;
    NSInteger  loadinter;
    NSTimer    *sucesstimer;
    NSTimer    *failuretimer;
    BOOL       SUCESS;
    BOOL       FAILURE;
}
@end

@implementation CustomImageView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        SUCESS = NO;
        FAILURE = NO;
    }
    return self;
}

-(void)loading

{
    loadinter = 1;
    loadtimer = [NSTimer scheduledTimerWithTimeInterval:0.04 target:self selector:@selector(timerclick)
                                               userInfo:nil repeats:YES];
}
-(void)timerclick
{
    if (SUCESS) {
        if (loadinter<37) {
            
            [self setImage:[UIImage imageNamed:[NSString stringWithFormat:@"支付loading00%d.png",loadinter]]];
            NSLog(@"inter ======== %d",loadinter);
            loadinter++;
           
        }
        else
        {
           [self setImage:[UIImage imageNamed:[NSString stringWithFormat:@"支付loading0036.png"]]];
            [loadtimer invalidate];
            loadtimer = nil;
            loadinter = 1;
             SUCESS = NO;
        }
    }
    else if (FAILURE)
    {
        if (loadinter<25) {
        [self setImage:[UIImage imageNamed:[NSString stringWithFormat:@"支付loading00%d.png",loadinter]]];
            NSLog(@"inter ======== %d",loadinter);
            loadinter++;
        }
        else if(loadinter == 25)
        {
//            loadinter = 37;
            loadinter = 39;
        }
        else
        {
            if (loadinter<48) {
            [self setImage:[UIImage imageNamed:[NSString stringWithFormat:@"支付loading00%d.png",loadinter]]];
                NSLog(@"inter ======== %d",loadinter);
                loadinter++;
            }
            else
            {
                [self setImage:[UIImage imageNamed:[NSString stringWithFormat:@"支付loading0047.png"]]];
                [loadtimer invalidate];
                loadtimer = nil;
                loadinter = 1;
                FAILURE = NO;
            }
        }
    }
    else
    {
        if (loadinter<25) {
           [self setImage:[UIImage imageNamed:[NSString stringWithFormat:@"支付loading00%d.png",loadinter]]];
            NSLog(@"inter ======== %d",loadinter);
            loadinter++;
        }
        else
        {
            loadinter = 1;
        }
    }
}

-(void)sucess

{
    SUCESS = YES;
    
}

-(void)failure

{
    FAILURE = YES;
}

@end

//
//  CashRegisterLocationCache.m
//  BaofooWallet
//
//  Created by 路国良 on 15/9/6.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import "CashRegisterLocationCache.h"
#define KEY       @"CashRegister"
#define ORKEY     @"OriginalCashRegister"

#define DISPLAY   @"DISPLAY"
@implementation CashRegisterLocationCache

+(CashRegisterLocationCache*)sharedManager

{
    static CashRegisterLocationCache*sharedSingleton = nil;
    
    static dispatch_once_t predicate;
    
    dispatch_once(&predicate, ^{
        
        sharedSingleton = [[super allocWithZone:NULL] init];
    });
    return sharedSingleton;
}

+(instancetype)allocWithZone:(struct _NSZone *)zone
{
    return [self sharedManager];
}

-(void)saveCashRegisterCacheDict:(NSMutableDictionary *)dict
{
    NSDictionary*temDict  = [NSDictionary dictionaryWithDictionary:dict];
    
    NSError*error;
    
    NSData*data = [NSJSONSerialization dataWithJSONObject:temDict options:NSJSONWritingPrettyPrinted error:&error];
    
    if (!error) {
        
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:KEY];
    }
    else
    {
        NSLog(@"error = %@",error);
    }
}

-(NSMutableDictionary*)geCashRegisterCachetDict
{
    NSData*data= [[NSUserDefaults standardUserDefaults] objectForKey:KEY];
    
    NSError*error;
    
    NSDictionary*temDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error ];
    
    if (error) {
        
        NSLog(@"error = %@",error);
        
    }
    return [NSMutableDictionary dictionaryWithDictionary:temDict];
}

-(void)saveOriginalCashRegisterCacheDict:(NSMutableDictionary *)dict
{
    NSDictionary*temDict  = [NSDictionary dictionaryWithDictionary:dict];
    
    NSError*error;
    
    NSData*data = [NSJSONSerialization dataWithJSONObject:temDict options:NSJSONWritingPrettyPrinted error:&error];
    
    if (!error) {
        
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:ORKEY];
    }
    else
    {
        NSLog(@"error = %@",error);
    }
}

-(NSMutableDictionary*)getOriginalCashRegisterCachetDict
{
    NSData*data= [[NSUserDefaults standardUserDefaults] objectForKey:ORKEY];
    
    NSError*error;
    
    NSDictionary*temDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error ];
    
    if (error) {
        
        NSLog(@"error = %@",error);
    }
    return [NSMutableDictionary dictionaryWithDictionary:temDict];
}

-(void)saveDisPlayCashRegisterCacheDict:(NSDictionary *)dict
{
    NSDictionary*temDict  = [NSDictionary dictionaryWithDictionary:dict];
    
    NSError*error;
    
    NSData*data = [NSJSONSerialization dataWithJSONObject:temDict options:NSJSONWritingPrettyPrinted error:&error];
    
    if (!error) {
        
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:DISPLAY];
    }
    else
    {
        NSLog(@"error = %@",error);
    }
    
}

-(NSDictionary*)getDisplayCashRegisterCachetDict
{
    NSData*data= [[NSUserDefaults standardUserDefaults] objectForKey:DISPLAY];
    
    NSError*error;
    
    NSDictionary*temDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error ];
    
    if (error) {
        
        NSLog(@"error = %@",error);
    }
    return temDict;
}

-(void)clearCashRegister
{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:KEY];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:ORKEY];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:DISPLAY];
}

@end

//
//  PayMentView.m
//  aaa
//
//  Created by 路国良 on 15/8/17.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//


#import "PayMentView.h"
#import "UIColor+Hexadecimal.h"
#import "FormatterString.h"
#import "ChangeVouchersView.h"
#import "CashRegisterLocationCache.h"
#define SCREE_W                           self.frame.size.width
#define SCREE_H                           self.frame.size.height
#define SHOW_HEIGHT                       80.0f
#define TITLEHEIGHT                       45.0f
#define LINE_COLOR1                        @"7F7F7F"//dcdcdc
#define BUTTON_COLOR                      @"2e8fd3"
#define VIEW_COLOR                        @"efeff4"
#define noRadStr                          @"暂无红包可用"
@interface PayMentView()<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate,ChangeVouchersViewDelegate>
{
    UITableView*_myTableView;
    UIButton*nextButton;
    UIControl*changeVouchersControl;
    UILabel*totalOrderLabel;
    UILabel*remainingamountLabel;
    UILabel*vouchersLabel;
    UIButton*vouchersLabelB;
    NSMutableDictionary*temDataDictionary;
    NSIndexPath *selectIndexPath;
    UILabel*balanceState;//
    UIImageView*selectImageView;
    NSMutableDictionary*_temSelect;
     ChangeVouchersView*changeVoucherView;
}
@end
@implementation PayMentView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        balanceState = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 60, TITLEHEIGHT)];
        selectImageView = [[UIImageView alloc] initWithFrame:CGRectMake(SCREE_W - 40, (60 - 20)/2, 20, 20)];
        selectImageView.image = [UIImage imageNamed:@"res_126-2.png"];
        UIView*line1 = [[UIView alloc] initWithFrame:CGRectMake(0, TITLEHEIGHT, SCREE_W, 0.5f)];
        line1.backgroundColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0];
        [self addSubview:line1];
        
        UIButton*backpaymentButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:backpaymentButton];
        [backpaymentButton addTarget:self action:@selector(backpaymentButton:) forControlEvents:UIControlEventTouchUpInside];
        backpaymentButton.frame = CGRectMake(0, 0, TITLEHEIGHT, TITLEHEIGHT);
        [backpaymentButton setImageEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
        [backpaymentButton setTitleEdgeInsets:UIEdgeInsetsMake(5, 5, 5, 5)];
        [backpaymentButton setImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
        
        
        UILabel*titleLabel2  = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(backpaymentButton.frame), 0, SCREE_W - CGRectGetMaxX(backpaymentButton.frame)*2, TITLEHEIGHT)];
        [self addSubview:titleLabel2];
        titleLabel2.text = @"选择支付方式";
        [self addSubview:titleLabel2];
        titleLabel2.textAlignment = NSTextAlignmentCenter;

        UIView*headerView  = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(line1.frame), SCREE_W, TITLEHEIGHT)];

        UILabel*label1 = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 100, TITLEHEIGHT)];
        [headerView addSubview:label1];

        label1.font = [UIFont systemFontOfSize:15.0f];
        label1.text = @"订单总额";

        totalOrderLabel  = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(label1.frame), 0, SCREE_W - (CGRectGetMaxX(label1.frame)+15), TITLEHEIGHT)];
        totalOrderLabel.font = [UIFont systemFontOfSize:15.0f];
        totalOrderLabel.textAlignment = NSTextAlignmentRight;
        totalOrderLabel.textColor = [UIColor colorWithHexString:@"ff722c" alpha:1.0f];

        
        
        totalOrderLabel.text = [NSString stringWithFormat:@"%@元",[[FormatterString sharedManager] formatterStringWithString:@"10086.00"]];
        [headerView addSubview:totalOrderLabel];

        [self addSubview:headerView];
        
        UIView*line2 = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(headerView.frame), SCREE_W, 0.5f)];
        line2.backgroundColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0];
        [self addSubview:line2];
        
        
        
        UIView*headerView2  = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(line2.frame), SCREE_W, TITLEHEIGHT)];
        
        UILabel*label2 = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 70, TITLEHEIGHT)];
//        [headerView2 addSubview:label2];
        
        label2.font = [UIFont systemFontOfSize:15.0f];
        label2.text = @"使用红包";
      
        vouchersLabelB = [UIButton buttonWithType:UIButtonTypeCustom];
        
        vouchersLabelB.frame = CGRectMake(0, 0, SCREE_W - (15), TITLEHEIGHT);
        vouchersLabelB.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        [headerView2 addSubview:vouchersLabelB];
        [vouchersLabelB setImage:[UIImage imageNamed:@"change.png"] forState:UIControlStateNormal];
        [vouchersLabelB addTarget:self action:@selector(changeVouchersControl:) forControlEvents:UIControlEventTouchUpInside];
        vouchersLabelB.titleLabel.font = [UIFont systemFontOfSize:15.0f];
        [vouchersLabelB setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [vouchersLabelB setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
        UIImage*image = [UIImage imageNamed:@"change.png"];

        [vouchersLabelB setAttributedTitle:[self arrributeStringWithString:noRadStr] forState:UIControlStateNormal];
        [vouchersLabelB layoutIfNeeded];
        [vouchersLabelB setTitleEdgeInsets:UIEdgeInsetsMake(0, -image.size.width, 0, image.size.width)];
        [vouchersLabelB setImageEdgeInsets:UIEdgeInsetsMake(0, vouchersLabelB.titleLabel.bounds.size.width, 0, -vouchersLabelB.titleLabel.bounds.size.width)];
        [headerView2 addSubview:label2];
        
        [self addSubview:headerView2];
        
        UIView*line3 = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(headerView2.frame), SCREE_W, 0.5f)];
        line3.backgroundColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0];
        [self addSubview:line3];
        
        UIView*headerView3  = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(line3.frame), SCREE_W, TITLEHEIGHT)];
        
        UILabel*label3 = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 180, TITLEHEIGHT)];
        [headerView3 addSubview:label3];
        
        label3.font = [UIFont systemFontOfSize:15.0f];
        label3.text = @"使用账户余额或安全卡支付";
        remainingamountLabel  = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(label3.frame), 0, SCREE_W - (CGRectGetMaxX(label3.frame)+15), TITLEHEIGHT)];
        remainingamountLabel.font = [UIFont systemFontOfSize:15.0f];
        remainingamountLabel.textAlignment = NSTextAlignmentRight;
        remainingamountLabel.text = [NSString stringWithFormat:@"%@元",[[FormatterString sharedManager] formatterStringWithString:@"10086.00"]];
//        remainingamountLabel.textColor = [UIColor colorWithHexString:@"ff722c" alpha:1.0f];
        [headerView3 addSubview:remainingamountLabel];
        [self addSubview:headerView3];
        
        _myTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(headerView3.frame), SCREE_W, frame.size.height - (CGRectGetMaxY(headerView3.frame)+SHOW_HEIGHT+40+20)) style:UITableViewStylePlain];
        [self addSubview:_myTableView];
        _myTableView.separatorColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0f];
        _myTableView.delegate = self;
        _myTableView.dataSource = self;
        UIView*footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREE_W, 10)];
        footView.backgroundColor = [UIColor whiteColor];
        _myTableView.tableFooterView = footView;
        
        UIView*l = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREE_W, 0.5f)];
        l.backgroundColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0];
        [footView addSubview:l];

        
        
        nextButton = [UIButton buttonWithType:UIButtonTypeSystem];
        nextButton.frame = CGRectMake((SCREE_W - 293)/2,(frame.size.height - SHOW_HEIGHT - 40 - 20), 293, 40);
        [self addSubview:nextButton];
        nextButton.backgroundColor = [UIColor colorWithHexString:BUTTON_COLOR alpha:1.0f];
        nextButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [nextButton setTintColor:[UIColor whiteColor]];
        nextButton.layer.masksToBounds = YES;
        nextButton.layer.cornerRadius = 20.0f;
        [nextButton setTitle:@"确认" forState:UIControlStateNormal];
        [nextButton addTarget:self action:@selector(nextButton:) forControlEvents:UIControlEventTouchUpInside];
        temDataDictionary = [NSMutableDictionary dictionary];
        [self loadChangeVouchersVeiw];
        
    }
    return self;
}

-(NSMutableAttributedString*)arrributeStringWithString:(NSString*)string
{
    NSMutableAttributedString*attributeStr = [[NSMutableAttributedString alloc] initWithString:string];
    
    [attributeStr addAttribute:NSForegroundColorAttributeName value:[UIColor clearColor] range:NSMakeRange((string.length - 1), 1)];
    
    if ([string rangeOfString:noRadStr].location != NSNotFound) {
        
        [attributeStr addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"c9c9c9" alpha:1.0f] range:NSMakeRange(0, string.length - 1)];
    }
    
    else
    {
//        [attributeStr addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"ff722c" alpha:1.0f] range:NSMakeRange(0, string.length - 1)];
         [attributeStr addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:NSMakeRange(0, string.length - 1)];
    }
    return attributeStr;
}

-(void)setDisPlayViewWith:(NSMutableDictionary *)dict
{
    
    temDataDictionary = dict;
    
    [self RemoveTheCheckStatePaidEnvelopesWith:dict];//When the amount is greater than the amount paid envelopes，Remove the check status
    
    
    totalOrderLabel.text = [NSString stringWithFormat:@"%@元",[self test:dict[@"amount"]]];//订单总金额
    
    [self calculatePaymentAomunt:dict];//Calculated payment amount
    
    [_myTableView reloadData];
}


-(void)RemoveTheCheckStatePaidEnvelopesWith:(NSMutableDictionary*)dict
{
    if([self AnalyzingRedEnvelopeisGreaterThanTotalPurchaseWith:dict])
        
    {
        [selectImageView removeFromSuperview];
        
        //calculated the cache data change the state if the isdefault was 1
        
        [self changdefaaultwith:dict];
        
        if ([[dict[@"balance"][@"isDefault"] stringValue] isEqualToString:@"1"]) {
            
            NSMutableDictionary*temdicts = dict[@"balance"];
            
            NSMutableDictionary*temdict = [NSMutableDictionary dictionaryWithDictionary:temdicts];
            
            if (temdict) {
                
                [temdict setObject:[NSNumber numberWithInt:0] forKey:@"isDefault"];
            }
            [temDataDictionary setObject:temdict forKey:@"balance"];
        }
        
        selectIndexPath = nil;
    }
}



-(void)calculatePaymentAomunt:(NSMutableDictionary*)dict
{
    NSMutableArray*array = dict[@"redWallert"];
    
    NSDictionary*defaRedWallert = [NSDictionary dictionary];
    
    if (array.count) {
        
        for (NSMutableDictionary*dict in array) {
            
            if ([[dict[@"isDefault"] stringValue] isEqualToString:@"1"]) {
                
                defaRedWallert = [NSDictionary dictionaryWithDictionary:dict];
            }
        }
    }
    if (defaRedWallert) {
        
        NSString*balnce = dict[@"amount"];
        
        NSString*wallet = defaRedWallert[@"balance"];
        
        if (wallet) {
            
            NSLog(@"可以使用代金券");

            [self WhetherToUse:YES redenvelopesavailableWithTitle:[NSString stringWithFormat:@"%@元红包",defaRedWallert[@"balance"]]];

            double d = [balnce doubleValue] - [wallet doubleValue];
            
            if (d<=0) {
            
               remainingamountLabel.text = [NSString stringWithFormat:@"%@元",[self test:@"0"]];
            }
            else
            {
                balnce = [NSString stringWithFormat:@"%f",d];
                
//               remainingamountLabel.text = [NSString stringWithFormat:@"%@元",[[FormatterString sharedManager] formatterStringWithString:balnce]];
                remainingamountLabel.text = [NSString stringWithFormat:@"%@元",[self test:balnce]];
            }
        }
        else{
            
//           remainingamountLabel.text = [NSString stringWithFormat:@"%@元",[[FormatterString sharedManager] formatterStringWithString:dict[@"amount"]]];
            remainingamountLabel.text = [NSString stringWithFormat:@"%@元",[self test:dict[@"amount"]]];
            
            [self WhetherToUse:NO redenvelopesavailableWithTitle:noRadStr];
        }

    }
    
}


-(void)WhetherToUse:(BOOL)use redenvelopesavailableWithTitle:(NSString*)str
{
    if (use) {
        
//        [vouchersLabelB setTitleColor:[UIColor colorWithHexString:@"ff722c" alpha:1.0f] forState:UIControlStateNormal];
        [vouchersLabelB setTitleColor:[UIColor colorWithHexString:@"ff722c" alpha:1.0f] forState:UIControlStateNormal];
    }
    else
    {
        [vouchersLabelB setTitleColor:[UIColor colorWithHexString:@"c9c9c9" alpha:1.0f] forState:UIControlStateNormal];
    }
    
    [vouchersLabelB setImage:[UIImage imageNamed:@"change.png"] forState:UIControlStateNormal];
    
    UIImage*image = [UIImage imageNamed:@"change.png"];

    [vouchersLabelB setAttributedTitle:[self arrributeStringWithString:[NSString stringWithFormat:@"%@s",str]] forState:UIControlStateNormal];
    
    [vouchersLabelB layoutIfNeeded];
    
    [vouchersLabelB setTitleEdgeInsets:UIEdgeInsetsMake(0, -image.size.width, 0, image.size.width)];
    
    [vouchersLabelB setImageEdgeInsets:UIEdgeInsetsMake(0, vouchersLabelB.titleLabel.bounds.size.width, 0, -vouchersLabelB.titleLabel.bounds.size.width)];

}


-(void)loadChangeVouchersVeiw
{
    changeVoucherView = [[ChangeVouchersView alloc] initWithFrame:CGRectMake(SCREE_W, 0, SCREE_W, SCREE_H)];
    
    changeVoucherView.delegate = self;
    
    //没办法了只有去处缓存了，there is originalCashData
    [changeVoucherView setDisPlayViewWith:[[CashRegisterLocationCache sharedManager] getOriginalCashRegisterCachetDict]];
    
    [self addSubview:changeVoucherView];
}





-(void)backpaymentButton:(UIButton*)button
{
     [_delegate payMent:nil didClickedBackButton:nil];
}

-(BOOL)AnalyzingRedEnvelopeisGreaterThanTotalPurchaseWith:(NSMutableDictionary*)dict
{
    NSString*balnce = dict[@"amount"];
    
    NSMutableDictionary*walletDictionary = [NSMutableDictionary dictionary];
    
    for (NSMutableDictionary*d in dict[@"redWallert"]) {
        
        if ([[d[@"isDefault"] stringValue] isEqualToString:@"1"]) {
            
            walletDictionary = d;
        }
    }
    NSString*wallet = walletDictionary[@"balance"];
    
    if (wallet) {
        
        double d = [balnce doubleValue] - [wallet doubleValue];
        
        if (d<=0) {
            
            return YES;
        }
        else
        {
            return NO;
        }
     }
    else
    {
        return NO;
    }
}


-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell*cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    
    if ([selectIndexPath isEqual:indexPath]) {
        
        [cell.contentView addSubview:selectImageView];
    }
    
    cell.userInteractionEnabled = YES;
    
    cell.textLabel.font = [UIFont systemFontOfSize:15.0f];
    cell.detailTextLabel.numberOfLines = 0;
    
    cell.detailTextLabel.font = [UIFont systemFontOfSize:11.0f];
    
    cell.detailTextLabel.textColor = [UIColor colorWithHexString:LINE_COLOR1 alpha:1.0f];
//
    if (([self AnalyzingRedEnvelopeisGreaterThanTotalPurchaseWith:temDataDictionary])) {//支付金额大于红包
        
        cell.userInteractionEnabled = NO;
    }
    if (indexPath.row == 0) {
        
        cell.imageView.image = [UIImage imageNamed:@"payment_balabce.png"];
        
        cell.textLabel.text = [NSString stringWithFormat:@"账户余额(%@元)",[self test:temDataDictionary[@"balance"][@"balance"]]];
        
        balanceState.font = [UIFont systemFontOfSize:13.0f];
        
        balanceState.textAlignment = NSTextAlignmentRight;
        
        cell.accessoryView = balanceState;
        
        balanceState.font = [UIFont systemFontOfSize:15.0f];
        if ([self AnalyzingBalanceIsAvailable:temDataDictionary[@"balance"][@"balance"]]) {
            
            balanceState.text = @"";
            
            balanceState.textColor = [UIColor blackColor];
        }
        else
        {
            balanceState.text = @"余额不足";
//            [selectImageView removeFromSuperview];
            cell.textLabel.textColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0f];
            
            balanceState.textColor = [UIColor colorWithHexString:LINE_COLOR alpha:1.0f];
            
            cell.userInteractionEnabled = NO;
        }
        
    }
    else
    {
        NSDictionary*de;
         if(indexPath.row == ([temDataDictionary[@"bankCard"] count]+1))
            {
                cell.textLabel.text = @"添加银行卡支付";
                
                cell.detailTextLabel.text = @"只能添加一张银行卡进行充值、消费和提现";
                
                cell.imageView.image = [UIImage imageNamed:@"addBankCard.png"];//
            }
//
        else{
        
            de = temDataDictionary[@"bankCard"][indexPath.row -1];
            
            cell.imageView.image = [UIImage imageNamed:de[@"payId"]];
            
            NSString*str = [self stringIntoArrayWithString:de[@"desc"]][0];
            
            cell.textLabel.text = [NSString stringWithFormat:@"%@(%@)",de[@"name"],str];

            cell.detailTextLabel.text = [NSString stringWithFormat:@"%@",[NSString stringWithFormat:@"单笔%@元,单日%@元",[self test:[self stringIntoArrayWithString:de[@"desc"]][2]],[self test:[self stringIntoArrayWithString:de[@"desc"]][3]]]];
            
            
        }
        
    }
    
    NSLog(@"temDataDictionary = %@",temDataDictionary);
    
    return cell;
}

-(NSString*)test:(NSString*)str
{
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    
    formatter.numberStyle = kCFNumberFormatterDecimalStyle;
    
    NSString *string = [formatter stringFromNumber:[NSNumber numberWithDouble:[str doubleValue]]];
    
    return string;
}


-(BOOL)DetermineWhetheThereIsAbankCard//
{
    BOOL ishave = YES;
    
    if (!([temDataDictionary[@"bankCard"] count])) {
        
        return YES;
    }
    else
    {
     
        for (NSMutableDictionary*dc in temDataDictionary[@"bankCard"]) {
            
            if ([dc[@"payType"] isEqualToString:@"301"]) {
                
                return NO;
            }

        }
    }
     return ishave;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath

{
    if (selectIndexPath) {
        
        [selectImageView removeFromSuperview];
    }
    
    [self performSelector:@selector(deselect) withObject:nil afterDelay:0.1f];
    
    UITableViewCell *cell = (UITableViewCell*)[tableView cellForRowAtIndexPath:indexPath];
    
    [cell.contentView addSubview:selectImageView];
    
    selectIndexPath = indexPath;
    
    [self performSelector:@selector(deselect) withObject:nil afterDelay:0.1f];
    
    NSLog(@"selectIndexPath = %@",selectIndexPath);
    
    NSLog(@"indexPath.row = %ld",(long)indexPath.row - 1);
    
    NSLog(@"temDataDictionary= %@",temDataDictionary[@"bankCard"]);
    
    NSMutableDictionary*ttd = temDataDictionary;
    NSLog(@"temDataDictionary = %@",temDataDictionary);
    NSMutableArray*arrays = [NSMutableArray arrayWithArray:ttd[@"bankCard"]];
    
    NSMutableDictionary*dc;
    
    balanceState.hidden =NO;
    
    if(indexPath.row == ([temDataDictionary[@"bankCard"] count]+1))
    {
        [self addBankCard];
    }
    else{
        
        if (indexPath.row == 0) {
            
            balanceState.hidden = YES;
            
            NSMutableDictionary*balance = [NSMutableDictionary dictionaryWithDictionary:temDataDictionary[@"balance"]];
            
            [balance setObject:[NSNumber numberWithInt:1] forKey:@"isDefault"];
            
            [temDataDictionary setObject:balance forKey:@"balance"];
             NSLog(@"temDataDictionary = %@",temDataDictionary);
            [self changdefaaultwith:temDataDictionary];
        }
        else{
        
        dc = arrays[indexPath.row - 1];
            
        }
        
        NSMutableDictionary*dcs  = [NSMutableDictionary dictionaryWithDictionary:dc];
        
        if ([[dcs[@"isUse"] stringValue]isEqualToString:@"1"]) {
            
            if (indexPath.row == 0) {
                
                NSMutableDictionary*balance = [NSMutableDictionary dictionaryWithDictionary:temDataDictionary[@"balance"]];
                
                [balance setObject:[NSNumber numberWithInt:1] forKey:@"isDefault"];
                
                [temDataDictionary setObject:balance forKey:@"balance"];
                 NSLog(@"temDataDictionary = %@",temDataDictionary);
                [self changdefaaultwith:temDataDictionary];
                
            }
        else
            {
            
                NSMutableDictionary*balance = [NSMutableDictionary dictionaryWithDictionary:temDataDictionary[@"balance"]];
                
                [balance setObject:[NSNumber numberWithInt:0] forKey:@"isDefault"];
                
                [temDataDictionary setObject:balance forKey:@"balance"];
                 NSLog(@"temDataDictionary = %@",temDataDictionary);
                [self changdefaaultwith:temDataDictionary];
                
                NSMutableDictionary*dd = [NSMutableDictionary dictionaryWithDictionary:arrays[indexPath.row-1]];
                
                
//                [[NSUserDefaults standardUserDefaults] setObject:dd forKey:@"temSelect"];
                
                _temSelect = dd;
                
                [dd setObject:[NSNumber numberWithInt:1] forKey:@"isDefault"];
                
                [arrays replaceObjectAtIndex:(indexPath.row - 1) withObject:dd];
                
                [temDataDictionary setObject:arrays forKey:@"bankCard"];
                NSLog(@"temDataDictionary = %@",temDataDictionary);
                
                if (!([dd[@"payType"] isEqualToString:@"301"])) {
                    
                    UIAlertView*alert  =[[UIAlertView alloc] initWithTitle:@"" message:@"慧生钱只能绑定或者添加一张常用的银行卡作为账户安全卡进行充值、消费和提现。确认使用该卡？" delegate:self cancelButtonTitle:@"添加新卡" otherButtonTitles:@"使用当前卡", nil];
                    
                    [alert show];
                    
                }
            }
        }
        
        
    }
    
//    [self DataProcessing:temDataDictionary];
    
}//sadasda

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 1:
        {
            [self nextButton:nil];
        }
            break;
            
        default:
        {
            [self addBankCard];
        }
            break;
    }
}

-(void)addBankCard

{

}

-(void)changdefaaultwith:(NSMutableDictionary*)dict

{
    for (int i = 0 ;i < [dict[@"bankCard"] count];i++) {
        
        if ([[dict[@"bankCard"][i][@"isDefault"] stringValue] isEqualToString:@"1"]) {
            
            NSMutableDictionary*dd = [NSMutableDictionary dictionaryWithDictionary:dict[@"bankCard"][i]];
            
            [dd setValue:[NSNumber numberWithInt:0] forKey:@"isDefault"];
            
            NSLog(@"i = %d",i);
            
            NSMutableArray*redarray = [NSMutableArray arrayWithArray:temDataDictionary[@"bankCard"]];//redWallertArray
            
            [redarray replaceObjectAtIndex:i withObject:dd];
            
            [temDataDictionary setObject:redarray forKey:@"bankCard"];
            
            NSLog(@"temDataDictionary = %@",temDataDictionary);
        }
    }
}

-(void)DataProcessing:(NSMutableDictionary*)dict
{
}

-(BOOL)DetermineWhetherThere:(NSMutableArray*)array

{
    BOOL isHave = NO;
    
    for (NSMutableDictionary*dc in array) {//Traversing the default red
        
        if ([[dc[@"isDefault"] stringValue] isEqualToString:@"1"]) {
        
            isHave = YES;
        }
    }
    
    return isHave;

}

- (void)deselect
{
    [_myTableView deselectRowAtIndexPath:[_myTableView indexPathForSelectedRow] animated:YES];
}


-(NSArray*)stringIntoArrayWithString:(NSString*)string
{
    NSArray*array = [string componentsSeparatedByString:@"|"];
    
    return array;
}

-(BOOL)AnalyzingBalanceIsAvailable:(NSString*)balance
{
    return YES;
 }

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSMutableArray*a = temDataDictionary[@"bankCard"];
    
    if ([self DetermineWhetheThereIsAbankCard]) {
        return (a.count+2);
    }
    else
    return (a.count + 1);
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

-(void)nextButton:(UIButton*)button
{
    [self DataProcessing:temDataDictionary];
    NSLog(@"temDataDictionary = %@",temDataDictionary);
    NSMutableDictionary*postDict = [NSMutableDictionary dictionaryWithDictionary:[[CashRegisterLocationCache sharedManager] geCashRegisterCachetDict]];
    [_delegate payMent:self didClickedSelectPaymentButton:postDict];
}

-(void)changeVouchersControl:(UIButton*)button
{
    NSLog(@"选择红包");
    [changeVoucherView setDisPlayViewWith:[[CashRegisterLocationCache sharedManager] getOriginalCashRegisterCachetDict]];
    [UIView animateWithDuration:0.3 animations:^{
        changeVoucherView.frame = CGRectMake(0, 0, SCREE_W, SCREE_H);
    } completion:^(BOOL finished) {
    }];

}

-(void)ChangeVouchersView:(ChangeVouchersView *)ChangeVouchers didChangeRedWalletWithDict:(NSMutableDictionary *)dict
{
    [self setDisPlayViewWith:dict];
}

-(void)ChangeVouchersView:(ChangeVouchersView*)ChangeVouchers didClickedBackButton:(UIButton*)button
{
    [UIView animateWithDuration:0.3 animations:^{
        
        changeVoucherView.frame = CGRectMake(SCREE_W, 0, SCREE_W, SCREE_H);
        
    } completion:^(BOOL finished) {
        
    }];
}


//- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
//{
//    
//    [self changdefaaultwith:temDataDictionary];//Change the selected state bank cards
//    
//    switch (buttonIndex) {
//        case 1:
//        {
//            [selectImageView removeFromSuperview];
//            
//        }
//            break;
//            
//        default:
//        {
//#warning message
//            NSMutableDictionary*dicts = [[CashRegisterLocationCache sharedManager] getOriginalCashRegisterCachetDict];
//            [_delegate payMent:self addBankCardWith:dicts];
//
//        }
//            break;
//    }
//}

@end

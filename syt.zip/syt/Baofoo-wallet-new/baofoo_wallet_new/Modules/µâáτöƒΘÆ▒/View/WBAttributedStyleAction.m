//
//  WBAttributedStyleAction.m
//  BaofooWallet
//
//  Created by 吴斌 on 16/4/14.
//  Copyright © 2016年 宝付网络（上海）有限公司. All rights reserved.
//

#import "WBAttributedStyleAction.h"
NSString* kWBAttributedStyleAction = @"WBAttributedStyleAction";
@implementation WBAttributedStyleAction
- (instancetype)initWithAction:(void (^)())action
{
    self = [super init];
    if (self) {
        self.action = action;
    }
    return self;
}

+(NSArray*)styledActionWithAction:(void (^)())action
{
    WBAttributedStyleAction* container = [[WBAttributedStyleAction alloc] initWithAction:action];
    return [container styledAction];
}

-(NSArray*)styledAction
{
    return @[ @{kWBAttributedStyleAction:self}, @"link"];
}
@end

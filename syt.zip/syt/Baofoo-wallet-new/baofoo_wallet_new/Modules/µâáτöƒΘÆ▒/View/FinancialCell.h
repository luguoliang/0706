//
//  FinancialCell.h
//  makr
//
//  Created by mac on 15/4/27.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FinancialCell;
@protocol FinancialCellDelegate <NSObject>

@optional
- (void)financialOpenProtocol:(UIButton *)protocolButton;

@end

@interface FinancialCell : UITableViewCell
@property(nonatomic,assign)id<FinancialCellDelegate>delegate;
- (void)applyData:(id)object indexRow:(NSInteger)row;
@end

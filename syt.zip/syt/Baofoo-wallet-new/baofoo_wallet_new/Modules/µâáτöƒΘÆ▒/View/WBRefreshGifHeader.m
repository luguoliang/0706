//
//  WBRefreshGifHeader.m
//  BaofooWallet
//
//  Created by mac on 15/7/16.
//  Copyright (c) 2015年 宝付网络（上海）有限公司. All rights reserved.
//

#import "WBRefreshGifHeader.h"
#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:0.25]

@implementation WBRefreshGifHeader

#pragma mark - 重写方法
#pragma mark 基本设置
- (void)prepare
{
    [super prepare];
    
    
    NSMutableArray *idleImages = [NSMutableArray array];
    for (int i = 1; i<=28; i++) {
        NSString *imageName = [NSString stringWithFormat:@"loading%d.png", i];
        UIImage *image = [UIImage imageNamed:imageName];
        [idleImages addObject:image];
    }
    
    
    NSMutableArray *stateIdleImages = [NSMutableArray array];
    for (int i = 1; i<=28; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"%d.png", i]];
        [stateIdleImages addObject:image];
    }
    
    NSMutableArray * refreshingImages= [NSMutableArray array];
    UIImage *image = [UIImage imageNamed:@"28.png"];
    [refreshingImages addObject:image];
    
    // 设置普通状态的动画图片
    [self setImages:stateIdleImages forState:MJRefreshStateIdle];
    
    // 设置即将刷新状态的动画图片（一松开就会刷新的状态）
    [self setImages:refreshingImages forState:MJRefreshStatePulling];
    
    // 设置正在刷新状态的动画图片
    [self setImages:idleImages forState:MJRefreshStateRefreshing];
    
    // 设置控件的高度
    self.mj_h = 60;
    self.backgroundColor = [UIColor colorWithRed:239.0f/255.0f green:239.0f/255.0f blue:244.0f/255.0f alpha:1.0f];
}

@end

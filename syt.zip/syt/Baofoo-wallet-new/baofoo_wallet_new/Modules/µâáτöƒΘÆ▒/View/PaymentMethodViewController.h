//
//  PaymentMethodViewController.h
//  checkoutcounter
//
//  Created by 路国良 on 15/5/28.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaymentMethodViewController : UIViewController
@property(strong,nonatomic) void (^callbackParms) (NSDictionary *selectbankDict,NSDictionary*selectVouchersDict);//选择快捷卡时回调
@property(strong,nonatomic) void (^callbackBalance) (NSDictionary *Balance);//选择账户余额时回调

@property(nonatomic,copy)NSMutableArray*bankCards;//银行卡的总数
@property(nonatomic,copy)NSMutableDictionary*DefaultVouchDict;//默认要显示的代金券
@property(nonatomic,copy)NSString*totalOrderStr;//显示支付总额
@property(nonatomic,copy)NSArray*vouchersArray;//代金券
@property(nonatomic,copy)NSString*orderNo;
@end

//
//  FinancialCell.m
//  makr
//
//  Created by mac on 15/4/27.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "FinancialCell.h"
#import "FinancialModel.h"
#import "NSString+DetailString.h"
#define CELL_HEIGHT 95.0f
#define STATE_COLOR_ARR @[RED_COLOR,GREEN_COLOR,GRAY_COLOR]
#define STATE_NAME_ARR @[@"募集中",@"收益中",@"本息已返还"]
#define name_font FONT_LIGHT(AUTO_LENGTH(15))
#define data_font FONT_LIGHT(AUTO_LENGTH(11))
#define data_height AUTO_LENGTH(13)
#define data_color COLOR_HEXSTRING(@"#7d7d7d")
@interface FinancialCell()
{
    UIView *contentView;//展示数据View
    
    UILabel *titleLabel;//名称
    UILabel *buyMoneyLabel;//购买金额
    UILabel *endTimeLabel;//结息日期
    UILabel *getMoneyLabel;//预期总收益
    UILabel *startTimeLabel;//起息日期
    
    
    UIImageView *stateImageView;//状态图片
    UIImageView *typeImageView;//产品类型
    UIButton *protocolButton;//协议按钮
    
}
@end
@implementation FinancialCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        
        self.backgroundColor = COLOR_HEXSTRING(BACKGROUND_COLOR);
        contentView = [[UIView alloc] initWithFrame:CGRectMake(0, AUTO_LENGTH(6), ScreenWidth, AUTO_LENGTH(105.0f))];
        contentView.backgroundColor = [UIColor whiteColor];
        [self addSubview:contentView];
        
        titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(AUTO_LENGTH(10), AUTO_LENGTH(20), AUTO_LENGTH(200), AUTO_LENGTH(17))];
        titleLabel.font = name_font;
        [contentView addSubview:titleLabel];
        
        buyMoneyLabel = [[UILabel alloc] initWithFrame:CGRectMake(AUTO_LENGTH(10), CGRectGetMaxY(titleLabel.frame)+AUTO_LENGTH(15), ScreenWidth*0.5, AUTO_LENGTH(13))];
        buyMoneyLabel.font = data_font;
        buyMoneyLabel.textColor = data_color;
        [contentView addSubview:buyMoneyLabel];
        
        getMoneyLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(buyMoneyLabel.frame), buyMoneyLabel.frame.origin.y, ScreenWidth*0.5-AUTO_LENGTH(20), data_height)];
        getMoneyLabel.font = data_font;
        getMoneyLabel.textColor = data_color;
        getMoneyLabel.textAlignment = NSTextAlignmentRight;
        [contentView addSubview:getMoneyLabel];
        
        startTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(AUTO_LENGTH(10), CGRectGetMaxY(buyMoneyLabel.frame)+AUTO_LENGTH(10), ScreenWidth*0.5, data_height)];
        startTimeLabel.font = data_font;
        startTimeLabel.textColor = data_color;
        [contentView addSubview:startTimeLabel];
        
        endTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(ScreenWidth-AUTO_LENGTH(10)-ScreenWidth*0.5, CGRectGetMaxY(buyMoneyLabel.frame)+AUTO_LENGTH(10), ScreenWidth*0.5, data_height)];
        endTimeLabel.font = data_font;
        endTimeLabel.textColor = data_color;
        endTimeLabel.textAlignment = NSTextAlignmentRight;
        [contentView addSubview:endTimeLabel];
        
        stateImageView = [[UIImageView alloc] init];
        [contentView addSubview:stateImageView];
        
        typeImageView = [[UIImageView alloc] init];
        [contentView addSubview:typeImageView];
        
        protocolButton = [UIButton buttonWithType:UIButtonTypeCustom];
        
        [protocolButton addTarget:self action:@selector(openProtocolAction:) forControlEvents:UIControlEventTouchUpInside];
        [contentView addSubview:protocolButton];
    }
    return self;
}

- (void)applyData:(id)object indexRow:(NSInteger)row
{
    FinancialModel *model = (FinancialModel *)object;
    
    UIImage *stateImage = [UIImage imageNamed:[NSString stringWithFormat:@"hsq_manage_state%d",[model.state intValue]]];
    
    UIImage *protocolImage = nil;

    if ([model.is_haveProtocol intValue]==1) protocolImage = [UIImage imageNamed:@"hsq_manage_protocol"];
    
    CGFloat stateImageWidht = stateImage.size.width;
    CGFloat stateImageHeight = stateImage.size.height;
    
    CGFloat protocolImageWidth = protocolImage.size.width;
    CGFloat protocolImageHeight = protocolImage.size.height;
    
    protocolButton.frame = CGRectMake(ScreenWidth-5.0f-stateImageWidht-protocolImageWidth, 0.0f, protocolImageWidth, protocolImageHeight);
    protocolButton.tag = row;
    [protocolButton setBackgroundImage:protocolImage forState:UIControlStateNormal];
    
    stateImageView.frame = CGRectMake(CGRectGetMaxX(protocolButton.frame), 0.0f, stateImageWidht, stateImageHeight);
    stateImageView.image = stateImage;
    
    
//    stateLabel.text = STATE_NAME_ARR[[model.state integerValue]-1];
//    stateLabel.backgroundColor = COLOR_HEXSTRING(STATE_COLOR_ARR[[model.state integerValue]-1]);
    titleLabel.text = model.product_name;
    NSLog(@"%@  %@",model.product_name,model.state);
    buyMoneyLabel.text = [NSString stringWithFormat:@"购买金额：%@元",[NSString moneyNumAndChangeformat:model.buy_amount isDisplayPoint:YES]];
    startTimeLabel.text = [NSString stringWithFormat:@"起息日期：%@",model.startTime];
    endTimeLabel.text = [NSString stringWithFormat:@"结息日期：%@",model.endTime];
    getMoneyLabel.text = [NSString stringWithFormat:@"预期收益：%@元",[NSString moneyNumAndChangeformat:model.exp_expire_amount isDisplayPoint:YES]];
    

    self.selectedBackgroundView = [[UIView alloc] initWithFrame:contentView.frame];
    self.selectedBackgroundView.backgroundColor = COLOR_HEXSTRING(@"#f5f5f5");
}
- (void)openProtocolAction:(UIButton *)sender
{
    if ([self.delegate respondsToSelector:@selector(financialOpenProtocol:)]) {
        [self.delegate financialOpenProtocol:protocolButton];
    }
}
@end

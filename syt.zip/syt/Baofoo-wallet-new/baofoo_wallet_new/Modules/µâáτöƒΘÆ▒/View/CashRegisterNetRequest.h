//
//  CashRegisterNetRequest.h
//  aaa
//
//  Created by 路国良 on 15/8/27.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CashRegisterNetRequest;

@interface CashRegisterNetRequest : NSObject

+(CashRegisterNetRequest*)sharedManager;

-(void)CashRegisterGetOrderNomberWithPostOrgetData:(NSDictionary*)dict Sucessful:(void (^)(NSDictionary *))Sucessful failure:(void (^)(NSString *))failure;

-(void)CashRegisterVerPasswordWith:(NSDictionary*)dict Sucessful:(void(^)(NSDictionary*))Sucessful failure:(void (^)(NSString*))failure;

-(void)CashRegisterVerMessageCodeAndConfirmPaymentWith:(NSDictionary*)dict Sucessful:(void(^)(NSDictionary*))Sucessful failure:(void (^)(NSString*))failure;

-(void)CashRegisterVerGetMessageCodeWith:(NSDictionary*)dict Sucessful:(void(^)(NSDictionary*))Sucessful failure:(void (^)(NSString*))failure;

-(void)CashRegisterConfirmPaymentWithPostOrgetData:(NSDictionary*)dict Sucessful:(void (^)(NSDictionary *))Sucessful failure:(void (^)(NSString *))failure;

-(void)CashRegisterCallBackServerPostOrgetData:(NSDictionary*)dict Sucessful:(void (^)(NSDictionary *))Sucessful failure:(void (^)(NSString *))failure;
@end

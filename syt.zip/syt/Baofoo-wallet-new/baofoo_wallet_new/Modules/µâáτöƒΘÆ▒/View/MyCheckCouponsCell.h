//
//  MyCheckCouponsCell.h
//  moneyTest
//
//  Created by 路国良 on 15/6/4.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCheckCouponsCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *conditionLabel;
@property (weak, nonatomic) IBOutlet UILabel *face_moneyLabel;
@property (weak, nonatomic) IBOutlet UILabel *end_timeLabel;
@property (weak, nonatomic) IBOutlet UIImageView *selectImageView;
@property (weak, nonatomic) IBOutlet UILabel *conditionLabel2;







@end

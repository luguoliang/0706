//
//  PopUpView.m
//  aaa
//
//  Created by 路国良 on 15/8/4.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//
#import "PopUpView.h"
#import "UIColor+Hexadecimal.h"
#import "FormatterString.h"
#import "BFKeyBoardView.h"
#import "CustomImageView.h"
#import "CountdownButton.h"
#import "PayMentView.h"
#import "VerifyPasswordView.h"
#import "BFReqAPI+Checkout.h"
#import "CashRegisterLocationCache.h"
#import "ChangeVouchersView.h"
#define SCREE_W                           self.frame.size.width
#define SCREE_H                           self.frame.size.height
#define BUTTON_COLOR                      @"2e8fd3"
#define VIEW_COLOR                        @"efeff4"
#define SHOW_HEIGHT                       80.0f
#define TITLEHEIGHT                       45.0F

@interface PopUpView ()<BFKeyBoardViewDelegate,UITextFieldDelegate,PayMentViewDelegate,VerifyPasswordViewDelegate>
{
    /*
     UI
     */
    VerifyPasswordView*PasswordView;
    PayMentView*paymentView;
    UIView*payMentMethodView;//选择支付方式
    BFKeyBoardView*_keyboard;
    UITextField*textField;
    UILabel*PaymentStatus;//支付状态
    NSString*_orderNo;
    ChangeVouchersView*redwalletView;
    /*
     DA
     */
}
@end
@implementation PopUpView

- (instancetype)initWithFrame:(CGRect)frame WithDict:(NSDictionary*)dict withDelegate:(id)controller
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.30f];
        _keyboard = [[[NSBundle mainBundle] loadNibNamed:@"BFKeyBoardView" owner:nil options:nil] lastObject];
        _keyboard.delegate = self;
        textField =[[UITextField alloc] init];
        [self addSubview:textField];
        textField.delegate = self;
        textField.inputView = _keyboard;
        self.delegate = controller;
        [self requestOrderNomberWithDict:dict];
    }
    return self;
}
-(void)loadShowView:(NSMutableDictionary*)dict
{
    PasswordView = [[VerifyPasswordView alloc] initWithFrame:CGRectMake(0, SCREE_H, SCREE_W, SCREE_H) WithDict:dict];
    
    [self addSubview:PasswordView];
    PasswordView.delegate = self;
}
-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword didClickedClosedButton:(UIButton*)button
{
    [self closed];
}

-(void)verifyPassword:(VerifyPasswordView*)verfiyPassword didClickedChangePayMentControlButton:(UIButton*)button
{
    [textField resignFirstResponder];
    [self performSelector:@selector(changePayMentControl) withObject:nil afterDelay:0.15];
}


-(void)verifyPassword:(VerifyPasswordView *)verfiyPassword VerifiedbyButton:(UIButton *)button
{
    [textField resignFirstResponder];
}
-(void)verifyPassword:(VerifyPasswordView *)verfiyPassword FailurebyButton:(UIButton *)button{
    [textField becomeFirstResponder];
}

-(void)verifyPassword:(VerifyPasswordView *)verfiyPassword HavePaymentCompletionButton:(UIButton *)button
{
    [self removeFromSuperview];
}

-(void)verifyPassword:(VerifyPasswordView *)verfiyPassword didClickedNextButtonButton:(UIButton *)button

{
    
}

-(void)verifyPassword:(VerifyPasswordView *)verfiyPassword ShowKeyboardButton:(UIButton *)button
{
    [textField becomeFirstResponder];
}
-(void)verifyPassword:(VerifyPasswordView *)verfiyPassword HideKeyboardButton:(UIButton *)button
{
    [textField resignFirstResponder];
}


-(void)verifyPassword:(VerifyPasswordView *)verfiyPassword forgetPassword:(UIButton *)button
{
    [textField resignFirstResponder];
    
    [UIView animateWithDuration:0.5 animations:^{
        
        PasswordView.frame = CGRectMake(0, SCREE_H, SCREE_W, SCREE_H);
        
    } completion:^(BOOL finished) {
        
        [self freed];
        
        if (_callback) {
            
            _callback(@"");
        }
        
        [_delegate popUpViewForgetPassWord];
        
    }];

}
-(void)changePayMentControl
{
    [UIView animateWithDuration:0.3 animations:^{
        paymentView.frame = CGRectMake(0, SHOW_HEIGHT, SCREE_W, SCREE_H);
    } completion:^(BOOL finished) {
        
    }];
}
-(void)loadRedWalletView
{
    
    redwalletView  = [[ChangeVouchersView alloc] initWithFrame:CGRectMake(SCREE_W, SHOW_HEIGHT, SCREE_W, SCREE_H)];
    
    [self addSubview:redwalletView];
}

-(void)loadPayMentViewWith:(NSMutableDictionary*)dict
{
    paymentView = [[PayMentView alloc] initWithFrame:CGRectMake(SCREE_W, SHOW_HEIGHT, SCREE_W, SCREE_H)];
    [paymentView setDisPlayViewWith:dict];
    paymentView.backgroundColor = [UIColor whiteColor];
    paymentView.delegate = self;
    [self addSubview:paymentView];
}

-(void)payMent:(PayMentView*)payView didClickedBackButton:(UIButton*)button
{

    [UIView animateWithDuration:0.3 animations:^{
        paymentView.frame = CGRectMake(SCREE_W, SHOW_HEIGHT, SCREE_W, SCREE_H);
    } completion:^(BOOL finished) {
        [textField becomeFirstResponder];
    }];

}

-(void)payMent:(PayMentView *)payView didClickedSelectPaymentButton:(NSMutableDictionary *)dict

{
    [PasswordView setDisPlayViewWith:dict];
    [UIView animateWithDuration:0.3 animations:^{
        paymentView.frame = CGRectMake(SCREE_W, SHOW_HEIGHT, SCREE_W, SCREE_H);
    } completion:^(BOOL finished) {
        [textField becomeFirstResponder];
    }];
}

-(void)payMent:(PayMentView *)payView addBankCardWith:(NSMutableDictionary *)dict
{
//    [self addBankCardClosedWithDict:dict];
    
    
    [textField resignFirstResponder];
    
    [UIView animateWithDuration:0.5 animations:^{
        
        PasswordView.frame = CGRectMake(0, SCREE_H, SCREE_W, SCREE_H);
        
    } completion:^(BOOL finished) {
        
        [self freed];
        
        if (_callback) {
            
            _callback(@"");
        }
        
        [_delegate AddBankCardWith:dict];
        
    }];
  
}

-(void)addBankCardClosedWithDict:(NSDictionary*)dict
{
    [textField resignFirstResponder];
    
    [UIView animateWithDuration:0.5 animations:^{
        
    PasswordView.frame = CGRectMake(0, SCREE_H, SCREE_W, SCREE_H);
        
    } completion:^(BOOL finished) {
        
        [self freed];

        if (_callback) {
            
                _callback(@"");
            }
        
        [_delegate AddBankCardWith:dict];
        
    }];
 }



-(void)test

{
    [UIView animateWithDuration:1.0 animations:^{
        
    } completion:^(BOOL finished) {
        
    }];
}
-(void)backredwalletButton:(UIButton*)button
{
}
-(void)backpaymentButton:(UIButton*)button
{
    
    [UIView animateWithDuration:0.5 animations:^{
        paymentView.frame = CGRectMake(SCREE_W, SHOW_HEIGHT, SCREE_W, SCREE_H);
    } completion:^(BOOL finished) {
    }];
}
-(void)rising
{
    [self registerForKeyboardNotifications];
    [UIView animateWithDuration:0.5 animations:^{
        PasswordView.frame = CGRectMake(0, SHOW_HEIGHT, SCREE_W, SCREE_H);
        paymentView.frame = CGRectMake(SCREE_W, SHOW_HEIGHT, SCREE_W, SCREE_H);
    } completion:^(BOOL finished) {
        [textField becomeFirstResponder];
     }];
}
-(void)closed
{
    [self CallBackServer];
    [textField resignFirstResponder];
    [UIView animateWithDuration:0.5 animations:^{
        PasswordView.frame = CGRectMake(0, SCREE_H, SCREE_W, SCREE_H);
    } completion:^(BOOL finished) {
        [self freed];
        if (_callback) {
            _callback(@"");
    }
    }];
}

-(void)freed
{
    [_delegate closedCashRegister];
    [self removeFromSuperview];
    [PasswordView removeFromSuperview];
    [self removeForboardNotifications];
    
}


-(void)CallBackServer{
     NSDictionary*dict = [NSDictionary dictionaryWithObject:[NSString stringWithFormat:@"%@",_orderNo] forKey:@"orderNo"];
    [BFReqAPI CashRegisterCallBackServerPostOrgetData:dict block:^(id responseObj, NSError *error) {
        
    }];
    
}
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    _keyboard.keyBoardNumberStatus = @"0";
    _keyboard.keyboardstytle = KeyboardstytlePassword;
    return YES;
}

-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedButton:(UIButton *)button WithText:(UITextField *)textfield
{
    [PasswordView verifyPassword:nil didClickedEnterButton:button];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateButton:(UIButton *)button WithText:(UITextField *)textfield
{
    [PasswordView verifyPassword:nil didClickedDeleteButton:button];
}
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateFinished:(UIButton *)button WithText:(UITextField *)textfield
{

}
-(void)button:(UIButton*)button
{
    [self closed];
}

- (void) registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]  addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardWillHideNotification object:nil];
}
-(void)removeForboardNotifications
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

- (void) keyboardWasShown:(NSNotification *) notif
{
    NSDictionary* info = [notif userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    CGFloat height = kbSize.height;
    NSLog(@"keyboardHeight  = %f",height);
    CGFloat moveHegiht = height - (SCREE_H - 321.25);
    NSLog(@"moveHegiht %f",moveHegiht);
    if (moveHegiht>0) {
        PasswordView.frame = CGRectMake(0, SHOW_HEIGHT - moveHegiht, SCREE_W, SCREE_H);
    }
}
- (void) keyboardWasHidden:(NSNotification *) notif
{
     PasswordView.frame = CGRectMake(0, SHOW_HEIGHT, SCREE_W, SCREE_H);
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    [self rising];
}
-(void)loadNet
{
    [_delegate determineWhetherOpenCashRegister];
}
-(void)loadPopupViewFailWithFailStr:(NSString*)str
{
    [_delegate failtoOpenTheCashRegisterWithStr:str];
}
-(void)openPopUpView:(PopUpView *)popUpView Sucessful:(void (^)(NSDictionary *))Sucessful failure:(void (^)(NSString *))failure
{
    
}

-(void)requestOrderNomberWithDict:(NSDictionary*)dict
{
    [BFReqAPI CashRegisterGetOrderNomberFromServerWithParameters:dict block:^(id responseObj, NSError *error) {
        if (responseObj != nil) {
            if (ERROR_CODE==1) {
                NSDictionary *obj = responseObj[@"obj"];
                NSString*orderNo =         responseObj[@"obj"][@"order_id"];//会员ID
                NSString*businessType =    responseObj[@"obj"][@"businessType"];//交易号
                NSString*amount =          responseObj[@"obj"][@"buy_amount"];//业务类型
                NSString*amountEncrypt =   responseObj[@"obj"][@"desEncrypt"];//金额
                NSString*createTime =      responseObj[@"obj"][@"create_time"];//金额加密//&productName=%@
                NSString*productName =     responseObj[@"obj"][@"product_name"];
                NSString*product_id =      responseObj[@"obj"][@"product_id"];
                NSDictionary*jsonDict = [NSDictionary dictionaryWithObjectsAndKeys:orderNo,@"orderNo",businessType,@"businessType",amount,@"amount",amountEncrypt,@"amountEncrypt",createTime,@ "createTime",productName,@"productName",product_id,@"productId" ,nil];
                [BFReqAPI AskingWhetherToOpenTheCashRegisterForServerWithParameters:jsonDict block:^(id responseObj, NSError *error) {
                    if (ERROR_CODE == 1) {
                        [[NSUserDefaults standardUserDefaults] setObject:obj[@"order_id"] forKey:@"sy_order_id"];
                        NSMutableDictionary*mutableDcit = [NSMutableDictionary dictionaryWithDictionary:jsonDict];
                        [[CashRegisterLocationCache sharedManager] saveCashRegisterCacheDict:mutableDcit];
                        NSLog(@"jsonDict = %@",responseObj);
                        [self formattingData:responseObj];
                        [self loadNet];
                    }
                 }];
            }else
            {
                if (ERROR_CODE == -10) {
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:CROWD_OUT_MESSAGE delegate:self cancelButtonTitle:@"重新登录" otherButtonTitles:nil, nil];
                    [alert show];
                    alert.tag = 500;
                }else
                {
                    [UIAlertView showWithMessage:responseObj[@"message"] delegate:nil];
                }
            }
            
        }
    }];
}

-(void)formattingData:(NSDictionary*)dict
{
    NSArray*payList = dict[@"obj"][@"payList"];//payList
   
    NSMutableArray*banksCardarray = [NSMutableArray array];//银行卡
    
    NSMutableArray*redWalletarray = [NSMutableArray array];//红包
    
    NSDictionary*safeCardDict =     [NSDictionary dictionary];//安全卡
    
    NSDictionary*balanceDict =      [NSDictionary dictionary];//余额
    
    NSMutableDictionary*originalDidct = [NSMutableDictionary dictionary];//原始的数据
    
    NSDictionary*defaultRedWalletarray =  [NSDictionary dictionary];//默认红包
    
    NSDictionary*defaultBankCard =  [NSDictionary dictionary];//默认的银行卡
    
    NSDictionary*defaultBalance =   [NSDictionary dictionary];//默认余额支付
    
    NSMutableDictionary*displayDataDict = [NSMutableDictionary dictionary];
    
    NSMutableArray*deprecatedBankCard = [NSMutableArray  array];//银行卡
    
    NSMutableArray*deprecatedRedWallet = [NSMutableArray array];//红包
    
    NSMutableArray*deprecatedRedBalance = [NSMutableArray array];
    
    NSMutableDictionary*deprecatedDataDict = [NSMutableDictionary dictionary];
    
    for (NSDictionary*d in payList) {
        
        if ([d[@"payType"] isEqualToString:@"2"]) {
            NSMutableDictionary*dd = [NSMutableDictionary dictionaryWithDictionary:d];
            
//            [dd setObject:@"11" forKey:@"11"];
            [redWalletarray addObject:dd];//红包
        }
        else if ([d[@"payType"] isEqualToString:@"1"])
        {
            balanceDict = [NSDictionary dictionaryWithDictionary:d];//余额
        }
        else
        {
            [banksCardarray addObject:d];
        }
    }
    for(NSDictionary*d in banksCardarray)
    {
        if ([d[@"payType"] isEqualToString:@"301"]) {
            
            safeCardDict = [NSDictionary dictionaryWithDictionary:d];//安全卡
        }
    }
    for (NSDictionary*d in redWalletarray) {
        
        if ([[d[@"isDefault"] stringValue] isEqualToString:@"1"]) {
            
            defaultRedWalletarray = [NSDictionary dictionaryWithDictionary:d];//匹配的红包
        }
        else
        {
            [deprecatedRedWallet addObject:d];
        }

    }
    
    for (NSDictionary*d in banksCardarray ) {
        
        if ([[d[@"defaultBankCard"] stringValue] isEqualToString:@"1"]) {
            
            defaultBankCard = [NSDictionary dictionaryWithDictionary:d];//匹配的银行卡
        }
        else
        {
            [deprecatedBankCard addObject:d];
        }
    }

    if ([[balanceDict[@"isDefault"] stringValue] isEqualToString:@"1"]) {
        defaultBalance = [NSDictionary dictionaryWithDictionary:balanceDict];// 默认匹配
    }
    else
    {
        [deprecatedRedBalance addObject:defaultBalance];
    }
    
    NSLog(@"banksCardarray = %@",banksCardarray);
    
    NSLog(@"redWalletarray = %@",redWalletarray);
    
    NSLog(@"safeCardDict = %@",safeCardDict);
    
    NSLog(@"balanceDict = %@",balanceDict);
    
    NSLog(@"defaultRedWalletarray = %@",defaultRedWalletarray);
    
    NSLog(@"defaultBalance = %@",defaultBalance);
    
    
    NSLog(@"deprecatedBankCard = %@",deprecatedBankCard);
    
    NSLog(@"deprecatedBankCard = %@",deprecatedRedWallet);
    
    NSLog(@"deprecatedRedBalance = %@",deprecatedRedBalance);
    
    NSMutableDictionary*tempoary = [NSMutableDictionary dictionary];
    
    if (defaultBalance.count) {
        NSLog(@"默认使用余额支付");
        
        [tempoary setObject:defaultBalance forKey:@"dfbalance"];
    }
    if (defaultRedWalletarray.count) {
        NSLog(@"默认使用红包支付");
        
        [tempoary setObject:defaultRedWalletarray forKey:@"dfredwallet"];
    }
    
    if (defaultBankCard.count) {

        [tempoary setObject:defaultBankCard forKey:@"defaultbankcard"];
    }
    if (safeCardDict.count) {
        
        [tempoary setObject:safeCardDict forKey:@"safecard"];
    }
    
    NSLog(@"temp= %@",tempoary);
    
    [displayDataDict setObject:tempoary forKey:@"payment"];
    
    [displayDataDict setObject:dict[@"obj"][@"amount"] forKey:@"amount"];
    [displayDataDict setObject:dict[@"obj"][@"businessType"] forKey:@"businessType"];
    [displayDataDict setObject:dict[@"obj"][@"memberId"] forKey:@"memberId"];
    [displayDataDict setObject:dict[@"obj"][@"orderNo"] forKey:@"orderNo"];
    NSLog(@"displayDataDict = %@",displayDataDict);//显示
    
    
    NSString*str = displayDataDict[@"payment"][@"safecard"][@"payType"];
    
    [deprecatedDataDict setObject:deprecatedBankCard forKey:@"deprecatedBankCard"];
    [deprecatedDataDict setObject:deprecatedRedBalance forKey:@"deprecatedRedBalance"];
    [deprecatedDataDict setObject:deprecatedRedWallet forKey:@"deprecatedRedWallet"];
    
    NSLog(@"deprecatedDataDict = %@",deprecatedDataDict);
    
    [originalDidct setObject:banksCardarray forKey:@"bankCard"];
    [originalDidct setObject:redWalletarray forKey:@"redWallert"];
    [originalDidct setObject:balanceDict    forKey:@"balance"];
    [originalDidct setObject:dict[@"obj"][@"amount"] forKey:@"amount"];

    NSLog(@"originalDidct = %@",originalDidct);
    
    [self loadShowView:displayDataDict];
    [self loadPayMentViewWith:originalDidct];
//    [self loadRedWalletView];

}
-(void)requestOpenCashRegister
{
    
}
@end

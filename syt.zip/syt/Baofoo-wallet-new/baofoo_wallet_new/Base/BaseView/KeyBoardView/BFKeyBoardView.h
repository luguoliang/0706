//
//  BFKeyBoardView.h
//  keyboardtest
//
//  Created by 路国良 on 15/5/8.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BFKeyBoardView;

@protocol BFKeyBoardViewDelegate <NSObject>
@required
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedButton:(UIButton*)button WithText:(UITextField*)textfield;
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateButton:(UIButton*)button WithText:(UITextField*)textfield;
-(void)keyBoard:(BFKeyBoardView *)keyBoard didClickedDelegateFinished:(UIButton*)button WithText:(UITextField*)textfield;
@end

typedef enum{
    KeyboardstytlePhoneNumber = 0,
    KeyboardstytleMoney = 1,
    KeyboardstytlePassword = 2,
    KeyboardstytleCardID = 3
}KeyBoardStytle;

@interface BFKeyBoardView : UIView
@property(nonatomic,assign)id<BFKeyBoardViewDelegate> delegate;
@property (nonatomic, assign) KeyBoardStytle keyboardstytle;
@property (weak, nonatomic) IBOutlet UIButton *zeroButton;
@property (weak, nonatomic) IBOutlet UIButton *oneButton;
@property (weak, nonatomic) IBOutlet UIButton *twoButton;
@property (weak, nonatomic) IBOutlet UIButton *thereButton;
@property (weak, nonatomic) IBOutlet UIButton *fourButton;
@property (weak, nonatomic) IBOutlet UIButton *fiveButton;
@property (weak, nonatomic) IBOutlet UIButton *sixButton;
@property (weak, nonatomic) IBOutlet UIButton *sevenButton;
@property (weak, nonatomic) IBOutlet UIButton *eightButton;
@property (weak, nonatomic) IBOutlet UIButton *nineButton;
@property (weak, nonatomic) IBOutlet UIButton *mydeleteButton;
@property (weak, nonatomic) IBOutlet UIButton *alphanumericbutton;
- (IBAction)clickButton:(id)sender;
- (IBAction)mydeletebutton:(id)sender;
- (IBAction)myfinishedButton:(id)sender;
-(void)setKeyboardstytle:(KeyBoardStytle)keyboardstytle;
-(void)setKeyBoardWith:(UITextField *)mytextfield;
@property (weak, nonatomic) IBOutlet UIImageView *myImageView;
@property(nonatomic,copy)NSString*keyBoardNumberStatus;

@end

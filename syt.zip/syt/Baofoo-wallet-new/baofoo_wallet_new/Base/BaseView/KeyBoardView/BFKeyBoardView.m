//
//  BFKeyBoardView.m
//  keyboardtest
//
//  Created by 路国良 on 15/5/8.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "BFKeyBoardView.h"
@interface BFKeyBoardView()
{
    UITextField*_globalTextField;
    NSArray*_buttonArray;
    NSString*status;
}
@end
@implementation BFKeyBoardView
-(void)awakeFromNib
{
    _buttonArray = [NSArray arrayWithObjects:_zeroButton,_oneButton,_twoButton,_thereButton,_fourButton,_fiveButton,_sixButton,_sevenButton,_eightButton,_nineButton, nil];
    for (UIButton*button in _buttonArray) {
        [button setImage:[UIImage imageNamed:@"keyboard_selecteight.png"] forState:UIControlStateHighlighted];
    }
    [_mydeleteButton setImage:[UIImage imageNamed:@"keyboard_selecteight.png"] forState:UIControlStateHighlighted];
    [_mydeleteButton setBackgroundImage:[UIImage imageNamed:@"keyboardImage_delegate.png"] forState:UIControlStateNormal];
    [_mydeleteButton setBackgroundImage:[UIImage imageNamed:@"keyBoardView_press.png"] forState:UIControlStateSelected];
    _myImageView.image = [UIImage imageNamed:@"keyboard_return.png"];
}
-(void)setKeyBoardWith:(UITextField *)mytextfield
{
    _globalTextField = mytextfield;
    status = self.keyBoardNumberStatus;
    NSArray*array = [self randomlDigital];
    for (NSInteger i = 0; i< [array  count]; i++) {
        [[_buttonArray objectAtIndex:i] setTitle:[array objectAtIndex:i] forState:UIControlStateNormal];
    }
//    [self setKeyboardstytle:mytextfield.keyboard];
}
-(NSMutableArray*)randomlDigital
{
    NSArray *temp = [NSArray arrayWithObjects:@"1",@"2", @"3", @"4", @"5", @"6", @"7", @"8",@"9",@"0",nil];
    NSMutableArray *tempArray = [[NSMutableArray alloc] initWithArray:temp];
    NSMutableArray *resultArray = [[NSMutableArray alloc] init];
    NSInteger i;
    NSInteger count = temp.count;
    for (i = 0; i < count; i ++) {
        int index = arc4random() % (count - i);
        [resultArray addObject:[tempArray objectAtIndex:index]];
        [tempArray removeObjectAtIndex:index];
    }
    if ([_keyBoardNumberStatus isEqualToString:@"0"]) {
        
        resultArray = [NSMutableArray arrayWithArray:temp];
        return resultArray;
    }
    else
    {
       return resultArray;
    }
    return tempArray;
    return resultArray;
}
-(void)setKeyboardstytle:(KeyBoardStytle)keyboardstytle
{
     switch (keyboardstytle) {
        case 0:
            _alphanumericbutton.enabled = NO;
            _alphanumericbutton.alpha = 0.0;
            [_alphanumericbutton setTitle:@"" forState:UIControlStateNormal];
            NSLog(@"电话号码");
            break;
        case 1:
            NSLog(@"金额");
            _alphanumericbutton.enabled = YES;
            _alphanumericbutton.alpha = 1.0;
            [_alphanumericbutton setTitle:@"." forState:UIControlStateNormal];
            break;
        case 2:
            NSLog(@"密码");
            _alphanumericbutton.enabled = NO;
            _alphanumericbutton.alpha = 0.0;
            [_alphanumericbutton setTitle:@"" forState:UIControlStateNormal];
            break;
        case 3:
            NSLog(@"身份证号");
            _alphanumericbutton.enabled = YES;
            _alphanumericbutton.alpha = 1.0;
            [_alphanumericbutton setTitle:@"X" forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    
}
- (IBAction)clickButton:(id)sender {
    [_delegate keyBoard:nil didClickedButton:sender WithText:_globalTextField];
}

- (IBAction)mydeletebutton:(id)sender {
    [_delegate keyBoard:nil didClickedDelegateButton:sender WithText:_globalTextField];
}

- (IBAction)myfinishedButton:(id)sender {
    [_delegate keyBoard:nil didClickedDelegateFinished:sender WithText:_globalTextField];
}
@end

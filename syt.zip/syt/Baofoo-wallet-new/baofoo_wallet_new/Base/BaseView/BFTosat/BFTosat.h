//
//  BFTosat.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/12.
//  Copyright © 2016年 BF. All rights reserved.
//

#define Display_duration 2.0f

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


//消息提示框,
@interface BFTosat : NSObject
{
    NSString *contentText;//显示内容
    UIButton *contentView;//显示视图
    CGFloat  showDuration;//显示时间
}

//默认显示方式(居中 时间:2秒)
+ (void)showTosatText:(NSString *)text;

//默认显示方式(居中) showDuration:(显示时间:单位秒)
+ (void)showTosatText:(NSString *)text
         showDuration:(CGFloat)showDuration;

// displayPosition:(显示位置)
+ (void)showTosatText:(NSString *)text
      displayPosition:(CGFloat)displayPosition;

// displayPosition:(显示位置) showDuration:(显示时间:单位秒)
+ (void)showTosatText:(NSString *)text
      displayPosition:(CGFloat)displayPosition
         showDuration:(CGFloat)showDuration;



@end

//
//  BFCustomActionSheetView.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/20.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFCustomActionSheetView.h"

#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0f]

@interface BFCustomActionSheetView ()
{
    NSMutableArray *btnArr;
    NSMutableArray *lineArr;
    
    
    UIView *btnView;//显示按钮的位置
    
    UIButton *clearBtn;//可被点击的上半部分
}
@end

@implementation BFCustomActionSheetView


- (instancetype)initWithArray:(NSArray *)titles
{
    if (self = [super init]) {
        
        btnArr = [[NSMutableArray alloc] initWithCapacity:0];
        lineArr = [[NSMutableArray alloc] initWithCapacity:0];
        
        
        btnView = [[UIView alloc] init];
        btnView.backgroundColor = UIColorFromRGB(0xf3f3f3);
        [self addSubview:btnView];
        
        for (NSString *title in titles) {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.backgroundColor = [UIColor whiteColor];
            [button setBackgroundImage:[UIImage createImageWithColor:UIColorFromRGB(0xf3f3f3)] forState:UIControlStateHighlighted];
            [button setTitle:title forState:UIControlStateNormal];
            [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [button setTitleColor:UIColorFromRGB(0x1b9af7) forState:UIControlStateSelected];
            button.titleLabel.font = [UIFont systemFontOfSize:17.0f];
            [button addTarget:self action:@selector(clickedButtonAtIndex:) forControlEvents:UIControlEventTouchUpInside];
            [btnArr addObject:button];
            [btnView addSubview:button];
        }
        
        for (int i=0; i<titles.count-1; i++) {
            UILabel *line = [[UILabel alloc] init];
            line.backgroundColor = UIColorFromRGB(0xf3f3f3);
            [btnView addSubview:line];
            
            [lineArr addObject:line];
        }
        
        UIButton *cancleBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        cancleBtn.backgroundColor = [UIColor whiteColor];
        [cancleBtn setBackgroundImage:[UIImage createImageWithColor:UIColorFromRGB(0xdfdfdf)] forState:UIControlStateHighlighted];
        [cancleBtn setTitle:@"取消" forState:UIControlStateNormal];
        [cancleBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        cancleBtn.titleLabel.font = [UIFont systemFontOfSize:16.0f];
        [cancleBtn addTarget:self action:@selector(clickedButtonAtIndex:) forControlEvents:UIControlEventTouchUpInside];
        [btnArr addObject:cancleBtn];
        [btnView addSubview:cancleBtn];
        
        clearBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [clearBtn setBackgroundColor:[UIColor clearColor]];
        [clearBtn addTarget:self action:@selector(removeShowView) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:clearBtn];
    }
    return self;
}

- (void)showInView:(UIWindow *)window
{
    [window addSubview:self];
    [window endEditing:YES];
    self.frame = window.frame;
    self.backgroundColor = [UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:0.4f];
    [self setupFrame];
    [self showView];
}
- (void)setupFrame
{
    CGFloat btnHeight = 0.0f;
    if (self.frame.size.height==480.0f) {
        btnHeight = 40.0f;
    }else
    {
        btnHeight = 45.0f;
    }
    CGFloat btnViewHeight = btnArr.count*btnHeight+5.0f;
    btnView.frame = CGRectMake(0.0f, self.frame.size.height, self.frame.size.width, btnViewHeight);
    clearBtn.frame = CGRectMake(0.0f, 0.0f, self.frame.size.width, self.frame.size.height-btnViewHeight);
    
    for (int i=1; i<=btnArr.count; i++) {
        UIButton *button = btnArr[i-1];
        
        
        if (i<btnArr.count) {
            
            button.frame = CGRectMake(0.0f, btnHeight*(i-1), btnView.frame.size.width, btnHeight);
            
        }else
        {
            button.frame = CGRectMake(0.0f, btnHeight*(i-1)+5.0f, btnView.frame.size.width, btnHeight);
        }
        
        if (i < btnArr.count - 1) {
            UILabel *line = lineArr[i-1];
            line.frame = CGRectMake(0.0f, btnHeight*i, btnView.frame.size.width, 0.5f);
        }
    }
}
//动画弹出展示view
- (void)showView
{
    
    [UIView animateWithDuration:0.5 animations:^{
        btnView.frame = CGRectMake(0.0f, self.frame.size.height-(btnView.frame.size.height), self.frame.size.width, btnView.frame.size.height);
    } completion:^(BOOL finished) {
        
    }];
}
- (void)removeShowView
{
    [UIView animateWithDuration:0.25 animations:^{
        btnView.frame = CGRectMake(0.0f, self.frame.size.height, self.frame.size.width, btnView.frame.size.height);
        self.backgroundColor = [UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:0.0f];
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

- (void)clickedButtonAtIndex:(UIButton *)button
{
    NSUInteger currentIndex = [btnArr indexOfObject:button];
    
    if (currentIndex < btnArr.count-1) {
        for (UIButton *clickBtn in btnArr) {
            clickBtn.selected = NO;
        }
        button.selected = YES;
    }
    
    [self removeShowView];
    if ([self.delegate respondsToSelector:@selector(clickedSheetButtonAtIndex:)]) {
        [self.delegate clickedSheetButtonAtIndex:currentIndex];
    }
    
}


@end

//
//  BFCustomActionSheetView.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/20.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@protocol CustomActionSheetDelegate <NSObject>

@optional
- (void)clickedSheetButtonAtIndex:(NSUInteger)btnIndex;

@end

@protocol CustomActionSheetDelegate ;

@interface BFCustomActionSheetView : UIView

@property(nonatomic,assign)id<CustomActionSheetDelegate>delegate;

- (instancetype)initWithArray:(NSArray *)titles;

- (void)showInView:(UIWindow *)view;

@end

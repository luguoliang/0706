//
//  BFReqAPI+Account.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/20.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI.h"

@interface BFReqAPI (Account)
// 补全信息
+ (void)reqComplementedCustomerInfoWithParams:(NSDictionary *)params
                                        block:(APIResponseBlock)block;
/**
 *  上传头像
 *
 *  @param memberId
 *  @param image
 *  @param block    
 */
+ (void)uploadImageWithMemberId:(NSString *)memberId
                          image:(UIImage *)image
                          block:(APIResponseBlock)block;
/**
 *  下载头像
 *
 *  @param url
 *  @param success
 *  @param failue
 */
+ (void)getImageWithUrl:(NSString *)url
                success:(void (^)(UIImage *image))success
                 failue:(void (^)(NSError *error))failue;
/**
 *  初级实名认证
 *
 *  @param params
 *  @param block
 */
+ (void)reqPrimaryRealNameWithParams:(NSDictionary *)params block:(APIResponseBlock)block;
/**
 *  上传认证图片
 *
 *  @return
 */
+ (void)uploadImageWithcardFont:(UIImage *)cardFontImage
                       cardBack:(UIImage *)cardBackImage
                          block:(APIResponseBlock)block;
@end

//
//  BFTosat.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/12.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFTosat.h"
#import "BFStringTool.h"
@interface BFTosat (private)

- (id)initWithText:(NSString *)text;
- (void)setDuration:(CGFloat)duration;

- (void)dismissToast;
- (void)toastTaped:(UIButton *)sender;

- (void)showAnimation;
- (void)hideAnimation;

- (void)show;
- (void)showDisplayPosition:(CGFloat)displayPosition;

@end

@implementation BFTosat
- (id)initWithText:(NSString *)text{
    if (self = [super init]) {
        
        contentText = [text copy];
        
        CGSize textSize =  [BFStringTool sizeOfString:contentText Size:CGSizeMake(280, MAXFLOAT) Font:BF_Font_14];
        
        UILabel *textLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, textSize.width + 12, textSize.height + 12)];
        textLabel.backgroundColor = [UIColor clearColor];
        textLabel.textColor = [UIColor whiteColor];
        textLabel.textAlignment = NSTextAlignmentCenter;
        textLabel.font = BF_Font_14;
        textLabel.text = contentText;
        textLabel.numberOfLines = 0;
        
        contentView = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, textLabel.frame.size.width, textLabel.frame.size.height)];
        contentView.layer.cornerRadius = 5.0f;
        contentView.layer.borderWidth = 1.0f;
        contentView.layer.borderColor = [[UIColor grayColor] colorWithAlphaComponent:0.5].CGColor;
        contentView.backgroundColor = UIColorRgbAlpha(0.2f, 0.2f, 0.2f, 0.75f);
        [contentView addSubview:textLabel];
        contentView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [contentView addTarget:self
                        action:@selector(toastTaped:)
              forControlEvents:UIControlEventTouchDown];
        contentView.alpha = 0.0f;
        
        showDuration = Display_duration;
        
    }
    return self;
}

- (void)dismissToast{
    [contentView removeFromSuperview];
}

- (void)toastTaped:(UIButton *)sender{
    [self hideAnimation];
}

- (void)setDuration:(CGFloat)duration{
    showDuration = duration;
}

- (void)showAnimation{
    [UIView beginAnimations:@"show" context:NULL];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
    [UIView setAnimationDuration:0.3];
    contentView.alpha = 1.0f;
    [UIView commitAnimations];
}

- (void)hideAnimation{
    [UIView beginAnimations:@"hide" context:NULL];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(dismissToast)];
    [UIView setAnimationDuration:0.3];
    contentView.alpha = 0.0f;
    [UIView commitAnimations];
}

- (void)show{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    contentView.center = window.center;
    [window  addSubview:contentView];
    [self showAnimation];
    [self performSelector:@selector(hideAnimation) withObject:nil afterDelay:showDuration];
}

- (void)showDisplayPosition:(CGFloat)displayPosition{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    contentView.center = CGPointMake(window.center.x, displayPosition + contentView.frame.size.height/2);
    [window  addSubview:contentView];
    [self showAnimation];
    [self performSelector:@selector(hideAnimation) withObject:nil afterDelay:showDuration];
}

+ (void)showTosatText:(NSString *)text{
    [BFTosat showTosatText:text showDuration:Display_duration];
}

+ (void)showTosatText:(NSString *)text
         showDuration:(CGFloat)showDuration{
    BFTosat *toast = [[BFTosat alloc] initWithText:text];
    [toast setDuration:showDuration];
    [toast show];
}

+ (void)showTosatText:(NSString *)text
      displayPosition:(CGFloat)displayPosition{
    [BFTosat showTosatText:text displayPosition:displayPosition showDuration:Display_duration];
}

+ (void)showTosatText:(NSString *)text
      displayPosition:(CGFloat)displayPosition
         showDuration:(CGFloat)showDuration{
    BFTosat *toast = [[BFTosat alloc] initWithText:text];
    [toast setDuration:showDuration];
    [toast showDisplayPosition:displayPosition];
}

- (void)dealloc{
    contentView = nil;
    contentText = nil;
}

@end

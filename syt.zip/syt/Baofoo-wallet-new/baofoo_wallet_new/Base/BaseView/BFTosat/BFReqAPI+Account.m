//
//  BFReqAPI+Account.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/20.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI+Account.h"
#import "Base64.h"
#import "AFNetWorking.h"
#import "BFReqHandle.h"
#import <SDWebImage/UIImage+MultiFormat.h>

@implementation BFReqAPI (Account)
// 补全信息
+ (void)reqComplementedCustomerInfoWithParams:(NSDictionary *)params block:(APIResponseBlock)block
{
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:nil];
    NSString *encryption = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *baseEncryption = [encryption base64EncodedString];
    NSString *encryptionStr = [RSAEntryPtion stringWithRSAEncryPtion:baseEncryption];
    
    NSDictionary *postDict = @{@"v":@"2.0",@"sp":encryptionStr};
    
    //业务层参数
    [BFReqAPI reqWithParams:postDict andExURL:complete_accountInfo block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

/// 上传图片
+ (void)uploadImageWithMemberId:(NSString *)memberId
                          image:(UIImage *)image
                          block:(APIResponseBlock)block{
  
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:BFWalletBaseURL]];
    [manager POST:account_uploadHeadImage parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        NSData *imageData = UIImageJPEGRepresentation(image, 1);
        NSString *fileName = [NSString stringWithFormat:@"%@.png", memberId];
        
        // 上传图片，以文件流的格式
        [formData appendPartWithFileData:imageData name:@"headImage" fileName:fileName mimeType:@"image/jpeg"];
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        block(responseObject,operation.error);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        block(operation.responseObject,operation.error);
    }];
}

+ (void)getImageWithUrl:(NSString *)url
                success:(void (^)(UIImage *image))success
                 failue:(void (^)(NSError *error))failue
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager POST:url parameters:[BFReqHandle appendBaseParams:@{}] success:^(NSURLSessionDataTask *task, id responseObject) {
        UIImage *responseImage = [UIImage sd_imageWithData:responseObject];
        success(responseImage);
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        failue(error);
    }];
}

// 初级实名认证
+ (void)reqPrimaryRealNameWithParams:(NSDictionary *)params block:(APIResponseBlock)block{
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:nil];
    NSString *encryption = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *baseEncryption = [encryption base64EncodedString];
    NSString *encryptionStr = [RSAEntryPtion stringWithRSAEncryPtion:baseEncryption];
    
    NSDictionary *postDict = @{@"v":@"2.0",@"sp":encryptionStr};
    
    //业务层参数
    [BFReqAPI reqWithParams:postDict andExURL:security_verifyLowerAuthen block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
// 上传认证图片
+ (void)uploadImageWithcardFont:(UIImage *)cardFontImage
                       cardBack:(UIImage *)cardBackImage
                          block:(APIResponseBlock)block
{
    
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:BFWalletBaseURL]];
    [manager POST:security_verifyHighAuthen parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        NSData *cardFontData = UIImageJPEGRepresentation(cardFontImage, 0.5);
        NSString *cardFontName = @"0101010.png";
        [formData appendPartWithFileData:cardFontData name:@"cardFont" fileName:cardFontName mimeType:@"image/jpeg"];
        
        NSData *cardBackData = UIImageJPEGRepresentation(cardBackImage, 0.5);
        NSString *cardBackName = @"0000000.png";
        [formData appendPartWithFileData:cardBackData name:@"cardBack" fileName:cardBackName mimeType:@"image/jpeg"];
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        block(responseObject,operation.error);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        block(operation.responseObject,operation.error);
    }];
}
@end

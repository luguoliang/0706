//
//  BFDeviceTool.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFDeviceTool.h"
#include <sys/types.h>
#include <sys/sysctl.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>
#import "SSKeychain.h"

NSString * const kDeviceUUID = @"com.baofoo.uuid";

@implementation BFDeviceTool


#pragma mark - 设备信息
+ (NSString *)machineName {
    size_t size;
    int nR = sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = (char *)malloc(size);
    nR = sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithCString:machine encoding:NSUTF8StringEncoding];
    free(machine);
    return platform ;
}


+ (NSString *)deviceType{
    
    size_t size;
    int nR = sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = (char *)malloc(size);
    nR = sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithCString:machine encoding:NSUTF8StringEncoding];
    free(machine);
    
    //iPhone
    if ([platform isEqualToString:@"iPhone1,1"]) return @"iPhone 2G";
    if ([platform isEqualToString:@"iPhone1,2"]) return @"iPhone 3G";
    if ([platform isEqualToString:@"iPhone2,1"]) return @"iPhone 3GS";
    if ([platform isEqualToString:@"iPhone3,1"]) return @"iPhone 4";
    if ([platform isEqualToString:@"iPhone3,2"]) return @"iPhone 4";
    if ([platform isEqualToString:@"iPhone3,3"]) return @"iPhone 4";
    if ([platform isEqualToString:@"iPhone4,1"]) return @"iPhone 4S";
    if ([platform isEqualToString:@"iPhone5,1"]) return @"iPhone 5";
    if ([platform isEqualToString:@"iPhone5,2"]) return @"iPhone 5";
    if ([platform isEqualToString:@"iPhone5,3"]) return @"iPhone 5c";
    if ([platform isEqualToString:@"iPhone5,4"]) return @"iPhone 5c";
    if ([platform isEqualToString:@"iPhone6,1"]) return @"iPhone 5s";
    if ([platform isEqualToString:@"iPhone6,2"]) return @"iPhone 5s";
    if ([platform isEqualToString:@"iPhone7,1"]) return @"iPhone 6 Plus";
    if ([platform isEqualToString:@"iPhone7,2"]) return @"iPhone 6";
    
    //iPod
    if ([platform isEqualToString:@"iPod1,1"]) return @"iPod Touch (1 Gen)";
    if ([platform isEqualToString:@"iPod2,1"]) return @"iPod Touch (2 Gen)";
    if ([platform isEqualToString:@"iPod3,1"]) return @"iPod Touch (3 Gen)";
    if ([platform isEqualToString:@"iPod4,1"]) return @"iPod Touch (4 Gen)";
    if ([platform isEqualToString:@"iPod5,1"]) return @"iPod Touch (5 Gen)";
    
    //iPad
    if ([platform isEqualToString:@"iPad1,1"]) return @"iPad";
    if ([platform isEqualToString:@"iPad1,2"]) return @"iPad 3G";
    if ([platform isEqualToString:@"iPad2,1"]) return @"iPad 2 (WiFi)";
    if ([platform isEqualToString:@"iPad2,2"]) return @"iPad 2";
    if ([platform isEqualToString:@"iPad2,3"]) return @"iPad 2 (CDMA)";
    if ([platform isEqualToString:@"iPad2,4"]) return @"iPad 2";
    if ([platform isEqualToString:@"iPad2,5"]) return @"iPad Mini (WiFi)";
    if ([platform isEqualToString:@"iPad2,6"]) return @"iPad Mini";
    if ([platform isEqualToString:@"iPad2,7"]) return @"iPad Mini (GSM+CDMA)";
    if ([platform isEqualToString:@"iPad3,1"]) return @"iPad 3 (WiFi)";
    if ([platform isEqualToString:@"iPad3,2"]) return @"iPad 3 (GSM+CDMA)";
    if ([platform isEqualToString:@"iPad3,3"]) return @"iPad 3";
    if ([platform isEqualToString:@"iPad3,4"]) return @"iPad 4 (WiFi)";
    if ([platform isEqualToString:@"iPad3,5"]) return @"iPad 4";
    if ([platform isEqualToString:@"iPad3,6"]) return @"iPad 4 (GSM+CDMA)";
    
    //
    if ([platform isEqualToString:@"i386"]) return @"Simulator_i386";
    if ([platform isEqualToString:@"x86_64"]) return @"Simulator_X86_64";
    
    return platform;
}

+ (NSString *)deviceName{
    return [[UIDevice currentDevice] name];
}

+ (NSString *)deviceModel{
    return [[UIDevice currentDevice] localizedModel];
}

+ (NSString *)uuid {
    CFUUIDRef uuid = CFUUIDCreate(NULL);
    assert(uuid != NULL);
    CFStringRef uuidStr = CFUUIDCreateString(NULL, uuid);
    [SSKeychain setPassword: [NSString stringWithFormat:@"%@", uuidStr]
                 forService:kDeviceUUID account:@"user"];
    NSString *deviceId = [SSKeychain passwordForService:kDeviceUUID account:@"user"];
    if(deviceId.length-7>0) {
        return [deviceId substringToIndex:deviceId.length-7] ;
    }
    return deviceId ;
}
#pragma mark - 系统信息

+ (NSString *)systemVersion{
    return [[UIDevice currentDevice] systemVersion];
}

+ (CGFloat)systemVersionValue{
    return [[[UIDevice currentDevice] systemVersion] floatValue];
}

#pragma mark - 应用信息

//APP displayname
+ (NSString *)appDisplayname{
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"];
}

//APP 版本信息
+ (NSString *)appVersion{
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
}

//APP 版本Build信息
+ (NSString *)appBuildVersion{
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
}

#pragma mark - SIM运营商信息

//运营商网络类型
+ (NSString *)carrierNetworkType{
    CTTelephonyNetworkInfo *networkInfo = [[CTTelephonyNetworkInfo alloc] init];
    NSString *type = [[NSString alloc] initWithFormat:@"%@", networkInfo.currentRadioAccessTechnology];
    return type;
}

//运营商名字
+ (NSString *)carrierName{
    
    CTTelephonyNetworkInfo *networkInfo = [[CTTelephonyNetworkInfo alloc] init];
    CTCarrier *carrier = networkInfo.subscriberCellularProvider;
    return carrier.carrierName;
}

#pragma mark - 检查是否越狱(装有Cydia)

+ (BOOL)isDeviceJailBreak {
#if TARGET_IPHONE_SIMULATOR
    return NO;
#else
    NSURL* url = [NSURL URLWithString:@"cydia://package/com.example.package"];
    return [[UIApplication sharedApplication] canOpenURL:url];
#endif
}


@end

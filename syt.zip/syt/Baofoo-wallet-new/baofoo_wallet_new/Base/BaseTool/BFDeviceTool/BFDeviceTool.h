//
//  BFDeviceTool.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>


#define DEVICETYPE ([BFDeviceTool deviceType])
#define NavgationBarHeight ((_iOS7_Or_Later_) ? 64.0 : 44.0)
//系统版本
#define SYSTEMVERSION ([BFDeviceTool systemVersion])
#define _iOS5_          (([BFDeviceTool systemVersionValue] >= 5.0f && [BFDeviceTool systemVersionValue] < 6.0f) ? YES : NO)\
#define _iOS5_Or_Later_ (([BFDeviceTool systemVersionValue] >= 5.0f) ? YES : NO)
#define _iOS6_          (([BFDeviceTool systemVersionValue] >= 6.0f && [BFDeviceTool systemVersionValue] < 7.0f) ? YES : NO)
#define _iOS6_Or_Later_ (([BFDeviceTool systemVersionValue] >= 6.0f) ? YES : NO)
#define _iOS7_          (([BFDeviceTool systemVersionValue] >= 7.0f && [BFDeviceTool systemVersionValue] < 8.0f) ? YES : NO)
#define _iOS7_Or_Later_ (([BFDeviceTool systemVersionValue] >= 7.0f) ? YES : NO)
#define _iOS8_          (([BFDeviceTool systemVersionValue] >= 8.0f && [BFDeviceTool systemVersionValue] < 9.0f) ? YES : NO)
#define _iOS8_Or_Later_ (([BFDeviceTool systemVersionValue] >= 8.0f) ? YES : NO)

//设备尺寸
#define _iPhone4_ (CGSizeEqualToSize(CGSizeMake(320, 480), [UIScreen mainScreen].bounds.size))
#define _iPhone5_ (CGSizeEqualToSize(CGSizeMake(320, 568), [UIScreen mainScreen].bounds.size))
#define _iPhone6_ (CGSizeEqualToSize(CGSizeMake(375, 667), [UIScreen mainScreen].bounds.size))
#define _iPhone6P_ (CGSizeEqualToSize(CGSizeMake(414, 736), [UIScreen mainScreen].bounds.size))

//屏幕尺寸
#define ScreenSize ([UIScreen mainScreen].bounds.size) //屏幕宽高
#define ScreenWidth ([UIScreen mainScreen].bounds.size.width) //屏幕宽度
#define ScreenHeight ([UIScreen mainScreen].bounds.size.height) //屏幕高度

//APP 信息
#define APPVERSION ([BFDeviceTool appVersion])
#define APPBUILDVERSION ([BFDeviceTool appBuildVersion])

@interface BFDeviceTool : NSObject

#pragma mark - 设备信息
+ (NSString *)machineName ;
+ (NSString *)deviceType;
+ (NSString *)deviceName;
+ (NSString *)deviceModel;
+ (NSString *)uuid;

#pragma mark - 系统信息

+ (NSString *)systemVersion;

+ (CGFloat)systemVersionValue;

#pragma mark - 应用信息

/**
 *  APP displayname
 */
+ (NSString *)appDisplayname;

/**
 *  APP 版本信息
 */
+ (NSString *)appVersion;

/**
 *  APP 版本Build信息
 */
+ (NSString *)appBuildVersion;

#pragma mark - SIM运营商信息

/**
 *  运营商网络类型
 */
+ (NSString *)carrierNetworkType;

/**
 *  运营商名字
 */
+ (NSString *)carrierName;

#pragma mark - 检查是否越狱(装有Cydia)
/**
 *  检查是否越狱
 */
+ (BOOL)isDeviceJailBreak;



@end

//
//  BFFileTool.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/24.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFFileTool.h"

@implementation BFFileTool

#pragma mark - 文件操作
//获取沙盒Documents路径
+ (NSString *)getDocumentFolderPath{
    return [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
}
//获取沙盒Documents中文件的路径,没有则创建
+ (NSString *)getDocumentFilePathWithName:(NSString *)filename{
    NSString *filePath = [[[self class] getDocumentFolderPath] stringByAppendingPathComponent:filename];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:filePath]) {
        [fm createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil] ;
        
    }
    return filePath;
}

//获取沙盒中H5Zip包的地址，首先在Documents中寻找，其次在caches中寻找，若都没有则创建.并标记iCloud是否备份
+ (NSString *)getDocumentFilePathWithName:(NSString *)filename skipiCloudBackup:(BOOL)skipBackup{
    NSString *filePath = [[[self class] getDocumentFolderPath] stringByAppendingPathComponent:filename];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:filePath]) {
        //移动cache的文件到此
        NSString *cacheDir = [[[self class] getCacheFolderPath] stringByAppendingPathComponent:filename];
        BOOL success = NO ;
        if ([fm fileExistsAtPath:cacheDir]) {
            success = [fm moveItemAtPath:cacheDir toPath:filePath error:nil] ;
        }
        
        if(success==NO) {
            [fm createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil];
        }
        
        if(skipBackup) {
            [[self class] addSkipBackupAttributeToItemAtPath:filePath] ;
        }
    }
    return filePath;
}

//标记iCloud是否备份
+ (BOOL)addSkipBackupAttributeToItemAtPath:(NSString *) filePathString{
    
    NSURL* URL= [NSURL fileURLWithPath: filePathString];
    assert([[NSFileManager defaultManager] fileExistsAtPath: [URL path]]);
    
    NSError *error = nil;
    BOOL success = [URL setResourceValue: [NSNumber numberWithBool: YES]
                                  forKey: NSURLIsExcludedFromBackupKey
                                   error: &error];
    if(!success){
        NSLog(@"Error excluding %@ from backup %@", [URL lastPathComponent], error);
    }
    return success;
}

//判断文件是否存在于Documents中
+(BOOL)isFileExistAtDocumentsWithName:(NSString *)name{
    return [[NSFileManager defaultManager] fileExistsAtPath:[[self class] getDocumentFilePathWithName:name]];
}

//删除沙盒Documents中的某一个文件数据
+ (void)removeDataAtDocumentsWithName:(NSString *)name
{
    
    NSBlockOperation *blockOperation = [NSBlockOperation blockOperationWithBlock:^{
        
        NSFileManager *manager = [NSFileManager defaultManager];
        NSArray *array = [manager contentsOfDirectoryAtPath:[[self class] getDocumentFolderPath]  error:nil];
        for (NSString *string  in array) {
            if ([string isEqualToString:name])
            {
                NSString *filePath = [NSString stringWithFormat:@"%@/%@",[[self class] getDocumentFolderPath],string];
                [manager removeItemAtPath:filePath error:nil];
            }
            
        }
    }];
    
    [blockOperation start];
}

//获取沙盒Caches路径
+ (NSString *)getCacheFolderPath{
    return [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
}
//获取沙盒Caches中文件的路径
+ (NSString *)getCacheFilePathWithName:(NSString *)filename {
    NSString *filePath = [[[self class] getCacheFolderPath] stringByAppendingPathComponent:filename];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:filePath]) {
        [fm createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil] ;
        
    }
    return filePath;
}

//判断文件是否存在于Caches中
+(BOOL)isFileExistAtCachesWithName:(NSString *)name{
    return [[NSFileManager defaultManager] fileExistsAtPath:[[self class] getCacheFilePathWithName:name]];
}

//删除沙盒Documents中的某一个文件数据
+ (void)removeDataAtCachesWithName:(NSString *)name
{
    
    NSBlockOperation *blockOperation = [NSBlockOperation blockOperationWithBlock:^{
        
        NSFileManager *manager = [NSFileManager defaultManager];
        NSArray *array = [manager contentsOfDirectoryAtPath:[[self class] getCacheFolderPath]  error:nil];
        for (NSString *string  in array) {
            if ([string isEqualToString:name])
            {
                NSString *filePath = [NSString stringWithFormat:@"%@/%@",[[self class] getCacheFolderPath],string];
                [manager removeItemAtPath:filePath error:nil];
            }
            
        }
    }];
    
    [blockOperation start];
}

//根据文件路径判断文件是否存在
+ (BOOL)fileExistsAtPath:(NSString *)path{
    return [[NSFileManager defaultManager] fileExistsAtPath:path];
}

//根据文件夹路径判断文件夹是否存在
+ (BOOL)directoryExistsAtPath:(NSString *)path{
    BOOL isDir;
    BOOL exist = [[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&isDir];
    if (exist && isDir) {
        return YES;
    }
    return NO;
}

//根据路径删除文件
+ (BOOL)removeFileAtPath:(NSString *)path{
    if ([[self class] fileExistsAtPath:path]) {
        return [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
    }
    return YES;
}

//根据路径创建文件夹
+ (BOOL)createDirectoryAtPath:(NSString *)path{
    
    if (![[self class] directoryExistsAtPath:path]) {
       return [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return YES;
}

//拷贝文件到某一路径
+ (BOOL)copyFileFromPath:(NSString *)fromPath toPath:(NSString *)toPath{
    
    if ([[self class] fileExistsAtPath:fromPath]) {
        [[self class] removeFileAtPath:toPath];
        return [[NSFileManager defaultManager] copyItemAtPath:fromPath toPath:toPath error:nil];
    }
    return NO;
}

#pragma mark - 文件存取
//归档
+ (BOOL)saveModelObject:(id)object toFile:(NSString *)path{
    [[self class] removeFileAtPath:path];
    return [NSKeyedArchiver archiveRootObject:object toFile:path];
}
//解档
+ (id)readModelObjectWithFile:(NSString *)path{
    if (![[self class] fileExistsAtPath:path]) {
        return nil;
    }
    return [NSKeyedUnarchiver unarchiveObjectWithFile:path];
}

/**
 *  存储数据(存储的数据类型包括：NSString、NSData、NSArray、NSDictionary)
 *
 *  @param obj  待存数的数据
 *  @param filePath 存储数据的文件路径
 */
+ (void)saveObject:(id)obj toFile:(NSString *)filePath{
    
    [self removeFileAtPath:filePath];
    
    if ([obj isKindOfClass:[NSString class]]) {
        [(NSString *)obj writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
    else if ([obj isKindOfClass:[NSData class]]) {
        [(NSData *)obj writeToFile:filePath atomically:YES];
    }
    else if ([obj isKindOfClass:[NSArray class]]) {
        [(NSArray *)obj writeToFile:filePath atomically:YES];
    }
    else if ([obj isKindOfClass:[NSMutableArray class]]) {
        [(NSArray *)obj writeToFile:filePath atomically:YES];
    }
    else if ([obj isKindOfClass:[NSDictionary class]]) {
        [(NSDictionary *)obj writeToFile:filePath atomically:YES];
    }
}

/**
 *  从沙盒某文件中读取数组
 *
 *  @param filePath 存储数据的文件路径
 *
 *  @return 可变数组
 */
+ (NSArray *)getArrayFromFile:(NSString*)filePath{
    if ([[self class] fileExistsAtPath:filePath]) {
        return  [[NSArray alloc] initWithContentsOfFile:filePath];
    }
    else {
        return [[NSArray alloc] init];
    }
}

/**
 *  从沙盒某文件中读取字典
 *
 *  @param filePath 存储数据的文件路径
 *
 *  @return 可变字典
 */
+ (NSMutableDictionary *)getDictionaryFromFile:(NSString*)filePath{
    if ([[self class] fileExistsAtPath:filePath]) {
        return [[NSMutableDictionary alloc] initWithContentsOfFile:filePath];
    }
    else {
        return [[NSMutableDictionary alloc] init];
    }
}

/**
 *  从沙盒某文件中读取字符串
 *
 *  @param filePath 存储数据的文件路径
 *
 *  @return 字符串
 */
+ (NSString *)getStringFromFile:(NSString*)filePath{
    if ([[self class] fileExistsAtPath:filePath]) {
        return [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    }
    else {
        return [[NSString alloc] init];
    }
}

/**
 *  从沙盒某文件中读取Data数据
 *
 *  @param filePath 存储数据的文件路径
 *
 *  @return Data数据
 */
+ (NSData *)getDataFromFile:(NSString*)filePath{
    if ([[self class] fileExistsAtPath:filePath]) {
        return [NSData dataWithContentsOfFile:filePath];
    }
    else {
        return [[NSData alloc] init];
    }
}

@end

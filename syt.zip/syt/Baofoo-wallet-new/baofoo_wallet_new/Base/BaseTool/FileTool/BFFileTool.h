//
//  BFFileTool.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/24.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BFFileTool : NSObject

#pragma mark - 文件操作
//获取Document文件路径
+ (NSString *)getDocumentFolderPath;
+ (NSString *)getDocumentFilePathWithName:(NSString *)filename;
+ (NSString *)getDocumentFilePathWithName:(NSString *)filename skipiCloudBackup:(BOOL)skipBackup;

//获取Caches文件路径
+ (NSString *)getCacheFolderPath;
+ (NSString *)getCacheFilePathWithName:(NSString *)filename;

//常用文件处理方法
+ (BOOL)fileExistsAtPath:(NSString *)path;
+ (BOOL)directoryExistsAtPath:(NSString *)path;
+ (BOOL)removeFileAtPath:(NSString *)path;
+ (BOOL)copyFileFromPath:(NSString *)fromPath toPath:(NSString *)toPath;
+ (BOOL)createDirectoryAtPath:(NSString *)path;
+ (BOOL)addSkipBackupAttributeToItemAtPath:(NSString *) filePathString;

#pragma mark - 文件存取
//归档对象
+ (BOOL)saveModelObject:(id)object toFile:(NSString *)path;
//解档对象
+ (id)readModelObjectWithFile:(NSString *)path;

+ (void)saveObject:(id)obj toFile:(NSString *)filePath;
+ (NSArray *)getArrayFromFile:(NSString *)filePath;
+ (NSMutableDictionary *)getDictionaryFromFile:(NSString *)filePath;
+ (NSString *)getStringFromFile:(NSString *)filePath;
+ (NSData *)getDataFromFile:(NSString *)filePath;

@end

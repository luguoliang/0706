//
//  BFStringTool.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFStringTool.h"

@implementation BFStringTool
+(BFStringTool*)sharedManager
{
    static BFStringTool*sharedSingleton = nil;
    
    static dispatch_once_t predicate;
    
    dispatch_once(&predicate, ^{
        
        sharedSingleton = [[super allocWithZone:NULL] init];
    });
    return sharedSingleton;
}

+(instancetype)allocWithZone:(struct _NSZone *)zone
{
    return [self sharedManager];
}
-(NSString*)formatterStringWithString:(NSString *)str
{
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.numberStyle = kCFNumberFormatterDecimalStyle;
    NSString *string = [formatter stringFromNumber:[NSNumber numberWithDouble:[str doubleValue]]];
    return [self rangeOfString:string];
}

-(NSString*)rangeOfString:(NSString*)str
{
    NSMutableString*mustr = [NSMutableString stringWithString:str];
    if ([mustr rangeOfString:@"."].location == NSNotFound) {
        [mustr appendString:@".00"];
    }
    NSString*strr = [NSString stringWithFormat:@"%@",mustr];
    return strr;
}

-(NSString*)getcCurrentSystemtime
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:@"yyyyMMddHHmmss"];
    
    NSString *tradeDate = [dateFormatter stringFromDate:[NSDate date]];
    
    return tradeDate;
}

//判断字符串是否为空
+ (BOOL)isEmptyString:(NSString *)string{
    if (string == nil) {
        return YES;
    }
    if (string == NULL) {
        return YES;
    }
    if ([string isKindOfClass:[NSNull class]]) {
        return YES;
    }
    if ([string isEqual:[NSNull null]]) {
        return YES;
    }
    if ([[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0) {
        return YES;
    }
    return NO;
}

+ (NSString *)stringToUrl:(NSString *)string{
    return [string stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}

+ (CGSize)sizeOfString:(NSString *)string Size:(CGSize)size Font:(UIFont *)font{
    CGSize sizeString;
    sizeString = [string boundingRectWithSize:size
                                      options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading
                                   attributes:@{NSFontAttributeName: font}
                                      context:nil].size;
    return sizeString;
}

//去掉字符串中空格
+ (NSString *)noSpaceString:(NSString *)string{
    if ([[self class] isEmptyString:string]) {
        return @"";
    }
    return [string stringByReplacingOccurrencesOfString:@" " withString:@""];
}

+ (NSString *)addSpaceToPhone:(NSString *)phone{
    phone = [phone stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSMutableString *string = [[NSMutableString alloc]initWithString:phone];
    
    long length = string.length;
    if (length > 3 && length <= 7 ) {
        [string insertString:@" " atIndex:3];
    }
    else if (length > 7 && length <= 11) {
        [string insertString:@" " atIndex:3];
        [string insertString:@" " atIndex:8];
    }
    return string;
}

+ (NSString *)addSpaceToBankCard:(NSString *)bankCard{
    bankCard = [bankCard stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSMutableString *string = [[NSMutableString alloc]initWithString:bankCard];
    long length = string.length;
    long blank = length / 4;
    if (length % 4==0) {
        blank = blank - 1;
    }
    for (int i = 0; i < blank; ++i) {
        [string insertString:@" " atIndex:(i+1)*4 + i];
        
    }
    return string;
}

+ (NSString *)addSpaceToIDCard:(NSString *)idCard{
    idCard = [idCard stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    NSMutableString *string = [[NSMutableString alloc] initWithString:idCard];
    long length = string.length;
    if (length > 6 && length <= 14) {
        [string insertString:@" " atIndex:6];
    }
    else if (length > 14 && length <= 18) {
        [string insertString:@" " atIndex:6];
        [string insertString:@" " atIndex:15];
    }
    return string;
}

//银行卡输入处理
+ (BOOL)bankCardCheckWithTextField:(UITextField *)textField range:(NSRange)range changeString:(NSString *)string{
    NSString *text = [textField text];
    NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789\b"];
    string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
    if ([string rangeOfCharacterFromSet:[characterSet invertedSet]].location != NSNotFound)
    {
        return NO;
    }
    text = [text stringByReplacingCharactersInRange:range withString:string];
    text = [text stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    NSString *newString = @"";
    while (text.length > 0) {
        NSString *subString = [text substringToIndex:MIN(text.length, 4)];
        newString = [newString stringByAppendingString:subString];
        if (subString.length == 4) {
            newString = [newString stringByAppendingString:@" "];
        }
        text = [text substringFromIndex:MIN(text.length, 4)];
    }
    
    newString = [newString stringByTrimmingCharactersInSet:[characterSet invertedSet]];
    if(newString.length >= 27)
    {
        return NO;
    }
    [textField setText:newString];
    return NO;
}

//身份证输入处理
+ (BOOL)idCardCheckWithTextField:(UITextField*)textField range:(NSRange)range changeString:(NSString *)string{
    NSString *text = [textField text];
    NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789Xx\b"];
    string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
    if ([string rangeOfCharacterFromSet:[characterSet invertedSet]].location != NSNotFound) {
        return NO;
    }
    
    text = [text stringByReplacingCharactersInRange:range withString:string];
    text = [text stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSInteger status = 0;
    NSString *newString = @"";
    while (text.length > 0) {
        if (text.length <= 7) {
            if (status == 0) {
                NSString *subString = [text substringToIndex:MIN(text.length, 6)];
                newString = [newString stringByAppendingString:subString];
                if (subString.length == 6) {
                    newString = [newString stringByAppendingString:@" "];
                }
                text = [text substringFromIndex:MIN(text.length, 6)];
            }
            else if (status == 1) {
                NSString *subString = [text substringToIndex:MIN(text.length, 7)];
                newString = [newString stringByAppendingString:subString];
                if (subString.length == 7) {
                    newString = [newString stringByAppendingString:@" "];
                }
                text = [text substringFromIndex:MIN(text.length, 7)];
            }
        }
        else if (text.length > 7) {
            if (status == 0) {
                NSString *subString = [text substringToIndex:MIN(text.length, 6)];
                newString = [newString stringByAppendingString:subString];
                if (subString.length == 6) {
                    newString = [newString stringByAppendingString:@" "];
                }
                text = [text substringFromIndex:MIN(text.length, 6)];
                status = 1;
            }
            else if (status == 1) {
                NSString *subString = [text substringToIndex:MIN(text.length, 8)];
                newString = [newString stringByAppendingString:subString];
                if (subString.length == 8) {
                    newString = [newString stringByAppendingString:@" "];
                }
                text = [text substringFromIndex:MIN(text.length, 8)];
            }
        }
        else {
            text = [text substringFromIndex:MIN(text.length, 4)];
        }
    }
    
    newString = [newString stringByTrimmingCharactersInSet:[characterSet invertedSet]];
    
    if (newString.length > 20) {
        return NO;
    }
    
    [textField setText:newString];
    return NO;
}

//手机号输入处理
+ (BOOL)phoneCheckWithTextField:(UITextField *)textField range:(NSRange)range changeString:(NSString *)string{
    
    NSString *text = [textField text];
    NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789\b"];
    string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
    if ([string rangeOfCharacterFromSet:[characterSet invertedSet]].location != NSNotFound) {
        return NO;
    }
    
    text = [text stringByReplacingCharactersInRange:range withString:string];
    text = [text stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSInteger status = 0;
    NSString *newString = @"";
    while (text.length > 0) {
        if (text.length <= 4) {
            if (status == 0) {
                NSString *subString = [text substringToIndex:MIN(text.length, 3)];
                newString = [newString stringByAppendingString:subString];
                if (subString.length == 3) {
                    newString = [newString stringByAppendingString:@" "];
                }
                text = [text substringFromIndex:MIN(text.length, 3)];
            }
            else if (status == 1) {
                NSString *subString = [text substringToIndex:MIN(text.length, 4)];
                newString = [newString stringByAppendingString:subString];
                if (subString.length == 4) {
                    newString = [newString stringByAppendingString:@" "];
                }
                text = [text substringFromIndex:MIN(text.length, 4)];
            }
        }
        else if (text.length > 4) {
            if (status == 0) {
                NSString *subString = [text substringToIndex:MIN(text.length, 3)];
                newString = [newString stringByAppendingString:subString];
                if (subString.length == 3) {
                    newString = [newString stringByAppendingString:@" "];
                }
                text = [text substringFromIndex:MIN(text.length, 3)];
                status = 1;
            }
            else if (status == 1) {
                NSString *subString = [text substringToIndex:MIN(text.length, 4)];
                newString = [newString stringByAppendingString:subString];
                if (subString.length == 4) {
                    newString = [newString stringByAppendingString:@" "];
                }
                text = [text substringFromIndex:MIN(text.length, 4)];
            }
        }
        else {
            text = [text substringFromIndex:MIN(text.length, 3)];
        }
    }
    newString = [newString stringByTrimmingCharactersInSet:[characterSet invertedSet]];
    
    if (newString.length >= 15) {
        return NO;
    }
    NSMutableString *tempStr = nil;
    if (newString.length > 6) {
        
        NSString  *tempStr1 = [newString substringToIndex:7];
        tempStr =[NSMutableString stringWithString:tempStr1];
        NSRange tempRange = [tempStr rangeOfString:@" "];
        if (tempRange.location != NSNotFound) {
            [tempStr deleteCharactersInRange:tempRange];
        }
    }
    [textField setText:newString];
    return NO;
}
@end

//
//  BFStringTool.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface BFStringTool : NSObject

/**
 *  字符串处理
 */
+(BFStringTool*)sharedManager;

-(NSString*)formatterStringWithString:(NSString*)str;

-(NSString*)getcCurrentSystemtime;

/**
 *  判断字符串是否为空
 */
+ (BOOL)isEmptyString:(NSString *)string;

+ (NSString *)stringToUrl:(NSString *)string;

+ (CGSize)sizeOfString:(NSString *)string Size:(CGSize)size Font:(UIFont *)font;

//去掉字符串中空格
+ (NSString *)noSpaceString:(NSString *)string;
+ (NSString *)addSpaceToPhone:(NSString *)phone;
+ (NSString *)addSpaceToBankCard:(NSString *)bankCard;
+ (NSString *)addSpaceToIDCard:(NSString *)idCard;

//银行卡输入处理
+ (BOOL)bankCardCheckWithTextField:(UITextField *)textField range:(NSRange)range changeString:(NSString *)string;

//身份证输入处理
+ (BOOL)idCardCheckWithTextField:(UITextField*)textField range:(NSRange)range changeString:(NSString *)string;

//手机号输入处理
+ (BOOL)phoneCheckWithTextField:(UITextField *)textField range:(NSRange)range changeString:(NSString *)string;

@end

/**
 *  判断字符串是否为空
 */
CG_INLINE BOOL IsEmptyString(NSString *string) {
    return ([BFStringTool isEmptyString:string]);
}

/**
 *  如果字符串为空返回@""
 */
CG_INLINE NSString* NoEmptyString(NSString *string) {
    return ([BFStringTool isEmptyString:string]?@"":string);
}

/**
 *  如果字符串为空返回replaceString
 */
CG_INLINE NSString* ReplaceEmptyString(NSString *string, NSString *replaceString) {
    return ([BFStringTool isEmptyString:string]?replaceString:string);
}

/**
 *  获取字符串长度
 *
 *  @param string          字符串
 *  @param constrainedSize 范围Size
 *  @param font            字体
 */
CG_INLINE CGSize CGSizeOfString(NSString *string, CGSize constrainedSize, UIFont *font) {
    return [BFStringTool sizeOfString:string Size:constrainedSize Font:font];
}

//常量转字符串
CG_INLINE NSString* NSStringFromInt(int intValue) {
    return [NSString stringWithFormat:@"%d", intValue];
}
CG_INLINE NSString* NSStringFromDouble(double doubleValue) {
    return [NSString stringWithFormat:@"%f", doubleValue];
}
CG_INLINE NSString* NSStringFromFloat(float floatValue) {
    return [NSString stringWithFormat:@"%f", floatValue];
}
CG_INLINE NSString* NSStringFromInteger(NSInteger integerValue) {
    return [NSString stringWithFormat:@"%ld", (long)integerValue];
}


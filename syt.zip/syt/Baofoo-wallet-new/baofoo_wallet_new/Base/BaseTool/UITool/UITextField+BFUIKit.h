//
//  UITextField+BFUIKit.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (BFUIKit)

+ (UITextField *)createWithFrame:(CGRect)frame placeholder:(NSString *)placeholder delegate:(id<UITextFieldDelegate>)delegate;

- (void)setPlaceholderWithText:(NSString *)text textColor:(UIColor *)textColor;

#pragma mark - Title Label

/**
 *  设置TextField Title
 *
 *  @param title      title文字
 *  @param titleColor 字体颜色，默认(nil)黑色
 *  @param margin     左边距
 *  @param width      宽度
 */
- (UILabel *)showTitleLabelWithTitle:(NSString *)title titleColor:(UIColor *)titleColor margin:(CGFloat)margin width:(CGFloat)width;

/**
 *  设置TextField Title，颜色默认黑色
 */
- (UILabel *)showTitleLabelWithTitle:(NSString *)title margin:(CGFloat)margin width:(CGFloat)width;
- (UILabel *)showTitleLabelWithTitle:(NSString *)title margin:(CGFloat)margin; //宽度90

/**
 *  设置TextField Title，颜色默认黑色，左边距0，宽度90
 */
- (UILabel *)showTitleLabelWithTitle:(NSString *)title titleColor:(UIColor *)titleColor;
- (UILabel *)showTitleLabelWithTitle:(NSString *)title; //文字颜色黑色

@end

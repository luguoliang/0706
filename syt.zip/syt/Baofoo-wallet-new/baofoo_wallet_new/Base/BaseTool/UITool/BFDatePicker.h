//
//  BFDatePicker.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BFDatePicker;

@protocol BFDatePickerDelegate <NSObject>
- (void)datePickerDidConfirm:(BFDatePicker *)datePicker;
- (void)datePickerDidCancel:(BFDatePicker *)datePicker;
@end

@interface BFDatePicker : UIDatePicker
@property (nonatomic, weak) id <BFDatePickerDelegate>actionDelegate;
+ (instancetype)createDatePicker;
- (void)show:(UIViewController *)controller;
@end

//
//  UIView+BFUIKit.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (BFUIKit)

/**
 *  创建UIView，默认背景透明
 */
+ (UIView *)createWithFrame:(CGRect)frame;

/**
 *  创建UIView
 */
+ (UIView *)createWithFrame:(CGRect)frame backgroundColor:(UIColor *)backgroundColor;

/**
 *  创建UIView，默认背景白色
 */
+ (UIView *)createWhiteViewWithFrame:(CGRect)frame;

- (UIView *)showTopBorder;
- (UIView *)showTopBorderWithColor:(UIColor *)color;
- (UIView *)showBottomBorder;
- (UIView *)showBottomBorderWithColor:(UIColor *)color;

#pragma mark - Line

/**
 *  创建line，默认背景rgb(245，245，245)
 */
+ (UIView *)createLineWithFrame:(CGRect)frame;

/**
 *  创建line
 */
+ (UIView *)createLineWithFrame:(CGRect)frame backgroundColor:(UIColor *)backgroundColor;

@end

/**
 *  创建line
 *
 *  @param frame           frame
 *  @param backgroundColor 背景色
 */
CG_INLINE UIView *UILineCreate(CGRect frame, UIColor *backgroundColor) {
    return [UIView createLineWithFrame:frame backgroundColor:backgroundColor];
}

/**
 *  创建line，高度0.5，背景rgb(245，245，245)
 *
 *  @param x     frame.origin.x
 *  @param y     frame.origin.y
 *  @param width frame.origin.width
 */
CG_INLINE UIView *UILineDefaultCreate(CGFloat x, CGFloat y, CGFloat width) {
    return [UIView createLineWithFrame:CGRectMake(x, y, width, 0.5)];
}
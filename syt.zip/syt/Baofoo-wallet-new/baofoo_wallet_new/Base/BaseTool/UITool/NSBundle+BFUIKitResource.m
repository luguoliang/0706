//
//  NSBundle+BFUIKitResource.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "NSBundle+BFUIKitResource.h"

@implementation NSBundle (BFUIKitResource)

+ (NSBundle *)UIKitResourcesBundle{
    static dispatch_once_t onceToken;
    static NSBundle *_bundle = nil;
    dispatch_once(&onceToken, ^{
        
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"BaofooUIKitBundle" withExtension:@"bundle"];
        
        _bundle = [NSBundle bundleWithURL:url];
    });
    return _bundle;
}

@end

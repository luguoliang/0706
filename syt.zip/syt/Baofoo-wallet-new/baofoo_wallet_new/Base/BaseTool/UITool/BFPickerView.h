//
//  BFPickerView.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BFPickerView;
@protocol BFPickerViewDelegate <NSObject>

- (void)pickerViewDidCancel:(BFPickerView *)pickerView;
- (void)pickerViewDidConfirm:(BFPickerView *)picerView;

@end

@interface BFPickerView : UIPickerView

@property (assign, nonatomic) id<BFPickerViewDelegate> actionDelegate;

+ (instancetype)createPickerView;
- (void)show:(UIViewController *)controller;

@end

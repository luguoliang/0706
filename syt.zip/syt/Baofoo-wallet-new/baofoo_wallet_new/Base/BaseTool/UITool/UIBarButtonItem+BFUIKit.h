//
//  UIBarButtonItem+BFUIKit.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (BFUIKit)

+ (UIBarButtonItem *)createWithTitle:(NSString *)title normalImage:(UIImage *)normalImage highlightedImage:(UIImage *)highlightedImage tagert:(id)tagert action:(SEL)action;

@end

//
//  UITableView+BFUIKit.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "UITableView+BFUIKit.h"

@implementation UITableView (BFUIKit)
+ (UITableView *)createWithFrame:(CGRect)frame style:(UITableViewStyle)style delegate:(id<UITableViewDelegate>)delegate datasource:(id<UITableViewDataSource>)dataSource{
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:frame style:style];
    tableView.backgroundColor = UIColorClear();
    tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    tableView.delegate = delegate;
    tableView.dataSource = dataSource;
    
    return tableView;
}

+ (UITableView *)createPlainTableWithFrame:(CGRect)frame delegate:(id<UITableViewDelegate>)delegate datasource:(id<UITableViewDataSource>)dataSource{
    UITableView *tableView = [[self class] createWithFrame:frame style:UITableViewStylePlain delegate:delegate datasource:dataSource];
    return tableView;
}

+ (UITableView *)createGroupTableWithFrame:(CGRect)frame delegate:(id<UITableViewDelegate>)delegate datasource:(id<UITableViewDataSource>)dataSource{
    UITableView *tableView = [[self class] createWithFrame:frame style:UITableViewStyleGrouped delegate:delegate datasource:dataSource];
    return tableView;
}

@end

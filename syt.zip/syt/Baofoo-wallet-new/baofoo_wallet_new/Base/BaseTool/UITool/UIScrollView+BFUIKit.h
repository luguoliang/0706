//
//  UIScrollView+BFUIKit.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (BFUIKit)

/**
 *  创建UIScrollView，背景透明，不显示横向纵向导航条，pagingEnabled no，bounces no
 */
+ (UIScrollView *)createWithFrame:(CGRect)frame delegate:(id<UIScrollViewDelegate>)delegate;

@end

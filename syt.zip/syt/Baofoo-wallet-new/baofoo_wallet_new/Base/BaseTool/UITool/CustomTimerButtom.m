//
//  CustomTimerButtom.m
//  BaofooMWallet
//
//  Created by 国良 on 14-11-21.
//  Copyright (c) 2014年 国良. All rights reserved.
//

#import "CustomTimerButtom.h"

@implementation CustomTimerButtom
//- (instancetype)init
//{
//    self = [super init];
//    if (self) {
//        [self setTitle:@"获取验证码" forState:UIControlStateNormal];
//    }
//    return self;
//}
//-(void)startTimer
//{
//    self.number = 59;
//    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(timerclick:) userInfo:nil repeats:YES];
//    [self setTitle:@"倒计时60秒" forState:UIControlStateNormal];
//    self.enabled = NO;
//    
//}
//-(void)stopTimer
//{
//    [self.timer invalidate];
//    self.enabled = YES;
//    [self setTitle:@"获取验证码" forState:UIControlStateNormal];
//}
//-(void)timerclick:(UIButton*)btn
//{
//    if (_number > 0) {
//        NSString *str = [NSString stringWithFormat:@"倒计时%d秒",_number];
//        [self setTitle:str forState:UIControlStateNormal];
//        _number = _number - 1;
//    }
//    else
//    {
//        [self.timer invalidate];
//        [self setTitle:@"获取验证码" forState:UIControlStateNormal];
//        self.enabled = YES;
//    }
//}


- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setTitle:@"获取" forState:UIControlStateNormal];
    }
    return self;
}
-(void)startTimer
{
    self.number = 59;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(timerclick:) userInfo:nil repeats:YES];
//     self.timer = [NSTimer timerWithTimeInterval:1.0f target:self selector:@selector(timerclick:) userInfo:nil repeats:YES];
    [self setTitle:@"60秒" forState:UIControlStateNormal];
    self.enabled = NO;
    
}
-(void)stopTimer
{
    [self.timer invalidate];
    self.enabled = YES;
    [self setTitle:@"获取" forState:UIControlStateNormal];
}
-(void)timerclick:(UIButton*)btn
{
    if (_number > 0) {
        NSString *str = [NSString stringWithFormat:@"%d秒",_number];
        [self setTitle:str forState:UIControlStateNormal];
        _number = _number - 1;
    }
    else
    {
        [self.timer invalidate];
        [self setTitle:@"获取" forState:UIControlStateNormal];
        self.enabled = YES;
    }
}


@end

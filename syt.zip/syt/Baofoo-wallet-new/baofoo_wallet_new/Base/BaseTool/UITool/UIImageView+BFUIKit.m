//
//  UIImageView+BFUIKit.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "UIImageView+BFUIKit.h"

@implementation UIImageView (BFUIKit)

+ (UIImageView *)createWithFrame:(CGRect)frame backgroundColor:(UIColor *)backgroundColor image:(UIImage *)image{
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:frame];
    imageView.backgroundColor = backgroundColor;
    imageView.image = image;
    return imageView;
}

+ (UIImageView *)createWithFrame:(CGRect)frame image:(UIImage *)image{
    return [[self class] createWithFrame:frame backgroundColor:UIColorClear() image:image];
}

@end

//
//  NSString+DetailString.h
//  makr
//
//  Created by mac on 15/4/23.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface NSString (DetailString)
//把小数转换成小数点后两位百分比显示
+(NSString *)percentWithTwoString:(NSString *)decimal;
//把小数转换成小数点后没有百分比显示
+(NSString *)percentWithZeroString:(NSString *)decimal;
//计算剩余时间
+(NSString *)getSurplusTime:(NSString *)surplusTimeStamp;
//计算字符数量
+ (NSUInteger)lenghtWithString:(NSString *)string;

//转换数字显示样式 数字为整数时是否显示小数点后两位
+(NSString *)moneyNumAndChangeformat:(NSString *)string isDisplayPoint:(BOOL)display;
//去掉金额里面的逗号
+(NSString *)digitalNumAndChangeformat:(NSString *)string;

/**
 *  计算收益
 *
 *  @param buyMoney 购买金额
 *  @param rate     年利率
 *  @param dayCount 天数
 *
 *  @return 预期总收益
 */
+(NSString *)preMoneyWithBuyMoney:(NSInteger)buyMoney yearRate:(CGFloat)rate day:(NSInteger)dayCount;


/**
 *  MD5加密
 *
 *  @param str 要加密的字符串
 *
 *  @return 加密后的字符串
 */
+(NSString*)md5:(NSString *)str;

//转化成字符串
+ (NSString *)serializeToUrlByDicString:(NSDictionary *)dic;
@end

//
//  BlockAlert.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/4/11.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BlockAlert.h"
#import "UIAlertView+BFAlertView.h"

@interface BlockAlert ()
{
    OperationBlock block;
}
@end

@implementation BlockAlert

+ (void)showWithTitle:(NSString *)title message:(NSString *)message cancelButtonTitle:(NSString *)cancelButtonTitle otherButtonTitles:(NSString *)otherButtonTitles operation:(OperationBlock)operationBlock{
    
    BlockAlert *alert = [[BlockAlert alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:cancelButtonTitle otherButtonTitles: otherButtonTitles, nil];
    [alert showAlert:operationBlock];
}

+ (void)showSingleSelAlertWithTitle:(NSString *)title message:(NSString *)message buttonTitle:(NSString *)buttonTitle operation:(OperationBlock)operationBlock{
    
    BlockAlert *alert = [[BlockAlert alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:buttonTitle otherButtonTitles: nil];
    [alert showAlert:operationBlock];
}


+ (void)showWithMessage:(NSString *)message operation:(OperationBlock)operationBlock{
    [[self class] showSingleSelAlertWithTitle:Alert_Title message:message buttonTitle:Alert_Button_Confirm operation:operationBlock];
}

+ (void)showNetErrorAlertWithOperation:(OperationBlock)operationBlock{
    [[self class] showSingleSelAlertWithTitle:Alert_Title_Net_Error message:Alert_Message_Net_Error buttonTitle:Alert_Button_Confirm operation:operationBlock];
}

+ (void)showReqFailedAlertWithCode:(NSString *)code message:(NSString *)message operation:(OperationBlock)operationBlock{
    if (code && [code isEqualToString:Net_Error_Code]) {
        [[self class] showNetErrorAlertWithOperation:operationBlock];
    }
    else {
        [[self class] showWithMessage:message operation:operationBlock];
    }
}

- (void)showAlert:(OperationBlock)operationBlock{
    block = operationBlock;
    self.delegate = self;
    [self show];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (block) {
        block(buttonIndex);
    }
}


@end

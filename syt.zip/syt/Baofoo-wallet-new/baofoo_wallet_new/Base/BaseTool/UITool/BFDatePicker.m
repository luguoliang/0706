//
//  BFDatePicker.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFDatePicker.h"

@interface BFDatePicker ()<UIActionSheetDelegate>

@end


@implementation BFDatePicker
+ (instancetype)createDatePicker{
    return [[self alloc]init];
}

- (void)show:(UIViewController *)controller{
    if ([[UIDevice currentDevice].systemVersion floatValue]>=8.0) {
        UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:nil message:@"\n\n\n\n\n\n\n\n\n\n\n\n" preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action){
            [self confirmAction];
        }];
        [actionSheet addAction:confirmAction];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action){
            [self cancelAction];
        }];
        [actionSheet addAction:cancelAction];
        [actionSheet.view addSubview:self];
        [controller presentViewController:actionSheet animated:YES completion:nil];
        
    }
    else{
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"\n\n\n\n\n\n\n\n\n\n\n\n" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"确定" otherButtonTitles:nil];
        actionSheet.actionSheetStyle = UIActionSheetStyleBlackTranslucent;
        [actionSheet addSubview:self];
        [actionSheet showInView:[controller.view window]];
    }
}

- (void)confirmAction{
    if ([self.actionDelegate respondsToSelector:@selector(datePickerDidConfirm:)]) {
        [self.actionDelegate datePickerDidConfirm:self];
    }
}

- (void)cancelAction{
    if ([self.actionDelegate respondsToSelector:@selector(datePickerDidCancel:)]) {
        [self.actionDelegate datePickerDidCancel:self];
    }
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if(buttonIndex == 0){
        [self cancelAction];
    }
    else{
        [self confirmAction];
    }
}

@end

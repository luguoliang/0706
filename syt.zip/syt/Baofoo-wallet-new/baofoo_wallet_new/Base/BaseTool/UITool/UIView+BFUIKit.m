//
//  UIView+BFUIKit.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "UIView+BFUIKit.h"
#import "BFUIKit.h"

@implementation UIView (BFUIKit)

+ (UIView *)createWithFrame:(CGRect)frame{
    UIView *view = [[self alloc] initWithFrame:frame];
    view.backgroundColor = UIColorClear();
    return view;
}

+ (UIView *)createWithFrame:(CGRect)frame backgroundColor:(UIColor *)backgroundColor{
    
    UIView *view = [[self class] createWithFrame:frame];
    view.backgroundColor = backgroundColor?backgroundColor:UIColorClear();
    return view;
}

+ (UIView *)createWhiteViewWithFrame:(CGRect)frame{
    return [[self class] createWithFrame:frame backgroundColor:UIColorWhite()];
}

- (UIView *)showTopBorder{
    UIView *line = UILineDefaultCreate(0, 0, self.frame.size.width);
    [self addSubview:line];
    return line;
}
- (UIView *)showTopBorderWithColor:(UIColor *)color{
    UIView *line = UILineCreate(CGRectMake(0, 0, self.frame.size.width, 0.5), color);
    [self addSubview:line];
    return line;
}

- (UIView *)showBottomBorder{
    UIView *line = UILineDefaultCreate(0, self.frame.size.height-0.5, self.frame.size.width);
    [self addSubview:line];
    return line;
}
- (UIView *)showBottomBorderWithColor:(UIColor *)color{
    UIView *line = UILineCreate(CGRectMake(0, self.frame.size.height-0.5, self.frame.size.width, 0.5), color);
    [self addSubview:line];
    return line;
}

#pragma mark - Line

+ (UIView *)createLineWithFrame:(CGRect)frame{
    return [[self class] createWithFrame:frame backgroundColor:BF_Color_SplitLine];
}

+ (UIView *)createLineWithFrame:(CGRect)frame backgroundColor:(UIColor *)backgroundColor{
    
    UIView *line = [[self class] createLineWithFrame:frame];
    line.backgroundColor = backgroundColor?backgroundColor:BF_Color_SplitLine;
    return line;
}

@end

//
//  UITextView+BFUIKit.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "UITextView+BFUIKit.h"

@implementation UITextView (BFUIKit)

+ (UITextView *)createWithFrame:(CGRect)frame delegate:(id<UITextViewDelegate>)delegate{
    UITextView *textView = [[UITextView alloc] initWithFrame:frame];
    textView.backgroundColor = UIColorClear();
    textView.delegate = delegate;
    textView.font = BF_Font_TextViewContent;
    textView.textColor = BF_Color_TextViewContent;
    return textView;
}

@end

//
//  UITableView+BFUIKit.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (BFUIKit)

/**
 *  创建UITableView，背景透明，不显示多余的行
 */
+ (UITableView *)createWithFrame:(CGRect)frame style:(UITableViewStyle)style delegate:(id<UITableViewDelegate>)delegate datasource:(id<UITableViewDataSource>)dataSource;

/**
 *  创建UITableView，背景透明，不显示多余的行，style plain
 */
+ (UITableView *)createPlainTableWithFrame:(CGRect)frame delegate:(id<UITableViewDelegate>)delegate datasource:(id<UITableViewDataSource>)dataSource;

/**
 *  创建UITableView，背景透明，不显示多余的行，style group
 */
+ (UITableView *)createGroupTableWithFrame:(CGRect)frame delegate:(id<UITableViewDelegate>)delegate datasource:(id<UITableViewDataSource>)dataSource;

@end

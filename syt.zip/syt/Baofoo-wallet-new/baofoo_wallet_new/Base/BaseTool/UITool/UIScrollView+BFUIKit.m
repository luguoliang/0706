//
//  UIScrollView+BFUIKit.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "UIScrollView+BFUIKit.h"

@implementation UIScrollView (BFUIKit)

+ (UIScrollView *)createWithFrame:(CGRect)frame delegate:(id<UIScrollViewDelegate>)delegate{
    
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:frame];
    scrollView.backgroundColor = UIColorClear();
    scrollView.delegate = delegate;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.pagingEnabled = NO;
    scrollView.bounces = YES;
    scrollView.contentSize = frame.size;
    return scrollView;
}

@end

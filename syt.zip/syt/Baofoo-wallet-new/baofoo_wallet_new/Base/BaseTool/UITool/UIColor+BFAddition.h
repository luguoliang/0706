//
//  UIColor+BFAddition.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (BFAddition)
+ (UIColor *)colorWithHexString:(NSString *)hexString;
+ (UIColor *)colorWithHexString:(NSString *)hexString alpha:(CGFloat)alpha;
+ (UIColor *)getCurrentAppSystemColor;
@end

//Basic
CG_INLINE UIColor *UIColorBlack() {
    return [UIColor blackColor];
}
CG_INLINE UIColor *UIColorBlue() {
    return [UIColor blueColor];
}
CG_INLINE UIColor *UIColorClear() {
    return [UIColor clearColor];
}
CG_INLINE UIColor *UIColorDarkGray() {
    return [UIColor darkGrayColor];
}
CG_INLINE UIColor *UIColorGray() {
    return [UIColor grayColor];
}
CG_INLINE UIColor *UIColorGreen() {
    return [UIColor greenColor];
}
CG_INLINE UIColor *UIColorLightGray() {
    return [UIColor lightGrayColor];
}
CG_INLINE UIColor *UIColorOrange() {
    return [UIColor orangeColor];
}
CG_INLINE UIColor *UIColorRed() {
    return [UIColor redColor];
}
CG_INLINE UIColor *UIColorWhite() {
    return [UIColor whiteColor];
}
CG_INLINE UIColor *UIColoreYellow() {
    return [UIColor yellowColor];
}

/**
 *  RGB颜色，Alpha默认1.0
 */
CG_INLINE UIColor *UIColorRgb(CGFloat red, CGFloat green, CGFloat blue) {
    return [UIColor colorWithRed:(red/255.0) green:(green/255.0) blue:(blue/255.0) alpha:1.0];
}

/**
 *  RGB & Alpha 颜色
 */
CG_INLINE UIColor *UIColorRgbAlpha(CGFloat red, CGFloat green, CGFloat blue, CGFloat alpha) {
    return [UIColor colorWithRed:(red/255.0) green:(green/255.0) blue:(blue/255.0) alpha:alpha];
}

/**
 *  Hex颜色，Alpha默认1.0，支持0x000000
 */
CG_INLINE UIColor *UIColorHex(NSInteger hex) {
    return [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:1.0];
}

/**
 *  Hex & Alpha颜色，支持0x000000
 */
CG_INLINE UIColor *UIColorHexAlpha(NSInteger hex, CGFloat alpha) {
    return [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:alpha];
}

/**
 *  Hex颜色，Alpha默认1.0，支持#000000、0x000000、000000字符串
 */
CG_INLINE UIColor *UIColorHexString(NSString *hexString) {
    return [UIColor colorWithHexString:hexString];
}

/**
 *  Hex & Alpha颜色，支持#000000、0x000000、000000字符串
 */
CG_INLINE UIColor *UIColorHexStringAlpha(NSString *hexString, CGFloat alpha) {
    return [UIColor colorWithHexString:hexString alpha:alpha];
}
//
//  BFUIKit.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/12.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "UIColor+BFAddition.h"
#import "UIFont+BFAddition.h"
#import "UIView+BFAddition.h"
#import "UIImage+BFAddition.h"

#import "UIImage+BFUIKitResource.h"

#pragma mark - Color颜色

#define BF_Color_TextDefault          ([UIColor blackColor])       //默认文字颜色，黑色
#define BF_Color_TextLink             (UIColorRgb(255, 110, 45))  //链接文字颜色
#define BF_Color_TextOperation        (UIColorRgb(255, 110, 45))  //操作文字颜色
#define BF_Color_TextHighlighted      (UIColorRgb(255, 25, 85))  //突出文字颜色
#define BF_Color_TextTitle            (UIColorRgb(54, 54, 54))    //标题颜色
#define BF_Color_TextContent          (UIColorRgb(54, 54, 54))    //正文颜色
#define BF_Color_TextSubhead          (UIColorRgb(128, 128, 128)) //副标题颜色
#define BF_Color_TextDescription      (UIColorRgb(178, 178, 178)) //说明文字颜色
#define BF_Color_TextPlaceholder      (UIColorRgb(198, 198, 198)) //文本框Placeholder文字颜色
#define BF_Color_TextWarning          (UIColorRgb(241, 58, 32))   //报错提示文字颜色

//导航栏
#define BF_Color_NavTitle             (UIColorRgb(255, 255, 255)) //导航栏标题文字颜色
#define BF_Color_NavBarButtonItem     (UIColorRgb(255, 255, 255)) //导航栏BarButtonItem文字颜色

//Cell
#define BF_Color_CellText             (UIColorRgb(0, 0, 0)) //Cell文字颜色
#define BF_Color_CellBackground       ([UIColor whiteColor]) //Cell背景颜色

//TextField
#define BF_Color_TextFieldContent     (UIColorRgb(54, 54, 54)) //TextField内容文字颜色
#define BF_Color_TextFieldPlaceholder (UIColorRgb(198, 198, 198)) //TextFieldPlaceholder文字颜色
#define BF_Color_TextFieldTitle       ([UIColor blackColor]) //TextField标题文字颜色

//TextView
#define BF_Color_TextViewContent      (UIColorRgb(54, 54, 54)) //TextView内容文字颜色

#define BF_Color_Background           (UIColorRgb(245, 245, 245)) //背景颜色

#define BF_Color_SplitLine            (UIColorRgb(230, 230, 230)) //分割线颜色

#define BF_Color_Warning              (UIColorRgb(241, 58, 32)) //警告

#define BF_Color_Dominant             (UIColorRgb(255, 45, 85)) //主色调:用于APP的所有本文等 桃红

#pragma mark - Font字体

#define BF_Font_Default               (UIFontSystemOfSize(15.0)) //默认文字字体

#define BF_Font_EndButton             (UIFontSystemOfSize(17.0))

#define BF_Font_12                    (UIFontSystemOfSize(12.0))
#define BF_Font_13                    (UIFontSystemOfSize(13.0))
#define BF_Font_14                    (UIFontSystemOfSize(14.0))
#define BF_Font_15                    (UIFontSystemOfSize(15.0))
#define BF_Font_16                    (UIFontSystemOfSize(16.0))
#define BF_Font_17                    (UIFontSystemOfSize(17.0))
#define BF_Font_(size)                (UIFontSystemOfSize(size))

//导航栏
#define BF_Font_NavTitle              ([UIFont fontWithName:@"Arial" size:20.0]) //导航栏文字字体
#define BF_Font_NavBarButtonItem      (UIFontSystemOfSize(14.0)) //导航栏BarButtonItem文字字体

//Cell
#define BF_Font_CellText              (UIFontSystemOfSize(15.0)) //Cell文字字体

//TextField
#define BF_Font_TextFieldContent      (UIFontSystemOfSize(15.0)) //TextField内容文字字体
#define BF_Font_TextFieldPlaceholder  (UIFontSystemOfSize(15.0)) //TextFieldPlaceholder文字字体
#define BF_Font_TextFieldTitle        (UIFontSystemOfSize(15.0)) //TextField标题文字字体

//TextView
#define BF_Font_TextViewContent       (UIFontSystemOfSize(15.0)) //输入框文字字体

#pragma mark - 距离

#define BF_Height_NavBar              (64.0f)
#define BF_Height_TabBar              (49.0f)

#define BF_Height_Cell                (44.0f)  //列表Cell高度 暂时44.0 以后47.0

#define BF_Height_TextField           (44.0f) //输入框高度
#define BF_Width_TextFieldTitle       (90.0f) //输入框Title宽度

#define BF_Height_SplitLine           (0.5f)  //分割线高度

#define BF_Margin_15                  (15.0f)
#define BF_Margin_20                  (20.0f)

#define BF_Height_44                  (44.0)
#define BF_Height_21                  (21.0)

#pragma mark - KeyBoardType

typedef NS_ENUM(NSInteger, BFKeyBoardType) {
    BFKeyBoardTypeDefault = UIKeyboardTypeDefault, //默认
    BFKeyBoardTypeName = UIKeyboardTypeDefault, //默认
    BFKeyBoardTypeASCII = UIKeyboardTypeASCIICapable, //ASCII
    BFKeyBoardTypePhone = UIKeyboardTypePhonePad, //电话号码
    BFKeyBoardTypeIDCardNo = UIKeyboardTypeASCIICapable,  //身份证号码
    BFKeyBoardTypeImgVerifyCode = UIKeyboardTypeASCIICapable, //图形验证码
    BFKeyBoardTypeSMSVerifyCode = UIKeyboardTypeNumberPad, //短信验证码
    BFKeyBoardTypeLoginPassword = UIKeyboardTypeASCIICapable, //登录密码
    BFKeyBoardTypePayPassword = UIKeyboardTypeNumberPad, //支付密码
    BFKeyBoardTypeBankCardNo = UIKeyboardTypeNumberPad, //银行卡号
    BFKeyBoardTypeNumber = UIKeyboardTypeNumberPad, //纯数字
    BFKeyBoardTypeAmount = UIKeyboardTypeNumberPad, //整数金额
    BFKeyBoardTypeAmountDecimal = UIKeyboardTypeDecimalPad //带小数的金额
};

@interface BFUIKit : NSObject

@end

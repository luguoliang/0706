//
//  ReachabilityTool.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/4/11.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Reachability.h"

typedef NS_ENUM(NSInteger, NetworkState) {
    NetworkStateUnknow = 0, //不可知
    NetworkStateUnable = 1, //网络不可用
    NetworkStateWiFi, //WiFi
    NetworkStateWWAN //移动数据
};

typedef void (^NetworkStateBlock) (NetworkState state);

@interface ReachabilityTool : NSObject

+ (NetworkState)checkNetworkState;

+ (void)checkNetworkStateBlock:(NetworkStateBlock)block;

@end

//
//  NSString+DetailString.m
//  makr
//
//  Created by mac on 15/4/23.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "NSString+DetailString.h"
#import "CryptoUtil.h"
#import "Base64.h"
#import <CommonCrypto/CommonDigest.h>
@implementation NSString (DetailString)

+(NSString *)percentWithTwoString:(NSString *)decimal
{
    return [NSString stringWithFormat:@"%@%%",decimal];
}

+(NSString *)percentWithZeroString:(NSString *)decimal
{
    return [NSString stringWithFormat:@"%@%%",decimal];
}

+(NSString *)getSurplusTime:(NSString *)surplusTimeStamp
{

    int day = [surplusTimeStamp intValue]/86400;
    int hour = ([surplusTimeStamp intValue] % 86400)/3600;
    int minute = (([surplusTimeStamp intValue] % 86400)%3600)/60;
    int seconds = (([surplusTimeStamp intValue] % 86400)%3600)%60;
    
    NSString *dayString = [NSString stringWithFormat:@"%d",day];
    if (dayString.length == 1) {
        dayString = [NSString stringWithFormat:@"00%@",dayString];
    }else if (dayString.length == 2)
    {
        dayString = [NSString stringWithFormat:@"0%@",dayString];
    }
    NSString *hourString = hour<10?[NSString stringWithFormat:@"0%d",hour]:[NSString stringWithFormat:@"%d",hour];
    NSString *minuteString = minute<10?[NSString stringWithFormat:@"0%d",minute]:[NSString stringWithFormat:@"%d",minute];
    NSString *secondsString = seconds<10?[NSString stringWithFormat:@"0%d",seconds]:[NSString stringWithFormat:@"%d",seconds];

    return [NSString stringWithFormat:@"%@,%@,%@,%@",dayString,hourString,minuteString,secondsString];
}
+ (NSUInteger) lenghtWithString:(NSString *)string
{
    NSUInteger len = string.length;
    // 汉字字符集
    NSString * pattern  = @"[\u4e00-\u9fa5]";
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:pattern options:NSRegularExpressionCaseInsensitive error:nil];
    // 计算中文字符的个数
    NSInteger numMatch = [regex numberOfMatchesInString:string options:NSMatchingReportProgress range:NSMakeRange(0, len)];
    
    return len + numMatch;
}

+(NSString *)moneyNumAndChangeformat:(NSString *)string isDisplayPoint:(BOOL)display
{
    
//    NSString *myString = [NSString stringWithFormat:@"%.2f",[string floatValue]];
    
//    NSLog(@"   %@",myString);
    
    NSNumber *moneyNumber = [NSNumber numberWithDouble:[string doubleValue]];
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc]init];
    
    formatter.numberStyle =NSNumberFormatterDecimalStyle;
    
    NSString *newAmount = [formatter stringFromNumber:moneyNumber];
    
    if (display == YES) {
        if ([self isPureInt:newAmount]==YES) {
            newAmount = [newAmount stringByAppendingString:@".00"];
        }
    }
    
    return newAmount;
}
+ (BOOL)isPureInt:(NSString*)string{
    NSScanner* scan = [NSScanner scannerWithString:string];
    int val;
    return[scan scanInt:&val] && [scan isAtEnd];
}
+(NSString *)digitalNumAndChangeformat:(NSString *)string
{
    string = [NSString stringWithFormat:@"%@",string];
    NSRange range = [string rangeOfString:@","];
    if(range.location !=NSNotFound)//_roaldSearchText
    {
        NSString *teStr = [string stringByReplacingCharactersInRange:range withString:@""];
        return teStr;
    }
    else
    {
        return string;
    }
    
}

+(NSString *)preMoneyWithBuyMoney:(NSInteger)buyMoney yearRate:(CGFloat)rate day:(NSInteger)dayCount
{
    CGFloat preMoney = (buyMoney * rate *dayCount)/365;
    
    //保留两位
    NSInteger money = preMoney*100;
    
    CGFloat myMoney = money/100.0;
    
    NSString *moneyString = [NSString stringWithFormat:@"%.2f",myMoney];
    
    NSLog(@"buyMoney %ld  preMoney%f  money%ld  myMoney%@",(long)buyMoney,preMoney,(long)money,moneyString);
    return moneyString;
}



+(NSString*)md5:(NSString *)str
{
    const char *cStr = [str UTF8String];
    unsigned char result[16];
    CC_MD5(cStr, strlen(cStr), result); // This is the md5 call
    NSString *s1tr = [NSString stringWithFormat:
                      @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
                      result[0], result[1], result[2], result[3],
                      result[4], result[5], result[6], result[7],
                      result[8], result[9], result[10], result[11],
                      result[12], result[13], result[14], result[15]
                      ];
    return s1tr;
}

+ (NSString *)serializeToUrlByDicString:(NSDictionary *)dic
{
    NSString *result = @"";
    if (dic == nil || dic.count == 0)
    {
        return result;
    }
    
    for (id key in dic)
    {
        result = [NSString stringWithFormat:@"%@%@%@%@%@",result,key,@"=",dic[key],@"&"];
    }
    if (result.length > 0)
    {
        result = [result substringToIndex:result.length - 1];
    }
    return result;
}
@end

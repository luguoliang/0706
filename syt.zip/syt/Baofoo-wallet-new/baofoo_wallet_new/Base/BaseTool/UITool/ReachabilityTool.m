//
//  ReachabilityTool.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/4/11.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "ReachabilityTool.h"

@implementation ReachabilityTool

+ (NetworkState)checkNetworkState{
    
    Reachability *reach = [Reachability reachabilityForInternetConnection];
    NetworkStatus netStatus = [reach currentReachabilityStatus];
    switch (netStatus) {
        case NotReachable: {
            
            return NetworkStateUnable;
            break;
        }
        case ReachableViaWiFi: {
            
            return NetworkStateWiFi;
            break;
        }
        case ReachableViaWWAN: {
            
            return NetworkStateWWAN;
            break;
        }
        default:
            break;
    }
    
    return NetworkStateUnknow;
}

+ (void)checkNetworkStateBlock:(NetworkStateBlock)block{
    
    NetworkState state = NetworkStateUnknow;
    
    Reachability *reach = [Reachability reachabilityForInternetConnection];
    NetworkStatus netStatus = [reach currentReachabilityStatus];
    switch (netStatus) {
        case NotReachable: {
            
            state = NetworkStateUnable;
            break;
        }
        case ReachableViaWiFi: {
            
            state = NetworkStateWiFi;
            break;
        }
        case ReachableViaWWAN: {
            
            state = NetworkStateWWAN;
            break;
        }
        default:
            break;
    }
    
    if (block) {
        block(state);
    }
}

@end

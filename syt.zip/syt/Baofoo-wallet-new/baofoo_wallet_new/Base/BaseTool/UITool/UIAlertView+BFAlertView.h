//
//  UIAlertView+BFAlertView.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/4/11.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

UIKIT_EXTERN NSString *const Alert_Title;
UIKIT_EXTERN NSString *const Alert_Title_Net_Error;
UIKIT_EXTERN NSString *const Alert_Title_Update;
UIKIT_EXTERN NSString *const Alert_Title_CameraAuth;

UIKIT_EXTERN NSString *const Alert_Message_Net_Error;
UIKIT_EXTERN NSString *const Alert_Message_Update;
UIKIT_EXTERN NSString *const Alert_Message_CameraAuth;
UIKIT_EXTERN NSString *const Alert_Message_PhotographAuth;
UIKIT_EXTERN NSString *const Alert_Message_SMSVerifyCode;
UIKIT_EXTERN NSString *const Alert_Message_CameraWrong;
UIKIT_EXTERN NSString *const Alert_Button_Cancel;
UIKIT_EXTERN NSString *const Alert_Button_Confirm;

UIKIT_EXTERN NSString *const Net_Error;
UIKIT_EXTERN NSString *const Net_Error_Code;
UIKIT_EXTERN NSString *const Net_Busy;

@interface UIAlertView (BFAlertView)

+ (UIAlertView *)showWithTitle:(NSString *)title message:(NSString *)message delegate:(id<UIAlertViewDelegate>)delegate cancelButtonTitle:(NSString *)cancelButtonTitle otherButtonTitles:(NSString *)otherButtonTitles;

+ (UIAlertView *)showSingleSelAlertWithTitle:(NSString *)title message:(NSString *)message buttonTitle:(NSString *)buttonTitle delegate:(id<UIAlertViewDelegate>)delegate;

+ (UIAlertView *)showWithMessage:(NSString *)message delegate:(id<UIAlertViewDelegate>)delegate;

+ (UIAlertView *)showNetErrorAlertWithDelegate:(id<UIAlertViewDelegate>)delegate;

+ (UIAlertView *)showReqFailedAlertWithCode:(NSString *)code message:(NSString *)message delegate:(id<UIAlertViewDelegate>)delegate;

@end

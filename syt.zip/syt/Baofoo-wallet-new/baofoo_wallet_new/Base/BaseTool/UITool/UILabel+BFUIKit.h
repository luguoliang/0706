//
//  UILabel+BFUIKit.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

UIKIT_EXTERN NSString *const BFFontProperty;
UIKIT_EXTERN NSString *const BFBackgroundColorProperty;
UIKIT_EXTERN NSString *const BFTextColorProperty;

@interface UILabel (BFUIKit)

@property (nonatomic, strong) NSDictionary *properties;

/**
 *  创建UILabel，背景透明，字体黑色，字体系统15.0
 */
+ (UILabel *)createWithFrame:(CGRect)frame;

/**
 *  创建UILabel
 */
+ (UILabel *)createWithFrame:(CGRect)frame textColor:(UIColor *)textColor font:(UIFont *)font;

#pragma mark - Properties

+ (NSDictionary *)cellTextProperties;
+ (CGFloat)width:(NSString *)contentString heightOfFatherView:(CGFloat)height textFont:(UIFont *)font;

+ (CGFloat)height:(NSString *)contentString widthOfFatherView:(CGFloat)width textFont:(UIFont *)font;
@end

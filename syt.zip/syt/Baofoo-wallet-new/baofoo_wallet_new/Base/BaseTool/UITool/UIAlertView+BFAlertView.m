//
//  UIAlertView+BFAlertView.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/4/11.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "UIAlertView+BFAlertView.h"

NSString *const Alert_Title = @"宝付钱包";
NSString *const Alert_Title_Net_Error = @"网络无法连接";
NSString *const Alert_Title_Update = @"更新";
NSString *const Alert_Title_CameraAuth = @"未获得授权使用摄像头";

NSString *const Alert_Message_Net_Error = @"请查看网络设置或稍后重试";
NSString *const Alert_Message_Update = @"您的客户端版本过低，需要升级才能使用后续功能，是否升级？";
NSString *const Alert_Message_CameraAuth = @"请在设备的\"设置\"-\"隐私\"-\"相机\"中，允许宝付钱包访问。";
NSString *const Alert_Message_PhotographAuth = @"请在设备的\"设置\"-\"隐私\"-\"照片\"中，允许宝付钱包访问。";
NSString *const Alert_Message_CameraWrong = @"您的后摄像头不可用";
NSString *const Alert_Message_SMSVerifyCode = @"短信验证码下发成功";

NSString *const Alert_Button_Cancel = @"取消";
NSString *const Alert_Button_Confirm = @"确定";

NSString *const Net_Error = @"网络无法连接\n请查看网络设置或稍后重试";
NSString *const Net_Error_Code = @"-999999";
NSString *const Net_Busy = @"服务器繁忙，请稍后重试";

@implementation UIAlertView (BFAlertView)

+ (UIAlertView *)showWithTitle:(NSString *)title message:(NSString *)message delegate:(id<UIAlertViewDelegate>)delegate cancelButtonTitle:(NSString *)cancelButtonTitle otherButtonTitles:(NSString *)otherButtonTitles{
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:delegate cancelButtonTitle:cancelButtonTitle otherButtonTitles:otherButtonTitles, nil];
    [alert show];
    return alert;
}

+ (UIAlertView *)showSingleSelAlertWithTitle:(NSString *)title message:(NSString *)message buttonTitle:(NSString *)buttonTitle delegate:(id<UIAlertViewDelegate>)delegate{
    return [[self class] showWithTitle:title message:message delegate:delegate cancelButtonTitle:buttonTitle otherButtonTitles:nil];
}

+ (UIAlertView *)showWithMessage:(NSString *)message delegate:(id<UIAlertViewDelegate>)delegate{
    return [[self class] showSingleSelAlertWithTitle:Alert_Title message:message buttonTitle:Alert_Button_Confirm delegate:delegate];
}
+ (UIAlertView *)showNetErrorAlertWithDelegate:(id<UIAlertViewDelegate>)delegate{
    return [[self class] showSingleSelAlertWithTitle:Alert_Title_Net_Error message:Alert_Message_Net_Error buttonTitle:Alert_Button_Confirm delegate:delegate];
}

+ (UIAlertView *)showReqFailedAlertWithCode:(NSString *)code message:(NSString *)message delegate:(id<UIAlertViewDelegate>)delegate{
    
    if (code && [code isEqualToString:Net_Error_Code]) {
        return [[self class] showNetErrorAlertWithDelegate:delegate];
    }
    else {
        return [[self class] showWithMessage:message delegate:delegate];
    }
}

@end

//
//  UIView+BFAddition.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "UIView+BFAddition.h"

@implementation UIView (BFAddition)

#pragma mark - Size

- (void)setSize:(CGSize)size{
    
    CGRect frame = self.frame;
    self.frame = CGRectMake(frame.origin.x, frame.origin.y, size.width, size.height);
}
- (CGSize)size{
    return self.frame.size;
}

- (void)setSize_W:(CGFloat)_size_W{
    CGRect frame = self.frame;
    self.frame = CGRectMake(frame.origin.x, frame.origin.y, _size_W, frame.size.height);
}
- (CGFloat)size_W{
    return self.frame.size.width;
}

- (void)setSize_H:(CGFloat)_size_H{
    CGRect frame = self.frame;
    self.frame = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, _size_H);
}
- (CGFloat)size_H{
    return self.frame.size.height;
}

#pragma mark - Origin

- (void)setOrigin:(CGPoint)origin{
    CGRect frame = self.frame;
    self.frame = CGRectMake(origin.x, origin.y, frame.size.width, frame.size.height);
}
- (CGPoint)origin{
    return self.frame.origin;
}

- (void)setOrigin_X:(CGFloat)_origin_X{
    CGRect frame = self.frame;
    self.frame = CGRectMake(_origin_X, frame.origin.y, frame.size.width, frame.size.height);
}
- (CGFloat)origin_X{
    return self.frame.origin.x;
}

- (void)setOrigin_Y:(CGFloat)_origin_Y{
    CGRect frame = self.frame;
    self.frame = CGRectMake(frame.origin.x, _origin_Y, frame.size.width, frame.size.height);
}
- (CGFloat)origin_Y{
    return self.frame.origin.y;
}

#pragma mark - Bottom

- (void)setBottom:(CGPoint)bottom{
    CGRect frame = self.frame;
    
    self.frame = CGRectMake(bottom.x-frame.size.width, bottom.y-frame.size.height, frame.size.width, frame.size.height);
}
- (CGPoint)bottom{
    
    CGFloat x = self.frame.origin.x+self.frame.size.width;
    CGFloat y = self.frame.origin.y+self.frame.size.height;
    
    return CGPointMake(x, y);
}

- (void)setBottom_X:(CGFloat)_bottom_X{
    CGRect frame = self.frame;
    self.frame = CGRectMake(_bottom_X-frame.size.width, frame.origin.y, frame.size.width, frame.size.height);
}
- (CGFloat)bottom_X{
    return self.frame.origin.x+self.frame.size.width;
}

- (void)setBottom_Y:(CGFloat)_bottom_Y{
    CGRect frame = self.frame;
    self.frame = CGRectMake(frame.origin.x, _bottom_Y-frame.size.height, frame.size.width, frame.size.height);
}
- (CGFloat)bottom_Y{
    return self.frame.origin.y+self.frame.size.height;
}

#pragma mark - Center

- (void)setCenter_X:(CGFloat)_center_X{
    CGPoint center = self.center;
    center.x = _center_X;
    self.center = center;
}
- (CGFloat)center_X{
    return self.center.x;
}

- (void)setCenter_Y:(CGFloat)_center_Y{
    CGPoint center = self.center;
    center.y = _center_Y;
    self.center = center;
}
- (CGFloat)center_Y{
    return self.center.y;
}

#pragma mark - Margin

- (void)setMargin:(CGMargin)margin{
    if (self.superview) {
        CGRect frame = self.superview.bounds;
        self.frame = CGRectMake(margin.left, margin.top, frame.size.width-margin.left-margin.right, frame.size.height-margin.top-margin.bottom);
    }
}
- (CGMargin)margin{
    
    if (self.superview) {
        CGRect frame = self.superview.bounds;
        CGFloat top = self.frame.origin.y;
        CGFloat left = self.frame.origin.x;
        CGFloat bottom = frame.size.height-top-self.frame.size.height;
        CGFloat right = frame.size.width-left-self.frame.size.width;
        CGMargin margin = CGMarginMake(top, left, bottom, right);
        return margin;
    }
    return CGMarginMake(0, 0, 0, 0);
}

- (void)setMarginTop:(CGFloat)marginTop{
    CGRect frame = self.frame;
    self.frame = CGRectMake(frame.origin.x, marginTop, frame.size.width, frame.size.height);
}
- (CGFloat)marginTop{
    return self.frame.origin.y;
}

- (void)setMarginLeft:(CGFloat)marginLeft{
    CGRect frame = self.frame;
    self.frame = CGRectMake(marginLeft, frame.origin.y, frame.size.width, frame.size.height);
}
- (CGFloat)marginLeft{
    return self.frame.origin.x;
}

- (void)setMarginBottom:(CGFloat)marginBottom{
    if (self.superview) {
        CGRect frame = self.superview.bounds;
        self.frame = CGRectMake(self.frame.origin.x, frame.size.height-marginBottom-self.frame.size.height, self.frame.size.width, self.frame.size.height);
    }
}
- (CGFloat)marginBottom{
    if (self.superview) {
        CGRect frame = self.superview.bounds;
        return (frame.size.height-self.frame.origin.y-self.frame.size.height);
    }
    return 0;
}

- (void)setMarginRight:(CGFloat)marginRight{
    if (self.superview) {
        CGRect frame = self.superview.bounds;
        self.frame = CGRectMake(frame.size.width-marginRight-self.frame.size.width, self.frame.origin.y, self.frame.size.width, self.frame.size.height);
    }
}
- (CGFloat)marginRight{
    if (self.superview) {
        CGRect frame = self.superview.bounds;
        return (frame.size.width-self.frame.origin.x-self.frame.size.width);
    }
    return 0;
}

@end

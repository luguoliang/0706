//
//  UIColor+BFColorTool.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/6.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (BFColorTool)

//用色值创建颜色 RGB都是number
+ (UIColor*)BFcolorWithFloat:(CGFloat)number;

//用RGB创建颜色，分别设置RGB，无需除以255
+ (UIColor *)BFcolorWithRed:(CGFloat)red
                      green:(CGFloat)green
                       blue:(CGFloat)blue;

//用RGBA创建颜色，无需除以255.0
+ (UIColor *)BFcolorWithRed:(CGFloat)red
                      green:(CGFloat)green
                       blue:(CGFloat)blue
                      alpha:(CGFloat)alpha;

// 16 进制颜色创建
+ (UIColor *)BFcolorWithHexString:(NSString *)str;
// 根据hex字符串和alpha创建颜色
+ (UIColor *)BFcolorWithHexString:(NSString *)hexString alpha:(CGFloat)alpha;

@end

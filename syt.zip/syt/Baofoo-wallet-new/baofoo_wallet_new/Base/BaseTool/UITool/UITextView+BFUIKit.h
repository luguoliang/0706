//
//  UITextView+BFUIKit.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextView (BFUIKit)

/**
 *  创建UITextView，背景透明
 */
+ (UITextView *)createWithFrame:(CGRect)frame delegate:(id<UITextViewDelegate>)delegate;

@end

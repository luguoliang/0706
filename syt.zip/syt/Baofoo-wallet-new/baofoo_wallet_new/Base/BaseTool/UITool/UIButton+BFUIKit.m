//
//  UIButton+BFUIKit.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "UIButton+BFUIKit.h"

#define Button_Normal_Color [UIColor colorWithRed:252.0/255.0 green:49.0/255.0 blue:89.0/255.0 alpha:1.0]
#define Button_Highlight_Color [UIColor whiteColor]
#define Button_Disable_Color [UIColor whiteColor]
#define ImageStretch UIEdgeInsetsMake(0, 20, 0, 20)

#define endBtnImage @""
#define endBtnHeighLightImage @""

#define btn_belt_normal @""
#define btn_belt_highlighted @""
#define btn_disable @""
#define btn_belt_highlighted2 @""
#define btn_belt_disable @""

#define BeltHeight  45
#define BeltSideGap  30


@implementation UIButton (BFUIKit)

@dynamic titleFont;

@dynamic normalTitle;
@dynamic highlightedTitle;
@dynamic disableTitle;

@dynamic normalTitleColor;
@dynamic highlightedTitleColor;
@dynamic disableTitleColor;

@dynamic normalBackgroundImage;
@dynamic hightlightedBackgroundImage;
@dynamic disabledBackgroundImage;

@dynamic normalImage;
@dynamic hightlightedImage;
@dynamic disabledImage;


+ (UIButton *)createWithFrame:(CGRect)frame target:(id)target action:(SEL)action{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;
    button.backgroundColor = UIColorClear();
    button.titleLabel.font = BF_Font_Default;
    button.normalTitleColor = UIColorWhite();
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

+ (UIButton *)createWithFrame:(CGRect)frame title:(NSString *)title target:(id)target action:(SEL)action{
    UIButton *button = [[self class] createWithFrame:frame target:target action:action];
    button.normalTitle = title;
    return button;
}

+ (UIButton *)createEndButtonWithTitle:(NSString *)title target:(id)target action:(SEL)action{
    CGRect frame = CGRectMake(15.0, 0.0, [UIScreen mainScreen].bounds.size.width-30.0, 43.0);
    
    UIButton *button = [[self class] createWithFrame:frame target:target action:action];
    button.normalTitle = title;
    button.titleFont = BF_Font_EndButton;
    button.normalBackgroundImage = [UIImage UIKitResourceImageNamed:endBtnImage];
    button.hightlightedBackgroundImage = [UIImage UIKitResourceImageNamed:endBtnHeighLightImage];
    return button;
}

#pragma mark - Getter & Setter

- (UIFont *)titleFont{
    return self.titleLabel.font;
}
- (void)setTitleFont:(UIFont *)titleFont{
    self.titleLabel.font = titleFont;
}

//title
- (NSString *)normalTitle{
    return [self titleForState:UIControlStateNormal];
}
- (void)setNormalTitle:(NSString *)normalTitle{
    [self setTitle:normalTitle forState:UIControlStateNormal];
}

- (NSString *)highlightedTitle{
    return [self titleForState:UIControlStateHighlighted];
}
- (void)setHighlightedTitle:(NSString *)highlightedTitle{
    [self setTitle:highlightedTitle forState:UIControlStateHighlighted];
}

- (NSString *)disableTitle{
    return [self titleForState:UIControlStateDisabled];
}
- (void)setDisableTitle:(NSString *)disableTitle{
    [self setTitle:disableTitle forState:UIControlStateDisabled];
}

//title color
- (UIColor *)normalTitleColor{
    return [self titleColorForState:UIControlStateNormal];
}
- (void)setNormalTitleColor:(UIColor *)normalTitleColor{
    [self setTitleColor:normalTitleColor forState:UIControlStateNormal];
}

- (UIColor *)highlightedTitleColor{
    return [self titleColorForState:UIControlStateHighlighted];
}
- (void)setHighlightedTitleColor:(UIColor *)highlightedTitleColor{
    [self setTitleColor:highlightedTitleColor forState:UIControlStateHighlighted];
}

- (UIColor *)disableTitleColor{
    return [self titleColorForState:UIControlStateDisabled];
}
- (void)setDisableTitleColor:(UIColor *)disableTitleColor{
    [self setTitleColor:disableTitleColor forState:UIControlStateDisabled];
}

//backgroundImage
- (UIImage *)normalBackgroundImage{
    return [self backgroundImageForState:UIControlStateNormal];
}
- (void)setNormalBackgroundImage:(UIImage *)normalBackgroundImage{
    [self setBackgroundImage:normalBackgroundImage forState:UIControlStateNormal];
}

- (UIImage *)hightlightedBackgroundImage{
    return [self backgroundImageForState:UIControlStateHighlighted];
}
- (void)setHightlightedBackgroundImage:(UIImage *)hightlightedBackgroundImage{
    [self setBackgroundImage:hightlightedBackgroundImage forState:UIControlStateHighlighted];
}

- (UIImage *)disabledBackgroundImage{
    return [self backgroundImageForState:UIControlStateDisabled];
}
- (void)setDisabledBackgroundImage:(UIImage *)disabledBackgroundImage{
    [self setBackgroundImage:disabledBackgroundImage forState:UIControlStateDisabled];
}

//image
- (UIImage *)normalImage{
    return [self imageForState:UIControlStateNormal];
}
- (void)setNormalImage:(UIImage *)normalImage{
    [self setImage:normalImage forState:UIControlStateNormal];
}

- (UIImage *)hightlightedImage{
    return [self imageForState:UIControlStateHighlighted];
}
- (void)setHightlightedImage:(UIImage *)hightlightedImage{
    [self setImage:hightlightedImage forState:UIControlStateHighlighted];
}

- (UIImage *)disabledImage{
    return [self imageForState:UIControlStateDisabled];
}
- (void)setDisabledImage:(UIImage *)disabledImage{
    [self setImage:disabledImage forState:UIControlStateDisabled];
}

@end

#pragma mark -
#pragma mark - BeltButton

@implementation BeltButton

+ (BeltButton *)createWithType:(BeltButtonType)type title:(NSString *)title target:(id)target action:(SEL)action{
    BeltButton *button = [BeltButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(30.0, 0, [UIScreen mainScreen].bounds.size.width-30.0*2, 45.0);
    button.backgroundColor = UIColorClear();
    button.titleFont = BF_Font_17;
    button.normalTitle = title;
    button.normalTitleColor = UIColorWhite();
    [button setType:type];
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    return button;
}

+ (BeltButton *)createWithTitle:(NSString *)title target:(id)target action:(SEL)action{
    return [[self class] createWithType:BeltButtonTypeCustom title:title target:target action:action];
}

- (void)setType:(BeltButtonType)type{
    
    switch (type) {
        case BeltButtonTypeCustom: {
            
            break;
        }
        case BeltButtonTypeCommon: {
            
            self.normalTitleColor = UIColorRgb(252, 49, 89);
            self.highlightedTitleColor = UIColorWhite();
            self.disableTitleColor = UIColorWhite();
            
            UIEdgeInsets imageStretch = UIEdgeInsetsMake(0, 20, 0, 20);
            self.normalBackgroundImage = [[UIImage UIKitResourceImageNamed:btn_belt_normal] resizableImageWithCapInsets:imageStretch];
            self.hightlightedBackgroundImage = [[UIImage UIKitResourceImageNamed:btn_belt_highlighted] resizableImageWithCapInsets:imageStretch];
            self.disabledBackgroundImage = [[UIImage UIKitResourceImageNamed:btn_disable] resizableImageWithCapInsets:imageStretch];
            
            break;
        }
        case BeltButtonTypeHighlighted: {
            
            self.normalTitleColor = UIColorWhite();
            self.highlightedTitleColor = UIColorWhite();
            self.disableTitleColor = UIColorWhite();
            
            UIEdgeInsets imageStretch = UIEdgeInsetsMake(0, 20, 0, 20);
            self.normalBackgroundImage = [[UIImage UIKitResourceImageNamed:btn_belt_highlighted] resizableImageWithCapInsets:imageStretch];
            self.hightlightedBackgroundImage = [[UIImage UIKitResourceImageNamed:btn_belt_highlighted2] resizableImageWithCapInsets:imageStretch];
            self.disabledBackgroundImage = [[UIImage UIKitResourceImageNamed:btn_belt_disable] resizableImageWithCapInsets:imageStretch];
            
            break;
        }
        default:
            break;
    }
}
@end

//
//  UITextField+BFUIKit.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "UITextField+BFUIKit.h"

@implementation UITextField (BFUIKit)

+ (UITextField *)createWithFrame:(CGRect)frame placeholder:(NSString *)placeholder delegate:(id<UITextFieldDelegate>)delegate{
    
    UITextField *textFiled = [[UITextField alloc] initWithFrame:frame];
    textFiled.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    textFiled.clearButtonMode = UITextFieldViewModeWhileEditing;
    textFiled.delegate = delegate;
    textFiled.backgroundColor = UIColorClear();
    textFiled.placeholder = placeholder;
    textFiled.font = BF_Font_TextFieldContent;
    textFiled.textColor = BF_Color_TextFieldContent;
    return textFiled;
}

- (void)setPlaceholderWithText:(NSString *)text textColor:(UIColor *)textColor{
    if (!text) {
        text = @"";
    }
    
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    attributes[NSForegroundColorAttributeName] = textColor?textColor:BF_Color_TextFieldPlaceholder;
    attributes[NSFontAttributeName] = self.font;
    
    self.attributedPlaceholder = [[NSAttributedString alloc] initWithString:text attributes:attributes];
}

- (void)setPlaceholder:(NSString *)placeholder{
    [self setPlaceholderWithText:placeholder textColor:BF_Color_TextFieldPlaceholder];
}

#pragma mark - Title Label

- (UILabel *)showTitleLabelWithTitle:(NSString *)title titleColor:(UIColor *)titleColor margin:(CGFloat)margin width:(CGFloat)width{
    
    UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, margin+width, self.frame.size.height)];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(margin, 0, width, self.frame.size.height)];
    label.font = self.font;
    label.backgroundColor = UIColorClear();
    label.textColor = titleColor?titleColor:BF_Color_TextFieldTitle;
    label.text = title;
    [leftView addSubview:label];
    
    self.leftView = leftView;
    self.leftViewMode = UITextFieldViewModeAlways;
    return label;
}

- (UILabel *)showTitleLabelWithTitle:(NSString *)title margin:(CGFloat)margin width:(CGFloat)width{
    return [self showTitleLabelWithTitle:title titleColor:BF_Color_TextFieldTitle margin:margin width:width];
}
- (UILabel *)showTitleLabelWithTitle:(NSString *)title margin:(CGFloat)margin{
    return [self showTitleLabelWithTitle:title titleColor:BF_Color_TextFieldTitle margin:margin width:BF_Width_TextFieldTitle];
}

- (UILabel *)showTitleLabelWithTitle:(NSString *)title titleColor:(UIColor *)titleColor{
    return [self showTitleLabelWithTitle:title titleColor:titleColor margin:0 width:BF_Width_TextFieldTitle];
}
- (UILabel *)showTitleLabelWithTitle:(NSString *)title{
    return [self showTitleLabelWithTitle:title titleColor:BF_Color_TextFieldTitle margin:0 width:BF_Width_TextFieldTitle];
}

@end

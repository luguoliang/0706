//
//  UIButton+BFUIKit.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (BFUIKit)

@property (nonatomic, strong) UIFont *titleFont;

//title
@property (nonatomic, copy) NSString *normalTitle;
@property (nonatomic, copy) NSString *highlightedTitle;
@property (nonatomic, copy) NSString *disableTitle;

//title Color
@property (nonatomic, strong) UIColor *normalTitleColor;
@property (nonatomic, strong) UIColor *highlightedTitleColor;
@property (nonatomic, strong) UIColor *disableTitleColor;

//backgroundImage
@property (nonatomic, strong) UIImage *normalBackgroundImage;
@property (nonatomic, strong) UIImage *hightlightedBackgroundImage;
@property (nonatomic, strong) UIImage *disabledBackgroundImage;

//image
@property (nonatomic, strong) UIImage *normalImage;
@property (nonatomic, strong) UIImage *hightlightedImage;
@property (nonatomic, strong) UIImage *disabledImage;

/**
 *  创建UIButton，背景透明，字体系统15.0，字体颜色白色
 */
+ (UIButton *)createWithFrame:(CGRect)frame target:(id)target action:(SEL)action;

+ (UIButton *)createWithFrame:(CGRect)frame title:(NSString *)title target:(id)target action:(SEL)action;

+ (UIButton *)createEndButtonWithTitle:(NSString *)title target:(id)target action:(SEL)action;

@end



#pragma mark - BeltButton

typedef NS_ENUM(NSInteger, BeltButtonType) {
    BeltButtonTypeCustom = 0,
    BeltButtonTypeCommon,
    BeltButtonTypeHighlighted
};


@interface BeltButton : UIButton

//frame = CGRectMake(30.0, 0, [UIScreen mainScreen].bounds.size.width-30.0*2, 45.0);
+ (BeltButton *)createWithType:(BeltButtonType)type title:(NSString *)title target:(id)target action:(SEL)action;
+ (BeltButton *)createWithTitle:(NSString *)title target:(id)target action:(SEL)action; //type:BeltButtonTypeCustom

@end

//
//  UIImage+BFUIKitResource.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "UIImage+BFUIKitResource.h"

@implementation UIImage (BFUIKitResource)

+ (UIImage *)UIKitResourceImageNamed:(NSString *)name{
    UIImage *imageFromMainBundle = [UIImage imageNamed:name];
    if (imageFromMainBundle) {
        return imageFromMainBundle;
    }
    
    NSInteger scale = (NSInteger)[[UIScreen mainScreen] scale];
    for (NSInteger i = scale; i >= 1; i--) {
        NSString *filepath = [self getUIKitImagePath:name scale:i];
        UIImage *tempImage = [UIImage imageWithContentsOfFile:filepath];
        if (tempImage) {
            return tempImage;
        }
    }
    return nil;
}

+ (NSString *)getUIKitImagePath:(NSString *)name scale:(NSInteger)scale{
    
    NSString *imgPath = [[[NSBundle mainBundle] pathForResource:@"BestpayUIKitBundle" ofType:@"bundle"] stringByAppendingPathComponent:name];
    return imgPath;
}
@end

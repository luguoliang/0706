//
//  NSMutableAttributedString+MutableString.m
//  makr
//
//  Created by mac on 15/4/24.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import "NSMutableAttributedString+MutableString.h"

@implementation NSMutableAttributedString (MutableString)

+ (NSMutableAttributedString *)stringWithText1:(NSString *)string1 text2:(NSString *)string2 text1Color:(UIColor*)color1 text2Color:(UIColor *)color2 font1:(UIFont *)font1 font2:(UIFont *)font2
{
    if ([string2 rangeOfString:@"小时"].location != NSNotFound ) {
        
        NSRange xiaoshiRange = [string2 rangeOfString:@"小时"];
        NSRange fenRange = [string2 rangeOfString:@"分"];
        NSRange miaoRange = [string2 rangeOfString:@"秒"];
        
        NSInteger length1 = [string1 length];
//        NSInteger length2 = [string2 length];
        
        NSString *allString = [NSString stringWithFormat:@"%@%@",string1,string2];
        NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:allString];
        [str addAttribute:NSForegroundColorAttributeName value:color1 range:NSMakeRange(0,length1)];
        [str addAttribute:NSForegroundColorAttributeName value:color1 range:NSMakeRange(length1+xiaoshiRange.location, xiaoshiRange.length)];
        [str addAttribute:NSForegroundColorAttributeName value:color1 range:NSMakeRange(length1+fenRange.location, fenRange.length)];
        [str addAttribute:NSForegroundColorAttributeName value:color1 range:NSMakeRange(length1+miaoRange.location, miaoRange.length)];
        
        [str addAttribute:NSFontAttributeName value:font1 range:NSMakeRange(0,length1)];
        [str addAttribute:NSFontAttributeName value:font1 range:NSMakeRange(length1+xiaoshiRange.location, xiaoshiRange.length)];
        [str addAttribute:NSFontAttributeName value:font1 range:NSMakeRange(length1+fenRange.location, fenRange.length)];
        [str addAttribute:NSFontAttributeName value:font1 range:NSMakeRange(length1+miaoRange.location, miaoRange.length)];
        return str;
        
    }else
    {
        NSInteger length1 = [string1 length];
        NSInteger length2 = [string2 length];
        
        NSString *allString = [NSString stringWithFormat:@"%@%@",string1,string2];
        NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:allString];
        [str addAttribute:NSForegroundColorAttributeName value:color1 range:NSMakeRange(0,length1)];
        [str addAttribute:NSForegroundColorAttributeName value:color2 range:NSMakeRange(length1,length2)];
        
        [str addAttribute:NSFontAttributeName value:font1 range:NSMakeRange(0,length1)];
        [str addAttribute:NSFontAttributeName value:font2 range:NSMakeRange(length1,length2)];
        return str;
    }
    
    
    
}

+ (NSMutableAttributedString *)stringMoneyText1:(NSString *)string1 text2:(NSString *)string2 text1Color:(UIColor*)color1 text2Color:(UIColor *)color2 font1:(UIFont *)font1 font2:(UIFont *)font2
{
    
    NSInteger length1 = [string1 length];
    NSInteger length2 = [[NSString stringWithFormat:@"%@",string2] length];
    
    NSString *allString = [NSString stringWithFormat:@"预期总收益：%@元 账户余额：%@元",string1,string2];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:allString];
    [str addAttribute:NSForegroundColorAttributeName value:color1 range:NSMakeRange(6,length1)];
    [str addAttribute:NSForegroundColorAttributeName value:color2 range:NSMakeRange(13+length1,length2)];
    
    [str addAttribute:NSFontAttributeName value:font1 range:NSMakeRange(6,length1)];
    [str addAttribute:NSFontAttributeName value:font2 range:NSMakeRange(13+length1,length2)];
    
    return str;
}
+ (NSMutableAttributedString *)threeStringWithText1:(NSString *)string1 text2:(NSString *)string2 text3:(NSString *)string3 text1Color:(UIColor*)color1 text2Color:(UIColor *)color2 text3Color:(UIColor *)color3 font1:(UIFont *)font1 font2:(UIFont *)font2 font3:(UIFont *)font3
{
    
    NSInteger length1 = [string1 length];
    NSInteger length2 = [[NSString stringWithFormat:@"%@",string2] length];
    NSInteger length3 = [string3 length];
    
    NSString *allString = [NSString stringWithFormat:@"%@%@%@",string1,string2,string3];
    
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:allString];
    [str addAttribute:NSForegroundColorAttributeName value:color1 range:NSMakeRange(0,length1)];
    [str addAttribute:NSForegroundColorAttributeName value:color2 range:NSMakeRange(length1,length2)];
    [str addAttribute:NSForegroundColorAttributeName value:color3 range:NSMakeRange(length1+length2,length3)];
    
    [str addAttribute:NSFontAttributeName value:font1 range:NSMakeRange(0,length1)];
    [str addAttribute:NSFontAttributeName value:font2 range:NSMakeRange(length1,length2)];
    [str addAttribute:NSFontAttributeName value:font3 range:NSMakeRange(length1+length2,length3)];
    
    return str;
}

+ (NSMutableAttributedString *)stringWithText1:(NSString *)string1 text2:(NSString *)string2 text1Color:(UIColor*)color1 text2Colot:(UIColor *)color2 font1:(UIFont *)font1 font2:(UIFont *)font2
{
    NSInteger length1 = [string1 length];
    NSInteger length2 = [string2 length];
    
    NSString *allString = [NSString stringWithFormat:@"%@%@",string1,string2];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:allString];
    [str addAttribute:NSForegroundColorAttributeName value:color1 range:NSMakeRange(0,length1)];
    [str addAttribute:NSForegroundColorAttributeName value:color2 range:NSMakeRange(length1,length2)];
    [str addAttribute:NSFontAttributeName value:font1 range:NSMakeRange(0,length1)];
    [str addAttribute:NSFontAttributeName value:font2 range:NSMakeRange(length1,length2)];
    
    return str;
}
@end

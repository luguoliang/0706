//
//  UIBarButtonItem+BFUIKit.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "UIBarButtonItem+BFUIKit.h"

@implementation UIBarButtonItem (BFUIKit)

+ (UIBarButtonItem *)createWithTitle:(NSString *)title normalImage:(UIImage *)normalImage highlightedImage:(UIImage *)highlightedImage tagert:(id)tagert action:(SEL)action{
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.backgroundColor = UIColorClear();
    btn.titleLabel.font = BF_Font_NavBarButtonItem;
    [btn setTitleColor:BF_Color_NavBarButtonItem forState:UIControlStateNormal];
    
    if (normalImage) {
        [btn setImage:normalImage forState:UIControlStateNormal];
    }
    if (highlightedImage) {
        [btn setImage:highlightedImage forState:UIControlStateHighlighted];
    }
    if (title != nil && ![title isEqualToString:@""]) {
        [btn setTitle:title forState:UIControlStateNormal];
    }
    
    [btn sizeToFit];
    [btn addTarget:tagert action:action forControlEvents:UIControlEventTouchUpInside];
    
    return [[UIBarButtonItem alloc] initWithCustomView:btn];
}

@end

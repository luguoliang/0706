//
//  UIFont+BFAddition.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIFont (BFAddition)

@end

/**
 *  系统字体
 *
 *  @param fontSize 字体Size
 */
CG_INLINE UIFont *UIFontSystemOfSize(CGFloat fontSize) {
    return [UIFont systemFontOfSize:fontSize];
}

CG_INLINE UIFont *UIFontNameOfSize(NSString *fontName, CGFloat fontSize) {
    return [UIFont fontWithName:fontName size:fontSize];
}

//
//  UILabel+BFUIKit.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "UILabel+BFUIKit.h"

NSString *const BFFontProperty = @"BFFontProperty";
NSString *const BFBackgroundColorProperty = @"BFBackgroundColorProperty";
NSString *const BFTextColorProperty = @"BFTextColorProperty";

@implementation UILabel (BFUIKit)
@dynamic properties;


+ (UILabel *)createWithFrame:(CGRect)frame{
    
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.backgroundColor = UIColorClear();
    label.textColor = BF_Color_TextDefault;
    label.font = BF_Font_Default;
    label.numberOfLines = 0;
    label.textAlignment = NSTextAlignmentLeft;
    return label;
}

+ (UILabel *)createWithFrame:(CGRect)frame textColor:(UIColor *)textColor font:(UIFont *)font{
    UILabel *label = [[self class] createWithFrame:frame];
    label.textColor = textColor?textColor:BF_Color_TextDefault;
    label.font = font?font:BF_Font_Default;
    return label;
}

#pragma mark - Properties

- (void)setProperties:(NSDictionary *)properties{
    
    for (NSString *key in properties) {
        id value = properties[key];
        
        if ([key isEqualToString:BFFontProperty] && [value isKindOfClass:[UIFont class]]) {
            self.font = (UIFont *)value;
        }
        else if ([key isEqualToString:BFBackgroundColorProperty] && [value isKindOfClass:[UIColor class]]) {
            self.backgroundColor = (UIColor *)value;
        }
        else if ([key isEqualToString:BFTextColorProperty] && [value isKindOfClass:[UIColor class]]) {
            self.textColor = (UIColor *)value;
        }
    }
}

+ (NSDictionary *)cellTextProperties{
    NSMutableDictionary *properties = [NSMutableDictionary dictionary];
    properties[BFBackgroundColorProperty] = UIColorClear();
    properties[BFTextColorProperty] = BF_Color_CellText;
    properties[BFFontProperty] = BF_Font_CellText;
    
    return properties;
}

+ (CGFloat)width:(NSString *)contentString heightOfFatherView:(CGFloat)height textFont:(UIFont *)font{
#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_7_0
    CGSize size = [contentString sizeWithFont:font constrainedToSize:CGSizeMake(CGFLOAT_MAX, height)];
    return size.width ;
#else
    NSDictionary *attributesDic = @{NSFontAttributeName:font};
    CGSize size = [contentString boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, height) options:NSStringDrawingUsesLineFragmentOrigin attributes:attributesDic context:nil].size;
    return size.width;
#endif
}

+ (CGFloat)height:(NSString *)contentString widthOfFatherView:(CGFloat)width textFont:(UIFont *)font{
#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_7_0
    CGSize size = [contentString sizeWithFont:font constrainedToSize:CGSizeMake(width, CGFLOAT_MAX)];
    return size.height;
#else
    NSDictionary *attributesDic = @{NSFontAttributeName:font};
    CGSize size = [contentString boundingRectWithSize:CGSizeMake(width, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:attributesDic context:nil].size;
    return size.height;
#endif
}
@end

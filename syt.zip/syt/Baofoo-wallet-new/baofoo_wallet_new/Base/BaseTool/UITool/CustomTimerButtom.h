//
//  CustomTimerButtom.h
//  BaofooMWallet
//
//  Created by 国良 on 14-11-21.
//  Copyright (c) 2014年 国良. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTimerButtom : UIButton
@property(nonatomic,strong)NSTimer *timer;
@property(nonatomic,assign)int number;
-(void)startTimer;
-(void)stopTimer;
@end

//
//  UIView+BFAddition.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>


//边距
struct CGMargin {
    CGFloat top; //上
    CGFloat left; //左
    CGFloat bottom; //下
    CGFloat right; //右
};
typedef struct CGMargin CGMargin;

/**
 *  边距
 *
 *  @param top    上边距
 *  @param left   左边距
 *  @param bottom 下边距
 *  @param right  右边距
 */
CG_INLINE CGMargin CGMarginMake(CGFloat top, CGFloat left, CGFloat bottom, CGFloat right) {
    CGMargin margin;
    margin.top = top;
    margin.left = left;
    margin.bottom = bottom;
    margin.right = right;
    return margin;
}

@interface UIView (BFAddition)

#pragma mark - Size

@property (assign, nonatomic) CGSize size;
@property (assign, nonatomic) CGFloat size_W;
@property (assign, nonatomic) CGFloat size_H;

#pragma mark - Origin

@property (assign, nonatomic) CGPoint origin;
@property (assign, nonatomic) CGFloat origin_X;
@property (assign, nonatomic) CGFloat origin_Y;

#pragma mark - Bottom

@property (assign, nonatomic) CGPoint bottom;
@property (assign, nonatomic) CGFloat bottom_X;
@property (assign, nonatomic) CGFloat bottom_Y;

#pragma mark - Center

@property (assign, nonatomic) CGFloat center_X;
@property (assign, nonatomic) CGFloat center_Y;

#pragma mark - Margin

/* 设置Margin，可能会改变Width和Height的值 */
@property (assign, nonatomic) CGMargin margin;

/* 设置以下四个值，会保持Width和Height不变，要有SuperView */
@property (assign, nonatomic) CGFloat marginTop;
@property (assign, nonatomic) CGFloat marginLeft;
@property (assign, nonatomic) CGFloat marginBottom;
@property (assign, nonatomic) CGFloat marginRight;

@end

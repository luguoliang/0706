//
//  BlockAlert.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/4/11.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^OperationBlock) (NSInteger index);

@interface BlockAlert : UIAlertView

+ (void)showWithTitle:(NSString *)title message:(NSString *)message cancelButtonTitle:(NSString *)cancelButtonTitle otherButtonTitles:(NSString *)otherButtonTitles operation:(OperationBlock)operationBlock;

+ (void)showSingleSelAlertWithTitle:(NSString *)title message:(NSString *)message buttonTitle:(NSString *)buttonTitle operation:(OperationBlock)operationBlock;

+ (void)showWithMessage:(NSString *)message operation:(OperationBlock)operationBlock;
+ (void)showNetErrorAlertWithOperation:(OperationBlock)operationBlock;
+ (void)showReqFailedAlertWithCode:(NSString *)code message:(NSString *)message operation:(OperationBlock)operationBlock;

@end

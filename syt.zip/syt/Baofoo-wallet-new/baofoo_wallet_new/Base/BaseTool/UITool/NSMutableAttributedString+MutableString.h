//
//  NSMutableAttributedString+MutableString.h
//  makr
//
//  Created by mac on 15/4/24.
//  Copyright (c) 2015年 baofoo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface NSMutableAttributedString (MutableString)
//两种不同字体
+ (NSMutableAttributedString *)stringWithText1:(NSString *)string1 text2:(NSString *)string2 text1Color:(UIColor*)color1 text2Color:(UIColor *)color2 font1:(UIFont *)font1 font2:(UIFont *)font2;

//收益 余额
+ (NSMutableAttributedString *)stringMoneyText1:(NSString *)string1 text2:(NSString *)string2 text1Color:(UIColor*)color1 text2Color:(UIColor *)color2 font1:(UIFont *)font1 font2:(UIFont *)font2;

+ (NSMutableAttributedString *)threeStringWithText1:(NSString *)string1 text2:(NSString *)string2 text3:(NSString *)string3 text1Color:(UIColor*)color1 text2Color:(UIColor *)color2 text3Color:(UIColor *)color3 font1:(UIFont *)font1 font2:(UIFont *)font2 font3:(UIFont *)font3;

//年化收益率
+ (NSMutableAttributedString *)stringWithText1:(NSString *)string1 text2:(NSString *)string2 text1Color:(UIColor*)color1 text2Colot:(UIColor *)color2 font1:(UIFont *)font1 font2:(UIFont *)font2;
@end

//
//  BFTool.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface BFTool : NSObject

+ (BOOL)isEmptyArray:(NSArray *)array;

//图片虚化
+ (UIImage *)blurryImage:(UIImage *)image withBlurLevel:(CGFloat)blur;

//汉字转拼音
+ (NSString *)pinyinFromChineseString:(NSString *)chinese;

@end

//Notification相关方法
CG_INLINE void NotificationRegister(NSString *name, id observer, SEL selector, id object) {
    
    [[NSNotificationCenter defaultCenter] addObserver:observer selector:selector name:name object:object];
}

CG_INLINE void NotificationPost(NSString *name, id object, NSDictionary *userInfo) {
    
    [[NSNotificationCenter defaultCenter] postNotificationName:name object:object userInfo:userInfo];
}

CG_INLINE void NotificationRemove(NSString *name, id observer, id object) {
    
    [[NSNotificationCenter defaultCenter] removeObserver:observer name:name object:object];
}

CG_INLINE void NotificationRemoveAll(id observer) {
    
    [[NSNotificationCenter defaultCenter] removeObserver:observer];
}
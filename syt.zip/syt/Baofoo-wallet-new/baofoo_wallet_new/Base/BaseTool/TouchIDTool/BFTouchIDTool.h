//
//  BFTouchIDTool.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/4/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <LocalAuthentication/LocalAuthentication.h>
#import <Security/Security.h>

typedef enum TouchIDError
{
    TouchIDErrorNoError,
    TouchIDErrorUnknown,
    
    //以下为鉴权是否可用返回
    
    //设备不支持，程序中所有设置项、功能都不展示
    TouchIDErrorNotSupport,
    
    //设备支持，用户未开启密码功能
    TouchIDErrorNoPassword,
    //设备支持，用户开启密码功能，但未录入指纹
    TouchIDErrorNoFingers,
    
    //以下为鉴权指纹返回
    
    //鉴权失败
    TouchIDErrorAuthenticateFail,
    //系统取消，比如其他应用启动
    TouchIDErrorSystemCacel,
    //用户取消
    TouchIDErrorUserCancel,
    //用户选择输入密码
    TouchIDErrorUserEnterPassword,
    
    
    //应用未开启功能
    TouchIDErrorAppNotEnable,
    
} TouchIDError;


typedef enum ApplicationType
{
    ApplicationTypeGesturePassword,
    ApplicationTypePayPassword,
    ApplicationTypeVerification,
    
} ApplicationType;



@interface BFTouchIDTool : NSObject

@property (nonatomic, readonly) NSString *reason;

+ (BFTouchIDTool *)sharedTool;

- (void)systemCanEvaluateTouchID:(void(^)(BOOL isCan, TouchIDError code))reply;

- (void)canEvaluateTouchIDType:(ApplicationType)type reply:(void(^)(BOOL isSuccess, TouchIDError code))reply;

- (void)evaluateTouchIDReason:(NSString *)reason reply:(void(^)(BOOL isSuccess, TouchIDError code))reply;

- (NSString *)descForTouchIDError:(TouchIDError)code;

- (NSString *)reasonForApp:(ApplicationType)type;


@end

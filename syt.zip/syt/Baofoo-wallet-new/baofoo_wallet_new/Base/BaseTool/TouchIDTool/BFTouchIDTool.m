//
//  BFTouchIDTool.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/4/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFTouchIDTool.h"

static BFTouchIDTool *_tool = nil;

@interface BFTouchIDTool ()

@end

@implementation BFTouchIDTool


+ (BFTouchIDTool *)sharedTool
{
    if (_tool == nil) {
        _tool = [[BFTouchIDTool alloc] init];
    }
    return _tool;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
    }
    return self;
}


- (void)systemCanEvaluateTouchID:(void(^)(BOOL isCan, TouchIDError code))reply
{
    LAContext *la = [[LAContext alloc] init];
    la.localizedFallbackTitle = @"";
    
    NSError *error;
    BOOL can = [la canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error];
    
    TouchIDError tError = TouchIDErrorUnknown;
    
    if ([error code] == LAErrorTouchIDNotAvailable) {
        NSLog(@"TouchID :::: 设备不支持");
        tError = TouchIDErrorNotSupport;
    }
    if ([error code] == LAErrorPasscodeNotSet) {
        NSLog(@"TouchID :::: 用户未开启密码功能");
        tError = TouchIDErrorNoPassword;
    }
    if ([error code] == LAErrorTouchIDNotEnrolled) {
        NSLog(@"TouchID :::: 未录制指纹");
        tError = TouchIDErrorNoFingers;
    }
    
    if (reply) {
        reply(can, can?TouchIDErrorNoError:tError);
    }
}


- (void)canEvaluateTouchIDType:(ApplicationType)type reply:(void(^)(BOOL isSuccess, TouchIDError code))reply;
{
    __block BOOL canUse = NO;
    __block TouchIDError tError = TouchIDErrorNotSupport;
    
    [self systemCanEvaluateTouchID:^(BOOL isCan, TouchIDError code) {
        canUse = isCan;
        tError = code;
    }];
    
    if (canUse) {
        switch (type) {
            case ApplicationTypeGesturePassword:
                // 数据库中增加是开启TouchID登录，以及手势密码登录
                canUse = [[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedTouchIDForLogin boolValue];
                tError = [[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedTouchIDForLogin boolValue]?tError:TouchIDErrorAppNotEnable;
                break;
            case ApplicationTypePayPassword:
                canUse = NO;
                tError = TouchIDErrorUnknown;
                break;
            case ApplicationTypeVerification:
                canUse = [[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedTouchIDForLogin boolValue];
                tError = [[[BFCoreDataModelop sharedManager] getCurrentBFuserModel].isUsedTouchIDForLogin boolValue]?tError:TouchIDErrorAppNotEnable;
                break;
            default:
                canUse = NO;
                tError = TouchIDErrorUnknown;
                break;
        }
    }
    if (reply) {
        reply(canUse, canUse?TouchIDErrorNoError:tError);
    }
}

- (void)evaluateTouchIDReason:(NSString *)reason reply:(void(^)(BOOL isSuccess, TouchIDError code))reply;
{
    LAContext *la = [[LAContext alloc] init];
    la.localizedFallbackTitle = @"";
    
    [la evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:reason reply:^(BOOL success, NSError *error) {
        
        TouchIDError tError = TouchIDErrorUnknown;
        
        if (success) {
            tError = TouchIDErrorNoError;
        }
        else
        {
            if ([error code] == LAErrorAuthenticationFailed) {
                NSLog(@"TouchID :::: 校验失败");
                tError = TouchIDErrorAuthenticateFail;
            }
            if ([error code] == LAErrorSystemCancel) {
                NSLog(@"TouchID :::: 系统取消");
                tError = TouchIDErrorSystemCacel;
            }
            if ([error code] == LAErrorUserCancel) {
                NSLog(@"TouchID :::: 用户取消");
                tError = TouchIDErrorUserCancel;
            }
            if ([error code] == LAErrorUserFallback) {
                NSLog(@"TouchID :::: 用户选择输入密码");
                tError = TouchIDErrorUserEnterPassword;
            }
        }
        
        if (reply) {
            reply(success, tError);
        }
        
    }];
}



- (NSString *)descForTouchIDError:(TouchIDError)code
{
    NSString *string = @"未知错误";
    switch (code) {
        case TouchIDErrorNotSupport:
            string = @"设备不支持TouchID";
            break;
        case TouchIDErrorNoPassword:
            string = @"请先在\"系统设置 - Touch ID 与密码\"中开启密码";
            break;
        case TouchIDErrorNoFingers:
            string = @"请先在\"系统设置 - Touch ID 与密码\"中添加指纹";
            break;
        case TouchIDErrorAuthenticateFail:
            string = @"Touch ID验证失败";
            break;
        case TouchIDErrorSystemCacel:
            string = @"系统取消指纹验证";
            break;
        case TouchIDErrorUserCancel:
            string = @"您取消指纹验证";
            break;
        case TouchIDErrorUserEnterPassword:
            string = @"您选择输入密码";
            break;
        case TouchIDErrorAppNotEnable:
            string = @"请先在\"账户 - 密码管理\"中开启指纹解锁";
            break;
        case TouchIDErrorNoError:
            string = @"Touch ID验证成功";
            break;
        case TouchIDErrorUnknown:
            string = string;
            break;
        default:
            string = string;
            break;
    }
    
    return string;
}


- (NSString *)reasonForApp:(ApplicationType)type
{
    NSString *string = @"验证指纹";
    
    switch (type) {
        case ApplicationTypeGesturePassword:
            string = @"通过验证指纹解锁宝付";
            break;
        case ApplicationTypePayPassword:
            string = @"通过验证指纹进行支付";
            break;
        case ApplicationTypeVerification:
            string = @"请验证已有指纹";
            break;
        default:
            string = string;
            break;
    }
    
    return string;
}

@end

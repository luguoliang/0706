//
//  BFJsonTool.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/18.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BFJsonTool : NSObject
@end
#pragma mark - Category
#pragma mark - 解码

#pragma mark - NSString

@interface NSString (BFJSONDeSerialization)

- (id)getObjectFromJSONString;
- (id)getObjectFromJSONStringWithOption:(NSJSONReadingOptions)option;

@end

#pragma mark - NSData

@interface NSData (BFJSONDeSerialization)

- (id)getObjectFromJSONData;

@end

#pragma mark - 编码

#pragma mark - NSObject

@interface NSObject (BFJSONSerialization)

- (NSData *)getJSONDataFromObject;
- (NSString *)getJSONStringFromObject;
@end

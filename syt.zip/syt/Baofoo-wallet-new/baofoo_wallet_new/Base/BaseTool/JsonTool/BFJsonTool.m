//
//  BFJsonTool.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/18.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFJsonTool.h"

@implementation BFJsonTool
@end
#pragma mark - Category
#pragma mark - 解码

#pragma mark - NSString

@implementation NSString (BFJSONDeSerialization)

- (id)getObjectFromJSONString{
    NSData *data = [self dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    id object = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
    if (error) {
        return nil;
    }
    else {
        return object;
    }
}

- (id)getObjectFromJSONStringWithOption:(NSJSONReadingOptions)option{
    NSData *data = [self dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    id object = [NSJSONSerialization JSONObjectWithData:data options:option error:&error];
    if (error) {
        return nil;
    }
    else {
        return object;
    }
}

@end

#pragma mark - NSData

@implementation NSData (BFJSONDeSerialization)

- (id)getObjectFromJSONData{
    NSError *error = nil;
    id object = [NSJSONSerialization JSONObjectWithData:self options:kNilOptions error:&error];
    if (error) {
        return nil;
    }
    else {
        return object;
    }
}

@end

#pragma mark - 编码

#pragma mark - NSObject

@implementation NSObject (BFJSONSerialization)

- (NSData *)getJSONDataFromObject{
    if (![NSJSONSerialization isValidJSONObject:self]) {
        return nil;
    }
    
    NSError *error = nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:self options:kNilOptions error:&error];
    if (error){
        return nil;
    }
    else {
        return data;
    }
}

- (NSString *)getJSONStringFromObject{
    if (![NSJSONSerialization isValidJSONObject:self]) {
        return nil;
    }
    
    NSError *error = nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:self options:kNilOptions error:&error];
    if (error) {
        return nil;
    }
    else {
        NSString *string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        return string;
    }
}

@end

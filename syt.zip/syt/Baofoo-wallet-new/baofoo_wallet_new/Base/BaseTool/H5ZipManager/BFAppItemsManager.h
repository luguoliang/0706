//
//  BFAppItemsManager.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/29.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "Reachability.h"
#import "AppCollectionViewCell.h"

@class BFAppItemsModel;

@interface BFAppItemsManager : NSObject

@property (assign, nonatomic) BOOL isSuccessGetAppItmesFromServer;
@property (strong, nonatomic) NSArray *appItemsArrayFromServer;
@property (strong, nonatomic) NSArray *appItemsArrayFromLocal;
@property(nonatomic, copy) NSArray  *BFH5ZipItemsItems;
@property(nonatomic, strong) AFURLSessionManager *downloadSessionManager;//下载管理中心
@property(nonatomic, strong) NSMutableDictionary* dictDownloadTask;
@property(nonatomic, strong) Reachability *reachability;


// 单例(初始化安装预置zip包)
+(instancetype) shareInstance;
// 请求服务器，获取zip包的在线状态，及各种信息（json格式，转换成BFAppItemsModel）

//验证当前版本是否可用
+(BOOL)checkCurAppItemAvailable:(BFAppItemsModel *)curAppItemModel;
// check zip包是否需要更新
+(BOOL)isNeedUpdateWithAppItemsModel:(BFAppItemsModel *)appItemModel;
// 判断网络环境
- (AppItemsStatus) checkAppItemState:(AppCollectionViewCell *)cell;
// 下载zip包
+(void)downloadH5ZipWithAppItemModel:(BFAppItemsModel *)appItemModel;
+(void)downloadH5ZipWithAppCollectionCell:(AppCollectionViewCell *)cell;

// 暂停下载
+(void)pauseDownloadWithAppItemModel:(BFAppItemsModel *)appItemModel;
+(void)pauseDownloadWithAppCollectionCell:(AppCollectionViewCell *)cell;
// 恢复下载
+(void)resumeDownloadWithAppItemModel:(BFAppItemsModel *)appItemMode;
+(void)resumeDownloadWithAppCollectionCell:(AppCollectionViewCell *)cell;

// 验证zip包md5
// 安装预置zip包
-(BOOL)installPresetPackage:(BFAppItemsModel *)itemModel;
// 安装zip包
-(BOOL)installAppItem:(BFAppItemsModel *)appItemModel;
@end

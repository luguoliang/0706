//
//  BFH5ZipSignTool.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/1.
//  Copyright © 2016年 BF. All rights reserved.
//

/*
 服务器下发zip包时，首先对包内容进行签名，具体签名规则如下：
 1. 先对包中每个文件（除特殊文件）md5；
 2. 拼接每个md5值为字符串；
 3. 对字符串再次md5,；
 4. 最后对md5值进行DES加密，将密文做为zip包签名属性下发。
 */
 
#import <Foundation/Foundation.h>

@interface BFH5ZipSignTool : NSObject

/**
 *  获取app包中的MD5字符串
 */
+ (NSString *)getH5ZipPackageStringWithAppItem:(NSString *)filepath;

/**
 *  获取文件MD5
 */
+ (NSString *)getFileMD5WithPath:(NSString *)path;

@end

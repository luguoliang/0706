//
//  BFAppItemOperationHandle.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFAppItemOperationHandle.h"

#import "BFLoginTool.h"
#import "ReachabilityTool.h"
#import "UIAlertView+BFAlertView.h"
#import "BFCommonHeader.h"
#import "BFMessageConstHeader.h"
#import "BFAppItemsManager.h"
#import "BFFilePathTool.h"
#import "BlockAlert.h"
#import "H5ViewController.h"

@implementation BFAppItemOperationHandle
#pragma mark - 应用打开处理
+ (void)handleApp:(AppCollectionViewCell *)cell curViewControlelr:(UIViewController *)controller{
    
    if (cell.model.BFAppItemsType == BFAppItemsH5Zip) {
        //HTML5应用
        if (![BFLoginTool checkLogin]) {
            return;
        }
        
        if ([ReachabilityTool checkNetworkState] == NetworkStateUnable) {
            
            [UIAlertView showNetErrorAlertWithDelegate:nil];
        }
        else {
            [[self class] handleHTML5App:cell curViewControlelr:controller];
        }
    }
    else {
        //Native应用
        if ([BFLoginTool checkLogin]) {
            [[self class] handleNativeApp:cell curViewControlelr:controller];
        }
    }
}

#pragma mark - HTML5应用

//Html5应用处理
+ (void)handleHTML5App:(AppCollectionViewCell *)cell curViewControlelr:(UIViewController *)controller{
    BFAppItemsModel *model = cell.model;
    
    DebugLog(@"AppOperationHandle: Handle html5 app %@/%@，状态 %ld", model.BFAppItemsName, model.BFAppItemsId, (long)cell.appStatus);
    
    switch (cell.appStatus) {
        case AppItemsStatusNormal:{
            
            BOOL checkAvailable = [BFAppItemsManager checkCurAppItemAvailable:model] ;
            
            //验证不通过，但是bundle已经内置，拷贝进去
            if (!checkAvailable) {
                NSString* bundlePath = [BFFilePathTool presetedPathOfCurVersionInBundleWithModel:model] ;
                if(bundlePath) {
                    NSString *installedPath = [BFFilePathTool presetAppInstalledPath:model];
                    [[NSFileManager defaultManager] removeItemAtPath:installedPath error:nil] ;
                    if ([[BFAppItemsManager shareInstance] installPresetPackage:model]) {
                        checkAvailable = [BFAppItemsManager checkCurAppItemAvailable:model] ;
                    }
                }
            }
            NetworkState networkstate = [ReachabilityTool checkNetworkState];
            //本地无可用版本
            if (checkAvailable==NO) {
                if (networkstate == NetworkStateWWAN) {
                    NSString* msg = @"此应用需要下载才能使用，但目前处于移动网络，下载应用会产生数据流量，是否下载？" ;
                    [BlockAlert showWithTitle:[NSString stringWithFormat:@"下载“%@”", model.BFAppItemsName] message:msg cancelButtonTitle:@"取消" otherButtonTitles:@"下载" operation:^(NSInteger index) {
                        if (index == 1) {
                            [BFAppItemsManager downloadH5ZipWithAppCollectionCell:cell] ;
                        }
                    }];
                }
                else if (networkstate == NetworkStateWiFi) {
                    [BFAppItemsManager downloadH5ZipWithAppCollectionCell:cell] ;
                }
                else {
                    [BlockAlert showWithTitle:@"宝付钱包" message:@"网络不可用" cancelButtonTitle:@"确定" otherButtonTitles:nil operation:nil];
                }
                return ;
            }
            //强制更新版本
            else if(networkstate == NetworkStateWWAN && [BFAppItemsManager isNeedUpdateWithAppItemsModel:model]){
                NSString* msg = @"目前处于移动网络，更新应用会产生数据流量，是否更新？" ;
                [BlockAlert showWithTitle:[NSString stringWithFormat:@"更新“%@”", model.BFAppItemsName] message:msg cancelButtonTitle:@"取消" otherButtonTitles:@"立即更新" operation:^(NSInteger index) {
                    if (index == 1) {//更新
                        [BFAppItemsManager downloadH5ZipWithAppCollectionCell:cell] ;
                    }
                }];
            }
            else if (networkstate == NetworkStateWiFi && [BFAppItemsManager isNeedUpdateWithAppItemsModel:model]){
                [BFAppItemsManager downloadH5ZipWithAppCollectionCell:cell] ;
            }
            else {
                DebugLog(@"AppOperationHandle: 打开 html5 app");
                
                H5ViewController *h5View = [[H5ViewController alloc] init];
                h5View.path = [BFFilePathTool appMainFilePath:model];
                h5View.model = model;
                [controller.navigationController pushViewController:h5View animated:YES];
            }
            break;
        }
        case AppItemsStatusWWANDownloading:{
            [BFAppItemsManager pauseDownloadWithAppCollectionCell:cell];
        }
        case AppItemsStatusWWANSuspend:{
            [BFAppItemsManager resumeDownloadWithAppCollectionCell:cell];
        }
        case AppItemsStatusWiFiDownloading:{
            [BlockAlert showWithTitle:Alert_Title message:App_Status_Downloading cancelButtonTitle:Alert_Button_Confirm otherButtonTitles:nil operation:nil];
            break;
        }
        case AppItemsStatusMaintain:{
            [BlockAlert showWithTitle:Alert_Title message:App_Status_Maintain cancelButtonTitle:Alert_Button_Confirm otherButtonTitles:nil operation:nil];
            break;
        }
        default:
            break;
    }
}

#pragma mark - 原生应用

//原生应用处理
+ (void)handleNativeApp:(AppCollectionViewCell *)cell curViewControlelr:(UIViewController *)controller{
    BFAppItemsModel *model = cell.model;
    
    DebugLog(@"AppOperationHandle: Handle native app %@/%@", model.BFAppItemsName, model.BFAppItemsId);
    
    if (cell.appStatus == AppItemsStatusMaintain) {
        [BlockAlert showWithTitle:Alert_Title message:App_Status_Maintain cancelButtonTitle:Alert_Button_Confirm otherButtonTitles:nil operation:nil];
        return;
    }
    
    [[self class] handleNativeAppItem:model curViewControlelr:controller];
}
+ (void)handleNativeAppItem:(BFAppItemsModel *)model curViewControlelr:(UIViewController *)controller{
    
    DebugLog(@"AppOperationHandle: handle Native AppItemModel %@/%@", model.BFAppItemsName, model.BFAppItemsId);
    
    NSInteger appIdValue = [model.BFAppItemsId integerValue];
    if (appIdValue == BFAppID_1) {
    }
    else if (appIdValue == BFAppID_2) {
    }
    else {
    }
}
@end

//
//  BFAppItemsManager.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/29.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFAppItemsManager.h"
#import "BFAppItemsModel.h"
#import "BFRequestURLConfigHeader.h"
#import "BFReqAPI+HomePage.h"
#import "BFFileTool.h"
#import "BFFilePathTool.h"
#import "BFCommonHeader.h"
#import "BFH5ZipSignTool.h"
#import <ZipArchive.h>

NSString *const BFApplistDidChangedNotification  = @"BFApplistDidChangedNotification" ;
NSString *const BFAppInstallFinishedNotification    = @"BFAppInstallFinishedNotification" ;


@interface BFH5ZipItemsDownloadTask: NSObject

@property (nonatomic, strong) BFAppItemsModel *oldAppItemsModel;
@property (nonatomic, strong) BFAppItemsModel* downloadModel ;
@property (nonatomic, strong) AppCollectionViewCell *cell;
@property (nonatomic, strong) NSProgress *progress ;
@property (nonatomic, strong) NSURLSessionDownloadTask* downloadTask ;

@end

@implementation BFH5ZipItemsDownloadTask

- (void) unzip {
    dispatch_queue_t installQueue = dispatch_queue_create("cn.com.baofoo.installApp", nil) ;
    dispatch_async(installQueue, ^{
        
        NSString* zipPath = [BFFilePathTool BFH5ZipItemsDownloadSavePath:self.downloadModel] ;
        NSFileManager* fm = [[NSFileManager alloc] init] ;
        // 安装成功后才从下载列表中删除任务
        if ([[BFAppItemsManager shareInstance] installAppItem:_downloadModel]) {
            [[BFAppItemsManager shareInstance].dictDownloadTask removeObjectForKey:_cell.model.BFAppItemsId];
        }
        DebugLog(@"下载结束安装 %@/%@", self.downloadModel.BFAppItemsName, self.downloadModel.BFAppItemsVersion);
        
        // 删除zip文件
        [fm removeItemAtPath:zipPath error:nil] ;
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            if(_cell) {
                _cell.appStatus = AppItemsStatusNormal ;
            }
            [[NSNotificationCenter defaultCenter] postNotificationName:BFAppInstallFinishedNotification object:_downloadModel] ;
        });
    }) ;
}


@end

@interface BFAppItemsManager ()
{
    ZipArchive *zip;
}
@end

@implementation BFAppItemsManager

// 单例(初始化安装预置zip包)
+(instancetype) shareInstance {
    
    static BFAppItemsManager *appManager = nil;
    static dispatch_once_t token = 0;
    dispatch_once(&token, ^{
        appManager = [[BFAppItemsManager alloc] init];
    });
    
    return appManager;
}

- (instancetype)init{
    if (self = [super init]) {
        if (self) {
            zip = [[ZipArchive alloc] init];
            //监听网络变化
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reachabilityChanged:) name:kReachabilityChangedNotification object:nil] ;
            //配置reachability
            self.reachability = [Reachability reachabilityForInternetConnection];
            [self.reachability startNotifier];
            
            _dictDownloadTask = [NSMutableDictionary dictionary];
            _downloadSessionManager   = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]] ;
        }
    }
    return self;
}

+(void) checkLocalModelStateAndServerModelState {
    dispatch_queue_t checkAndDownloadQueue = dispatch_queue_create("cn.com.baofoo.checkAndDownload", nil) ;
    dispatch_async(checkAndDownloadQueue, ^{
        if ([[self class] getAppItemsModelFromServer].count > 0 && [BFAppItemsManager shareInstance].isSuccessGetAppItmesFromServer) {
            [[self class] checkAllAppItemsState:[[self class] getAppItemsModelFromServer] relativeToOldAppItemsArray:[[self class] getAppItemsModelFromLocal]];
        }
    });
}

// 从本地获取appItems的上次状态
#define appItemsModelAtLocal @"appItemsModelAtLocal"
#define appItemsModelPlist @"BaoFooWalletAppItemsList.plist"
+(NSArray *) getAppItemsModelFromLocal {
    NSArray *appItemsArray = [[NSArray alloc] init];
    appItemsArray = [NSArray arrayWithArray:[BFFileTool getArrayFromFile:[BFFileTool getDocumentFilePathWithName:appItemsModelAtLocal skipiCloudBackup:YES]]];
    if (appItemsArray.count == 0) {
        appItemsArray = [NSArray arrayWithContentsOfFile:[BFFileTool getDocumentFilePathWithName:appItemsModelPlist]];
    }
    return appItemsArray;
}
+(void) saveAppItemsModelAfterDownload:(NSArray *)appItemsArray {
    [BFFileTool saveObject:appItemsArray toFile:[BFFileTool getDocumentFilePathWithName:appItemsModelAtLocal skipiCloudBackup:YES]];
    [appItemsArray writeToFile:[BFFileTool getDocumentFilePathWithName:appItemsModelPlist] atomically:YES];
}

// 请求服务器，获取appItems的在线状态(包含模型中的各种信息）
+(NSArray *) getAppItemsModelFromServer {
    
    __block NSArray *appItems = [[NSArray alloc] init];
    
    NSMutableDictionary * dict = [NSMutableDictionary dictionary];
    
    /*此处与服务器约定请求参数规则*/
    
    [BFReqAPI getH5ZipItemsModelFromServerWithParameters:dict block:^(id responseObj, NSError *error) {
        // 此处的返回值与服务器约定为JSON
        // success: 0/1
        // isNeedUpdate: 0/1
        // result:数组
        // errorCode:按约定规则
        if(error == nil) {
            // 时刻考虑服务器的不确定性，当服务器返回出错是，此处可能会因为不存在success这个key而崩溃。
            // 故先考虑error的情况，正常才可进行下一步处理。
            if ([responseObj[@"success"] boolValue] && [responseObj[@"isNeedUpdate"] boolValue]) {
                appItems = [NSArray arrayWithArray:responseObj[@"result"]];
                [BFAppItemsManager saveAppItemsModelAfterDownload:appItems];
                [BFAppItemsManager shareInstance].isSuccessGetAppItmesFromServer = YES;
            }
            else{
                [BFAppItemsManager shareInstance].isSuccessGetAppItmesFromServer = NO;
                // 打印错误日志
                
            }
        }
        else{
            [BFAppItemsManager shareInstance].isSuccessGetAppItmesFromServer = NO;
            // 打印错误日志
            
        }
    }];
    return appItems;
}

// 程序启动时轮循各app的状态
+(void) checkAllAppItemsState:(NSArray *)curAppItemsArray relativeToOldAppItemsArray:(NSArray *)oldAppItemsArray {
    for (int i = 0; i < curAppItemsArray.count < oldAppItemsArray.count ? curAppItemsArray.count : oldAppItemsArray.count; i ++) {
        BFAppItemsModel *tempCurModel = curAppItemsArray[i];
        BFAppItemsModel *tempOldModel = oldAppItemsArray[i];
        // 本地版本低时，在wifi环境下自动更新
        if ([tempOldModel.BFAppItemsVersion compare:tempCurModel.BFAppItemsVersion] == NSOrderedDescending ) {
            if (BFNetworkEnvironmentStateValueWiFi == [BFAppItemsManager getNetworkEnvironmentState]) {
                [[self class] downloadH5ZipWithAppItemModel:tempCurModel];
            }
        }
    }
}

// check zip包的版本信息
+(BOOL)isNeedUpdateWithAppItemsModel:(BFAppItemsModel *)appItemModel{
    if (![BFAppItemsManager shareInstance].isSuccessGetAppItmesFromServer) {
        return NO;
    }
    if (appItemModel.BFAppItemsType != BFAppItemsH5Zip) {
        return NO;
    }// 只有强制更新的应用，才让用户强制更新
    BFAppItemsModel *originAppItemModel = [[BFAppItemsModel alloc] init];
    for (int i = 0; i < [BFAppItemsManager shareInstance].appItemsArrayFromLocal.count; i++) {
        BFAppItemsModel *model = [BFAppItemsManager shareInstance].appItemsArrayFromLocal[i];
        if ([model.BFAppItemsId isEqualToString:appItemModel.BFAppItemsId]) {
            originAppItemModel = model;
        }
    }
    if (([originAppItemModel.BFAppItemsVersion compare:appItemModel.BFAppItemsVersion] == NSOrderedDescending ) && (appItemModel.BFAppItemsStateValue == BFAppItemsStateValueUpdatedRequired)) {
        return YES;
    }
    else{
        return NO;
    }
}

// 判断网络环境,通过状态栏
// 网络类型的定义，需要测试顺序的正确性
typedef NS_ENUM(NSInteger, BFNetworkEnvironmentStateValue) {
    BFNetworkEnvironmentStateValueNone = 0, // 无网络
    BFNetworkEnvironmentStateValue2G,  // 2G
    BFNetworkEnvironmentStateValue3G,  // 3G
    BFNetworkEnvironmentStateValue4G,  // 4G
    BFNetworkEnvironmentStateValueWiFi // wifi
};
+(BFNetworkEnvironmentStateValue) getNetworkEnvironmentState {
    UIApplication *app = [UIApplication sharedApplication];
    NSArray *statusBarChildViews = [[[app valueForKeyPath:@"statusBar"] valueForKeyPath:@"foregroundView"] subviews];
    NSInteger type = 0;
    for (id view in statusBarChildViews) {
        if ([view isKindOfClass:NSClassFromString(@"UIStatusBarDataNetworkItemView")]) {
            type = [[view valueForKeyPath:@"dataNetworkType"] integerValue];
        }
    }
    return type;
}

// 下载zip包
+(void)downloadH5ZipWithAppItemModel:(BFAppItemsModel *)appItemModel {
    [[BFAppItemsManager shareInstance] downloadAppOfModel:appItemModel];
}
+(void)downloadH5ZipWithAppCollectionCell:(AppCollectionViewCell *)cell {
    [[BFAppItemsManager shareInstance] downloadAppOfCell:cell];
}

// 暂停下载
+(void)pauseDownloadWithAppItemModel:(BFAppItemsModel *)appItemModel {
    [[BFAppItemsManager shareInstance] pauseDownloadH5ZipModelWithTask:[[BFAppItemsManager shareInstance].dictDownloadTask objectForKey:appItemModel.BFAppItemsId]];
}
+(void)pauseDownloadWithAppCollectionCell:(AppCollectionViewCell *)cell {
    [[BFAppItemsManager shareInstance] pauseDownloadH5ZipModelWithTask:[[BFAppItemsManager shareInstance].dictDownloadTask objectForKey:cell.model.BFAppItemsId]];
}
// 恢复下载
+(void)resumeDownloadWithAppItemModel:(BFAppItemsModel *)appItemMode {
    [[BFAppItemsManager shareInstance] resumeDownloadH5ZipModelWithTask:[[BFAppItemsManager shareInstance].dictDownloadTask objectForKey:appItemMode.BFAppItemsId]];
}
+(void)resumeDownloadWithAppCollectionCell:(AppCollectionViewCell *)cell {
    [[BFAppItemsManager shareInstance] resumeDownloadH5ZipModelWithTask:[[BFAppItemsManager shareInstance].dictDownloadTask objectForKey:cell.model.BFAppItemsId]];
}

//验证当前版本是否可用
+(BOOL) checkCurAppItemAvailable:(BFAppItemsModel *)curAppItemModel {
    if (curAppItemModel.BFAppItemsType != BFAppItemsH5Zip) return YES ;
    
    //安装目录是否存在
    NSString *installedPath = [BFFilePathTool presetAppInstalledPath:curAppItemModel] ;
    if ([[NSFileManager defaultManager] fileExistsAtPath:installedPath]==NO) {
        return NO ;
    }
    
    //1、检验Properties
    NSString *propertyFilePath = [BFFilePathTool appPropertyFilePath:curAppItemModel] ;
    if ([[NSFileManager defaultManager] fileExistsAtPath:propertyFilePath]==NO) {
        return NO ;
    }
    //2、检验MainFile
    NSString *mainFilePath = [BFFilePathTool appMainFilePath:curAppItemModel] ;
    if (!mainFilePath || ![BFFileTool fileExistsAtPath:mainFilePath]) {
        return NO ;
    }
    
    //3、验证MD5
    NSString *generateStr = [BFH5ZipSignTool getH5ZipPackageStringWithAppItem:installedPath] ;
    if([curAppItemModel.BFAppItemsVersion isEqualToString:generateStr]==NO) {
        [[NSFileManager defaultManager] removeItemAtPath:installedPath error:nil] ;
        return NO ;
    }
    //本地存在，不需要更新，验证接口正确性
    NSString* jsPath = [installedPath stringByAppendingPathComponent:PublicJs_File] ;
    NSString *oldSign = [BFH5ZipSignTool getFileMD5WithPath:jsPath];
    NSString *newSign = [BFH5ZipSignTool getFileMD5WithPath:[BFFilePathTool publicPortPath]];
    
    if (oldSign.length==0 || [oldSign isEqualToString:newSign]==NO) {
        [[NSFileManager defaultManager] removeItemAtPath:jsPath error:nil] ;
        [[NSFileManager defaultManager] copyItemAtPath:[BFFilePathTool publicPortPath] toPath:jsPath error:NULL] ;
    }
    return YES ;
}

// 安装预置zip包
- (BOOL)installPresetPackage:(BFAppItemsModel *)itemModel {
    NSString *folderPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"PresetHtml5Zip"];
    NSString *zipName = [NSString stringWithFormat:@"%@_%@.zip", itemModel.BFAppItemsId, itemModel.BFAppItemsVersion];
    NSString *zipSorucePath = [folderPath stringByAppendingPathComponent:zipName];
    
    if ([zip UnzipOpenFile:zipSorucePath]) {
        NSString *installedPath = [BFFilePathTool presetAppInstalledPath:itemModel];
        if ([zip UnzipFileTo:installedPath overWrite:YES]) {
            
            DebugLog(@"BFAppItemsManager: 安装[%@/%@/%@]（预置）成功", itemModel.BFAppItemsName, itemModel.BFAppItemsId, itemModel.BFAppItemsVersion);
            [self verifyPublicPort:[BFFilePathTool presetAppPublicJsFilePath:itemModel]];
            return YES;
        }
        else {
            DebugLog(@"BFAppItemsManager: 安装[%@/%@/%@]（预置）失败", itemModel.BFAppItemsName, itemModel.BFAppItemsId, itemModel.BFAppItemsVersion);
            return NO;
        }
    }
    else {
        return NO;
    }
}

- (BOOL)verifyPublicPort:(NSString *)path{
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:path]) {
        NSString *oldSign = [BFH5ZipSignTool getFileMD5WithPath:path];
        NSString *newSign = [BFH5ZipSignTool getFileMD5WithPath:[BFFilePathTool publicPortPath]];
        
        if (![newSign isEqualToString:oldSign]) {
            [self installPublicPort:path];
            return NO;
        }
    }
    else {
        
        [self installPublicPort:path];
        return NO;
    }
    return YES;
}

- (void)installPublicPort:(NSString *)path{
    NSError *error;
    [[NSFileManager defaultManager] copyItemAtPath:[BFFilePathTool publicPortPath] toPath:path error:&error];
    if (error) {
        DebugLog(@"BFAppItemsManager: 安装公共接口失败，Error = %@", error);
    }
    else {
        DebugLog(@"BFAppItemsManager: 安装公共接口成功");
    }
}

#pragma mark - Package Delete
- (void)deleteDownloadSaveFile:(BFAppItemsModel *)item{
    NSError *error;
    [[NSFileManager defaultManager] removeItemAtPath:[BFFilePathTool BFH5ZipItemsDownloadSavePath:item] error:&error];
    if (error) {
        DebugLog(@"BFAppItemsManager delete %@ download package error %@", item.BFAppItemsName, error);
    }
}

- (void)deleteInstalledPackage:(BFAppItemsModel *)item{
    NSString *path = [BFFilePathTool BFH5ZipItemsInstalledPath:item];
    if ([BFFileTool removeFileAtPath:path]) {
        DebugLog(@"BFAppItemsManager: 删除[%@/%@/%@]本地包成功", item.BFAppItemsName, item.BFAppItemsId, item.BFAppItemsVersion);
    }
    else {
        DebugLog(@"BFAppItemsManager: 删除[%@/%@/%@]本地包失败", item.BFAppItemsName, item.BFAppItemsId, item.BFAppItemsVersion);
    }
}

#pragma mark 安装zip包 Private API
//安装应用
- (BOOL) installAppItem:(BFAppItemsModel *)appItemModel {
    //解压路径
    NSString *installedPath = [BFFilePathTool BFH5ZipItemsInstalledPath:appItemModel] ;
    
    NSFileManager *fm = [NSFileManager defaultManager];
    //删除以前文件
    if ([fm fileExistsAtPath:installedPath]) {
        [fm removeItemAtPath:installedPath error:nil] ;
    }
    
    NSString *zipFilePath = [BFFilePathTool BFH5ZipItemsDownloadSavePath:appItemModel];
    //文件是否存在
    if([fm fileExistsAtPath:zipFilePath]==NO) {
        return NO ;
    }
    
    //解压
    ZipArchive* zipArchive = [[ZipArchive alloc] init] ;
    if (![zipArchive UnzipOpenFile:zipFilePath] || ![zipArchive UnzipFileTo:installedPath overWrite:YES]) {
        return NO ;
    }
    //安装JS接口
    NSString* jsPath = [installedPath stringByAppendingPathComponent:PublicJs_File] ;
    return [self verifyPublicPortAtPath:jsPath fileManager:fm] ;
}

- (BOOL)verifyPublicPortAtPath:(NSString *)path fileManager:(NSFileManager *)fm {
    if ([fm fileExistsAtPath:path]==NO) {
        return [fm copyItemAtPath:[BFFilePathTool publicPortPath] toPath:path error:NULL] ;
    }
    
    NSString *oldSign = [BFH5ZipSignTool getFileMD5WithPath:path];
    NSString *newSign = [BFH5ZipSignTool getFileMD5WithPath:[BFFilePathTool publicPortPath]];
    
    if (oldSign.length==0 || [oldSign isEqualToString:newSign]==NO) {
        [fm removeItemAtPath:path error:nil] ;
        return [fm copyItemAtPath:[BFFilePathTool publicPortPath] toPath:path error:NULL] ;
    }
    return YES ;
}


#pragma mark Reachability related

-(void) reachabilityChanged:(NSNotification*) notification {
    if([self.reachability currentReachabilityStatus] == ReachableViaWiFi) {
        [_dictDownloadTask enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            [self resumeDownloadH5ZipModelWithTask:(BFH5ZipItemsDownloadTask *)obj];
        }];
    }
    else if([self.reachability currentReachabilityStatus] == ReachableViaWWAN) {
        [_dictDownloadTask enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            [self pauseDownloadH5ZipModelWithTask:(BFH5ZipItemsDownloadTask *)obj];
        }];
    }
    else if([self.reachability currentReachabilityStatus] == NotReachable) {
        [_dictDownloadTask enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            [self pauseDownloadH5ZipModelWithTask:(BFH5ZipItemsDownloadTask *)obj];
        }];
    }
}

/**
 *  通过模型下载zip包，模型与实例绑定，后面实例与下载线程绑定，从而实现下载任务的暂停与断点续传
 *
 *  @param downloadModel  zip包模型
 *  @param sessionManager 下载管理中心
 *
 *  @return 下载任务实例
 */
- (BFH5ZipItemsDownloadTask *) downloadH5ZipModel:(BFAppItemsModel *)downloadModel sessionManager:(AFURLSessionManager *)sessionManager {
    
    BFH5ZipItemsDownloadTask *downloadTask = [[BFH5ZipItemsDownloadTask alloc] init];
    downloadTask.downloadModel = downloadModel;
    
    //新的下载任务
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:downloadModel.BFAppItemsFileUrl]] ;
    __block NSProgress* progress = [[NSProgress alloc] init] ;
    downloadTask.downloadTask = [sessionManager downloadTaskWithRequest:request progress:&progress
                                                            destination:^NSURL *(NSURL *targetPath, NSURLResponse *response)
                                 {
                                     // 设置下载目标路径
                                     NSString* savePath = [BFFilePathTool BFH5ZipItemsDownloadSavePath:downloadModel] ;
                                     return [NSURL fileURLWithPath:savePath] ;
                                 }
                                                      completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error)
                                 {
                                     [downloadTask unzip];
                                 }];
    // 同步获取下载进度
    [downloadTask setProgress:progress];
    [downloadTask.downloadTask resume];
    return downloadTask ;
}

/**
 *  暂停下载
 *
 *  @param downloadTask 任务实例
 */
- (void) pauseDownloadH5ZipModelWithTask:(BFH5ZipItemsDownloadTask *)downloadTask {
    if (downloadTask.downloadTask.state == NSURLSessionTaskStateRunning) {
        [downloadTask.downloadTask suspend];
    }
}

/**
 *  继续下载
 *
 *  @param downloadTask 任务实例
 */
- (void) resumeDownloadH5ZipModelWithTask:(BFH5ZipItemsDownloadTask *)downloadTask {
    if (downloadTask.downloadTask.state == NSURLSessionTaskStateSuspended) {
        [downloadTask.downloadTask resume];
    }
}
/**
 *  获取下载状态, appItem只分为可点与不可点，不可点时显示下载进度，可点时只考虑移动网络下载时可手动暂停
 */
- (AppItemsStatus) checkAppItemState:(AppCollectionViewCell *)cell {
    
    BFAppItemsModel *model = cell.model ;
    BFH5ZipItemsDownloadTask *task = [_dictDownloadTask objectForKey:model.BFAppItemsId];
    
    if (nil == task) {
        return AppItemsStatusNormal;
    }
    
    if ([_reachability isReachableViaWWAN]) {
        if (task.downloadTask.state == NSURLSessionTaskStateRunning) {
            return AppItemsStatusWWANDownloading;
        }
        else if(task.downloadTask.state == NSURLSessionTaskStateSuspended){
            return AppItemsStatusWWANSuspend;
        }
        else if (task.downloadTask.state == NSURLSessionTaskStateCompleted) {
            return AppItemsStatusDownloadCompleted;
        }
        else{
            return AppItemsStatusNormal;
        }
    }
    else if ([_reachability isReachableViaWiFi]) {
        if (task.downloadTask.state == NSURLSessionTaskStateRunning) {
            return AppItemsStatusWiFiDownloading;
        }
        else if (task.downloadTask.state == NSURLSessionTaskStateCompleted) {
            return AppItemsStatusDownloadCompleted;
        }
        else{
            return AppItemsStatusNormal;
        }
    }
    else{
        return AppItemsStatusNotNet;
    }
}

- (void) downloadAppOfCell:(AppCollectionViewCell *) cell {
    
    BFAppItemsModel *model = cell.model ;
    
    BFH5ZipItemsDownloadTask* task = [_dictDownloadTask objectForKey:model.BFAppItemsId];
    
    if(task == nil) {
        task = [self downloadH5ZipModel:model sessionManager:_downloadSessionManager];
        [_dictDownloadTask setValue:task forKey:model.BFAppItemsId] ;
    }
    else {
        [task.progress removeObserver:task.cell forKeyPath:@"fractionCompleted"] ;
    }
    
    if ([task.downloadModel.BFAppItemsVersion isEqualToString:model.BFAppItemsVersion]) {
        [task.downloadTask cancel] ;
        [_dictDownloadTask removeObjectForKey:model.BFAppItemsId] ;
    }
    
    //绑定cell
    task.cell = cell ;
    [task.progress addObserver:cell forKeyPath:@"fractionCompleted" options:NSKeyValueObservingOptionNew context:nil] ;
}

- (void) downloadAppOfModel:(BFAppItemsModel *) model {
    BFH5ZipItemsDownloadTask *task = [_dictDownloadTask objectForKey:model.BFAppItemsId] ;
    if(task == nil) {
        task = [self downloadH5ZipModel:model sessionManager:_downloadSessionManager];
        [_dictDownloadTask setValue:task forKey:model.BFAppItemsId] ;
    }
    else {
        [task.progress removeObserver:task.cell forKeyPath:@"fractionCompleted"] ;
    }
    
    if ([task.downloadModel.BFAppItemsVersion isEqualToString:model.BFAppItemsVersion]) {
        [task.downloadTask cancel] ;
        [_dictDownloadTask removeObjectForKey:model.BFAppItemsId] ;
    }
}

@end

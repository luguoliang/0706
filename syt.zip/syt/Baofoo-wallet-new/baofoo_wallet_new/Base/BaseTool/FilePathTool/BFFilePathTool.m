//
//  BFFilePathTool.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/24.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFFilePathTool.h"
#import "BFFileTool.h"
#import "BFAppItemsModel.h"

NSString *const LobbyVersionInfoFileName = @"BestPay.iAPP.Lobby.VersionInfo";
NSString *const LobbyAppListFileName = @"BestPay.iAPP.Lobby.Apps";//为了兼容老的版本，考虑文件不大，直接换名
NSString *const LobbyAdListFileName = @"BestPay.iAPP.Lobby.AdList";
NSString *const LobbyResourceListFileName = @"BestPay.iAPP.Lobby.ResourceList";
NSString *const LobbyResourceLaunchImageFileName = @"BestPay.iAPP.Lobby.ResourceLaunchImage";

@implementation BFFilePathTool

/* *************** tempHomePage *************** */

+ (NSString *)applicationModelFilePath{
    return [BFFileTool getDocumentFilePathWithName:@"BestPay.iAPP.state.reconstruction.application"];
}

/* *************** tempHomePage *************** */


// 获取某一文件夹中的某一文件的路径
+ (NSString *)pathForFolder:(NSString *)folder File:(NSString *)name{
    return [folder stringByAppendingPathComponent:name];
}

//验证预置包是否存在
+ (NSString *) presetedPathOfCurVersionInBundleWithModel:(BFAppItemsModel *)model {
    //是否存在于bundle
    NSString *presetPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"PresetHtml5Zip"] ;
    NSString *fileName = [NSString stringWithFormat:@"%@_%@.zip", model.BFAppItemsId, model.BFAppItemsName] ;
    presetPath = [presetPath stringByAppendingPathComponent:fileName] ;
    
    if([[NSFileManager defaultManager] fileExistsAtPath:presetPath]) {
        return presetPath ;
    }
    return nil ;
}

#pragma mark - 下载

//Html5App Zip包下载文件夹地址
+ (NSString *)BFH5ZipItemsDownloadTempFolderPath{
    return [BFFileTool getCacheFilePathWithName:@"BFH5ZipItemsDownloadTemp"];
}

//Html5App Zip包安装文件夹地址
+ (NSString *)BFH5ZipItemsAppsFinalFolderPath{
    return [BFFileTool getDocumentFilePathWithName:@"BFH5ZipItems" skipiCloudBackup:YES];
}

//H5与Native交互的公共接口JS文件地址
+ (NSString *)publicPortPath{
    NSString *folderPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"PresetHtml5Zip"];
    return [folderPath stringByAppendingPathComponent:PublicJs_File];
}

//Html5App Zip包临时缓存下载地址
+ (NSString *)BFH5ZipItemsDownloadTempPath:(BFAppItemsModel *)itemModel {
    return [[[self class] BFH5ZipItemsDownloadTempFolderPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@.zip.temp", itemModel.BFAppItemsId, itemModel.BFAppItemsVersion]];
}

//Html5App Zip包保存地址
+ (NSString *)BFH5ZipItemsDownloadSavePath:(BFAppItemsModel *)itemModel {
    return [[[self class] BFH5ZipItemsDownloadTempFolderPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@.zip", itemModel.BFAppItemsId, itemModel.BFAppItemsVersion]];
}

//Html5App 包文件夹地址
+ (NSString *)BFH5ZipItemsInstalledPath:(BFAppItemsModel *)itemModel {
    NSString *path = [[[self class] BFH5ZipItemsAppsFinalFolderPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@", itemModel.BFAppItemsId, itemModel.BFAppItemsVersion]];
    return path;
}

//Html5App包 主页地址
+ (NSString *)appMainFilePath:(BFAppItemsModel *)itemModel {
    
    //通过Properties文件去取MainFile
    NSString *appPropertyFilePath = [[self class] appPropertyFilePath:itemModel];
    if ([BFFileTool fileExistsAtPath:appPropertyFilePath]) {
        NSString *appInstalledPath = [BFFilePathTool BFH5ZipItemsInstalledPath:itemModel];
        NSString *mainFileName = [BFFilePathTool propertyMainItem:itemModel];
        if (mainFileName) {
            return [appInstalledPath stringByAppendingPathComponent:mainFileName];
        }
    }
    return nil;
}

//Html5App包 属性文件地址
+ (NSString *)appPropertyFilePath:(BFAppItemsModel *)itemModel {
    NSString *folderPath = [[self class] BFH5ZipItemsInstalledPath:itemModel];
    return [[self class] pathForFolder:folderPath File:Properties_File];
}

+ (NSString *)appPublicJsFilePath:(BFAppItemsModel *)itemModel{
    NSString *folderPath = [[self class] BFH5ZipItemsInstalledPath:itemModel];
    return [[self class] pathForFolder:folderPath File:PublicJs_File];
}

#pragma mark - Html5App预置包

//Html5App（预置） 文件夹
+ (NSString *)presetAppInstalledPath:(BFAppItemsModel *)itemModel{
    NSString *path = [[[self class] BFH5ZipItemsAppsFinalFolderPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_%@", itemModel.BFAppItemsId, itemModel.BFAppItemsVersion]];
    return path;
}

//Html5App（预置） MainFile
+ (NSString *)presetAppMainFilePath:(BFAppItemsModel *)itemModel{
    NSString *folderPath = [[self class] presetAppInstalledPath:itemModel];
    return [[self class] pathForFolder:folderPath File:Main_File];
}

//Html5App（预置） PropertyFile
+ (NSString *)presetAppPropertyFilePath:(BFAppItemsModel *)itemModel{
    NSString *folderPath = [[self class] presetAppInstalledPath:itemModel];
    return [[self class] pathForFolder:folderPath File:Properties_File];
}

//Html5App（预置） 接口Js
+ (NSString *)presetAppPublicJsFilePath:(BFAppItemsModel *)itemModel{
    NSString *folderPath = [[self class] presetAppInstalledPath:itemModel];
    return [[self class] pathForFolder:folderPath File:PublicJs_File];
}


#pragma mark - 包属性文件解析
+ (NSString *)propertyVersionItem:(BFAppItemsModel *)itemModel{
    return [[[self class] propertyDictionaryForItem:itemModel] objectForKey:@"VERSION"];
}

+ (NSString *)propertyKeyForItem:(BFAppItemsModel *)itemModel{
    return [[[self class] propertyDictionaryForItem:itemModel] objectForKey:@"KEY"];
}

+ (NSString *)propertyMainItem:(BFAppItemsModel *)itemModel{
    return [[[self class] propertyDictionaryForItem:itemModel] objectForKey:@"MAIN"];
}

+ (NSDictionary *)propertyDictionaryForItem:(BFAppItemsModel *)item {
    NSString *propertyFile = [[self class] appPropertyFilePath:item];
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    
    NSString *contents = [[NSString alloc] initWithContentsOfFile:propertyFile encoding:NSUTF8StringEncoding error:nil];
    
    NSArray *array = [contents componentsSeparatedByString:@"\n"];
    if ([array count]) {
        for (int i = 0; i < [array count]; i ++) {
            NSString *pStr = [array objectAtIndex:i];
            NSArray *kvArray = [pStr componentsSeparatedByString:@"="];
            if ([kvArray count] != 2) {
                continue;
            }
            NSString *key = [kvArray objectAtIndex:0];
            key = [key stringByReplacingOccurrencesOfString:@"\b" withString:@""];
            key = [key stringByReplacingOccurrencesOfString:@"\r" withString:@""];
            key = [key stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            key = [key stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            key = [key stringByReplacingOccurrencesOfString:@"\0" withString:@""];
            NSString *value = [kvArray objectAtIndex:1];
            value = [value stringByReplacingOccurrencesOfString:@"\b" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"\r" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"\0" withString:@""];
            
            [dic setObject:value forKey:key];
        }
    }
    return dic;
}

/* *********************   tempHomePage ****************/
#pragma mark - 大厅

+ (NSString *)lobbyVersionInfoFilePath{
    NSString *filename = LobbyVersionInfoFileName;
    if ([BFLoginTool loggedIn]) {
        filename = [NSString stringWithFormat:@"%@.%@", @"BestPay.iAPP.Lobby.VersionInfo", [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].mobile];
    }
    return [BFFileTool getDocumentFilePathWithName:filename];
}

+ (NSString *)lobbyAppListFilePath{
    NSString *filename = LobbyAppListFileName;
    if ([BFLoginTool loggedIn]) {
        //为了兼容老的版本，考虑文件不大，直接换名 换名称 BestPay.iAPP.Lobby.AppList －> BestPay.iAPP.Lobby.Apps
        filename = [NSString stringWithFormat:@"%@.%@", @"BestPay.iAPP.Lobby.Apps", [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].mobile];
    }
    return [BFFileTool getDocumentFilePathWithName:filename];
}

+ (NSString *)lobbyAdListFilePath{
    NSString *filename = LobbyAdListFileName;
    if ([BFLoginTool loggedIn]) {
        filename = [NSString stringWithFormat:@"%@.%@", @"BestPay.iAPP.Lobby.AdList", [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].mobile];
    }
    return [BFFileTool getDocumentFilePathWithName:filename];
}

+ (NSString *)lobbyResourceListFilePath{
    NSString *filename = LobbyResourceListFileName;
    if ([BFLoginTool loggedIn]) {
        filename = [NSString stringWithFormat:@"%@.%@", @"BestPay.iAPP.Lobby.ResourceList", [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].mobile];
    }
    return [BFFileTool getDocumentFilePathWithName:filename];
}

+ (NSString *)lobbyResourceLaunchImageFilePath{
    NSString *filename = LobbyResourceLaunchImageFileName;
    if ([BFLoginTool loggedIn]) {
        filename = [NSString stringWithFormat:@"%@.%@", @"BestPay.iAPP.Lobby.ResourceLaunchImage", [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].mobile];
    }
    return [BFFileTool getDocumentFilePathWithName:filename];
}

/* *********************   tempHomePage ****************/


@end

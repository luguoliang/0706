//
//  BFFilePathTool.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/24.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BFAppItemsModel.h"

#define PublicJs_File @"baofoo.html5.js"
#define Main_File @"main.html"
#define Properties_File @"manifest.properties"

UIKIT_EXTERN NSString *const LobbyVersionInfoFileName;
UIKIT_EXTERN NSString *const LobbyAppListFileName;
UIKIT_EXTERN NSString *const LobbyAdListFileName;
UIKIT_EXTERN NSString *const LobbyResourceListFileName;
UIKIT_EXTERN NSString *const LobbyResourceLaunchImageFileName;

@interface BFFilePathTool : NSObject

/* *************** tempHomePage *************** */
+ (NSString *)applicationModelFilePath;
/* *************** tempHomePage *************** */


//验证预置包是否存在
+ (NSString *)presetedPathOfCurVersionInBundleWithModel:(BFAppItemsModel *)model;

//Html5App Zip包下载文件夹地址
+ (NSString *)BFH5ZipItemsDownloadTempFolderPath;

//Html5App Zip包安装文件夹地址
+ (NSString *)BFH5ZipItemsAppsFinalFolderPath;

//H5与Native交互的公共接口JS文件地址
+ (NSString *)publicPortPath;

//Html5App Zip包临时缓存下载地址
+ (NSString *)BFH5ZipItemsDownloadTempPath:(BFAppItemsModel *)itemModel;

//Html5App Zip包保存地址
+ (NSString *)BFH5ZipItemsDownloadSavePath:(BFAppItemsModel *)itemModel;

//Html5App 包文件夹地址
+ (NSString *)BFH5ZipItemsInstalledPath:(BFAppItemsModel *)itemModel;

//Html5App包 主页地址
+ (NSString *)appMainFilePath:(BFAppItemsModel *)itemModel;

//Html5App包 属性文件地址
+ (NSString *)appPropertyFilePath:(BFAppItemsModel *)itemModel;

//公共接口文件地址
+ (NSString *)appPublicJsFilePath:(BFAppItemsModel *)itemModel;
/**
 *  Html5App（预置） 文件夹
 */
+ (NSString *)presetAppInstalledPath:(BFAppItemsModel *)itemModel;

/**
 *  Html5App（预置） MainFile
 */
+ (NSString *)presetAppMainFilePath:(BFAppItemsModel *)itemModel;

/**
 *  Html5App（预置） PropertyFile
 */
+ (NSString *)presetAppPropertyFilePath:(BFAppItemsModel *)itemModel;

/**
 *  Html5App（预置） 接口Js
 */
+ (NSString *)presetAppPublicJsFilePath:(BFAppItemsModel *)itemModel;



#pragma mark - 大厅

+ (NSString *)lobbyVersionInfoFilePath; //大厅版本地址
+ (NSString *)lobbyAppListFilePath; //大厅应用列表地址
+ (NSString *)lobbyAdListFilePath; //大厅轮播广告地址
+ (NSString *)lobbyResourceListFilePath; //大厅资源图地址
+ (NSString *)lobbyResourceLaunchImageFilePath; //进入图地址




@end

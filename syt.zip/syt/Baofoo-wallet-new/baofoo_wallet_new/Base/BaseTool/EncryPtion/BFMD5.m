//
//  BFMD5.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/20.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFMD5.h"
#import <CommonCrypto/CommonDigest.h>

@implementation BFMD5
+ (NSString *) md5:(NSString *)str
{
    const char *cStr = [str UTF8String];
    unsigned char result[16];
    CC_MD5( cStr, (unsigned int) strlen(cStr), result);
    return [NSString stringWithFormat:
            @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
            result[0], result[1], result[2], result[3],
            result[4], result[5], result[6], result[7],
            result[8], result[9], result[10], result[11],
            result[12], result[13], result[14], result[15]
            ];      
}

+ (NSString *)md5Encrypt:(NSString*)str{
    return [[self class] md5Encrypt:str withType:MD5EncryptType32Uppercase];
}

+ (NSString *)md5Encrypt:(NSString *)str withType:(MD5EncryptType)type{
    const char *original_str = [str UTF8String];
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    CC_MD5(original_str, (unsigned int)strlen(original_str), result);
    NSMutableString *hash = [NSMutableString string];
    
    switch (type) {
        case MD5EncryptType16Lowercase:{
            for (int i = 4; i < CC_MD5_DIGEST_LENGTH-4; i++) {
                [hash appendFormat:@"%02x", result[i]];
            }
            break;
        }
        case MD5EncryptType16Uppercase:{
            for (int i = 4; i < CC_MD5_DIGEST_LENGTH-4; i++) {
                [hash appendFormat:@"%02X", result[i]];
            }
            break;
        }
        case MD5EncryptType32Lowercase:{
            for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i++) {
                [hash appendFormat:@"%02x", result[i]];
            }
            break;
        }
        case MD5EncryptType32Uppercase:{
            for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i++) {
                [hash appendFormat:@"%02X", result[i]];
            }
            break;
        }
        default:
            break;
    }
    return hash;
}
@end

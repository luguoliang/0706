//
//  BFMD5.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/20.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, MD5EncryptType) {
    MD5EncryptType16Lowercase = 0, //16位小写
    MD5EncryptType16Uppercase, //16位大写
    MD5EncryptType32Lowercase, //32位小写
    MD5EncryptType32Uppercase //32位大写
};

@interface BFMD5 : NSObject
+ (NSString *) md5:(NSString *)str;

/**
 *  MD5加密，默认采用32位大写
 */
+ (NSString *)md5Encrypt:(NSString*)str;

/**
 *  MD5加密
 *
 *  @param type MD5加密类型
 *
 *  @return MD5加密后的字符串
 */
+ (NSString *)md5Encrypt:(NSString *)str withType:(MD5EncryptType)type;

@end

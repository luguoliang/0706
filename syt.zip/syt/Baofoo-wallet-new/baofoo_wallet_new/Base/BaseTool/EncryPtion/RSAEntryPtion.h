//
//  RSAEntryPtion.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/15.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RSAEntryPtion : NSObject

+(NSString *)stringWithRSAEncryPtion:(NSString*)encryPtionString;
+ (NSString*)entcryPtion:(NSString*)encryptString;
@end

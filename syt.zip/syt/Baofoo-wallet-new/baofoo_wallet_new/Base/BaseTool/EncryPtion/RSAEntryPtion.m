//
//  RSAEntryPtion.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/15.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "RSAEntryPtion.h"
#import "Base64.h"
#import "CryptoUtil.h"

#define PUBLICKEY @"-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC+TUJvk96Ni89YazVTq14eVReHgNPjduo4RVEY1BZStSpISBTJ4LkaHNTDVc6IGe6WVQdESSSigq5YtrGZ2weXCf96jKSd0lAwglj5rxQgs9JlKtnEPce5+Hy8Mrz3ZRgjasZ2Eb4o764oPf7ZMY24WJi2o5fn97685ylQZdRi8QIDAQAB\n-----END PUBLIC KEY-----"

@implementation RSAEntryPtion
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

+ (NSString*)entcryPtion:(NSString*)encryptString
{
    //double totalLength = [encryptString length];
    
    //    NSString *path = [[NSBundle mainBundle] pathForResource:@"PublicKey" ofType:@"txt"];
    NSString *publicKeyString = PUBLICKEY;
    // NSLog(@"%@", publicKeyString);
    //    SecKeyRef publicKey = [CryptoUtil RSAPublicKeyRefFromBase64String:publicKeyString withTag:@"com.gracelancy.tag"];
    SecKeyRef publicKey = [CryptoUtil RSAPublicKeyRefFromBase64String:publicKeyString withTag:nil];
    NSData *encryptData = [CryptoUtil encryptString:encryptString RSAPublicKey:publicKey padding:kSecPaddingNone];
    // NSString *ssss = [[NSString alloc] initWithData:encryptData encoding:NSUTF8StringEncoding];
    // NSData *da = [encryptData base64EncodedString];
    NSLog(@"加密后的数据是:%@", [encryptData base64EncodedString]);
    NSString *backEntcry = [encryptData base64EncodedString];
    
    backEntcry = [backEntcry stringByReplacingOccurrencesOfString:@"\n" withString:@"%OA"];
    backEntcry = [backEntcry stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
    backEntcry = [backEntcry stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
    backEntcry = [backEntcry stringByReplacingOccurrencesOfString:@"=" withString:@""];
    
    return backEntcry;
}

+(NSString *)stringWithRSAEncryPtion:(NSString *)encryPtionString
{
    //@"com.gracelancy.tag"
    SecKeyRef publicKey = [CryptoUtil RSAPublicKeyRefFromBase64String:PUBLICKEY withTag:@"what fuck is this!!"];
    if (publicKey == nil) {
        return @"";
    }
    //SecKeyRef publicKey = [CryptoUtil RSAPublicKeyRefFromBase64String:publicKeyString withTag:nil];
    //分段加密每段最大加密长度117字节
    NSMutableData *encryptData = [[NSMutableData alloc] init];
    double totalLength = [encryPtionString length];
    size_t size = 117;
    size_t count = (size_t)ceil(totalLength / size);
    for (int  i = 0; i < count; i ++) {
        NSUInteger loc = i * size;
        NSInteger dataSegmentRealSize = MIN(size, [encryPtionString length] - loc);
        NSString *stringSegment = [encryPtionString substringWithRange:NSMakeRange(loc,dataSegmentRealSize)];
        NSData *encryptDataSegment = [CryptoUtil encryptString:stringSegment RSAPublicKey:publicKey padding:kSecPaddingNone];
        [encryptData appendData:encryptDataSegment];
    }
    // NSData *encryptData = [CryptoUtil encryptString:encryPtionString RSAPublicKey:publicKey padding:kSecPaddingNone];
    //对加密后的数据进行base64编码
    NSString*backEncryPtionstring = [encryptData base64EncodedString];
    //过滤掉敏感字符
    backEncryPtionstring = [backEncryPtionstring stringByReplacingOccurrencesOfString:@"\n" withString:@"%OA"];
    backEncryPtionstring = [backEncryPtionstring stringByReplacingOccurrencesOfString:@"+" withString:@"-"];
    backEncryPtionstring = [backEncryPtionstring stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
    backEncryPtionstring = [backEncryPtionstring stringByReplacingOccurrencesOfString:@"=" withString:@""];
    return backEncryPtionstring;
    
}
@end

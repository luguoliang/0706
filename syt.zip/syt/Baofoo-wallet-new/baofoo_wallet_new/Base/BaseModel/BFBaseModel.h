//
//  BFBaseModel.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/25.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BFBaseModel : NSObject

+ (instancetype)getModelFromDictionary:(NSDictionary *)dictionary;
+ (NSArray *)getModelsFromArray:(NSArray *)array;

+ (instancetype)createModel;
- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end

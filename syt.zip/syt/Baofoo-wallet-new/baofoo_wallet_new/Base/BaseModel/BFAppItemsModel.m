//
//  BFAppItemsModel.m
//  baofoo_wallet_new
//
//  Created by jackzhou on 16/3/24.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFAppItemsModel.h"

@interface BFAppItemsModel ()<NSCoding>

@end

@implementation BFAppItemsModel

- (instancetype)init{
    if (self = [super init]) {
        _BFAppItemsStateValue = BFAppItemsStateValueNormal ;
        _BFAppItemsType = BFAppItemsNative ;
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super init]) {
        self.BFAppItemsId = [aDecoder decodeObjectForKey:@"BFAppItemsId"];
        self.BFAppItemsName = [aDecoder decodeObjectForKey:@"BFAppItemsName"];
        self.BFAppItemsVersion = [aDecoder decodeObjectForKey:@"BFAppItemsVersion"];
        self.BFAppItemsCheckMd5 = [aDecoder decodeObjectForKey:@"BFAppItemsCheckMd5"];
        self.BFAppItemsFileUrl = [aDecoder decodeObjectForKey:@"BFAppItemsFileUrl"];
        self.BFAppItemsIconUrl = [aDecoder decodeObjectForKey:@"BFAppItemsIconUrl"];
        self.BFAppItemsFileSize = [aDecoder decodeObjectForKey:@"BFAppItemsFileSize"];
        
        self.BFAppItemsStateValue = [aDecoder decodeIntegerForKey:@"BFAppItemsStateValue"];
        self.BFAppItemsType = [aDecoder decodeIntegerForKey:@"BFAppItemsType"];
        
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.BFAppItemsId forKey:@"BFAppItemsId"];
    [aCoder encodeObject:self.BFAppItemsName forKey:@"BFAppItemsName"];
    [aCoder encodeObject:self.BFAppItemsVersion forKey:@"BFAppItemsVersion"];
    [aCoder encodeObject:self.BFAppItemsCheckMd5 forKey:@"BFAppItemsCheckMd5"];
    [aCoder encodeObject:self.BFAppItemsFileUrl forKey:@"BFAppItemsFileUrl"];
    [aCoder encodeObject:self.BFAppItemsIconUrl forKey:@"BFAppItemsIconUrl"];
    [aCoder encodeObject:self.BFAppItemsFileSize forKey:@"BFAppItemsFileSize"];
    
    [aCoder encodeInteger:self.BFAppItemsStateValue forKey:@"BFAppItemsStateValue"];
    [aCoder encodeInteger:self.BFAppItemsType forKey:@"BFAppItemsType"];
}


@end

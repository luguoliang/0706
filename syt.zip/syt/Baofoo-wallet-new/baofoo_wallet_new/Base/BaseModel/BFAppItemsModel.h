//
//  BFAppItemsModel.h
//  baofoo_wallet_new
//
//  Created by jackzhou on 16/3/24.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseModel.h"

// app状态的定义
typedef NS_ENUM(NSInteger, BFAppItemsStateValue) {
    BFAppItemsStateValueWaitingForCheck = 0, //待审核
    BFAppItemsStateValueNormal, //正常
    BFAppItemsStateValueUpdatedOptional, //可选更新
    BFAppItemsStateValueUpdatedRequired,//强制更新
    BFAppItemsStateValueSuspend, //暂停
    BFAppItemsStateValueOffline, //下线
    BFAppItemsStateValueAreaLimited //区域受限
};


// app类型的定义
typedef NS_ENUM(NSInteger, BFAppItemsType) {
    BFAppItemsH5 = 0, // h5
    BFAppItemsH5Zip, // h5 Zip包
    BFAppItemsNative // 原生应用
};


// APPID
typedef NS_ENUM(NSInteger, BFAppId) {
    BFAppID_1 = 0 ,
    BFAppID_2
};

@interface BFAppItemsModel : BFBaseModel

@property (copy, nonatomic) NSString *BFAppItemsId; //包编号
@property (copy, nonatomic) NSString *BFAppItemsName;  //包名，即首页上显示的名字
@property (copy, nonatomic) NSString *BFAppItemsVersion;  //版本 
@property (copy, nonatomic) NSString *BFAppItemsCheckMd5; //md5
@property (copy, nonatomic) NSString *BFAppItemsFileUrl;  //文件Url
@property (copy, nonatomic) NSString *BFAppItemsIconUrl;  //图标iconUrl
@property (copy, nonatomic) NSString *BFAppItemsFileSize; //app大小
@property (assign, nonatomic) BFAppItemsStateValue BFAppItemsStateValue; //app的状态
@property (assign, nonatomic) BFAppItemsType BFAppItemsType; // 是否为zip包

@end

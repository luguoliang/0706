//
//  BaseMethodModel.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseMethodModel : NSObject

@property (nonatomic, strong) NSDictionary *userInfo;
@property (nonatomic, copy) NSString *name;
@property (nonatomic) SEL method;
@property (nonatomic, strong) id methodObject;

+ (instancetype)createModel;

+ (instancetype)createWithName:(NSString *)name selector:(SEL)method;

@end

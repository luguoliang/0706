//
//  BaseMethodModel.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BaseMethodModel.h"

@implementation BaseMethodModel

+ (instancetype)createModel{
    return [[self alloc] init];
}

+ (instancetype)createWithName:(NSString *)name selector:(SEL)method{
    
    BaseMethodModel *model = [[BaseMethodModel alloc] init];
    model.name = name;
    model.method = method;
    
    return model;
}
@end

//
//  BFBaseModel.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/25.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseModel.h"

@implementation BFBaseModel
+ (instancetype)getModelFromDictionary:(NSDictionary *)dictionary{
    return [[self class] createModel];
}

+ (NSArray *)getModelsFromArray:(NSArray *)array{
    return nil;
}

+ (instancetype)createModel{
    return [[self alloc] init];
}

- (instancetype)initWithDictionary:(NSDictionary *)dictionary{
    return [self init];
}
@end

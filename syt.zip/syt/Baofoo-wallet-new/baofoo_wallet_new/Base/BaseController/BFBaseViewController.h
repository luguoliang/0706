//
//  BFBaseViewController.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/5.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MBProgressHUD/MBProgressHUD.h>

@interface BFBaseViewController : UIViewController<UIAlertViewDelegate>
//左侧按钮定制
- (UIBarButtonItem *)barBtnItemWithCustomView:(UIView *)customView;
- (void)setLeftBarButtonItemTarget:(id)target action:(SEL)action;
- (void)setLeftBarButtonItemTarget:(id)target action:(SEL)action image:(UIImage *)image;
- (void)setLeftBarButtonItemWithCustomView:(UIView *)customView;
- (void)hideLeftBarButtonItem;
- (void)clickLeftBarButtonItem:(id)sender;

//右侧按钮定制
- (UIButton *)setRightBarButtonItemTarget:(id)target action:(SEL)action title:(NSString *)title bgImage:(NSString *)imageName;
- (UIButton *)setRightBarButtonItemTarget:(id)target action:(SEL)action title:(NSString *)title bgImage:(NSString *)imageName titleColor:(UIColor *)titleColor;

- (void)setRightBarButtonItemWithCustomView:(UIView *)customView;
- (void)hideRightBarButtonItem;

#pragma mark - Alert

- (void)showAlertWithMsg:(NSString *)msg delegate:(id<UIAlertViewDelegate>)delegate;
- (void)cancelAlertDelegate;

#pragma mark - YZFProgressHUD

- (void)showProgress;
- (void)showWindowProgress;
- (void)hideProgress;

#pragma mark - NotifyProgress

- (void)showNotifyProgressWithTitle:(NSString *)title completionBlock:(void(^)(void))completionBlock;
- (void)showNotifyProgressWithTitle:(NSString *)title duration:(NSTimeInterval)duration completionBlock:(void(^)(void))completionBlock;

//设置导航栏图片，字体颜色
- (void)setNavBarImage:(UIImage *)image titleColor:(UIColor *)titleColor;

@end

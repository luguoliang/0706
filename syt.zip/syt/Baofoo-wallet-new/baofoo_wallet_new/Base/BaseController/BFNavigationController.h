//
//  BFNavigationController.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/5.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BFNavigationController : UINavigationController

@end

//
//  BFTabBarController.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/5.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFTabBarController.h"
#import "BFNavigationController.h"

// childViewControllers
#import "HomePageViewController.h"
#import "HsqViewController.h"
#import "TTZViewController.h"
#import "BFAccountViewController.h"
#import "BFHomePageViewController.h"

// 配置表
#import "BFTabBarConfigHeader.h"
#import "BFCommonHeader.h"

// 工具类
#import "UIColor+BFColorTool.h"
#import "BFLoginTool.h"

// 数据
#import "BFApplicationModel.h"

@interface BFTabBarController ()<UITabBarControllerDelegate>

@property (nonatomic, strong) NSMutableArray *imageArray;
@property (nonatomic, strong) NSMutableArray *selectedImageArray;

@end

@implementation BFTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    _imageArray = [[NSMutableArray alloc] init];
    _selectedImageArray = [[NSMutableArray alloc] init];
    self.delegate = self;
    // 修改字体颜色
    [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:TAB_BAR_COLOR_Selected, NSForegroundColorAttributeName,nil] forState:UIControlStateSelected];
    
    // 初始化子控制器
    [self subControllers];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 初始化子控制器
- (void)subControllers
{
    HomePageViewController *vc0 = [[HomePageViewController alloc] init];
//    BFHomePageViewController*vc0 = [[BFHomePageViewController alloc] init];
    HsqViewController *vc1 = [[HsqViewController alloc] init];
    BFAccountViewController *vc2 = [[BFAccountViewController alloc] init];
 
    [BFApplicationModel loadApplicationInfo];
    NSString *colorId = [BFApplicationModel sharedInstance].lobbyTopBackgroundId?[BFApplicationModel sharedInstance].lobbyTopBackgroundId : @"0";
    NSArray *array = [NSArray arrayWithObjects:
                      [self navWithRoot:vc0 title:BFtabBarTitle_0 image:BFtabBarImage_0 selectedImage:[NSString stringWithFormat:@"hsq_home_click_%@",colorId] atIndex:0],
                      [self navWithRoot:vc1 title:BFtabBarTitle_1 image:BFtabBarImage_1 selectedImage:[NSString stringWithFormat:@"hsq_hsq_click_%@",colorId] atIndex:1],
                      [self navWithRoot:vc2 title:BFtabBarTitle_2 image:BFtabBarImage_2 selectedImage:[NSString stringWithFormat:@"hsq_account_click_%@",colorId] atIndex:2], nil];
    
    [self setViewControllers:array animated:YES];
}

- (BFNavigationController *)navWithRoot:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage atIndex:(NSInteger)index
{
    vc.title = title;
    BFNavigationController *nav = [[BFNavigationController alloc] initWithRootViewController:vc];
    nav.tabBarItem = [[UITabBarItem alloc] initWithTitle:title image:[[UIImage imageNamed:image] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:selectedImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    [_imageArray addObject:[UIImage imageNamed:image]];
    [_selectedImageArray addObject:[[UIImage imageNamed:selectedImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    return nav;
}

#pragma mark - UITabbarViewControllerDelegate

-(BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController{
    BFNavigationController*navigation = (BFNavigationController*)viewController;
    UIViewController*controller = [navigation.viewControllers lastObject];
    if ([controller isMemberOfClass:[HomePageViewController class]]) {
        [[self.tabBar items][0] setSelectedImage:[[UIImage imageNamed:[NSString stringWithFormat:@"hsq_home_click_%@",[BFApplicationModel sharedInstance].lobbyTopBackgroundId]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    }
    else if ([controller isMemberOfClass:[HsqViewController class]]) {
        
        [[self.tabBar items][1] setSelectedImage:[[UIImage imageNamed:[NSString stringWithFormat:@"hsq_hsq_click_%@",[BFApplicationModel sharedInstance].lobbyTopBackgroundId]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
        
        DebugLog(@"%@",[NSString stringWithFormat:@"hsq_hsq_click_%@",[BFApplicationModel sharedInstance].lobbyTopBackgroundId]);
    }
    else if ([controller isMemberOfClass:[BFAccountViewController class]]) {
        [[self.tabBar items][2] setSelectedImage:[[UIImage imageNamed:[NSString stringWithFormat:@"hsq_account_click_%@",[BFApplicationModel sharedInstance].lobbyTopBackgroundId]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    }
//    if (!([BFLoginTool checkLogin])) {
//        if ([controller isMemberOfClass:[BFAccountViewController class]]) {
//            [BFLoginTool toLoginWithAccountName:nil];
//            return NO;
//        }
//        else{
//            return YES;
//        }
//    }
    return YES;
}

- (void)setTabBarHomePageSelectImage {
    [[self.tabBar items][0] setSelectedImage:[[UIImage imageNamed:[NSString stringWithFormat:@"hsq_home_click_%@",[BFApplicationModel sharedInstance].lobbyTopBackgroundId]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
}

#pragma mark - Red Point 暂时不用的方法
- (void)setRedPointShow:(BOOL)isShow atIndex:(NSUInteger)index
{
    if (index > (self.viewControllers.count - 1)) {
        return;
    }
    
    UITabBarItem *item = [self.tabBar items][index];
    
    if (isShow) {
        [item setImage:[[self cicleImageWithBgImage:self.imageArray[index]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] ];
        [item setSelectedImage:[self cicleImageWithBgImage:self.selectedImageArray[index]]];
    }
    else
    {
        [item setImage:self.imageArray[index]];
        [item setSelectedImage:self.selectedImageArray[index]];
    }
}
- (UIImage *)cicleImageWithBgImage:(UIImage *)bgImage{
    CGFloat cicleW = 7;
    CGFloat cicleH = cicleW;
    CGFloat cicleX = bgImage.size.width;
    CGFloat cicleY = 0;
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(bgImage.size.width + cicleW, bgImage.size.height + cicleH + 2), NO, 0.0);
    
    CGContextRef ctx= UIGraphicsGetCurrentContext();
    CGContextAddEllipseInRect(ctx, CGRectMake(cicleX, cicleY, cicleW, cicleH));
    [[UIColor yellowColor] set];
    CGContextFillPath(ctx);
    
    [bgImage drawInRect:CGRectMake(cicleW / 2,( cicleH + 2) / 2, bgImage.size.width, bgImage.size.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage;
}

@end

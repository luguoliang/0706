//
//  BFBaseViewController.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/5.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseViewController.h"

@interface BFBaseViewController ()
{
    UIAlertView *defaultAlert;
    MBProgressHUD *hudView;
    BOOL isExchangeStatusStyle;
}
@end

@implementation BFBaseViewController

#pragma mark - Alert

- (void)showAlertWithMsg:(NSString *)msg delegate:(id<UIAlertViewDelegate>)delegate{
    defaultAlert = [[UIAlertView alloc] initWithTitle:Alert_Title message:msg delegate:delegate cancelButtonTitle:Alert_Button_Confirm otherButtonTitles:nil, nil];
    [defaultAlert show];
}

- (void)cancelAlertDelegate{
    defaultAlert.delegate = nil;
}

#pragma mark - MBProgressHUD

//显示菊花
- (void)showProgress{
    if (hudView == nil) {
        hudView = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    }
    else {
        [hudView show:YES];
    }
    [self.view bringSubviewToFront:hudView];
}

- (void)showWindowProgress{

    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    if (hudView == nil) {
        hudView = [MBProgressHUD showHUDAddedTo:window animated:YES];
    }
    else {
        [hudView show:YES];
    }

    [window bringSubviewToFront:hudView];
}

//隐藏菊花
- (void)hideProgress{
    if (hudView) {
        [hudView hide:YES];
        hudView = nil;
    }
}

#pragma mark - AppRoute Protocol

- (void) setAppRouteParameters:(NSDictionary *)parameters{
    //设置参数
    
}

#pragma mark - NotifyProgress

- (void)showNotifyProgressWithTitle:(NSString *)title duration:(NSTimeInterval)duration completionBlock:(void(^)(void))completionBlock{
    [BFTosat showTosatText:title displayPosition:ScreenHeight - 120 showDuration:duration];
    if (completionBlock) {
        completionBlock();
    }
}

- (void)showNotifyProgressWithTitle:(NSString *)title completionBlock:(void (^)(void))completionBlock{
    [self showNotifyProgressWithTitle:title duration:1.0 completionBlock:completionBlock];
}
#pragma mark - 左侧按钮定制

//自定义BarButtonItem
- (UIBarButtonItem *)barBtnItemWithCustomView:(UIView *)customView{
    UIBarButtonItem *barBtnItem = [[UIBarButtonItem alloc] initWithCustomView:customView];
    barBtnItem.style = UIBarButtonItemStylePlain;
    return barBtnItem;
}

//导航左侧按钮定制
- (void)setLeftBarButtonItemTarget:(id)target action:(SEL)action{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImage *nImage = [UIImage imageNamed:@"btn_back_gray"];
    UIImage *hImage = [UIImage imageNamed:@"btn_back_gray"];
    
    [button setFrame:CGRectMake(0, 0, nImage.size.width, nImage.size.height)];
    [button setBackgroundColor:[UIColor clearColor]];
    [button setBackgroundImage:nImage forState:UIControlStateNormal];
    [button setBackgroundImage:hImage forState:UIControlStateHighlighted];
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    [self.navigationItem setLeftBarButtonItem:[self barBtnItemWithCustomView:button]];
}

//导航左侧按钮定制(图片)
- (void)setLeftBarButtonItemTarget:(id)target action:(SEL)action image:(UIImage *)image{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
    [button setBackgroundColor:[UIColor clearColor]];
    [button setBackgroundImage:image forState:UIControlStateNormal];
    [button setBackgroundImage:image forState:UIControlStateHighlighted];
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    [self.navigationItem setLeftBarButtonItem:[self barBtnItemWithCustomView:button]];
}

//导航左侧按钮定制
- (void)setLeftBarButtonItemWithCustomView:(UIView *)customView{
    [self.navigationItem setLeftBarButtonItem:[self barBtnItemWithCustomView:customView]];
}

//隐藏导航左侧按钮
- (void)hideLeftBarButtonItem{
    [self.navigationItem setLeftBarButtonItem:nil];
    [self.navigationItem setHidesBackButton:YES];
}

//返回按钮默认事件处理
- (void)clickLeftBarButtonItem:(id)sender{
    [self.view endEditing:YES];
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - 右侧按钮定制

//导航右侧按钮定制
- (UIButton *)setRightBarButtonItemTarget:(id)target action:(SEL)action title:(NSString *)title bgImage:(NSString *)imageName{
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor = [UIColor clearColor];
    button.titleLabel.font = BF_Font_NavBarButtonItem;
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    if (title && ![title isEqualToString:@""]) {
        [button setTitle:title forState:UIControlStateNormal];
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        
        CGSize size = [BFStringTool sizeOfString:title Size:CGSizeMake(100.0, 44.0) Font:button.titleLabel.font];
        button.titleLabel.font = BF_Font_14;
        button.frame = CGRectMake(0, 0, size.width+20.0, 44.0);
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    if (imageName && ![imageName isEqualToString:@""]) {
        UIImage *nImage = [UIImage imageNamed:imageName];
        UIImage *hImage = [UIImage imageNamed:imageName];
        [button setBackgroundImage:nImage forState:UIControlStateNormal];
        [button setBackgroundImage:hImage forState:UIControlStateHighlighted];
        [button setFrame:CGRectMake(0, 0, nImage.size.width, nImage.size.height)];
    }
    
    [self.navigationItem setRightBarButtonItem:[self barBtnItemWithCustomView:button]];
    
    return button;
}

- (UIButton *)setRightBarButtonItemTarget:(id)target action:(SEL)action title:(NSString *)title bgImage:(NSString *)imageName titleColor:(UIColor *)titleColor{
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor = [UIColor clearColor];
    button.titleLabel.font = BF_Font_NavBarButtonItem;
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    if (title && ![title isEqualToString:@""]) {
        [button setTitle:title forState:UIControlStateNormal];
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        
        CGSize size = [BFStringTool sizeOfString:title Size:CGSizeMake(100.0, 44.0) Font:button.titleLabel.font];
        button.titleLabel.font = BF_Font_14;
        button.frame = CGRectMake(0, 0, size.width+20.0, 44.0);
        [button setTitleColor:titleColor forState:UIControlStateNormal];
    }
    if (imageName && ![imageName isEqualToString:@""]) {
        UIImage *nImage = [UIImage imageNamed:imageName];
        UIImage *hImage = [UIImage imageNamed:imageName];
        [button setBackgroundImage:nImage forState:UIControlStateNormal];
        [button setBackgroundImage:hImage forState:UIControlStateHighlighted];
        [button setFrame:CGRectMake(0, 0, nImage.size.width, nImage.size.height)];
    }
    
    [self.navigationItem setRightBarButtonItem:[self barBtnItemWithCustomView:button]];
    
    return button;
}

//导航右侧按钮定制
- (void)setRightBarButtonItemWithCustomView:(UIView *)customView{
    [self.navigationItem setRightBarButtonItem:[self barBtnItemWithCustomView:customView]];
}

//隐藏导航右侧按钮
- (void)hideRightBarButtonItem{
    [self.navigationItem setRightBarButtonItem:nil];
}

#pragma mark - View Life Cycle

- (void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = BF_Color_Background;
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    
    [self setNavBarImage:[UIImage imageNamed:@"navbar_white_bg"] titleColor:[UIColor blackColor]];
    if (_iOS7_Or_Later_) {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    [self setLeftBarButtonItemTarget:self action:@selector(clickLeftBarButtonItem:)];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.view endEditing:YES];
    if ( [UIApplication sharedApplication].statusBarStyle == UIStatusBarStyleLightContent) {
        //状态栏颜色
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:NO];
        isExchangeStatusStyle = YES;
    }
    else {
        isExchangeStatusStyle = NO;
    }
   
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.view endEditing:YES];
    if (isExchangeStatusStyle) {
        //状态栏颜色
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:NO];
    }
}

//设置导航栏图片，字体颜色
- (void)setNavBarImage:(UIImage *)image titleColor:(UIColor *)titleColor{
    [self.navigationController.navigationBar setTranslucent:NO];
    [self.navigationController.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:titleColor,NSFontAttributeName:BF_Font_NavTitle}];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

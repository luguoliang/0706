//
//  BFNavigationController.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/5.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFNavigationController.h"

@interface BFNavigationController () <UINavigationControllerDelegate>

@end

@implementation BFNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.delegate = self;
    
    [self.interactivePopGestureRecognizer setEnabled:NO];
    [self.interactivePopGestureRecognizer setDelegate:nil];
    
    [self.navigationBar setTranslucent:NO];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    //重载push，当push到二级页面时，隐藏底部tabbar
    UIViewController *navRoot = [self rootViewController];
    if (navRoot && ![viewController isEqual:navRoot]) {
        viewController.hidesBottomBarWhenPushed = YES;
    }
    else
    {
        viewController.hidesBottomBarWhenPushed = NO;
    }
    
    [super pushViewController:viewController animated:animated];
}

#pragma mark - UINavigationControllerDelegate


- (void)navigationController:(UINavigationController *)navigationController
       didShowViewController:(UIViewController *)viewController
                    animated:(BOOL)animated
{
    //通过delegate实现，当处于二级页面时，开启侧滑返回手势
    
    //不和上面隐藏tabbar在一起处理，是因为手势造成的pop操作，执行中进行改变手势支持状态会造成导航栈异常
    //所以在页面已经展示后改变手势是否支持的状态值
    UIViewController *navRoot = [self rootViewController];
    if (navRoot && ![viewController isEqual:navRoot]) {
        [viewController.navigationController.interactivePopGestureRecognizer setEnabled:YES];
        [viewController.navigationController.interactivePopGestureRecognizer setDelegate:nil];
    }
    else
    {
        [viewController.navigationController.interactivePopGestureRecognizer setEnabled:NO];
        [viewController.navigationController.interactivePopGestureRecognizer setDelegate:nil];
    }
}


#pragma mark - Private


- (UIViewController *)rootViewController
{
    return [self.viewControllers firstObject];
}


@end

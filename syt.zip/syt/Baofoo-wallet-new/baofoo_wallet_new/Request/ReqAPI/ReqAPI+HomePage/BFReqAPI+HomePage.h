//
//  BFReqAPI+HomePage.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/31.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI.h"

@interface BFReqAPI (HomePage)

/*
 * 请求H5Zip包的在线实时状态
 */
+ (void)getH5ZipItemsModelFromServerWithParameters:(NSDictionary *)params
                                             block:(APIResponseBlock)block;


@end

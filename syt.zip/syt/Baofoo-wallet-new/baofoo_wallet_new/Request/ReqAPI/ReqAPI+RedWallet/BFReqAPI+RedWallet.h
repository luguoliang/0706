//
//  BFReqAPI+RedWallet.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI.h"

@interface BFReqAPI (RedWallet)
/*
 *红包请求接口
 *1、我的账户红包
 *2、收银台里红包
 */
+ (void)getAccountRedWalletListCellModelFromServerWithParameters:(NSDictionary *)params
                                              block:(APIResponseBlock)block;
+ (void)getCheckoutCounterRedWalletListCellModelFromServerWithParameters:(NSDictionary *)params
                                              block:(APIResponseBlock)block;

@end

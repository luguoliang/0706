//
//  BFReqAPI+RedWallet.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI+RedWallet.h"

@implementation BFReqAPI (RedWallet)
+(void)getAccountRedWalletListCellModelFromServerWithParameters:(NSDictionary *)params block:(APIResponseBlock)block{
    NSDictionary*dict = @{}.copy;
    [BFReqAPI reqWithParams:dict andExURL:myAccount_Vouchers block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
+(void)getCheckoutCounterRedWalletListCellModelFromServerWithParameters:(NSDictionary *)params block:(APIResponseBlock)block{
    
}
@end

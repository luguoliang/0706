//
//  BFReqAPI+Security.m
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI+Security.h"

@implementation BFReqAPI (Security)

// 验证码下发
+ (void)reqVerifyCodeSendWithType:(NSString *)type andMsg_type:(NSString *)msg_type block:(APIResponseBlock)block
{
    NSDictionary *userIndo = [[NSDictionary alloc] initWithObjectsAndKeys:type,@"type",msg_type,@"msg_type",nil];

    [BFReqAPI reqWithParams:[[self class] encryptionParams:userIndo withEncryPtionVersion:@"2.0"] andExURL:login_sendMobileHttpServer block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];

}

// 验证登录密码
+ (void)reqValiLoginPwd:(NSString *)loginPwd block:(APIResponseBlock)block
{
    NSDictionary *userIndo = [[NSDictionary alloc] initWithObjectsAndKeys:loginPwd,@"password",nil];
    
    [BFReqAPI reqWithParams:[[self class] encryptionCodeParams:userIndo withEncryPtionVersion:@"2.0"]  andExURL:security_checkPwdAction block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

// 修改登录密码
+ (void)reqModifyLoginPwdWithOldPwd:(NSString *)oldPwd freshPwd:(NSString *)freshPwd andValiCode:(NSString *)code block:(APIResponseBlock)block
{
    NSDictionary *userIndo = [[NSDictionary alloc] initWithObjectsAndKeys:oldPwd,@"pay_password",freshPwd,@"password",code,@"dynamicCode",nil];
  
    [BFReqAPI reqWithParams:[[self class] encryptionParams:userIndo withEncryPtionVersion:@"2.0"] andExURL:security_modifyPwdAction block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
// 找回支付密码
+ (void)reqFindPayPwdWithSign:(NSString *)sign operation:(NSString *)op andFreshPayPwd:(NSString *)freshPayPwd block:(APIResponseBlock)block
{
    NSDictionary *userIndo = @{@"sign":sign,@"op":op,@"newPwd":freshPayPwd};
    
  
    [BFReqAPI reqWithParams:[[self class] encryptionParams:userIndo withEncryPtionVersion:@"2.0"] andExURL:findPayPwd_findPayPwdtPwd block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
// 修改支付密码
+ (void)reqModifyPayPwdWithOldPwd:(NSString *)oldPwd freshPwd:(NSString *)freshPwd andValiCode:(NSString *)code block:(APIResponseBlock)block
{
    NSDictionary *userIndo = [[NSDictionary alloc] initWithObjectsAndKeys:oldPwd,@"password",freshPwd,@"pay_password",code,@"dynamicCode",nil];
    
    [BFReqAPI reqWithParams:[[self class] encryptionParams:userIndo withEncryPtionVersion:@"2.0"]  andExURL:security_resetPayPwd block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

// 验证支付密码
+ (void)reqValiPayPwd:(NSString *)paypwd block:(APIResponseBlock)block
{
    NSDictionary *userIndo = [[NSDictionary alloc] initWithObjectsAndKeys:paypwd,@"pay_password",nil];
    
    [BFReqAPI reqWithParams:[[self class] encryptionCodeParams:userIndo withEncryPtionVersion:@"2.0"]  andExURL:security_checkPayPwd block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

// 验证找回支付密码的验证码
+ (void)reqValiPhoneCodeAtFindPayPwdWithSign:(NSString *)sign mobile:(NSString *)mobile code:(NSString *)code andOperation:(NSString *)op block:(APIResponseBlock)block
{
    NSDictionary *postDict = @{@"sign":sign,@"mobile":mobile,@"mobileCode":code,@"op":op};

    [BFReqAPI reqWithParams:postDict andExURL:findPayPwd_findPayPwdValiMobile block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
// 找回支付密码初始化
+ (void)reqInitFindPayPwdBlock:(APIResponseBlock)block
{
    [BFReqAPI reqWithParams:@{} andExURL:findPayPwd_init block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

// 找回支付密码验证码下发
+ (void)reqVerifyCodeSendForFindPayPwdWithPhoneNo:(NSString *)phoneNo block:(APIResponseBlock)block
{
    NSDictionary *postDict = @{@"mobile":phoneNo};

    [BFReqAPI reqWithParams:postDict andExURL:findPayPwd_findPayPwdndMobileVerCode block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

// 找回支付密码的方式列表
+ (void)reqTypeListOfFindPayPwdWithSign:(NSString *)sign block:(APIResponseBlock)block
{
    NSDictionary *postDict = @{@"sign":sign};

    [BFReqAPI reqWithParams:postDict andExURL:findPayPwd_findPayPwdpeList block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

// 获取安全问题
+ (void)reqGetSecurityQuestionBlock:(APIResponseBlock)block
{
    [BFReqAPI reqWithParams:@{} andExURL:register_getSecQuestions block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

// 验证安全问题
+ (void)reqValiSecurityQuestionWithParams:(NSDictionary *)params block:(APIResponseBlock)block
{
    [BFReqAPI reqWithParams:[[self class] encryptionParams:params withEncryPtionVersion:@"2.0"]  andExURL:findPayPwd_findPayPwdalidSafeAnsw block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

// 注册设置安全问题
+ (void)reqSettingSecurityQuestionForRegisterWithParams:(NSDictionary *)params block:(APIResponseBlock)block
{
    [BFReqAPI reqWithParams:[[self class] encryptionParams:params withEncryPtionVersion:@"2.0"] andExURL:register_walletRegister block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
// 信息加密
+ (NSDictionary *)encryptionParams:(NSDictionary *)params withEncryPtionVersion:(NSString *)version {
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:nil];
    NSString *encryption = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *encryptionStr = [RSAEntryPtion stringWithRSAEncryPtion:[encryption base64EncodedString]];
    NSDictionary *postDict = @{@"v":version,@"sp":encryptionStr};
    return postDict;
}
// 密码加密
+ (NSDictionary *)encryptionCodeParams:(NSDictionary *)params withEncryPtionVersion:(NSString*)version {
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:nil];
    NSString *encryption = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *encryptionStr = [RSAEntryPtion entcryPtion:[encryption base64EncodedString]];
    NSDictionary *postDict = @{@"v":version,@"sp":encryptionStr};
    return postDict;
}

// 修改安全问题
+ (void)reqModifySecurityQuestionWithParams:(NSDictionary *)params andModifyReqAPI:(NSString *)api block:(APIResponseBlock)block
{
    [BFReqAPI reqWithParams:[[self class] encryptionParams:params withEncryPtionVersion:@"2.0"] andExURL:api block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

// 修改安全问题时验证安全问题
+ (void)reqValiSecurityQuestionForModifyWithParams:(NSDictionary *)params block:(APIResponseBlock)block
{
    [BFReqAPI reqWithParams:[[self class] encryptionParams:params withEncryPtionVersion:@"2.0"] andExURL:security_veryAnswer block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
+ (void)reqValiPayPwdAtCheckOutWithPwd:(NSString *)pwd block:(APIResponseBlock)block {
    NSDictionary *postDict = @{@"payPassword":pwd};
    [BFReqAPI reqWithParams:[[self class] encryptionParams:postDict withEncryPtionVersion:@"2.0"] andExURL:cashPlatform_checkPayPwd block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
// 修改绑定手机验证码验证
+ (void)reqValiPhoneCodeAtModifyMobileWithParams:(NSDictionary *)params block:(APIResponseBlock)block{
    [BFReqAPI reqWithParams:[[self class] encryptionParams:params withEncryPtionVersion:@"2.0"] andExURL:security_checkMobileAction block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
// 重置绑定手机验证码下发
+ (void)reqVerifyCodeSendAtResetBindMobileWithParams:(NSDictionary *)params block:(APIResponseBlock)block{
    [BFReqAPI reqWithParams:[[self class] encryptionParams:params withEncryPtionVersion:@"2.0"] andExURL:security_changeMobileSvc block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
// 修改绑定手机
+ (void)reqResetBindMobileWithParams:(NSDictionary *)params block:(APIResponseBlock)block{
    [BFReqAPI reqWithParams:[[self class] encryptionParams:params withEncryPtionVersion:@"2.0"] andExURL:security_bindMobileAction block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
@end

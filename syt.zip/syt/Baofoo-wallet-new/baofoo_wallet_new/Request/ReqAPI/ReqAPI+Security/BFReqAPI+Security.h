//
//  BFReqAPI+Security.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/5/13.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI.h"



@interface BFReqAPI (Security)
// 验证码下发
+ (void)reqVerifyCodeSendWithType:(NSString *)type andMsg_type:(NSString *)msg_type block:(APIResponseBlock)block;
// 验证登录密码
+ (void)reqValiLoginPwd:(NSString *)loginPwd block:(APIResponseBlock)block;
// 修改登录密码
+ (void)reqModifyLoginPwdWithOldPwd:(NSString *)oldPwd freshPwd:(NSString *)freshPwd andValiCode:(NSString *)code block:(APIResponseBlock)block;
// 找回支付密码
+ (void)reqFindPayPwdWithSign:(NSString *)sign operation:(NSString *)op andFreshPayPwd:(NSString *)freshPayPwd block:(APIResponseBlock)block;
// 修改支付密码
+ (void)reqModifyPayPwdWithOldPwd:(NSString *)oldPwd freshPwd:(NSString *)freshPwd andValiCode:(NSString *)code block:(APIResponseBlock)block;
// 验证支付密码
+ (void)reqValiPayPwd:(NSString *)paypwd block:(APIResponseBlock)block;
// 验证找回支付密码的验证码
+ (void)reqValiPhoneCodeAtFindPayPwdWithSign:(NSString *)sign mobile:(NSString *)mobile code:(NSString *)code andOperation:(NSString *)op block:(APIResponseBlock)block;
// 找回支付密码初始化
+ (void)reqInitFindPayPwdBlock:(APIResponseBlock)block;
// 找回支付密码验证码下发
+ (void)reqVerifyCodeSendForFindPayPwdWithPhoneNo:(NSString *)phoneNo block:(APIResponseBlock)block;
// 找回支付密码的方式列表
+ (void)reqTypeListOfFindPayPwdWithSign:(NSString *)sign block:(APIResponseBlock)block;
// 找回支付密码时验证安全问题
+ (void)reqValiSecurityQuestionWithParams:(NSDictionary *)params block:(APIResponseBlock)block;
// 获取安全问题
+ (void)reqGetSecurityQuestionBlock:(APIResponseBlock)block;

// 注册设置安全问题
+ (void)reqSettingSecurityQuestionForRegisterWithParams:(NSDictionary *)params block:(APIResponseBlock)block;
// 修改安全问题
+ (void)reqModifySecurityQuestionWithParams:(NSDictionary *)params andModifyReqAPI:(NSString *)api block:(APIResponseBlock)block;
// 修改安全问题时验证安全问题
+ (void)reqValiSecurityQuestionForModifyWithParams:(NSDictionary *)params block:(APIResponseBlock)block;
// 收银台验证支付密码
+ (void)reqValiPayPwdAtCheckOutWithPwd:(NSString *)pwd block:(APIResponseBlock)block;
// 修改绑定手机验证码验证
+ (void)reqValiPhoneCodeAtModifyMobileWithParams:(NSDictionary *)params block:(APIResponseBlock)block;
// 重置绑定手机验证码下发
+ (void)reqVerifyCodeSendAtResetBindMobileWithParams:(NSDictionary *)params block:(APIResponseBlock)block;
// 修改绑定手机
+ (void)reqResetBindMobileWithParams:(NSDictionary *)params block:(APIResponseBlock)block;
@end

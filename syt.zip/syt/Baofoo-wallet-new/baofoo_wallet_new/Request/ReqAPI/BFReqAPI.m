//
//  BFReqAPI.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/31.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI.h"

@implementation BFReqAPI
+ (void)reqWithParams:(NSDictionary *)params andExURL:(NSString *)exURL block:(APIResponseBlock)block
{
    [[BFBaseReqManager shareManager] POST:exURL parameters:params success:^(NSURLSessionDataTask *task, id responseObject) {
        [BFReqHandle handleReqAPIResponse:task object:responseObject error:nil block:block];
        
        NSLog(@"responseObject = %@",responseObject);
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        [BFReqHandle handleReqAPIResponse:task object:nil error:error block:block];
    }];
}

+ (void)hsqreqWithParams:(NSDictionary *)params andExURL:(NSString *)exURL block:(APIResponseBlock)block
{
    [[BFBaseReqManager shareManagerForHSQ] POST:exURL parameters:params success:^(NSURLSessionDataTask *task, id responseObject) {
        [BFReqHandle handleReqAPIResponse:task object:responseObject error:nil block:block];
        
        NSLog(@"responseObject = %@",responseObject);
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        [BFReqHandle handleReqAPIResponse:task object:nil error:error block:block];
    }];
}


+ (NSString *)getEncryptStrWithUserName:(NSString *)userName andPassword:(NSString *)pwd
{
    NSString *MD5str = [BFMD5 md5:pwd];//The first MD5 encryption
    NSString *converted = [MD5str uppercaseString];//Converted to uppercase
    NSString *mosaicstr = [converted stringByAppendingString:@"www.baofoo.com"];
    NSString *Rmd5str = [BFMD5 md5:mosaicstr];//Second MD5 encryption
    NSDictionary *userIndo = [[NSDictionary alloc] initWithObjectsAndKeys:userName,@"account",Rmd5str,@"password", nil];
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:userIndo options:NSJSONWritingPrettyPrinted error:nil];
    NSString *encryption = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    NSString *e = [RSAEntryPtion stringWithRSAEncryPtion:[encryption base64EncodedString]];
    return e;
}

@end

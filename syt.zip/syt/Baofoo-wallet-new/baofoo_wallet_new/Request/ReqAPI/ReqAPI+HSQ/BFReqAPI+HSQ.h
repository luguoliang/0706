//
//  BFReqAPI+HSQ.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/4/6.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI.h"

@interface BFReqAPI (HSQ)
/*
 *慧生钱请求接口
 *1、慧生钱长列表数据model
 *2、慧生钱详情展示数据model
 *3、慧生钱首页展示数据model
 */
+ (void)getHSQListCellModelFromServerWithParameters:(NSDictionary *)params
                                             block:(APIResponseBlock)block;

+ (void)getHSQIDetailModelFromServerWithParameters:(NSDictionary *)params
                                           block:(APIResponseBlock)block;

+ (void)getHSQIHomeCellModelFromServerWithParameters:(NSDictionary *)params
                                           block:(APIResponseBlock)block;
// 下拉刷新
+ (void)reqUpdateDataForUpRefreshWithParams:(NSDictionary *)params
                                      block:(APIResponseBlock)block;
// 上拉刷新
+ (void)reqUpdateDataForDownRefreshWithParams:(NSDictionary *)params
                                      block:(APIResponseBlock)block;

@end

//
//  BFReqAPI+HSQ.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/4/6.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI+HSQ.h"

@implementation BFReqAPI (HSQ)
+(void)getHSQListCellModelFromServerWithParameters:(NSDictionary *)params block:(APIResponseBlock)block{
    NSMutableDictionary*paramdict = @{}.mutableCopy;
    //业务层参数
    NSString*urlStr = @"hsqurl";
    [[BFBaseReqManager shareManager] POST:urlStr parameters:paramdict success:^(NSURLSessionDataTask *task, id responseObject) {
        [BFReqHandle handleReqAPIResponse:task object:responseObject error:nil block:block];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [BFReqHandle handleReqAPIResponse:task object:nil error:error block:block];
    }];
}

// 上拉刷新
+ (void)reqUpdateDataForUpRefreshWithParams:(NSDictionary *)params
                                      block:(APIResponseBlock)block
{
    [[BFBaseReqManager shareManagerForHSQ] POST:api_showProductDownRefresh parameters:params success:^(NSURLSessionDataTask *task, id responseObject) {
        [BFReqHandle handleReqAPIResponse:task object:responseObject error:nil block:block];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [BFReqHandle handleReqAPIResponse:task object:nil error:error block:block];
    }];
}

// 下拉刷新
+ (void)reqUpdateDataForDownRefreshWithParams:(NSDictionary *)params
                                        block:(APIResponseBlock)block
{
    [[BFBaseReqManager shareManagerForHSQ] POST:api_showProductUpRefresh parameters:params success:^(NSURLSessionDataTask *task, id responseObject) {
        [BFReqHandle handleReqAPIResponse:task object:responseObject error:nil block:block];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [BFReqHandle handleReqAPIResponse:task object:nil error:error block:block];
    }];
}
@end

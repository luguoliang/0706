//
//  BFReqAPI+Checkout.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI.h"

@interface BFReqAPI (Checkout)
/*
 *收银台请求接口
 *1、收银台请求OrderNomber
 *2、询问是否能够打开收银台
 *2、收银台获取短信验证码
 *4、收银台支付
 *5、收银台添加银行卡
 *6、收银台验证支付密码
 */
+ (void)CashRegisterGetOrderNomberFromServerWithParameters:(NSDictionary *)params
                                                           block:(APIResponseBlock)block;
+ (void)AskingWhetherToOpenTheCashRegisterForServerWithParameters:(NSDictionary *)params
                                                                   block:(APIResponseBlock)block;
+ (void)CashRegisterVerGetMessageCodeFormServerWithParameters:(NSDictionary *)params
                                                            block:(APIResponseBlock)block;
+ (void)CashRegisterConfirmPaymentToServerWithParameters:(NSDictionary *)params
                                                        block:(APIResponseBlock)block;
+ (void)reqAtPreBuyProductWithParams:(NSDictionary *)params block:(APIResponseBlock)block;

+ (void)reqCloseCheckoutWithParams:(NSDictionary *)params block:(APIResponseBlock)block;

+(void)CashRegisterVerPasswordWith:(NSDictionary *)params block:(APIResponseBlock)block;//余额支付验证支付密码

+(void)CashRegisterConfirmPaymentWithPostOrgetData:(NSDictionary *)params block:(APIResponseBlock)block;//确认支付

+(void)CashRegisterCallBackServerPostOrgetData:(NSDictionary *)params block:(APIResponseBlock)block;
@end

//
//  BFReqAPI+Checkout.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI+Checkout.h"

@implementation BFReqAPI (Checkout)
+ (void)reqAtPreBuyProductWithParams:(NSDictionary *)params block:(APIResponseBlock)block{
    [BFReqAPI hsqreqWithParams:params andExURL:api_preBuyProduct block:^(id responseObj, NSError *error) {
        
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
+ (void)reqCloseCheckoutWithParams:(NSDictionary *)params block:(APIResponseBlock)block{
    [BFReqAPI hsqreqWithParams:params andExURL:api_cancelCreateOrder block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
+ (void)CashRegisterGetOrderNomberFromServerWithParameters:(NSDictionary *)params block:(APIResponseBlock)block{
    [BFReqAPI hsqreqWithParams:params andExURL:api_buyProductNewCheck block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
+(void)AskingWhetherToOpenTheCashRegisterForServerWithParameters:(NSDictionary *)params block:(APIResponseBlock)block{
    [BFReqAPI reqWithParams:params andExURL:cashPlatform_toPay block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
+(void)CashRegisterVerGetMessageCodeFormServerWithParameters:(NSDictionary *)params block:(APIResponseBlock)block{
    
    [BFReqAPI hsqreqWithParams:params andExURL:api_geimessageCode block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
    
    
}
+(void)CashRegisterConfirmPaymentToServerWithParameters:(NSDictionary *)params block:(APIResponseBlock)block{
    [BFReqAPI hsqreqWithParams:params andExURL:cashPlatform_checkPayPwd block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];

}

+(void)CashRegisterConfirmPaymentWithPostOrgetData:(NSDictionary *)params block:(APIResponseBlock)block{
    [BFReqAPI hsqreqWithParams:params andExURL:cashPlatform_pay block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

+(void)CashRegisterCallBackServerPostOrgetData:(NSDictionary *)params block:(APIResponseBlock)block{
    [BFReqAPI hsqreqWithParams:params andExURL:api_cancelCreateOrder block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
//base_url http://tad.my.baofoo.com/mandaojr/
@end

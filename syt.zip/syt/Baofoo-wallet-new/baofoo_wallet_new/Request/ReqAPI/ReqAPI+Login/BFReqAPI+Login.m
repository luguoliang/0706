//
//  BFReqAPI+Login.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI+Login.h"

@implementation BFReqAPI (Login)
+ (void)reqLoginAccountWithUserName:(NSString *)userName andPassword:(NSString *)pwd
                              block:(APIResponseBlock)block
{
    NSDictionary *postDict = @{@"v":@"2.0",@"sp":[self getEncryptStrWithUserName:userName andPassword:pwd]};
    //业务层参数
    [BFReqAPI reqWithParams:postDict andExURL:login_loginApp block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

+ (void)reqLoginByTokenBlock:(APIResponseBlock)block
{
    NSString *access_token = [[BFCoreDataModelop sharedManager] getCurrentBFuserModel].access_token;
    [[self class] reqLoginByToken:access_token block:^(id responseObj, NSError *error) {
        block(responseObj,error);
    }];
}

+ (void)reqLoginByToken:(NSString *)token block:(APIResponseBlock)block
{
    NSHTTPCookie *cookie;
    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (cookie in [storage cookies]) {
        [storage deleteCookie:cookie];
    }
    NSMutableDictionary *tokenProperties = [[NSMutableDictionary alloc] initWithCapacity:0];;
    [tokenProperties setValue:token forKey:NSHTTPCookieValue];
    [tokenProperties setValue:@"access_token" forKey:NSHTTPCookieName];
    [tokenProperties setValue:@".baofoo.com" forKey:NSHTTPCookieDomain];
    [tokenProperties setValue:[NSDate dateWithTimeIntervalSinceNow:60*60] forKey:NSHTTPCookieExpires];
    [tokenProperties setValue:@"/" forKey:NSHTTPCookiePath];
    
    NSHTTPCookie *cookie_PD1 = [NSHTTPCookie cookieWithProperties:tokenProperties];
    
    [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie_PD1];
    
    NSString *jsessionid = [[NSUserDefaults standardUserDefaults] objectForKey:@"JSESSIONID"];
    NSMutableDictionary *jsessionidProperties = [[NSMutableDictionary alloc] initWithCapacity:0];;
    [jsessionidProperties setValue:jsessionid.length>0?jsessionid:@"" forKey:NSHTTPCookieValue];
    [jsessionidProperties setValue:@"JSESSIONID" forKey:NSHTTPCookieName];
    [jsessionidProperties setValue:@"twallet.baofoo.com" forKey:NSHTTPCookieDomain];
    [jsessionidProperties setValue:[NSDate dateWithTimeIntervalSinceNow:60*60] forKey:NSHTTPCookieExpires];
    [jsessionidProperties setValue:@"/" forKey:NSHTTPCookiePath];
    
    NSHTTPCookie *cookie_PD2 = [NSHTTPCookie cookieWithProperties:jsessionidProperties];
    [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie_PD2];
    
    //业务层参数
    [BFReqAPI reqWithParams:@{} andExURL:login_doAuth block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}

+ (void)registNewUserWithTheInformationToTheServerWithParameters:(NSDictionary *)params
                                                           block:(APIResponseBlock)block{
    //业务层参数
    [BFReqAPI reqWithParams:params andExURL:register_checkVerificationCode block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
+ (void)getCodeForRegistWithPhoneNo:(NSString *)phoneNo block:(APIResponseBlock)block{
    //业务层参数
    [BFReqAPI reqWithParams:@{@"regMobile":phoneNo} andExURL:register_sendVerificationCode block:^(id responseObj, NSError *error) {
        [BFReqHandle handleReqSerResponse:responseObj error:error block:block];
    }];
}
@end

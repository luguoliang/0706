//
//  BFReqAPI+Login.h
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI.h"

@interface BFReqAPI (Login)
/**
 *  用户名登录
 *
 *  @param userName
 *  @param pwd
 *  @param block
 */
+ (void)reqLoginAccountWithUserName:(NSString *)userName andPassword:(NSString *)pwd
                              block:(APIResponseBlock)block;
/**
 *  手势和指纹所用的Token登录
 */
+ (void)reqLoginByTokenBlock:(APIResponseBlock)block;
/**
 *  切换账户所用的Token登录
 *
 *  @param token
 *  @param block
 */
+ (void)reqLoginByToken:(NSString *)token block:(APIResponseBlock)block;
/**
 *  新用户注册
 *
 *  @param params
 *  @param block
 */
+ (void)registNewUserWithTheInformationToTheServerWithParameters:(NSDictionary *)params
                                                           block:(APIResponseBlock)block;
/**
 *  新用户注册获取短信验证码
 *
 *  @param phoneNo
 *  @param block
 */
+ (void)getCodeForRegistWithPhoneNo:(NSString *)phoneNo block:(APIResponseBlock)block;
+ (void)RetrievePasswordToTheServerWithParameters:(NSDictionary *)params
                                            block:(APIResponseBlock)block;

@end
 
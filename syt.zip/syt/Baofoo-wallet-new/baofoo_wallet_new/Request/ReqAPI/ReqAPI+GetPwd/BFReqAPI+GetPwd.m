//
//  BFReqAPI+GetPwd.m
//  baofoo_wallet_new
//
//  Created by 路国良 on 16/6/2.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqAPI+GetPwd.h"

@implementation BFReqAPI (GetPwd)

@end

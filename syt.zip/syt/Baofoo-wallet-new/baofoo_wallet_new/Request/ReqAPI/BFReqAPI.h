//
//  BFReqAPI.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/31.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BFBaseReqManager.h"
#import "BFReqHandle.h"
#import "RSAEntryPtion.h"

@interface BFReqAPI : NSObject

// 具体业务的API只需要传入必须参数及请求扩展地址即可
+ (void)reqWithParams:(NSDictionary *)params andExURL:(NSString *)exURL block:(APIResponseBlock)block;

// 登录所用的将用户名和密码的加密方法
+ (NSString *)getEncryptStrWithUserName:(NSString *)userName andPassword:(NSString *)pwd ;

//临时条件慧生钱接口
+ (void)hsqreqWithParams:(NSDictionary *)params andExURL:(NSString *)exURL block:(APIResponseBlock)block;
@end

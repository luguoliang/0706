//
//  BFBaseReqManager.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFBaseReqManager.h"
#import "BFRequestURLConfigHeader.h"
#import "BFReqHandle.h"

@implementation BFBaseReqManager

+ (instancetype)shareManager{
    static BFBaseReqManager *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        instance = [[BFBaseReqManager alloc] initWithBaseURL:[NSURL URLWithString:[BFWalletBaseURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
    });
    return instance;
}
+ (instancetype)shareManagerForHSQ{
    static BFBaseReqManager *instanceForHSQ;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        instanceForHSQ = [[BFBaseReqManager alloc] initWithBaseURL:[NSURL URLWithString:[HSQBaseURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]];
    });
    return instanceForHSQ;
}

- (instancetype)initWithBaseURL:(NSURL *)url{
    if (self = [super initWithBaseURL:url]) {
        //HTTPS
        self.securityPolicy.allowInvalidCertificates = YES;
        self.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/json",@"text/javascript",@"text/plain",@"text/html",nil];
    }
    return self;
}

- (nullable NSURLSessionDataTask *)POST:(NSString *)URLString
                             parameters:(nullable id)parameters
                                success:(nullable void (^)(NSURLSessionDataTask *task, id responseObject))success
                                failure:(nullable void (^)(NSURLSessionDataTask *task, NSError *error))failure
{
    NSMutableDictionary *params = [BFReqHandle appendBaseParams:parameters];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES ;
    
    return [super POST:URLString parameters:params success:success failure:failure];
}

- (nullable NSURLSessionDataTask *)GET:(NSString *)URLString
                            parameters:(id)parameters
                               success:(void (^)(NSURLSessionDataTask *, id))success
                               failure:(void (^)(NSURLSessionDataTask *, NSError *))failure
{
    return [super GET:URLString parameters:parameters success:success failure:failure];
}

@end

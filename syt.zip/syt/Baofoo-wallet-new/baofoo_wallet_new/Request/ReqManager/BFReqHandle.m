//
//  BFReqHandle.m
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "BFReqHandle.h"
#import <AFNetworking/AFNetworking.h>

@implementation BFReqHandle

// 将字典转成字符串，中间以&分隔开
+ (NSString *)componentParams:(NSDictionary *)params{
    return [[self class] componentParams:params joinedByString:@"&"];
}

// 将字典转成字符串，中间以符号分隔开
+ (NSString *)componentParams:(NSDictionary *)params joinedByString:(NSString *)separator{
    if (!params) {
        return @"";
    }
    NSMutableArray *array = [NSMutableArray array];
    [params enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *obj, BOOL *stop) {
        
        NSString *str = [NSString stringWithFormat:@"%@=%@",key, obj];
        [array addObject:str];
    }];
    return [array componentsJoinedByString:separator];
}

#pragma mark - 公共参数
// 基本参数
+ (NSMutableDictionary *)baseCommonParams{
    NSMutableDictionary *commonParams = [NSMutableDictionary dictionary];
    /*此处添加公共参数*/
    NSString *deviceName = [BFDeviceTool deviceName];
    NSString *deviceType = [BFDeviceTool deviceType];
    NSString *uuid       = [BFDeviceTool uuid];//上真机时记得加上
    // 注意在必要的地方存储这一信息
    NSString *deviceToken = [[NSUserDefaults standardUserDefaults] objectForKey:@"NSNotification_DeviceToken"];
    commonParams[@"devid"] = [NSString stringWithFormat:@"%@,%@,%@,%@",deviceName,deviceType,uuid,deviceToken];
    commonParams[@"ver"] = [BFDeviceTool appVersion];
    commonParams[@"ts"] = [NSString stringWithFormat:@"%.f",[[NSDate date] timeIntervalSince1970]*1000];
    commonParams[@"terminal"] = @"ios";
    commonParams[@"osver"] = [BFDeviceTool systemVersion];
    commonParams[@"model"] = [BFDeviceTool deviceType];
    commonParams[@"term"] = [[UIDevice currentDevice] model];
    return commonParams;
}

// 请求接口参数附加公共参数
+ (NSMutableDictionary *)appendBaseParams:(NSDictionary *)params{
    NSMutableDictionary *newParams = [[self class] baseCommonParams];
    if (params) {
        for (NSString *key in [params allKeys]) {
            newParams[key] = params[key];
        }
    }
    return newParams;
}

#pragma mark - 返回结果处理

//API
+ (void)handleReqAPIResponse:(NSURLSessionDataTask *)opertation object:(id)obj error:(NSError *)error block:(APIResponseBlock)block{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    if (block) {
        if (error) {
            block(nil, error);
        }
        else {
            NSDictionary *dict = (NSDictionary *)obj;
            block(dict, nil);
        }
    }
}

//老平台 Service
+ (void)handleReqSerResponse:(id)responeObj error:(NSError *)error block:(APIResponseBlock)block{
    if (block) {
        if (error) {
            block(nil, error);
        }
        else {
            NSDictionary *dict = (NSDictionary *)responeObj;
            block(dict, nil);
        }
    }
}
@end

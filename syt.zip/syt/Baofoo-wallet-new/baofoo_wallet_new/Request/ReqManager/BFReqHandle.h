//
//  BFReqHandle.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BFReqResponse.h"

typedef void(^APIResponseBlock)(id responseObj, NSError *error);

@interface BFReqHandle : NSObject
#pragma mark - 公共参数
//参数
+ (NSMutableDictionary *)baseCommonParams;
+ (NSMutableDictionary *)appendBaseParams:(NSDictionary *)params;

#pragma mark - 返回结果处理
//API
+ (void)handleReqAPIResponse:(NSURLSessionDataTask *)opertation object:(id)obj error:(NSError *)error block:(APIResponseBlock)block;

+ (void)handleReqSerResponse:(id)responeObj error:(NSError *)error block:(APIResponseBlock)block;
@end

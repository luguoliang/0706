//
//  BFReqResponse.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/30.
//  Copyright © 2016年 BF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BFReqResponse : NSObject

@property (assign, nonatomic) BOOL reqStatus; //请求是否成功 YES成功 NO失败
@property (assign, nonatomic) BOOL reqNetError; //是否物理请求失败
@property (copy, nonatomic) NSString *reqCode; //请求Code
@property (copy, nonatomic) NSString *reqMsg; //描述信息

@property (strong, nonatomic) id reqData;
@property (copy, nonatomic) NSString *reqDataStr;
@property (strong, nonatomic) id reqResult; //Restful Result


+ (instancetype)newResponse;

@end

//
//  BFCommonHeader.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/31.
//  Copyright © 2016年 BF. All rights reserved.
//

#ifndef BFCommonHeader_h
#define BFCommonHeader_h

//工具类
#import "BFTool.h"
#import "NSDate+Addition.h"

//login
#import "BFLoginTool.h"

//DeviceTool
#import "BFDeviceTool.h"

//FileTool
#import "BFFileTool.h"
#import "BFFilePathTool.h"

//App TabBar
#import "BFTabBarConfigHeader.h"
#import "BFHomePageUIHeader.h"
#import "BFMessageConstHeader.h"
#import "BFBaseViewController.h"

//BFUIKit
#import "MBProgressHUD.h"
#import "BFUIKit.h"
#import "BFTool.h"
#import "BlockAlert.h"
#import "BFStringTool.h"
#import "UIView+BFUIKit.h"
#import "UILabel+BFUIKit.h"
#import "UIButton+BFUIKit.h"
#import "UIBarButtonItem+BFUIKit.h"
#import "UIImageView+BFUIKit.h"
#import "UITextView+BFUIKit.h"
#import "UITextField+BFUIKit.h"
#import "UITableView+BFUIKit.h"
#import "UIScrollView+BFUIKit.h"
#import "BaseMethodModel.h"
#import "BFTosat.h"
#import "UIAlertView+BFAlertView.h"
#import "BFJsonTool.h"
#import "CustomTimerButtom.h"
#import "NSMutableAttributedString+MutableString.h"
#import "NSString+DetailString.h"

//UserModel
#import "BFCoreUserModel.h"
#import "BFCoreDataModelop.h"
#define USER_D [NSUserDefaults standardUserDefaults]
//安全中心
#import "BFTouchIDTool.h"
#import "BFMD5.h"
#import "Base64.h"
#import "RSAEntryPtion.h"

/* UI 相关定义 */
#define PROMT_COLOR @"#b5b5b5"//提示字体颜色
#define BLACK_COLOR @"#000000"//黑色
#define BLUE_COLOR @"#2e8fd3"//蓝色
#define RED_COLOR @"#fa5151"//红色
#define GREEN_COLOR @"#95c927"//进度条绿色
#define GRAY_COLOR @"#e3e3e3"//进度条灰色
#define BACKGROUND_COLOR @"#efeff4"//背景颜色
#define LINE_COLOR @"#dcdcdc"//线条颜色
#define ORANGE_COLOR @"#ff722c"//橙色
#define BLANK_FONT_COLOR @"#a6a6a6"
#define telNumber @"021-68811008"

#define AUTO_LENGTH(a) (ScreenWidth/320)*a
//正常字体
#define FONT(a) [UIFont systemFontOfSize:a]
//细体
#define FONT_LIGHT(a) [UIFont fontWithName:@"Helvetica-Light" size:a]

/* Coding 相关定义 */
#define __weakself__ __weak __typeof(&*self)weakself = self;

/* Debug 相关定义 */
#ifdef DEBUG
#define DebugLog(...) NSLog(__VA_ARGS__)
#define DebugMethod() NSLog(@"%s", __func__)
#else
#define DebugLog(...)
#define DebugMethod()
#endif

/* Color 处理的相关定义 */
#define COLOR_HEXSTRING(hexString) [UIColor colorWithHexString:hexString]


//网络请求
#pragma mark--网络接口
//首页
#define home_init                                   @"v3_0_0/home/init.do"

//检查更新
#define app_update_version_ios                      @"app/update/version_ios.txt"

//登录
#define login_loginApp                              @"login/loginApp.do"//doLogin.do

//#define login_doLogin                               @"login/loginApp.do"

//令牌认证
#define login_doAuth                                @"login/loginAppT.do"

#define login_get_user_info                         @"login/getUserInfo.do"

//补全信息
#define complete_accountInfo                        @"complete/accountInfo.do"

//安全退出
#define  login_doLogout                             @"login/doLogout.do"

//注册发送短信验证码
#define register_sendVerificationCode               @"register/sendVerificationCode.do"

//验证验证码与手机号
#define register_checkVerificationCode              @"register/checkVerificationCode.do"

//获取安全问题
#define register_getSecQuestions                    @"register/getSecQuestions.do"

//注册设置安全问题
#define register_walletRegister                     @"register/walletRegister.do"

//修改登录密码发送验证码
#define console_sendMobileMsg                       @"console/sendMobileMsg.do"

//验证修改密码的验证码
#define console_sendCheckDynanic                    @"console/sendCheckDynanic.do"

//修改登录密码
#define console_confirmNewLoginPwd                  @"console/confirmNewLoginPwd.do"

//找回登录密码时图片验证码
#define console_indexVerifyCodeServlet              @"indexVerifyCodeServlet"

//找回登录密码时验证
#define console_findMyPassWord                      @"console/findMyPassWord.do"

//找回密码获取验证码
#define console_sendMobileMsg                       @"console/sendMobileMsg.do"

//验证找回密码的验证码
#define console_sendCheckDynanic                    @"console/sendCheckDynanic.do"

//找回登录密码时验证安全问题
#define consle_veryfyAnswer                         @"console/veryfyAnswer.do"

//找回密码时设置登录密码
#define consle_confirmNewLoginPwd                   @"console/confirmNewLoginPwd.do"

//验证修改绑定手机验证码
#define security_checkMobileAction                  @"security/checkMobileAction.do"

//安全中心确认修改登录密码
#define security_modifyPwdAction                    @"security/modifyPwdAction.do"

//验证登录密码
#define security_checkPwdAction                     @"security/checkPwdAction.do"

//设置安全问题
#define security_setSafeQuestion                    @"security/setSafeQuestion.do"

//修改安全问题
#define security_changeSafeQuestion                 @"security/changeSafeQuestion.do"

#define security_checkPayPwd                        @"security/checkPayPwd.do"

//重置安全问题
#define security_resetSafeQuestion                  @"security/resetSafeQuestion.do"

//初级实名认证
#define security_verifyLowerAuthen                  @"security/verifyLowerAuthen.do"

//修改绑定手机短信验证
#define security_changeMobileSvc                    @"security/changeMobileSvc.do"

// 下发短信验证码，用于多处，希望后端能够统一接口
#define login_sendMobileHttpServer                  @"login/sendMobileHttpServer.do"

//绑定手机号
#define security_bindMobile                         @"security/bindMobile.do"

//修改绑定手机号
#define security_bindMobileAction                   @"security/bindMobileAction.do"

//验证支付密码
#define cashPlatform_checkPayPwd                    @"cashPlatform/checkPayPassword.do"

//验证银行卡
#define card_identifyCard                           @"card/identifySpecifyCard.do"

//获取支持银行卡列表
#define account_getBankList                         @"account/getSpecifyBankList.do"

//收款
#define payment_collect                             @"payment/collect.do"

//上传头像
#define account_uploadHeadImage                     @"account/uploadHeadImage.do"

//下拉刷新红包列表
#define voucher_queryMyVoucherGenStorages           @"voucher/queryMyVoucherGenStorages.do"

//实名认证提交照片审核
#define security_verifyHighAuthen                   @"security/verifyHighAuthen.do"

/*********************** 我的账户 begin*********************/

//我的账户银行卡列表
#define myAccount_bankList                          @"www/2.1.7/wallet/yhk.html"
//我的账户充值
#define myAccount_Recharge                          @"www/2.1.7/wallet/cz.html"
//我的账户提现
#define myAccount_Withdraw                          @"www/2.1.7/wallet/tx.html"
//账单
#define myAccount_InExpenditure                     @"www/2.1.7/wallet/sz.html"

#define myAccount_Vouchers                          @"voucher/queryMyVoucherGenStorages.do"

#define activity_activitycenter                     @"activity/activitycenter.do"
//忘记登陆密码
#define forget_loginPassword                        @"www/2.1.7/wallet/wjdl.html"

/*********************** 我的账户  end*********************/

/*********************** 找回支付密码 begin*********************/
//找回支付密码初始化
#define findPayPwd_init                             @"findPayPwd/init.do"

//发送短信验证码
#define findPayPwd_findPayPwdndMobileVerCode        @"findPayPwd/sendMobileVerCode.do"

//方式列表
#define findPayPwd_findPayPwdpeList                 @"findPayPwd/typeList.do"

//验证短信验证码
#define findPayPwd_findPayPwdValiMobile              @"findPayPwd/valiMobile.do"

//验证银行卡号(RSA加密)
#define findPayPwd_findPayPwdaliSafeCard            @"findPayPwd/valiSafeCard.do"

//验证身份证(RSA加密)
#define findPayPwd_findPayPwdalidIdcard             @"findPayPwd/valiIdCard.do"

//验证安全问题(RSA加密)
#define findPayPwd_findPayPwdalidSafeAnsw           @"findPayPwd/valiSafeQues.do"

//设置支付密码(RSA加密)
#define findPayPwd_findPayPwdtPwd                   @"findPayPwd/setPwd.do"

/*
 备注说明:
 code:返回状态码 // 1:成功|-1:失败
 next:下个页面的跳转信息
 sign:作为输入时,取值为上一个流程的输出
 */
/*********************** 找回支付密码 end*********************/



//找回支付密码验证问题
#define security_veryAnswer                         @"security/veryAnswer.do"

//修改支付密码
#define security_resetPayPwd                        @"security/resetPayPwd.do"

/**
 *
 功能:发送短信验证码 用于确认支付 绑定安全卡的环节
 输入:
 memberId:会员ID (session中获取)
 bankAccount:银行卡号
 amount:金额(银行卡使用金额)
 cardId:银行卡ID
 mobile:手机号
 orderNo:交易号
 businessType:业务类型
 payId:银行ID
 name:银行名称
	
 输出:
 code:返回状态码 // 1:成功|-1:失败
 message:返回信息
 tradeNo:充值交易号 //用于充值平台
 businessNo: 充值业务号 //用于充值平台
 */
#define cashPlatform_sendVerficateCode              @"cashPlatform/sendVerficateCode.do"

/**
 *
 功能:收银台确认支付
 输入:
 memberId:会员ID
 orderNo:交易号
 payPassword:支付密码
 businessType:业务类型
 tradeNo:充值交易号 //用于充值平台
 businessNo: 充值业务号 //用于充值平台
 confirmPayList: 支付方式列表
 [cardId,payId,type,name,amount,desc] [卡ID,支付ID,支付类别,支付名称,金额]
	
 输出:
 code:返回状态码 // 1:成功|-1:失败
 message:返回信息
	
 说明:
 payType含义
 1:账户余额
 2:红包列表
 3:银行卡
 301:安全卡
 302:快捷卡
 303:信用卡
 cardId含义
 a.账户余额时为会员ID
 b.红包支付时为红包编号
 c.银行卡(安全卡,快捷卡,信用卡)为卡的id
 businessType含义
 10001:钱包充值
 20001:PC充值
 10002:钱包提现
 20002:PC提现
 10003:钱包转账
 20003:PC转账
 10004:慧生钱定期
 10005:慧生钱活期
	
 注:调用时使用RSA加密
 */
#define cashPlatform_confirmPay                 @"cashPlatform/confirmPay.do"

//请求打开收银台
#define cashPlatform_toPay                      @"cashPlatform/toPay.do"
//关闭收银台 参数 订单号
#define api_cancelCreateOrder                   @"api/cancelCreateOrder.do"

//请求短信验证码
#define api_geimessageCode                      @"cashPlatform/sendVerficateCode.do"

//验证支付密码
#define cashPlatform_checkPayPwd                 @"cashPlatform/checkPayPassword.do"


//确认支付
#define cashPlatform_pay                         @"cashPlatform/confirmPay.do"

//关闭收银台 参数 订单号
#define api_cancelCreateOrder                   @"api/cancelCreateOrder.do"
/**
 *  首页产品展示
 参数：
 createTime 产品创建时间(不是必输)
 productId	产品ID(不是必输)
 */
#define api_showAllProduct                          @"api/showAllProduct.do"

/**
 *  查看商品详情 首页点击
 参数：
 productId	产品ID(必输)
 */
#define api_viewProduct                             @"api/viewProduct.do"

/**
 *  查看商品详情 我的理财页面点击
 参数：
 productId	产品ID(必输)
 */
#define api_viewMyOrderProduct                      @"api/viewMyOrderProduct.do"

/**
 *  查看产品详情-更多 直接跳转到html页面
 参数：
 productId	产品ID(必输)
 showType	展示类型（必输） 1、项目介绍 2、资产安全 3、建议配比
 */
#define api_viewProductInfo                         @"api/viewProductInfo.do"

/**
 *  预购买产品页面
 参数：
 productId	产品ID(必输)
 */
#define api_preBuyProduct                           @"api/preBuyProduct.do"

/**
 *  购买产品
 购买产品
	接口：http://localhost:8080/api/buyProduct.do
	参数：
 sp = (random_key + money + payPass + productId)
 v = 1.0
 */
#define api_buyProduct                              @"api/buyProduct.do?v=1.0&sp=%@"

/**
 *  我的理财产品
 参数：
 */
#define api_myProduct                               @"api/myProduct.do"

//理财产品明细
#define api_queryOrderDetails                       @"api/queryOrderDetails.do"

/**
 *  显示首页广告图片
 参数：
 */
#define api_showAllBanner                           @"api/showAllBanner.do"

/**
 *  首页产品顶部刷新
 参数：
 endTime (不是必输)
 */
#define api_showProductUpRefresh                    @"api/showProductUpRefresh.do"

/**
 *  首页产品底部刷新
 参数：
 */
#define api_showProductDownRefresh                  @"api/showProductDownRefresh.do"

/**
 *  预计收益
 参数：
 buyMoney (必输)
 productId （必输）
 */
#define api_estimatedTotalRevenue                   @"api/estimatedTotalRevenue.do"

//打开收银台
#define api_buyProductNewCheck                      @"api/buyProductNewCheck.do"

/*
 http://twallet.baofoo.com/
 */


//云测
//#define WEB_HOST [USER_D boolForKey:@"isCeshi"]==NO?@"https://wallet.baofoo.com/":@"http://dwallet.baofoo.com:8089/"

//#define WEB_HOST @"https://wallet.baofoo.com/"

//充值
#define getMonery                                   @"www/2.1.7/wallet/cz.html"
//提现
#define TX_MONEY                                    @"www/2.1.7/wallet/tx.html"
//银行卡
#define web_yhk                                     @"www/2.1.7/wallet/yhk.html"

//账单
#define wallet_zd                                   @"www/2.1.7/wallet/zd.html"
//忘记登录密码
#define wallet_wjdl                                 @"www/2.1.7/wallet/wjdl.html"
//手指明细
#define wallet_sz                                   @"www/2.1.7/wallet/sz.html"
//红包充值
#define wallet_hb                                   @"www/2.1.7/wallet/hb.html"
//合伙人规则页面判断
#define partner_judgePartnerWhetherExist            @"partner/judgePartnerWhetherExist.do"

//合伙人收益
#define partner_partner                             @"partner/partner.html"

//我的合伙人
#define partner_mypartner                           @"partner/mypartner.html"

//合伙人规则
#define partner_rule                                @"partner/rule.html"

//邀请好友
//#define activity_inviteFriend   [USER_D boolForKey:@"isCeshi"]==NO?@"activity/inviteFriend.do":@"activity/inviteFriend.do?scene=test"

#define activity_activitycenter                     @"activity/activitycenter.do"

//获取是否有未读的通知
#define app_push_queryMyWaitHandlePushs             @"app/push/queryMyWaitHandlePushs.do"

//消息中心列表
#define app_push_index                              @"app/push/index.html"

//宝付自助服务协议
#define AGREEMENT_HELPSELF                          @"agreement_helpself.html"

//慧生钱服务协议
#define AGREEMENT_HSQ                               @"agreement_hsq.html"

//宝付关联服务开通协议
#define AGREENTMENT_OPEN                            @"agreement_open.html"

//宝付用户协议
#define agreen_quickpay                             @"agreement_quickpay.html"
//合伙人总收益
#define  partner_queryPartnerTotalRevenue           @"partner/queryPartnerTotalRevenue.do"


//天天精选主页
//已登录
#define  fund_main                                  @"app/fund/main.html"
//未登录
#define  fund_index                                 @"app/fund/index.html"

//协议列表
#define  protocol_queryProtocolList                 @"protocol/queryProtocolList.do"

//购买之前看的协议详情
#define  protocol_showProtocolTemplate              @"protocol/showProtocolTemplate.do"

//购买之后看的协议详情
#define  protocol_showProtocolNew                   @"protocol/showProtocolNew.do"

#define  app_hsq_hsqdetail                          @"app/hsq/hsqdetail.html"


#define ERROR_CODE [[responseObj objectForKey:@"code"] intValue]

#endif /* BFCommonHeader_h */

//
//  BFHomePageUIHeader.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/7.
//  Copyright © 2016年 BF. All rights reserved.
//

#ifndef BFHomePageUIHeader_h
#define BFHomePageUIHeader_h

// 
#define DefaultImage [UIImage imageNamed:@"icon_default_image"]

#endif /* BFHomePageUIHeader_h */

//
//  BFMessageConstHeader.h
//  baofoo_wallet_new
//
//  Created by zhouwufeng on 16/4/11.
//  Copyright © 2016年 BF. All rights reserved.
//

#ifndef BFMessageConstHeader_h
#define BFMessageConstHeader_h

#define App_Status_Downloading  @"该应用下载中"
#define App_Status_Maintain  @"该应用维护中"
#define App_Status_WWAN  @"目前处于移动网络，应用下载和更新会产生数据流量，是否要进行下载？"

//被挤掉提示语
#define CROWD_OUT_MESSAGE [NSString stringWithFormat:@"您的账户已在别处登录。如非本人操作，请致电慧生钱客服：%@",@"021-68811008"]

#endif /* BFMessageConstHeader_h */

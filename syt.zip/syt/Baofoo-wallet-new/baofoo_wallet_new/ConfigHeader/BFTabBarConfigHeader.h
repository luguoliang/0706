//
//  BFTabBarConfigHeader.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/4/5.
//  Copyright © 2016年 BF. All rights reserved.
//

#ifndef BFTabBarConfigHeader_h
#define BFTabBarConfigHeader_h

// TabBar Title
#define BFtabBarTitle_0   @"首页"
#define BFtabBarTitle_1   @"惠生钱"
#define BFtabBarTitle_2   @"账户"

// TabBar Images
#define BFtabBarImage_0   @"hsq_home_default"
#define BFtabBarImage_1   @"hsq_hsq_default"
#define BFtabBarImage_2   @"hsq_account_default"

// TabBar Images_selected
#define BFtabBarImage_selected_0   @"hsq_home_click_0"
#define BFtabBarImage_selected_1   @"hsq_hsq_click_0"
#define BFtabBarImage_selected_2   @"hsq_account_click_0"

// NavigationController Setting
#define BFnavigationBackgroundImage @""

// TabBarItem Color
#define TAB_BAR_COLOR_Selected [UIColor blackColor]
#define TAB_BAR_COLOR_Normal COLOR_HEXSTRING(@"#999999")
// TabBarItem Font
#define TAB_BAR_FONT_Selected [UIFont fontWithName:@"HelveticaNeue-Bold" size:12.0F]
#define TAB_BAR_FONT_Normal [UIFont systemFontOfSize:12.0F]







#endif /* BFTabBarConfigHeader_h */

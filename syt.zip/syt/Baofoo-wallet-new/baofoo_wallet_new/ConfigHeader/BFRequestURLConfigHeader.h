//
//  BFRequestURLConfigHeader.h
//  baofoo_wallet_new
//
//  Created by zhoujun on 16/3/29.
//  Copyright © 2016年 BF. All rights reserved.
//

#ifndef BFRequestURLConfigHeader_h
#define BFRequestURLConfigHeader_h

/**
 *  0.生产环境
 *
 *  1.准生产环境
 *
 *  2.测试环境
 */
#define BFServerEnvironment (2)

//生产环境
#if (BFServerEnvironment == (0))
#define BFAppItemsInfoURLFromServer @""
#define BFWalletBaseURL @"https://wallet.baofoo.com/"
#define HSQBaseURL @"https://tmandaojr.baofoo.com/mandaojr/"

//准生产环境
#elif (BFServerEnvironment == (1))
#define BFAppItemsInfoURLFromServer @""
#define BFWalletBaseURL @""
#define HSQBaseURL @""
//测试环境
#elif (BFServerEnvironment == (2))
#define BFAppItemsInfoURLFromServer @""
#define BFWalletBaseURL @"http://twallet.baofoo.com/"
#define HSQBaseURL @"http://tad.my.baofoo.com/mandaojr/"
#endif
//@"http://tad.my.baofoo.com/mandaojr/"

#endif /* BFRequestURLConfigHeader_h */
